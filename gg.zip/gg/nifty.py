import time
import math
import logging
import csv
import os
import sys
import argparse
from datetime import datetime
import numpy as np
from fyers_apiv3 import fyersModel

# ---------- Configuration ----------
CLIENT_ID = "J0ENYFX9ME-200"
ACCESS_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOlsiZDoxIiwiZDoyIiwieDowIiwieDoxIiwieDoyIl0sImF0X2hhc2giOiJnQUFBQUFCcU4zUTBGSE9abE9nbDB4ejBmckI1NS10Szl5VjhrSWc4TG96aG93X01tVE5vTVRjNXdYR2Q4bVRWSmd1RGVtb1FWMm03ZHJOcnI5WUx3NUlVM1NQNG5pVFkzT25uNjRBenVOUGRNcHhyWTdFRWpkST0iLCJkaXNwbGF5X25hbWUiOiIiLCJvbXMiOiJLMSIsImhzbV9rZXkiOiIwNWQyNjAxMzM1MGQ3MmJhN2RjOWZhOTMzNTQ1MGIzNzExMjE0YzE0ZGNkZTFmODU3NjMzM2ZjYiIsImlzRGRwaUVuYWJsZWQiOiJOIiwiaXNNdGZFbmFibGVkIjoiTiIsImZ5X2lkIjoiRkFBMzE0OTUiLCJhcHBUeXBlIjoyMDAsImV4cCI6MTc4MjA4ODIwMCwiaWF0IjoxNzgyMDE5MTI0LCJpc3MiOiJhcGkuZnllcnMuaW4iLCJuYmYiOjE3ODIwMTkxMjQsInN1YiI6ImFjY2Vzc190b2tlbiJ9.Bl_aVdqkqtPrRtY-ueAtszc5lea1kJauVq0U5rYEUr8"
SYMBOL = "NSE:NIFTY50-INDEX"
STRIKE_COUNT = 2
GREEKS = "1"
ENTRY_THRESHOLD = 0.3
QUANTITY = 3
LOT_SIZE = 65          # Note: NIFTY lot size is 50; this is your custom setting
TIMEOUT = 60           # Fetch every 60 seconds, aligned to the clock (HH:MM:00)
CSV_FILENAME = "paper_trading_log.csv"

# --- Exit Logic: Percentage retracement from extreme ---
EXIT_PERCENT = 0.5      # Exit when d_norm retraces 50% from its peak (long) or trough (short)

# ---------- Logging Setup ----------
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# ---------- Helper for IST Time ----------
def get_ist_time(timestamp=None):
    """Return current/local time as IST formatted string (assuming system time is IST)."""
    if timestamp is None:
        dt = datetime.now()
    else:
        dt = datetime.fromtimestamp(timestamp)
    return dt.strftime('%Y-%m-%d %H:%M:%S IST')

# ---------- Fyers Initialisation ----------
fyers = fyersModel.FyersModel(client_id=CLIENT_ID, token=ACCESS_TOKEN, is_async=False, log_path="")


class PaperTrader:
    def __init__(self, initial_cash=100000):
        self.cash = initial_cash
        self.position = None
        self.realized_pnl = 0
        self.trade_log = []
        self.current_d_norm = 0
        self.underlying_price = 0
        self.atm_strike = None
        self.atm_ce = None
        self.atm_pe = None
        # Prepare CSV header if file doesn't exist
        self.csv_headers = [
            'timestamp', 'underlying_price', 'd_norm', 'atm_strike',
            'ce_ltp', 'pe_ltp', 'ce_delta', 'pe_delta',
            'ce_volume', 'pe_volume', 'ce_oi', 'pe_oi',
            'ce_iv', 'pe_iv',
            'position_type', 'entry_price', 'current_price',
            'unrealized_pnl', 'extreme',
            'cash', 'realized_pnl', 'total_equity',
            'event_type', 'entry_time', 'exit_price', 'trade_pnl',
            'exit_reason'
        ]
        if not os.path.exists(CSV_FILENAME):
            with open(CSV_FILENAME, 'w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=self.csv_headers)
                writer.writeheader()
        self.csv_file = open(CSV_FILENAME, 'a', newline='')
        self.csv_writer = csv.DictWriter(self.csv_file, fieldnames=self.csv_headers)

    def __del__(self):
        if hasattr(self, 'csv_file'):
            self.csv_file.close()

    def fetch_option_chain(self):
        """Fetch chain and extract ATM CE/PE. Log detailed components."""
        logger.debug("Fetching option chain...")
        data = {
            "symbol": SYMBOL,
            "strikecount": STRIKE_COUNT,
            "timestamp": "",
            "greeks": GREEKS
        }
        response = fyers.optionchain(data=data)
        if response.get('s') != 'ok':
            logger.error(f"API error: {response}")
            return None

        chain = response['data']['optionsChain']
        underlying = chain[0]
        self.underlying_price = underlying['ltp']
        logger.info(f"📈 Underlying LTP: {self.underlying_price:.2f}")

        option_contracts = chain[1:]
        # Find ATM strike
        atm_strike = None
        min_diff = float('inf')
        for contract in option_contracts:
            strike = contract['strike_price']
            if strike == -1:
                continue
            diff = abs(strike - self.underlying_price)
            if diff < min_diff:
                min_diff = diff
                atm_strike = strike
        self.atm_strike = atm_strike
        logger.info(f"🎯 ATM Strike: {atm_strike}")

        # Get CE and PE for that strike
        atm_ce = None
        atm_pe = None
        for contract in option_contracts:
            if contract['strike_price'] == atm_strike:
                if contract['option_type'] == 'CE':
                    atm_ce = contract
                elif contract['option_type'] == 'PE':
                    atm_pe = contract
        if atm_ce is None or atm_pe is None:
            logger.warning("ATM CE or PE not found")
            return None

        self.atm_ce = atm_ce
        self.atm_pe = atm_pe

        # --- Detailed logging of ATM CE ---
        ce_delta = atm_ce['greeks']['delta']
        ce_ltp = atm_ce['ltp']
        ce_volume = atm_ce['volume']
        ce = ce_delta * ce_ltp * ce_volume
        logger.info(f"📊 CE (strike {atm_strike}): delta={ce_delta:.4f}, ltp={ce_ltp:.2f}, volume={ce_volume:,} → ce = {ce:.2f}")

        # --- Detailed logging of ATM PE (using abs delta) ---
        pe_delta = abs(atm_pe['greeks']['delta'])
        pe_ltp = atm_pe['ltp']
        pe_volume = atm_pe['volume']
        pe = pe_delta * pe_ltp * pe_volume
        logger.info(f"📊 PE (strike {atm_strike}): |delta|={pe_delta:.4f}, ltp={pe_ltp:.2f}, volume={pe_volume:,} → pe = {pe:.2f}")

        # Compute d_norm
        denominator = ce + pe
        if denominator != 0:
            d_norm = (ce - pe) / denominator
        else:
            d_norm = 0
        self.current_d_norm = d_norm
        logger.info(f"🔢 d_norm = ({ce:.2f} - {pe:.2f}) / {denominator:.2f} = {d_norm:.4f}")

        return {
            'strike': atm_strike,
            'ce': atm_ce,
            'pe': atm_pe,
            'd_norm': d_norm,
            'underlying': underlying
        }

    def enter_position(self, option_type, contract, price):
        """Enter a long position (buy CE or PE)."""
        if self.position is not None:
            logger.warning("Already in a position, cannot enter.")
            return

        entry_price = contract['ltp']
        quantity = QUANTITY * LOT_SIZE
        cost = entry_price * quantity

        # 🛡️ Cash sufficiency check
        if cost > self.cash:
            logger.warning(f"Insufficient cash! Need {cost:.2f}, have {self.cash:.2f}. Skipping entry.")
            return

        self.position = {
            'type': option_type,
            'entry_price': entry_price,
            'entry_time': datetime.now(),
            'strike': contract['strike_price'],
            'quantity': quantity,
            'extreme': self.current_d_norm,   # initialise with entry d_norm
            'contract': contract
        }
        self.cash -= cost
        logger.info(f"✅ ENTER {option_type} (Strike: {contract['strike_price']}) @ {entry_price:.2f} x {quantity} = {cost:.2f} | d_norm={self.current_d_norm:.3f} (IST: {get_ist_time()})")
        self._log_row(event_type='entry')

    def exit_position(self, exit_price, reason=None):
        """Close the current position and log the trade result."""
        if self.position is None:
            return

        # Calculate P&L
        pnl = (exit_price - self.position['entry_price']) * self.position['quantity']
        self.cash += exit_price * self.position['quantity']
        self.realized_pnl += pnl

        # --- LOUD AND CLEAR TRADE RESULT ---
        logger.info("=" * 70)
        logger.info(f"🔹 TRADE CLOSED 🔹  (IST: {get_ist_time()})")
        logger.info(f"   Type     : {self.position['type']} (Strike: {self.position['strike']})")
        logger.info(f"   Entry    : {self.position['entry_price']:.2f}")
        logger.info(f"   Exit     : {exit_price:.2f}")
        logger.info(f"   Quantity : {self.position['quantity']}")
        logger.info(f"   ▶ P&L    : {pnl:+.2f}  <-- THIS TRADE")
        logger.info(f"   Total Realized P&L: {self.realized_pnl:.2f}")
        if reason:
            logger.info(f"   Exit reason: {reason}")
        logger.info("=" * 70)

        # Store in trade log
        trade_info = {
            'type': self.position['type'],
            'strike': self.position['strike'],
            'entry_price': self.position['entry_price'],
            'entry_time': self.position['entry_time'],
            'exit_price': exit_price,
            'exit_time': datetime.now(),
            'pnl': pnl,
            'reason': reason
        }
        self.trade_log.append(trade_info)

        # Log to CSV (exit row)
        self._log_row(event_type='exit', exit_price=exit_price, trade_pnl=pnl, exit_reason=reason)

        # Clear position
        self.position = None

    def update_position(self, current_data):
        """Check entry/exit conditions. No warmup – trading starts immediately."""
        if self.position is None:
            # Entry logic
            if self.current_d_norm > ENTRY_THRESHOLD:
                self.enter_position('CE', current_data['ce'], current_data['ce']['ltp'])
            elif self.current_d_norm < -ENTRY_THRESHOLD:
                self.enter_position('PE', current_data['pe'], current_data['pe']['ltp'])
        else:
            # Update extreme based on position type
            pos_type = self.position['type']
            if pos_type == 'CE':
                # Track new peak
                if self.current_d_norm > self.position['extreme']:
                    self.position['extreme'] = self.current_d_norm
                    logger.debug(f"CE: New peak = {self.current_d_norm:.3f}")
                # Exit if current d_norm falls below 50% of the peak
                exit_threshold = self.position['extreme'] * EXIT_PERCENT
                if self.current_d_norm < exit_threshold:
                    reason = (f"CE exit: d_norm fell from peak {self.position['extreme']:.3f} "
                              f"to {self.current_d_norm:.3f} (below {EXIT_PERCENT*100:.0f}% threshold {exit_threshold:.3f})")
                    self.exit_position(self.position['contract']['ltp'], reason)
            else:  # PE
                # Track new trough (most negative)
                if self.current_d_norm < self.position['extreme']:
                    self.position['extreme'] = self.current_d_norm
                    logger.debug(f"PE: New bottom = {self.current_d_norm:.3f}")
                # Exit if current d_norm rises above 50% of the trough
                exit_threshold = self.position['extreme'] * EXIT_PERCENT  # extreme is negative, threshold less negative
                if self.current_d_norm > exit_threshold:
                    reason = (f"PE exit: d_norm rose from bottom {self.position['extreme']:.3f} "
                              f"to {self.current_d_norm:.3f} (above {EXIT_PERCENT*100:.0f}% threshold {exit_threshold:.3f})")
                    self.exit_position(self.position['contract']['ltp'], reason)

        # Log the current state (update)
        self._log_row(event_type='update')

    def _log_row(self, event_type='update', exit_price=None, trade_pnl=None, exit_reason=None):
        """Append a row to the CSV with current state."""
        row = {
            'timestamp': datetime.now().isoformat(),
            'underlying_price': self.underlying_price,
            'd_norm': self.current_d_norm,
            'atm_strike': self.atm_strike if self.atm_strike else -1,
            'ce_ltp': self.atm_ce['ltp'] if self.atm_ce else 0,
            'pe_ltp': self.atm_pe['ltp'] if self.atm_pe else 0,
            'ce_delta': self.atm_ce['greeks']['delta'] if self.atm_ce and 'greeks' in self.atm_ce else 0,
            'pe_delta': self.atm_pe['greeks']['delta'] if self.atm_pe and 'greeks' in self.atm_pe else 0,
            'ce_volume': self.atm_ce['volume'] if self.atm_ce else 0,
            'pe_volume': self.atm_pe['volume'] if self.atm_pe else 0,
            'ce_oi': self.atm_ce['oi'] if self.atm_ce else 0,
            'pe_oi': self.atm_pe['oi'] if self.atm_pe else 0,
            'ce_iv': self.atm_ce['greeks']['iv'] if self.atm_ce and 'greeks' in self.atm_ce else 0,
            'pe_iv': self.atm_pe['greeks']['iv'] if self.atm_pe and 'greeks' in self.atm_pe else 0,
            'position_type': self.position['type'] if self.position else 'NONE',
            'entry_price': self.position['entry_price'] if self.position else 0,
            'current_price': self.position['contract']['ltp'] if self.position else 0,
            'unrealized_pnl': (self.position['contract']['ltp'] - self.position['entry_price']) * self.position['quantity'] if self.position else 0,
            'extreme': self.position['extreme'] if self.position else 0,
            'cash': self.cash,
            'realized_pnl': self.realized_pnl,
            'total_equity': self.cash + self.realized_pnl + (self.position['contract']['ltp'] - self.position['entry_price']) * self.position['quantity'] if self.position else self.cash + self.realized_pnl,
            'event_type': event_type,
            'entry_time': self.position['entry_time'].isoformat() if self.position else '',
            'exit_price': exit_price if exit_price is not None else 0,
            'trade_pnl': trade_pnl if trade_pnl is not None else 0,
            'exit_reason': exit_reason if exit_reason else ''
        }
        self.csv_writer.writerow(row)
        self.csv_file.flush()
        logger.debug(f"CSV row logged: {event_type}")

    def get_status(self):
        """Print current status to console with IST timestamp."""
        logger.info(f"📊 STATUS UPDATE @ {get_ist_time()}")
        logger.info(f"   Underlying: {self.underlying_price:.2f}, d_norm: {self.current_d_norm:.3f}")
        if self.position:
            unrealized = (self.position['contract']['ltp'] - self.position['entry_price']) * self.position['quantity']
            logger.info(f"   Position: {self.position['type']} strike {self.position['strike']}, entry {self.position['entry_price']:.2f}, current {self.position['contract']['ltp']:.2f}, unrealized P&L: {unrealized:.2f}")
            # Show current exit threshold
            if self.position['type'] == 'CE':
                threshold = self.position['extreme'] * EXIT_PERCENT
                logger.info(f"   Exit threshold (50% of peak {self.position['extreme']:.3f}): {threshold:.3f}")
            else:
                threshold = self.position['extreme'] * EXIT_PERCENT
                logger.info(f"   Exit threshold (50% of bottom {self.position['extreme']:.3f}): {threshold:.3f}")
        else:
            logger.info("   No open position")
        logger.info(f"   Cash: {self.cash:.2f}, Realized P&L: {self.realized_pnl:.2f}, Total Equity: {self.cash + self.realized_pnl:.2f}")


# ---------- Analysis Functions ----------
def analyze_trading_log(csv_path):
    """Read CSV, compute stats, and optionally plot."""
    try:
        import pandas as pd
        have_pandas = True
    except ImportError:
        have_pandas = False
        print("WARNING: pandas not installed. Limited analysis available.")
        return

    if not os.path.exists(csv_path):
        print(f"CSV file {csv_path} not found. Nothing to analyze.")
        return

    df = pd.read_csv(csv_path)
    df['timestamp'] = pd.to_datetime(df['timestamp'])
    df.sort_values('timestamp', inplace=True)

    # Extract exits (completed trades)
    exits = df[df['event_type'] == 'exit'].copy()
    num_trades = len(exits)

    if num_trades > 0:
        # 📋 Print detailed trade list
        print("\n" + "=" * 80)
        print("📋 DETAILED TRADE LOG (Per-Trade P&L)")
        print("=" * 80)

        # Prepare display columns
        if 'entry_time' in exits.columns:
            exits['entry_time_dt'] = pd.to_datetime(exits['entry_time'])
        display_cols = ['timestamp', 'position_type', 'entry_price', 'exit_price', 'trade_pnl', 'exit_reason']
        if 'exit_reason' not in exits.columns:
            exits['exit_reason'] = ''
        display_df = exits[display_cols].copy()
        display_df.columns = ['Exit Time (IST)', 'Type', 'Entry Price', 'Exit Price', 'Trade P&L', 'Exit Reason']
        pd.set_option('display.float_format', '{:.2f}'.format)
        print(display_df.to_string(index=False))
        print("=" * 80)

        # Trade P&L statistics
        pnl_series = exits['trade_pnl'].values
        winning_trades = pnl_series[pnl_series > 0]
        losing_trades = pnl_series[pnl_series < 0]

        total_pnl = pnl_series.sum()
        avg_pnl = pnl_series.mean()
        win_rate = len(winning_trades) / num_trades * 100
        avg_win = winning_trades.mean() if len(winning_trades) > 0 else 0
        avg_loss = losing_trades.mean() if len(losing_trades) > 0 else 0
        best_trade = pnl_series.max()
        worst_trade = pnl_series.min()

        # Compute equity curve (if total_equity exists)
        equity = df['total_equity'].values
        peak = equity[0]
        drawdown = 0
        max_drawdown = 0
        for val in equity:
            if val > peak:
                peak = val
            dd = (peak - val) / peak if peak != 0 else 0
            if dd > max_drawdown:
                max_drawdown = dd

        # Print summary
        print("\n" + "=" * 60)
        print("TRADING LOG ANALYSIS")
        print("=" * 60)
        print(f"Total trades completed: {num_trades}")
        print(f"Win rate: {win_rate:.2f}%")
        print(f"Total realised P&L: {total_pnl:.2f}")
        print(f"Average P&L per trade: {avg_pnl:.2f}")
        print(f"Average winning trade: {avg_win:.2f}")
        print(f"Average losing trade: {avg_loss:.2f}")
        print(f"Best trade: {best_trade:.2f}")
        print(f"Worst trade: {worst_trade:.2f}")
        print(f"Maximum drawdown: {max_drawdown*100:.2f}%")
        final_equity = equity[-1] if len(equity) > 0 else 0
        print(f"Final equity: {final_equity:.2f}")
        print("=" * 60)

    else:
        print("No completed trades found.")
        if 'total_equity' in df.columns:
            print("Plotting equity curve even without trades...")

    # Plot if matplotlib available and data exists
    try:
        import matplotlib.pyplot as plt
        import matplotlib.dates as mdates

        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 10), sharex=True)

        # Equity curve
        ax1.plot(df['timestamp'], df['total_equity'], label='Equity', color='blue')
        ax1.set_ylabel('Equity')
        ax1.set_title('Equity Curve')
        ax1.legend()
        ax1.grid(True)

        # d_norm with entry/exit markers
        ax2.plot(df['timestamp'], df['d_norm'], label='d_norm', color='gray', alpha=0.7)
        entries = df[df['event_type'] == 'entry']
        exits_plot = df[df['event_type'] == 'exit']
        if not entries.empty:
            ax2.scatter(entries['timestamp'], entries['d_norm'], color='green', marker='^', s=100, label='Entry')
        if not exits_plot.empty:
            ax2.scatter(exits_plot['timestamp'], exits_plot['d_norm'], color='red', marker='v', s=100, label='Exit')
        ax2.axhline(y=ENTRY_THRESHOLD, color='green', linestyle='--', alpha=0.5, label='Entry threshold')
        ax2.axhline(y=-ENTRY_THRESHOLD, color='red', linestyle='--', alpha=0.5, label='Exit threshold')
        ax2.set_xlabel('Time (IST)')
        ax2.set_ylabel('d_norm')
        ax2.set_title('d_norm with Entry/Exit Points')
        ax2.legend()
        ax2.grid(True)

        plt.tight_layout()
        plt.show()
    except ImportError:
        print("matplotlib not installed. Skipping plots.")
    except Exception as e:
        print(f"Plotting error: {e}")


# ---------- Main ----------
def main():
    parser = argparse.ArgumentParser(description='Paper Trading with Fyers Option Chain')
    parser.add_argument('-a', '--analyze', action='store_true', help='Analyze the existing CSV log and exit')
    args = parser.parse_args()

    if args.analyze:
        analyze_trading_log(CSV_FILENAME)
        return

    # Otherwise run the trading loop
    trader = PaperTrader(initial_cash=100000)
    logger.info(f"🚀 Starting paper trading for {SYMBOL}")
    logger.info(f"   Entry threshold: {ENTRY_THRESHOLD}")
    logger.info(f"   Exit rule: retracement of {EXIT_PERCENT*100:.0f}% from extreme (peak for CE, trough for PE)")
    logger.info(f"   Refresh interval: {TIMEOUT} seconds (aligned to wall clock)")
    logger.info(f"   First fetch will happen immediately, then every round minute.")

    # --- Fetch immediately on start ---
    try:
        logger.info(f"⏰ Fetching data immediately (startup) at {get_ist_time()}")
        data = trader.fetch_option_chain()
        if data is not None:
            trader.update_position(data)
            trader.get_status()
        else:
            logger.warning("Initial fetch failed.")
    except Exception as e:
        logger.exception("Error during initial fetch")

    # --- Then loop with clock alignment ---
    while True:
        try:
            current_ts = time.time()
            next_ts = math.ceil(current_ts / TIMEOUT) * TIMEOUT
            sleep_duration = next_ts - current_ts
            if sleep_duration < 0.5:
                sleep_duration += TIMEOUT

            time.sleep(sleep_duration)

            logger.info(f"⏰ Fetching data at {get_ist_time()}")
            data = trader.fetch_option_chain()
            if data is None:
                logger.warning("Failed to fetch data. Retrying at next cycle...")
                continue
            trader.update_position(data)
            trader.get_status()
        except Exception as e:
            logger.exception("Error in main loop")

if __name__ == "__main__":
    main()