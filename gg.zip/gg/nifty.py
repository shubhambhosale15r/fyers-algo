import time
import math
import logging
import csv
import os
import sys
import argparse
from datetime import datetime
import numpy as np
from fyers_apiv3 import fyersModel

# ---------- Configuration ----------
CLIENT_ID = "J0ENYFX9ME-200"
ACCESS_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOlsiZDoxIiwiZDoyIiwieDowIiwieDoxIiwieDoyIl0sImF0X2hhc2giOiJnQUFBQUFCcU9MRmoyQnM0c0w3QnBXVXVFRGg5T21QVE9RRjVjc3FHOXlTQ3M2bmg1NzNuRUN2QVdpUVlCclMtdGd0cWNYdUtvMDFHcVFUX2w2azRJYnVMdF9nQUVJY0Z1dkJkSmR5cTM0ZXhrN2w0TTJuRFFjVT0iLCJkaXNwbGF5X25hbWUiOiIiLCJvbXMiOiJLMSIsImhzbV9rZXkiOiIwNWQyNjAxMzM1MGQ3MmJhN2RjOWZhOTMzNTQ1MGIzNzExMjE0YzE0ZGNkZTFmODU3NjMzM2ZjYiIsImlzRGRwaUVuYWJsZWQiOiJOIiwiaXNNdGZFbmFibGVkIjoiTiIsImZ5X2lkIjoiRkFBMzE0OTUiLCJhcHBUeXBlIjoyMDAsImV4cCI6MTc4MjE3NDYwMCwiaWF0IjoxNzgyMTAwMzIzLCJpc3MiOiJhcGkuZnllcnMuaW4iLCJuYmYiOjE3ODIxMDAzMjMsInN1YiI6ImFjY2Vzc190b2tlbiJ9.FZkk7WbYgLsedcjcvQc1FQkLMiYzM4uKOjRWDYzqKHQ"
SYMBOL = "NSE:NIFTY50-INDEX"
STRIKE_COUNT = 2
GREEKS = "1"
ENTRY_THRESHOLD = 0.3
QUANTITY = 3
LOT_SIZE = 65
TIMEOUT = 60
CSV_FILENAME = "paper_trading_log.csv"

EXIT_PERCENT = 0.5

# ---------- Logging Setup ----------
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# ---------- Helper for IST Time ----------
def get_ist_time(timestamp=None):
    if timestamp is None:
        dt = datetime.now()
    else:
        dt = datetime.fromtimestamp(timestamp)
    return dt.strftime('%Y-%m-%d %H:%M:%S IST')

# ---------- Fyers Initialisation ----------
fyers = fyersModel.FyersModel(client_id=CLIENT_ID, token=ACCESS_TOKEN, is_async=False, log_path="")


class PaperTrader:
    def __init__(self, initial_cash=100000):
        self.cash = initial_cash
        self.position = None
        self.realized_pnl = 0
        self.trade_log = []
        self.current_d_norm = 0
        self.underlying_price = 0
        self.atm_strike = None          # Real strike used for execution
        self.atm_ce = None              # Real CE contract for execution
        self.atm_pe = None              # Real PE contract for execution
        self.synthetic_strike = None    # For logging only
        
        self.csv_headers = [
            'timestamp', 'underlying_price', 'd_norm', 'atm_strike',
            'ce_ltp', 'pe_ltp', 'ce_delta', 'pe_delta',
            'ce_volume', 'pe_volume', 'ce_oi', 'pe_oi',
            'ce_iv', 'pe_iv',
            'position_type', 'entry_price', 'current_price',
            'unrealized_pnl', 'extreme',
            'cash', 'realized_pnl', 'total_equity',
            'event_type', 'entry_time', 'exit_price', 'trade_pnl',
            'exit_reason'
        ]
        if not os.path.exists(CSV_FILENAME):
            with open(CSV_FILENAME, 'w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=self.csv_headers)
                writer.writeheader()
        self.csv_file = open(CSV_FILENAME, 'a', newline='')
        self.csv_writer = csv.DictWriter(self.csv_file, fieldnames=self.csv_headers)

    def __del__(self):
        if hasattr(self, 'csv_file'):
            self.csv_file.close()

    # ---------- Synthetic Interpolation Helper (for Signal ONLY) ----------
    def _interpolate_synthetic_contract(self, contracts, target_delta_abs=0.50):
        """
        Interpolate a synthetic contract at the exact target absolute delta.
        Used ONLY to calculate a smooth d_norm signal.
        Returns the synthetic contract dict, or None.
        """
        valid = [c for c in contracts if c['strike_price'] != -1 and 'greeks' in c]
        if not valid:
            return None
        valid.sort(key=lambda x: x['strike_price'])

        sample_delta = valid[0]['greeks']['delta']
        is_put = sample_delta < 0

        K1 = None  # Higher absolute delta
        K2 = None  # Lower absolute delta

        if is_put:
            for c in valid:
                abs_d = abs(c['greeks']['delta'])
                if abs_d >= target_delta_abs and K1 is None:
                    K1 = c
                if abs_d <= target_delta_abs and K2 is None:
                    K2 = c
        else:
            for c in valid:
                d = c['greeks']['delta']
                if d >= target_delta_abs and K1 is None:
                    K1 = c
                if d <= target_delta_abs and K2 is None:
                    K2 = c

        if K1 is None and K2 is not None:
            return K2
        if K2 is None and K1 is not None:
            return K1
        if K1 is None or K2 is None:
            return None

        delta_K1 = abs(K1['greeks']['delta'])
        delta_K2 = abs(K2['greeks']['delta'])

        if delta_K1 == delta_K2:
            W = 0.5
        else:
            W = (target_delta_abs - delta_K2) / (delta_K1 - delta_K2)
        W = max(0.0, min(1.0, W))

        def interpolate(field):
            v1 = K1[field]
            v2 = K2[field]
            if field == 'strike_price':
                return W * v1 + (1 - W) * v2
            if field == 'greeks':
                return {
                    'delta': W * K1['greeks']['delta'] + (1 - W) * K2['greeks']['delta'],
                    'iv': W * K1['greeks'].get('iv', 0) + (1 - W) * K2['greeks'].get('iv', 0),
                    'gamma': W * K1['greeks'].get('gamma', 0) + (1 - W) * K2['greeks'].get('gamma', 0),
                    'theta': W * K1['greeks'].get('theta', 0) + (1 - W) * K2['greeks'].get('theta', 0),
                    'vega': W * K1['greeks'].get('vega', 0) + (1 - W) * K2['greeks'].get('vega', 0),
                }
            if isinstance(v1, (int, float)):
                return W * v1 + (1 - W) * v2
            return v1

        synthetic = {
            'strike_price': interpolate('strike_price'),
            'ltp': interpolate('ltp'),
            'volume': interpolate('volume'),
            'oi': interpolate('oi'),
            'option_type': K1['option_type'],
            'greeks': interpolate('greeks'),
        }
        return synthetic

    def fetch_option_chain(self):
        """Fetch chain, calculate smooth d_norm synthetically, but pick real strike for execution."""
        logger.debug("Fetching option chain...")
        data = {
            "symbol": SYMBOL,
            "strikecount": STRIKE_COUNT,
            "timestamp": "",
            "greeks": GREEKS
        }
        response = fyers.optionchain(data=data)
        if response.get('s') != 'ok':
            logger.error(f"API error: {response}")
            return None

        chain = response['data']['optionsChain']
        underlying = chain[0]
        self.underlying_price = underlying['ltp']
        logger.info(f"📈 Underlying LTP: {self.underlying_price:.2f}")

        option_contracts = chain[1:]

        # Separate into CE and PE
        ce_list = [c for c in option_contracts if c['option_type'] == 'CE' and c['strike_price'] != -1]
        pe_list = [c for c in option_contracts if c['option_type'] == 'PE' and c['strike_price'] != -1]

        # ----- STEP 1: Calculate SMOOTH d_norm using Synthetic Interpolation (Signal) -----
        syn_ce = self._interpolate_synthetic_contract(ce_list, target_delta_abs=0.50)
        syn_pe = self._interpolate_synthetic_contract(pe_list, target_delta_abs=0.50)

        if syn_ce is not None and syn_pe is not None:
            ce_delta = syn_ce['greeks']['delta']
            ce_ltp = syn_ce['ltp']
            ce_volume = syn_ce['volume']
            ce = ce_delta * ce_ltp * ce_volume

            pe_delta = abs(syn_pe['greeks']['delta'])
            pe_ltp = syn_pe['ltp']
            pe_volume = syn_pe['volume']
            pe = pe_delta * pe_ltp * pe_volume

            denominator = ce + pe
            d_norm = (ce - pe) / denominator if denominator != 0 else 0
            self.current_d_norm = d_norm
            self.synthetic_strike = syn_ce['strike_price']
            logger.info(f"🎯 Synthetic ATM Strike (for signal): {self.synthetic_strike:.2f}")
            logger.info(f"🔢 d_norm (smooth, synthetic) = {d_norm:.4f}")
        else:
            # Fallback to nearest strike if interpolation fails
            logger.warning("Synthetic interpolation failed. Falling back to nearest strike for d_norm.")
            atm_strike = None
            min_diff = float('inf')
            for contract in option_contracts:
                strike = contract['strike_price']
                if strike == -1:
                    continue
                diff = abs(strike - self.underlying_price)
                if diff < min_diff:
                    min_diff = diff
                    atm_strike = strike
            fallback_ce = None
            fallback_pe = None
            for contract in option_contracts:
                if contract['strike_price'] == atm_strike:
                    if contract['option_type'] == 'CE':
                        fallback_ce = contract
                    elif contract['option_type'] == 'PE':
                        fallback_pe = contract
            if fallback_ce is None or fallback_pe is None:
                return None
            ce_delta = fallback_ce['greeks']['delta']
            ce_ltp = fallback_ce['ltp']
            ce_volume = fallback_ce['volume']
            ce = ce_delta * ce_ltp * ce_volume
            pe_delta = abs(fallback_pe['greeks']['delta'])
            pe_ltp = fallback_pe['ltp']
            pe_volume = fallback_pe['volume']
            pe = pe_delta * pe_ltp * pe_volume
            denominator = ce + pe
            d_norm = (ce - pe) / denominator if denominator != 0 else 0
            self.current_d_norm = d_norm
            self.synthetic_strike = atm_strike
            logger.info(f"🎯 ATM Strike (fallback): {atm_strike}")
            logger.info(f"🔢 d_norm (fallback) = {d_norm:.4f}")

        # ----- STEP 2: Pick the REAL strike for execution (Nearest to Spot) -----
        real_strike = None
        min_diff = float('inf')
        for contract in option_contracts:
            strike = contract['strike_price']
            if strike == -1:
                continue
            diff = abs(strike - self.underlying_price)
            if diff < min_diff:
                min_diff = diff
                real_strike = strike

        self.atm_strike = real_strike
        logger.info(f"📍 REAL Execution Strike (Nearest to Spot): {real_strike}")

        # Get the real CE and PE for this strike
        real_ce = None
        real_pe = None
        for contract in option_contracts:
            if contract['strike_price'] == real_strike:
                if contract['option_type'] == 'CE':
                    real_ce = contract
                elif contract['option_type'] == 'PE':
                    real_pe = contract

        if real_ce is None or real_pe is None:
            logger.warning("Real CE or PE not found for execution strike.")
            return None

        self.atm_ce = real_ce
        self.atm_pe = real_pe

        # Log the real contract details
        logger.info(f"📊 REAL CE (strike {real_strike}): delta={real_ce['greeks']['delta']:.4f}, ltp={real_ce['ltp']:.2f}")
        logger.info(f"📊 REAL PE (strike {real_strike}): delta={real_pe['greeks']['delta']:.4f}, ltp={real_pe['ltp']:.2f}")

        return {
            'strike': real_strike,      # This is the real strike for execution
            'ce': real_ce,              # Real CE contract
            'pe': real_pe,              # Real PE contract
            'd_norm': self.current_d_norm,
            'underlying': underlying,
            'synthetic_strike': self.synthetic_strike  # Just for info
        }

    def enter_position(self, option_type, contract, price):
        """Enter a long position using a SINGLE real strike."""
        if self.position is not None:
            logger.warning("Already in a position, cannot enter.")
            return

        entry_price = contract['ltp']
        quantity = QUANTITY * LOT_SIZE
        cost = entry_price * quantity

        if cost > self.cash:
            logger.warning(f"Insufficient cash! Need {cost:.2f}, have {self.cash:.2f}. Skipping entry.")
            return

        self.position = {
            'type': option_type,
            'entry_price': entry_price,
            'entry_time': datetime.now(),
            'strike': contract['strike_price'],
            'quantity': quantity,
            'extreme': self.current_d_norm,
            'contract': contract
        }
        self.cash -= cost
        logger.info(f"✅ ENTER {option_type} (REAL Strike: {contract['strike_price']}) @ {entry_price:.2f} x {quantity} = {cost:.2f} | d_norm={self.current_d_norm:.3f}")
        self._log_row(event_type='entry')

    def exit_position(self, exit_price=None, reason=None):
        """Close the current position (single strike)."""
        if self.position is None:
            return

        exit_price = self.position['contract']['ltp'] if exit_price is None else exit_price
        pnl = (exit_price - self.position['entry_price']) * self.position['quantity']
        self.cash += exit_price * self.position['quantity']
        self.realized_pnl += pnl

        logger.info("=" * 70)
        logger.info(f"🔹 TRADE CLOSED 🔹  (IST: {get_ist_time()})")
        logger.info(f"   Type     : {self.position['type']} (Strike: {self.position['strike']})")
        logger.info(f"   Entry    : {self.position['entry_price']:.2f}")
        logger.info(f"   Exit     : {exit_price:.2f}")
        logger.info(f"   Quantity : {self.position['quantity']}")
        logger.info(f"   ▶ P&L    : {pnl:+.2f}")
        logger.info(f"   Total Realized P&L: {self.realized_pnl:.2f}")
        if reason:
            logger.info(f"   Exit reason: {reason}")
        logger.info("=" * 70)

        trade_info = {
            'type': self.position['type'],
            'strike': self.position['strike'],
            'entry_price': self.position['entry_price'],
            'entry_time': self.position['entry_time'],
            'exit_price': exit_price,
            'exit_time': datetime.now(),
            'pnl': pnl,
            'reason': reason
        }
        self.trade_log.append(trade_info)
        self._log_row(event_type='exit', exit_price=exit_price, trade_pnl=pnl, exit_reason=reason)
        self.position = None

    def update_position(self, current_data):
        """Check entry/exit conditions using smooth synthetic d_norm, execute on real strike."""
        if self.position is None:
            if self.current_d_norm > ENTRY_THRESHOLD:
                self.enter_position('CE', current_data['ce'], current_data['ce']['ltp'])
            elif self.current_d_norm < -ENTRY_THRESHOLD:
                self.enter_position('PE', current_data['pe'], current_data['pe']['ltp'])
        else:
            pos_type = self.position['type']
            if pos_type == 'CE':
                if self.current_d_norm > self.position['extreme']:
                    self.position['extreme'] = self.current_d_norm
                exit_threshold = self.position['extreme'] * EXIT_PERCENT
                if self.current_d_norm < exit_threshold:
                    reason = (f"CE exit: d_norm fell from peak {self.position['extreme']:.3f} "
                              f"to {self.current_d_norm:.3f} (below {EXIT_PERCENT*100:.0f}% threshold {exit_threshold:.3f})")
                    self.exit_position(reason=reason)
            else:  # PE
                if self.current_d_norm < self.position['extreme']:
                    self.position['extreme'] = self.current_d_norm
                exit_threshold = self.position['extreme'] * EXIT_PERCENT
                if self.current_d_norm > exit_threshold:
                    reason = (f"PE exit: d_norm rose from bottom {self.position['extreme']:.3f} "
                              f"to {self.current_d_norm:.3f} (above {EXIT_PERCENT*100:.0f}% threshold {exit_threshold:.3f})")
                    self.exit_position(reason=reason)

        self._log_row(event_type='update')

    def _log_row(self, event_type='update', exit_price=None, trade_pnl=None, exit_reason=None):
        row = {
            'timestamp': datetime.now().isoformat(),
            'underlying_price': self.underlying_price,
            'd_norm': self.current_d_norm,
            'atm_strike': self.atm_strike if self.atm_strike else -1,
            'ce_ltp': self.atm_ce['ltp'] if self.atm_ce else 0,
            'pe_ltp': self.atm_pe['ltp'] if self.atm_pe else 0,
            'ce_delta': self.atm_ce['greeks']['delta'] if self.atm_ce and 'greeks' in self.atm_ce else 0,
            'pe_delta': self.atm_pe['greeks']['delta'] if self.atm_pe and 'greeks' in self.atm_pe else 0,
            'ce_volume': self.atm_ce['volume'] if self.atm_ce else 0,
            'pe_volume': self.atm_pe['volume'] if self.atm_pe else 0,
            'ce_oi': self.atm_ce['oi'] if self.atm_ce else 0,
            'pe_oi': self.atm_pe['oi'] if self.atm_pe else 0,
            'ce_iv': self.atm_ce['greeks']['iv'] if self.atm_ce and 'greeks' in self.atm_ce else 0,
            'pe_iv': self.atm_pe['greeks']['iv'] if self.atm_pe and 'greeks' in self.atm_pe else 0,
            'position_type': self.position['type'] if self.position else 'NONE',
            'entry_price': self.position['entry_price'] if self.position else 0,
            'current_price': self.position['contract']['ltp'] if self.position else 0,
            'unrealized_pnl': (self.position['contract']['ltp'] - self.position['entry_price']) * self.position['quantity'] if self.position else 0,
            'extreme': self.position['extreme'] if self.position else 0,
            'cash': self.cash,
            'realized_pnl': self.realized_pnl,
            'total_equity': self.cash + self.realized_pnl + ((self.position['contract']['ltp'] - self.position['entry_price']) * self.position['quantity'] if self.position else 0),
            'event_type': event_type,
            'entry_time': self.position['entry_time'].isoformat() if self.position else '',
            'exit_price': exit_price if exit_price is not None else 0,
            'trade_pnl': trade_pnl if trade_pnl is not None else 0,
            'exit_reason': exit_reason if exit_reason else ''
        }
        self.csv_writer.writerow(row)
        self.csv_file.flush()

    def get_status(self):
        logger.info(f"📊 STATUS UPDATE @ {get_ist_time()}")
        logger.info(f"   Underlying: {self.underlying_price:.2f}, d_norm: {self.current_d_norm:.3f}")
        if self.position:
            unrealized = (self.position['contract']['ltp'] - self.position['entry_price']) * self.position['quantity']
            logger.info(f"   Position: {self.position['type']} strike {self.position['strike']}, entry {self.position['entry_price']:.2f}, current {self.position['contract']['ltp']:.2f}, unrealized P&L: {unrealized:.2f}")
            if self.position['type'] == 'CE':
                threshold = self.position['extreme'] * EXIT_PERCENT
                logger.info(f"   Exit threshold (50% of peak {self.position['extreme']:.3f}): {threshold:.3f}")
            else:
                threshold = self.position['extreme'] * EXIT_PERCENT
                logger.info(f"   Exit threshold (50% of bottom {self.position['extreme']:.3f}): {threshold:.3f}")
        else:
            logger.info("   No open position")
        logger.info(f"   Cash: {self.cash:.2f}, Realized P&L: {self.realized_pnl:.2f}, Total Equity: {self.cash + self.realized_pnl:.2f}")


# ---------- Analysis (unchanged from original) ----------
def analyze_trading_log(csv_path):
    try:
        import pandas as pd
    except ImportError:
        print("pandas not installed.")
        return
    if not os.path.exists(csv_path):
        print(f"CSV file {csv_path} not found.")
        return
    df = pd.read_csv(csv_path)
    df['timestamp'] = pd.to_datetime(df['timestamp'])
    df.sort_values('timestamp', inplace=True)
    exits = df[df['event_type'] == 'exit'].copy()
    num_trades = len(exits)
    if num_trades > 0:
        print("\n" + "=" * 80)
        print("📋 DETAILED TRADE LOG")
        print("=" * 80)
        display_cols = ['timestamp', 'position_type', 'entry_price', 'exit_price', 'trade_pnl', 'exit_reason']
        if 'exit_reason' not in exits.columns:
            exits['exit_reason'] = ''
        display_df = exits[display_cols].copy()
        display_df.columns = ['Exit Time', 'Type', 'Entry', 'Exit', 'P&L', 'Reason']
        print(display_df.to_string(index=False))
        print("=" * 80)
        pnl_series = exits['trade_pnl'].values
        total_pnl = pnl_series.sum()
        win_rate = (pnl_series > 0).sum() / num_trades * 100
        print(f"Total Trades: {num_trades}")
        print(f"Win Rate: {win_rate:.2f}%")
        print(f"Total Realised P&L: {total_pnl:.2f}")
        print(f"Avg P&L: {pnl_series.mean():.2f}")
        print("=" * 60)
    else:
        print("No completed trades.")
    try:
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(2, 1, figsize=(12, 8), sharex=True)
        ax[0].plot(df['timestamp'], df['total_equity'], label='Equity', color='blue')
        ax[0].set_ylabel('Equity')
        ax[0].legend()
        ax[0].grid(True)
        ax[1].plot(df['timestamp'], df['d_norm'], label='d_norm', color='gray')
        ax[1].axhline(y=ENTRY_THRESHOLD, color='g', linestyle='--')
        ax[1].axhline(y=-ENTRY_THRESHOLD, color='r', linestyle='--')
        entries = df[df['event_type'] == 'entry']
        exits_plot = df[df['event_type'] == 'exit']
        if not entries.empty:
            ax[1].scatter(entries['timestamp'], entries['d_norm'], color='green', marker='^', s=100, label='Entry')
        if not exits_plot.empty:
            ax[1].scatter(exits_plot['timestamp'], exits_plot['d_norm'], color='red', marker='v', s=100, label='Exit')
        ax[1].set_ylabel('d_norm')
        ax[1].legend()
        ax[1].grid(True)
        plt.tight_layout()
        plt.show()
    except ImportError:
        print("matplotlib not installed, skipping plots.")


# ---------- Main ----------
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('-a', '--analyze', action='store_true', help='Analyze the CSV log')
    args = parser.parse_args()
    if args.analyze:
        analyze_trading_log(CSV_FILENAME)
        return

    trader = PaperTrader(initial_cash=100000)
    logger.info(f"🚀 Starting paper trading for {SYMBOL}")
    logger.info(f"   Entry threshold: {ENTRY_THRESHOLD}")
    logger.info(f"   🔥 Signal = Synthetic (smooth d_norm) | Execution = Single Real Strike (Nearest to Spot)")

    try:
        logger.info(f"⏰ Fetching data immediately at {get_ist_time()}")
        data = trader.fetch_option_chain()
        if data is not None:
            trader.update_position(data)
            trader.get_status()
    except Exception as e:
        logger.exception("Initial fetch error")

    while True:
        try:
            current_ts = time.time()
            next_ts = math.ceil(current_ts / TIMEOUT) * TIMEOUT
            sleep_duration = next_ts - current_ts
            if sleep_duration < 0.5:
                sleep_duration += TIMEOUT
            time.sleep(sleep_duration)
            logger.info(f"⏰ Fetching data at {get_ist_time()}")
            data = trader.fetch_option_chain()
            if data is None:
                logger.warning("Failed to fetch data.")
                continue
            trader.update_position(data)
            trader.get_status()
        except Exception as e:
            logger.exception("Error in main loop")

if __name__ == "__main__":
    main()