import time
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import pytz
from fyers_apiv3 import fyersModel
import logging
import uuid
from functools import lru_cache
import os
import subprocess
import sys
import json
from typing import Dict, List, Any, Optional, Tuple
from collections import Counter
import matplotlib.pyplot as plt
import csv


# Constants
class Config:
    REFRESH_INTERVAL = 30  # seconds
    API_RATE_LIMIT = 200
    API_WINDOW = 60  # seconds
    LOT_SIZE = 75  # nifty lot size
    MAX_RETRIES = 3
    RETRY_DELAY = 2  # seconds
    EXIT_ON_SIDEWAYS = True


# Initialize logging
logging.basicConfig(
    filename="trading_app.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)


def get_next_aligned_time(interval_seconds):
    """Get next time aligned to the interval"""
    now = datetime.now()
    current_seconds = (now - now.replace(hour=0, minute=0, second=0, microsecond=0)).total_seconds()
    intervals_passed = current_seconds // interval_seconds
    next_aligned_seconds = (intervals_passed + 1) * interval_seconds
    
    next_time = now.replace(hour=0, minute=0, second=0, microsecond=0) + timedelta(seconds=next_aligned_seconds)
    return next_time

def wait_until_next_interval(interval_seconds):
    """Wait until next aligned interval"""
    next_time = get_next_aligned_time(interval_seconds)
    wait_seconds = (next_time - datetime.now()).total_seconds()
    
    if wait_seconds > 0:
        print(f"⏳ Next update at {next_time.strftime('%H:%M:%S')} (waiting {wait_seconds:.1f}s)")
        time.sleep(wait_seconds)

# Data Logging Class with PNL Tracking
class DataLogger:
    def __init__(self, filename="trading_data.csv"):
        self.filename = filename
        self.pnl_file = "pnl_data.csv"
        self._ensure_header()
        self._ensure_pnl_header()

    def _ensure_header(self):
        """Create file with headers if it doesn't exist"""
        try:
            with open(self.filename, 'r') as f:
                pass
        except FileNotFoundError:
            with open(self.filename, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'timestamp', 'underlying_ltp', 'signal',
                    'atm_strike', 'expiry_date', 'ce_placement_avg',
                    'pe_placement_avg', 'net_flow', 'direction_ratio',
                    'ce_z_score', 'pe_z_score', 'using_dynamic_thresholds'
                ])

    def _ensure_pnl_header(self):
        """Create PNL file with headers if it doesn't exist"""
        try:
            with open(self.pnl_file, 'r') as f:
                pass
        except FileNotFoundError:
            with open(self.pnl_file, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'timestamp', 'signal', 'entry_price', 'exit_price',
                    'quantity', 'pnl', 'cumulative_pnl', 'trade_type'
                ])

    def log_data(self, timestamp, underlying_ltp, signal, atm_strike,
                 expiry_date, ce_placement_avg=0, pe_placement_avg=0,
                 net_flow=0, direction_ratio=0, ce_z_score=0, pe_z_score=0, 
                 using_dynamic_thresholds=False):
        """Log trading data to CSV file with Z-score metrics"""
        try:
            with open(self.filename, 'a', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    timestamp, underlying_ltp, signal, atm_strike,
                    expiry_date, ce_placement_avg, pe_placement_avg,
                    net_flow, direction_ratio, ce_z_score, pe_z_score,
                    using_dynamic_thresholds
                ])
            print(f"✅ Data logged: {timestamp} - LTP: {underlying_ltp}, Signal: {signal}")
            if using_dynamic_thresholds:
                print(f"   📊 Z-scores - CE: {ce_z_score:.2f}, PE: {pe_z_score:.2f}")
        except Exception as e:
            print(f"❌ Error logging data: {e}")

    def log_pnl(self, timestamp, signal, entry_price, exit_price, quantity, pnl, trade_type):
        """Log PNL data"""
        try:
            # Read existing PNL data to calculate cumulative PNL
            cumulative_pnl = 0
            try:
                pnl_df = pd.read_csv(self.pnl_file)
                if not pnl_df.empty:
                    cumulative_pnl = pnl_df['pnl'].sum() + pnl
            except:
                cumulative_pnl = pnl

            with open(self.pnl_file, 'a', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    timestamp, signal, entry_price, exit_price,
                    quantity, pnl, cumulative_pnl, trade_type
                ])
            print(f"💰 PNL logged: {timestamp} - PNL: {pnl}, Cumulative: {cumulative_pnl}")
        except Exception as e:
            print(f"❌ Error logging PNL: {e}")

    def read_data(self, limit=None):
        """Read logged data from CSV file"""
        try:
            df = pd.read_csv(self.filename)
            if limit:
                return df.tail(limit)
            return df
        except Exception as e:
            print(f"❌ Error reading data: {e}")
            return pd.DataFrame()

    def read_pnl_data(self):
        """Read PNL data"""
        try:
            return pd.read_csv(self.pnl_file)
        except Exception as e:
            print(f"❌ Error reading PNL data: {e}")
            return pd.DataFrame()


# Terminal-based Live Dashboard
class TerminalDashboard:
    def __init__(self, data_logger):
        self.data_logger = data_logger
        self.last_update = None

    def display_live_dashboard(self):
        """Display live dashboard in terminal"""
        try:
            # Clear screen
            os.system('cls' if os.name == 'nt' else 'clear')

            # Read latest data
            df = self.data_logger.read_data(limit=20)
            pnl_df = self.data_logger.read_pnl_data()

            print("\n" + "=" * 100)
            print("📊 LIVE TRADING DASHBOARD")
            print("=" * 100)
            print(f"Last Update: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
            print("-" * 100)

            if df.empty:
                print("🔄 Waiting for trading data...")
                return

            # Convert timestamp
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            df = df.sort_values('timestamp')

            # Display current status
            latest = df.iloc[-1]
            print(f"\n📈 CURRENT STATUS:")
            print(f"   Nifty LTP: {latest['underlying_ltp']:.2f}")
            print(f"   Signal: {latest['signal']}")
            print(f"   ATM Strike: {latest['atm_strike']}")
            print(f"   CE Placement: {latest['ce_placement_avg']:.3f}")
            print(f"   PE Placement: {latest['pe_placement_avg']:.3f}")
            
            # Show Z-score info if available
            if 'ce_z_score' in latest and 'pe_z_score' in latest:
                print(f"   CE Z-score: {latest['ce_z_score']:.2f}, PE Z-score: {latest['pe_z_score']:.2f}")
                if 'using_dynamic_thresholds' in latest:
                    threshold_type = "DYNAMIC" if latest['using_dynamic_thresholds'] else "FIXED"
                    print(f"   Threshold Type: {threshold_type}")

            # Display recent signals
            print(f"\n🔄 RECENT SIGNALS (Last 5):")
            recent_signals = df.tail(5)[['timestamp', 'underlying_ltp', 'signal']]
            for _, row in recent_signals.iterrows():
                signal_color = {
                    'BUY': '🟢',
                    'SELL': '🔴',
                    'SIDEWAYS': '🟡',
                    'HOLD': '⚪'
                }.get(row['signal'], '⚪')

                print(
                    f"   {row['timestamp'].strftime('%H:%M:%S')} - {signal_color} {row['signal']} - LTP: {row['underlying_ltp']:.2f}")

            # Display P&L summary
            if not pnl_df.empty:
                pnl_df['timestamp'] = pd.to_datetime(pnl_df['timestamp'])
                pnl_df = pnl_df.sort_values('timestamp')

                total_pnl = pnl_df['pnl'].sum()
                total_trades = len(pnl_df)
                profitable_trades = len(pnl_df[pnl_df['pnl'] > 0])
                win_rate = (profitable_trades / total_trades) * 100 if total_trades > 0 else 0
                current_cumulative = pnl_df['cumulative_pnl'].iloc[-1] if not pnl_df.empty else 0

                print(f"\n💰 P&L SUMMARY:")
                print(f"   Total Trades: {total_trades}")
                print(f"   Profitable: {profitable_trades}")
                print(f"   Win Rate: {win_rate:.1f}%")
                print(f"   Total P&L: {total_pnl:.2f}")
                print(f"   Cumulative P&L: {current_cumulative:.2f}")

                # Show recent trades
                recent_trades = pnl_df.tail(3)
                print(f"\n📋 RECENT TRADES:")
                for _, trade in recent_trades.iterrows():
                    pnl_color = "🟢" if trade['pnl'] > 0 else "🔴" if trade['pnl'] < 0 else "⚪"
                    print(
                        f"   {trade['timestamp'].strftime('%H:%M:%S')} - {pnl_color} {trade['signal']} - P&L: {trade['pnl']:.2f}")
            else:
                print(f"\n💰 P&L SUMMARY: No trades yet")

            # Display signal statistics
            signal_counts = df['signal'].value_counts()
            print(f"\n📊 SIGNAL STATISTICS:")
            for signal, count in signal_counts.items():
                percentage = (count / len(df)) * 100
                print(f"   {signal}: {count} times ({percentage:.1f}%)")

            print("\n" + "=" * 100)
            print("🔄 Next update in 30 seconds... (Press Ctrl+C to stop)")
            print("=" * 100)

        except Exception as e:
            print(f"❌ Error displaying dashboard: {e}")


# Plotting Functions (for manual use)
def generate_static_plot():
    """Generate a static plot that can be viewed manually"""
    try:
        data_logger = DataLogger()
        df = data_logger.read_data()
        pnl_df = data_logger.read_pnl_data()

        if df.empty:
            print("❌ No data available for plotting")
            return

        # Create the plot
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(15, 10))

        # Convert timestamp
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        df = df.sort_values('timestamp')

        # Plot 1: Nifty LTP and Signals
        ax1.plot(df['timestamp'], df['underlying_ltp'], 'b-', label='Nifty LTP', linewidth=2)
        ax1.set_ylabel('Nifty LTP', color='blue')
        ax1.tick_params(axis='y', labelcolor='blue')
        ax1.grid(True, alpha=0.3)

        # Add signals
        buy_signals = df[df['signal'] == 'BUY']
        sell_signals = df[df['signal'] == 'SELL']
        sideways_signals = df[df['signal'] == 'SIDEWAYS']

        if not buy_signals.empty:
            ax1.scatter(buy_signals['timestamp'], buy_signals['underlying_ltp'],
                        color='green', s=100, label='BUY', marker='^', alpha=0.8)

        if not sell_signals.empty:
            ax1.scatter(sell_signals['timestamp'], sell_signals['underlying_ltp'],
                        color='red', s=100, label='SELL', marker='v', alpha=0.8)

        if not sideways_signals.empty:
            ax1.scatter(sideways_signals['timestamp'], sideways_signals['underlying_ltp'],
                        color='orange', s=80, label='SIDEWAYS', marker='s', alpha=0.6)

        ax1.legend()
        ax1.set_title('Nifty LTP vs Trading Signals')

        # Plot 2: PNL Data
        if not pnl_df.empty:
            pnl_df['timestamp'] = pd.to_datetime(pnl_df['timestamp'])
            pnl_df = pnl_df.sort_values('timestamp')

            ax2.plot(pnl_df['timestamp'], pnl_df['cumulative_pnl'], 'purple',
                     label='Cumulative P&L', linewidth=2)
            ax2.set_ylabel('Cumulative P&L')
            ax2.grid(True, alpha=0.3)

            # Mark individual trades
            profitable = pnl_df[pnl_df['pnl'] > 0]
            losses = pnl_df[pnl_df['pnl'] < 0]

            if not profitable.empty:
                ax2.scatter(profitable['timestamp'], profitable['cumulative_pnl'],
                            color='green', s=60, label='Profit', alpha=0.7)
            if not losses.empty:
                ax2.scatter(losses['timestamp'], losses['cumulative_pnl'],
                            color='red', s=60, label='Loss', alpha=0.7)

            ax2.legend()
            ax2.set_title('Cumulative Profit & Loss')
        else:
            ax2.text(0.5, 0.5, 'No P&L Data Available', ha='center', va='center',
                     transform=ax2.transAxes)
            ax2.set_title('Cumulative Profit & Loss')

        plt.tight_layout()

        # Save plot
        plot_filename = f"trading_plot_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
        plt.savefig(plot_filename, dpi=300, bbox_inches='tight')
        plt.close()

        print(f"✅ Plot saved as: {plot_filename}")
        return plot_filename

    except Exception as e:
        print(f"❌ Error generating plot: {e}")
        return None


# Error handling decorator
def handle_errors(func):
    def wrapper(*args, **kwargs):
        retries = 0
        while retries < Config.MAX_RETRIES:
            try:
                return func(*args, **kwargs)
            except Exception as e:
                retries += 1
                logging.error(f"Error in {func.__name__} (attempt {retries}): {str(e)}", exc_info=True)
                if retries < Config.MAX_RETRIES:
                    time.sleep(Config.RETRY_DELAY)
                else:
                    print(f"❌ Operation failed after {Config.MAX_RETRIES} attempts: {str(e)}")
                    return None

    return wrapper


#Z-score calculation with detailed debugging
def calculate_z_score_dynamic(current_value, history, min_data_points, history_length):
    """
    Calculate Z-score with comprehensive debugging and fallback
    Returns: z_score, debug_info
    """
    debug_info = {
        'data_points': len(history),
        'mean': 0,
        'std': 0,
        'status': 'INSUFFICIENT_DATA'
    }
    
    # Use only the most recent data points up to history_length
    relevant_history = history[-history_length:] if len(history) > history_length else history
    
    if len(relevant_history) < min_data_points:
        print(f"🔍 [Z-SCORE DEBUG] Insufficient data: {len(relevant_history)}/{min_data_points} points")
        return 0, debug_info
    
    try:
        mean = np.mean(relevant_history)
        std = np.std(relevant_history)
        
        debug_info['mean'] = round(mean, 3)
        debug_info['std'] = round(std, 3)
        
        # Avoid division by zero
        if std == 0:
            print(f"⚠️ [Z-SCORE DEBUG] Zero standard deviation detected")
            debug_info['status'] = 'ZERO_STD'
            return 0, debug_info
        
        z_score = (current_value - mean) / std
        debug_info['status'] = 'CALCULATED'
        debug_info['z_score'] = round(z_score, 3)
        debug_info['history_used'] = len(relevant_history)
        
        print(f"✅ [Z-SCORE DEBUG] Calculated: value={current_value:.3f}, mean={mean:.3f}, std={std:.3f}, z={z_score:.3f}, history_used={len(relevant_history)}")
        return z_score, debug_info
        
    except Exception as e:
        print(f"❌ [Z-SCORE DEBUG] Calculation error: {e}")
        debug_info['status'] = 'ERROR'
        debug_info['error'] = str(e)
        return 0, debug_info

# Initialize all session state in one place
class SessionState:
    def __init__(self):
        self.option_chain_api_count = 0
        self.quote_api_count = 0
        self.api_window_start = datetime.now()
        self.last_signal = None
        self.last_signal_order_ids = []
        self.live_last_signal = None
        self.live_last_signal_order_ids = []
        self.signal_history = []
        self.signal_buffer = []  # For majority signal calculation
        self.cid = ""
        self.token = ""
        self._hb_lock = False
        self.trade_tracker = {}  # For PNL tracking
        
        # Z-Score Dynamic Thresholds
        self.ce_placement_history = []  # Store last 30 CE placements
        self.pe_placement_history = []  # Store last 30 PE placements
        self.zscore_data_points = 0     # Track data collection progress
        self.zscore_ready = False       # Track if we have enough data
        self.last_zscore_calculation = None  # For debugging

    def get(self, key, default=None):
        """Dictionary-like get method for session state attributes"""
        return getattr(self, key, default)


# Load credentials from environment variables
def load_credentials(session_state):
    """Load credentials from JSON file or environment variables"""
    try:
        # Try to load from JSON file first
        with open('fyers_credentials.json', 'r') as f:
            creds = json.load(f)
            session_state.cid = creds.get('client_id', '')
            session_state.token = creds.get('access_token', '')
            print("✅ Credentials loaded from JSON file")
    except FileNotFoundError:
        # Fall back to environment variables if file doesn't exist
        print("⚠️ JSON file not found, checking environment variables")
        session_state.cid = os.getenv("FYERS_CID", session_state.cid)
        session_state.token = os.getenv("FYERS_TOKEN", session_state.token)
    except Exception as e:
        print(f"❌ Error loading credentials: {str(e)}")
        # Fall back to environment variables
        session_state.cid = os.getenv("FYERS CID", session_state.cid)
        session_state.token = os.getenv("FYERS_TOKEN", session_state.token)


# Rate limiting with improved logic
def enforce_rate_limit(session_state):
    now = datetime.now()
    window = now - session_state.api_window_start
    total_calls = session_state.option_chain_api_count + session_state.quote_api_count

    if window > timedelta(seconds=Config.API_WINDOW):
        session_state.api_window_start = now
        session_state.option_chain_api_count = 0
        session_state.quote_api_count = 0
    elif total_calls >= Config.API_RATE_LIMIT:
        wait = Config.API_WINDOW - window.seconds
        logging.warning(f"Approaching rate limit, waiting {wait}s...")
        print(f"⚠️ Approaching rate limit, waiting {wait}s...")
        time.sleep(wait)
        session_state.api_window_start = datetime.now()
        session_state.option_chain_api_count = 0
        session_state.quote_api_count = 0


# API calls with retry logic
@handle_errors
@lru_cache(maxsize=32)
def get_option_chain_data(session_state, cid, token, sym, expiry_ts=""):
    print(f"🔍 [DEBUG] Fetching option chain data for {sym}, expiry: {expiry_ts or 'nearest'}")
    enforce_rate_limit(session_state)
    session_state.option_chain_api_count += 1
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    resp = fy.optionchain(data={"symbol": sym, "timestamp": expiry_ts})
    if not resp or resp.get("code") != 200:
        error_msg = f"Option chain error ({expiry_ts or 'nearest'}): {resp.get('message', 'Unknown')}"
        logging.error(error_msg)
        print(f"❌ {error_msg}")
        return None
    print(f"✅ [DEBUG] Option chain data fetched successfully")
    return resp["data"]["optionsChain"]


@handle_errors
def get_underlying_ltp(session_state, cid, token, sym):
    print(f"🔍 [DEBUG] Fetching underlying LTP for {sym}")
    enforce_rate_limit(session_state)
    session_state.quote_api_count += 1
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    resp = fy.quotes(data={"symbols": sym})
    if not resp or resp.get("code") != 200 or not resp.get("d"):
        error_msg = f"Quotes API error ({resp.get('code')}): {resp.get('message', 'Unknown')}"
        logging.error(error_msg)
        print(f"❌ {error_msg}")
        return None
    ltp = resp["d"][0]["v"]["lp"]
    print(f"✅ [DEBUG] Underlying LTP: {ltp}")
    return ltp


@handle_errors
def get_symbol_ltp(session_state, cid, token, symbol):
    print(f"🔍 [DEBUG] Fetching LTP for {symbol}")
    enforce_rate_limit(session_state)
    session_state.quote_api_count += 1
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    resp = fy.quotes(data={"symbols": symbol})
    if not resp or resp.get("code") != 200 or not resp.get("d"):
        error_msg = f"Quotes API error for {symbol}: {resp.get('message', 'Unknown')}"
        logging.error(error_msg)
        print(f"❌ [error_msg]")
        return None
    ltp = resp["d"][0]["v"]["lp"]
    print(f"✅ [DEBUG] Symbol LTP: {ltp}")
    return ltp


MAX_HISTORY = 1  # last N signals for majority check
MAJORITY_THRESHOLD = 1  # number of same signals to confirm majority


def majority_signal(history, threshold=MAJORITY_THRESHOLD):
    """
    Determine majority signal from the history.
    Returns the majority signal if all signals in buffer are the same, else HOLD.
    """
    if not history or len(history) < threshold:
        return "HOLD"

    if all(signal == history[0] for signal in history):
        return history[0]

    return "HOLD"



def compute_signals(
        merged_df,
        atm_strike,
        ltp,
        fyers_api=None,
        session_state=None
):
    """
    Compute intraday trading signals using Z-score dynamic thresholds with EXIT -> Neutral -> ENTRY logic.
    Returns: "BUY", "SELL", "SIDEWAYS", or "HOLD"
    """
    print(f"🔍 [DEBUG] Computing signals for ATM strike: {atm_strike}, LTP: {ltp}")

    # ----------------------------
    # Config
    # ----------------------------
    ZSCORE_HISTORY_LENGTH = 30
    MIN_DATA_POINTS_REQUIRED = 30
    MAX_SMOOTH_HISTORY = 3

    try:
        # ----------------------------
        # Step 0: Initialize trade state / neutral reset
        # ----------------------------
        print(f"🔍 [DEBUG STEP 0] Initializing trade state / neutral reset")
        if session_state:
            if not hasattr(session_state, "trade_state"):
                session_state.trade_state = "FLAT"  # FLAT / LONG / SHORT
    

        # ----------------------------
        # Step 1: Check open positions via API (for hedge / ENTRY logic)
        # ----------------------------
        print(f"🔍 [DEBUG STEP 1] Checking open positions via API")
        has_pe_long = False
        has_ce_long = False
        try:
            if fyers_api:
                pos_resp = fyers_api.positions()
                if pos_resp.get("s") == "ok":
                    for p in pos_resp.get("netPositions", []):
                        qty = p.get("netQty", 0)
                        sym = (p.get("symbol") or "").upper()
                        if qty > 0 and "PE" in sym:
                            has_pe_long = True
                        if qty > 0 and "CE" in sym:
                            has_ce_long = True
        except Exception as e:
            print(f"⚠️ [DEBUG STEP 1] Position check failed: {e}")

        print(f"📊 [DEBUG STEP 1] Open positions: CE_long={has_ce_long}, PE_long={has_pe_long}")
        
        # ----------------------------
        # Step 2: Select ATM +/- 1 strikes
        # ----------------------------
        print(f"🔍 [DEBUG STEP 2] Selecting ATM +/- 1 strikes")
        strikes = sorted(merged_df["Strike"].dropna().unique())
        if atm_strike not in strikes:
            print(f"⚠️ [DEBUG STEP 2] ATM strike {atm_strike} not found")
            return "SIDEWAYS", {'ce_placement_avg': 0, 'pe_placement_avg': 0, 'net_flow': 0, 'direction_ratio': 0}

        atm_idx = strikes.index(atm_strike)
        selected_strikes = []
        if atm_idx > 0: selected_strikes.append(strikes[atm_idx - 1])
        selected_strikes.append(strikes[atm_idx])
        if atm_idx < len(strikes) - 1: selected_strikes.append(strikes[atm_idx + 1])

        print(f"📊 [DEBUG STEP 2] Selected strikes: {selected_strikes}")
        range_df = merged_df[merged_df["Strike"].isin(selected_strikes)].copy()

        # DEBUG: Show what we have in range_df
        print(f"🔍 [DEBUG STEP 2] Range df shape: {range_df.shape}")
        print(f"🔍 [DEBUG STEP 2] Range df has CE_symbol: {'CE_symbol' in range_df.columns}")
        print(f"🔍 [DEBUG STEP 2] Range df has PE_symbol: {'PE_symbol' in range_df.columns}")

        # ----------------------------
        # STEP 2.5: Fetch high/low data from quote API ONLY for range_df strikes
        # ----------------------------
        print(f"🔍 [DEBUG STEP 2.5] Fetching high/low data from quote API for range_df strikes")
        
        if fyers_api and {"CE_symbol", "PE_symbol"} <= set(range_df.columns):
            print(f"🔍 [DEBUG STEP 2.5] Both CE_symbol and PE_symbol columns exist, fetching quotes...")
            
            try:
                # Collect all symbols from range_df
                symbols = list(set(
                    range_df["CE_symbol"].dropna().tolist() + 
                    range_df["PE_symbol"].dropna().tolist()
                ))
                symbols = [s for s in symbols if isinstance(s, str) and s.strip()]
                print(f"🔍 [DEBUG STEP 2.5] Total symbols to fetch: {len(symbols)}")
                
                quotes = {}
                # Fetch in batches
                for i in range(0, len(symbols), 50):
                    batch = symbols[i:i + 50]
                    print(f"🔍 [DEBUG STEP 2.5] Fetching batch {i//50 + 1}: {len(batch)} symbols")
                    response = fyers_api.quotes({"symbols": ",".join(batch)})
                    
                    print(f"🔍 [DEBUG STEP 2.5] API response code: {response.get('code')}")
                    print(f"🔍 [DEBUG STEP 2.5] API response status: {response.get('s')}")
                    
                    if response.get("code") == 200:
                        # Extract quote data - using correct structure from your code
                        for item in response.get("d", []):
                            if item.get("s") == "ok":
                                symbol_name = item.get("n")
                                if symbol_name:
                                    quotes[symbol_name] = item.get("v", {})
                        print(f"🔍 [DEBUG STEP 2.5] Successfully fetched {len(quotes)} quotes")
                    else:
                        print(f"⚠️ [DEBUG STEP 2.5] API response not 200: {response}")

                # Update range_df with quote data
                print(f"🔍 [DEBUG STEP 2.5] Updating range_df with quote data...")
                
                # Initialize high/low columns if they don't exist
                if 'CE_high' not in range_df.columns:
                    range_df['CE_high'] = 0.0
                if 'CE_low' not in range_df.columns:
                    range_df['CE_low'] = 0.0
                if 'PE_high' not in range_df.columns:
                    range_df['PE_high'] = 0.0   
                if 'PE_low' not in range_df.columns:
                    range_df['PE_low'] = 0.0
                
                # Also update LTP from quotes for accuracy
                if 'CE_ltp' not in range_df.columns:
                    range_df['CE_ltp'] = 0.0
                if 'PE_ltp' not in range_df.columns:
                    range_df['PE_ltp'] = 0.0
                
                for idx, row in range_df.iterrows():
                    ce_symbol = row.get("CE_symbol")
                    pe_symbol = row.get("PE_symbol")
                    
                    # Update CE data
                    if ce_symbol and ce_symbol in quotes:
                        ce_data = quotes[ce_symbol]
                        ce_ltp = float(ce_data.get("lp", 0) or 0)
                        ce_high = float(ce_data.get("high_price", 0) or 0)
                        ce_low = float(ce_data.get("low_price", 0) or 0)
                        
                        range_df.at[idx, "CE_ltp"] = ce_ltp
                        range_df.at[idx, "CE_high"] = ce_high
                        range_df.at[idx, "CE_low"] = ce_low
                        
                        print(f"🔍 [DEBUG STEP 2.5] CE {ce_symbol}: LTP={ce_ltp}, High={ce_high}, Low={ce_low}")
                    
                    # Update PE data
                    if pe_symbol and pe_symbol in quotes:
                        pe_data = quotes[pe_symbol]
                        pe_ltp = float(pe_data.get("lp", 0) or 0)
                        pe_high = float(pe_data.get("high_price", 0) or 0)
                        pe_low = float(pe_data.get("low_price", 0) or 0)
                        
                        range_df.at[idx, "PE_ltp"] = pe_ltp
                        range_df.at[idx, "PE_high"] = pe_high
                        range_df.at[idx, "PE_low"] = pe_low
                        
                        print(f"🔍 [DEBUG STEP 2.5] PE {pe_symbol}: LTP={pe_ltp}, High={pe_high}, Low={pe_low}")
                
                print(f"✅ [DEBUG STEP 2.5] Successfully updated range_df with quote data")
                
            except Exception as e:
                print(f"⚠️ [DEBUG STEP 2.5] Error fetching quotes: {str(e)}")
                import traceback
                traceback.print_exc()
        else:
            print(f"⚠️ [DEBUG STEP 2.5] Cannot fetch quotes - missing columns or API")
            if not fyers_api:
                print(f"⚠️ [DEBUG STEP 2.5] No fyers_api provided")
            if "CE_symbol" not in range_df.columns:
                print(f"⚠️ [DEBUG STEP 2.5] CE_symbol column missing")
            if "PE_symbol" not in range_df.columns:
                print(f"⚠️ [DEBUG STEP 2.5] PE_symbol column missing")

        # Show the high/low values we'll use
        print(f"🔍 [DEBUG STEP 2.5] Final high/low values for range_df:")
        for idx, row in range_df.iterrows():
            strike = row.get('Strike', 'N/A')
            print(f"  Strike {strike}:")
            print(f"    CE: high={row.get('CE_high', 0)}, low={row.get('CE_low', 0)}, ltp={row.get('CE_ltp', 0)}")
            print(f"    PE: high={row.get('PE_high', 0)}, low={row.get('PE_low', 0)}, ltp={row.get('PE_ltp', 0)}")

        # ----------------------------
        # Step 3: Range placement logic
        # ----------------------------
        print(f"🔍 [DEBUG STEP 3] Calculating range placement")
        
        # Debug: Show what we're calculating
        for idx, row in range_df.iterrows():
            strike = row.get('Strike', 'N/A')
            ce_high = row.get('CE_high', 0)
            ce_low = row.get('CE_low', 0)
            ce_ltp = row.get('CE_ltp', 0)
            pe_high = row.get('PE_high', 0)
            pe_low = row.get('PE_low', 0)
            pe_ltp = row.get('PE_ltp', 0)
            
            print(f"  Strike {strike}:")
            print(f"    CE: ({ce_ltp}-{ce_low})/({ce_high}-{ce_low}) = ", end="")
            if ce_high - ce_low > 0:
                print(f"({ce_ltp-ce_low:.2f})/({ce_high-ce_low:.2f}) = {(ce_ltp-ce_low)/(ce_high-ce_low):.6f}")
            else:
                print(f"0 (denominator <= 0)")
            
            print(f"    PE: ({pe_ltp}-{pe_low})/({pe_high}-{pe_low}) = ", end="")
            if pe_high - pe_low > 0:
                print(f"({pe_ltp-pe_low:.2f})/({pe_high-pe_low:.2f}) = {(pe_ltp-pe_low)/(pe_high-pe_low):.6f}")
            else:
                print(f"0 (denominator <= 0)")
        
        # Original logic - unchanged
        range_df["CE_range_placement"] = np.where(
            (range_df.get("CE_high", 0) - range_df.get("CE_low", 0)) > 0,
            (range_df.get("CE_ltp", 0) - range_df.get("CE_low", 0)) / (range_df.get("CE_high", 0) - range_df.get("CE_low", 0)), 0
        )
        range_df["PE_range_placement"] = np.where(
            (range_df.get("PE_high", 0) - range_df.get("PE_low", 0)) > 0,
            (range_df.get("PE_ltp", 0) - range_df.get("PE_low", 0)) / (range_df.get("PE_high", 0) - range_df.get("PE_low", 0)), 0
        )

        print(f"🔍 [DEBUG STEP 3] Calculated placements:")
        for idx, row in range_df.iterrows():
            strike = row.get('Strike', 'N/A')
            ce_place = row.get('CE_range_placement', 0)
            pe_place = row.get('PE_range_placement', 0)
            print(f"  Strike {strike}: CE_placement={ce_place:.6f}, PE_placement={pe_place:.6f}")

        ce_per_bar = range_df["CE_range_placement"].mean()
        pe_per_bar = range_df["PE_range_placement"].mean()
        print(f"📊 [DEBUG STEP 3] CE mean placement: {ce_per_bar:.6f}, PE mean placement: {pe_per_bar:.6f}")

        # ----------------------------
        # Step 4: Temporal smoothing
        # ----------------------------
        print(f"🔍 [DEBUG STEP 4] Temporal smoothing")
        if session_state:
            if not hasattr(session_state, "ce_placement_buffer"): session_state.ce_placement_buffer = []
            if not hasattr(session_state, "pe_placement_buffer"): session_state.pe_placement_buffer = []

            session_state.ce_placement_buffer.append(ce_per_bar)
            session_state.pe_placement_buffer.append(pe_per_bar)
            session_state.ce_placement_buffer = session_state.ce_placement_buffer[-MAX_SMOOTH_HISTORY:]
            session_state.pe_placement_buffer = session_state.pe_placement_buffer[-MAX_SMOOTH_HISTORY:]

            ce_placement_avg = np.mean(session_state.ce_placement_buffer)
            pe_placement_avg = np.mean(session_state.pe_placement_buffer)

            print(f"📊 [DEBUG STEP 4] CE buffer: {session_state.ce_placement_buffer} -> smoothed avg: {ce_placement_avg:.3f}")
            print(f"📊 [DEBUG STEP 4] PE buffer: {session_state.pe_placement_buffer} -> smoothed avg: {pe_placement_avg:.3f}")
        else:
            ce_placement_avg = ce_per_bar
            pe_placement_avg = pe_per_bar

        # ----------------------------
        # Step 5: Z-score calculation
        # ----------------------------
        print(f"🔍 [DEBUG STEP 5] Z-score calculation")
        if session_state:
            if not hasattr(session_state, "ce_placement_history"): session_state.ce_placement_history = []
            if not hasattr(session_state, "pe_placement_history"): session_state.pe_placement_history = []

            session_state.ce_placement_history.append(ce_placement_avg)
            session_state.pe_placement_history.append(pe_placement_avg)
            if len(session_state.ce_placement_history) > ZSCORE_HISTORY_LENGTH:
                session_state.ce_placement_history.pop(0)
                session_state.pe_placement_history.pop(0)
            session_state.zscore_data_points = len(session_state.ce_placement_history)
            session_state.zscore_ready = session_state.zscore_data_points >= MIN_DATA_POINTS_REQUIRED

        ce_z, _ = calculate_z_score_dynamic(ce_placement_avg,
                                            session_state.ce_placement_history if session_state else [],
                                            history_length=ZSCORE_HISTORY_LENGTH,
                                            min_data_points=MIN_DATA_POINTS_REQUIRED)
        pe_z, _ = calculate_z_score_dynamic(pe_placement_avg,
                                            session_state.pe_placement_history if session_state else [],
                                            history_length=ZSCORE_HISTORY_LENGTH,
                                            min_data_points=MIN_DATA_POINTS_REQUIRED)

        # ----------------------------
        # Step 6: EXIT → Neutral → ENTRY logic
        # ----------------------------
        raw_signal = "HOLD"

        if session_state and session_state.zscore_ready:
            # 1️⃣ EXIT
            if has_ce_long and pe_z > 2 and ce_z < -2:
                raw_signal = "SIDEWAYS"
                session_state.trade_state = "FLAT"
                print(f"⚡ [EXIT] LONG exited (PE z={pe_z:.2f}, CE z={ce_z:.2f})")

            elif has_pe_long and ce_z > 2 and pe_z < -2:
                raw_signal = "SIDEWAYS"
                session_state.trade_state = "FLAT"
                print(f"⚡ [EXIT] SHORT exited (CE z={ce_z:.2f}, PE z={pe_z:.2f})")

            # 2️⃣ ENTRY — block compression (both < 0.25)
            elif pe_placement_avg < 0.25 and ce_placement_avg < 0.25:
                print(
                    f"🟡 [BLOCKED] Both CE and PE placements low, no ENTRY signal generated "
                    f"(CE placement={ce_placement_avg:.3f}, "
                    f"PE placement={pe_placement_avg:.3f})"
                )
            else:
                if (pe_z > 1 and pe_z < 1.5) and (ce_z < -1 and ce_z > -1.5) and not has_ce_long and pe_placement_avg < 0.25 and ce_placement_avg > 0.75:
                    raw_signal = "BUY"
                    session_state.trade_state = "LONG"
                    print(f"✅ [ENTRY] BUY triggered (PE z={pe_z:.2f}, CE z={ce_z:.2f})")

                elif (ce_z > 1 and ce_z < 1.5) and (pe_z < -1 and pe_z > -1.5) and not has_pe_long and ce_placement_avg < 0.25 and pe_placement_avg > 0.75:
                    raw_signal = "SELL"
                    session_state.trade_state = "SHORT"
                    print(f"✅ [ENTRY] SELL triggered (CE z={ce_z:.2f}, PE z={pe_z:.2f})")

        else:
            raw_signal = "HOLD"
            print("⏳ [Z-SCORE] Waiting for sufficient data points for trading")


        # ----------------------------
        # Step 7: Signal smoothing (majority)
        # ----------------------------
        if session_state:
            if not hasattr(session_state, "signal_buffer"): session_state.signal_buffer = []
            session_state.signal_buffer.append(raw_signal)
            if len(session_state.signal_buffer) > MAX_HISTORY:
                session_state.signal_buffer.pop(0)
            print(f"📊 [DEBUG] Signal Buffer: {session_state.signal_buffer}")
            final_signal = majority_signal(session_state.signal_buffer)
        else:
            final_signal = raw_signal

        # ----------------------------
        # Step 8: Debug Summary
        # ----------------------------
        print(f"\n" + "="*50)
        print(f"\n🎯 [DEBUG SUMMARY]")
        print(f"📊 ATM Strike: {atm_strike}, LTP: {ltp:.2f}")
        print(f"📊 Open CE_long={has_ce_long}, PE_long={has_pe_long}")
        print(f"📊 Trade State: {session_state.trade_state if session_state else 'N/A'}")
        print(f"📊 CE Placement Avg: {ce_placement_avg:.3f}, PE Placement Avg: {pe_placement_avg:.3f}")
        print(f"📊 CE Z: {ce_z:.3f}, PE Z: {pe_z:.3f}")
        print(f"📊 Raw Signal: {raw_signal}, Final Signal: {final_signal}")
        print(f"\n" + "="*50)

        metrics = {
            'ce_placement_avg': ce_placement_avg,
            'pe_placement_avg': pe_placement_avg,
            'ce_z_score': ce_z,
            'pe_z_score': pe_z,
            'using_dynamic_thresholds': session_state.zscore_ready if session_state else False,
            'signal': final_signal,
            'has_ce_long': has_ce_long ,
            'has_pe_long': has_pe_long
        }

        return final_signal, metrics

    except Exception as e:
        logging.error(f"Error in compute_signals: {str(e)}", exc_info=True)
        print(f"❌ [DEBUG] Error in compute_signals: {str(e)}")
        return "SIDEWAYS", {'ce_placement_avg': 0, 'pe_placement_avg': 0, 'net_flow': 0, 'direction_ratio': 0, 'has_ce_short': False, 'has_pe_short': False}


def select_strikes_atm_half_price(chain, atm_strike):
    """
    Strategy:
      - BUY ATM (both CE & PE)
      - SELL OTM where LTP ≈  ATM LTP / 4
    """
    print(f"🔍 [DEBUG] Selecting strikes for ATM Buy / OTM Sell: {atm_strike}")
    try:
        df = pd.DataFrame(chain)
        if df.empty or atm_strike is None:
            print("⚠️ [DEBUG] No data or ATM strike for selection")
            return None, None, None, None

        ce = df[df["option_type"] == "CE"].copy()
        pe = df[df["option_type"] == "PE"].copy()

        # ---------------- ATM Buy legs ----------------
        atm_pe_row = pe[pe["strike_price"] == atm_strike]
        atm_ce_row = ce[ce["strike_price"] == atm_strike]

        buy_pe_row = atm_pe_row.iloc[0].to_dict() if not atm_pe_row.empty else None
        buy_ce_row = atm_ce_row.iloc[0].to_dict() if not atm_ce_row.empty else None

        # ---------------- OTM Sell legs (half price) ----------------
        sell_pe_row, sell_ce_row = None, None

        if buy_pe_row and "ltp" in buy_pe_row and buy_pe_row["ltp"] > 0:
            target = buy_pe_row["ltp"] / 4
            # Only consider OTM PEs (strike < ATM strike)
            pe_candidates = pe[pe["strike_price"] < atm_strike].copy()
            pe_candidates["ltp_diff"] = (pe_candidates["ltp"] - target).abs()
            if not pe_candidates.empty:
                sell_pe_row = pe_candidates.nsmallest(1, "ltp_diff").iloc[0].to_dict()

        if buy_ce_row and "ltp" in buy_ce_row and buy_ce_row["ltp"] > 0:
            target = buy_ce_row["ltp"] / 4
            # Only consider OTM CEs (strike > ATM strike)
            ce_candidates = ce[ce["strike_price"] > atm_strike].copy()
            ce_candidates["ltp_diff"] = (ce_candidates["ltp"] - target).abs()
            if not ce_candidates.empty:
                sell_ce_row = ce_candidates.nsmallest(1, "ltp_diff").iloc[0].to_dict()

        # print(f"✅ [DEBUG] Strike selection complete:")
        # print(f"   - BUY PE: {buy_pe_row['symbol'] if buy_pe_row else 'None'}")
        # print(f"   - SELL PE (OTM): {sell_pe_row['symbol'] if sell_pe_row else 'None'}")
        # print(f"   - BUY CE: {buy_ce_row['symbol'] if buy_ce_row else 'None'}")
        # print(f"   - SELL CE (OTM): {sell_ce_row['symbol'] if sell_ce_row else 'None'}")

        print(f"✅ [DEBUG] Strike selection complete:")
        print(f"   - BUY PE : {buy_pe_row['symbol'] if buy_pe_row else 'None'} @ {buy_pe_row['ltp'] if buy_pe_row else 'N/A'}")
        print(f"   - SELL PE : {sell_pe_row['symbol'] if sell_pe_row else 'None'} @ {sell_pe_row['ltp'] if sell_pe_row else 'N/A'}")
        print(f"   - BUY CE : {buy_ce_row['symbol'] if buy_ce_row else 'None'} @ {buy_ce_row['ltp'] if buy_ce_row else 'N/A'}")
        print(f"   - SELL CE : {sell_ce_row['symbol'] if sell_ce_row else 'None'} @ {sell_ce_row['ltp'] if sell_ce_row else 'N/A'}")


        return buy_pe_row, sell_pe_row, buy_ce_row, sell_ce_row

    except Exception as e:
        logging.error(f"Error in select_strikes_atm_half_price: {str(e)}", exc_info=True)
        print(f"❌ [DEBUG] Error in select_strikes_atm_half_price: {str(e)}")
        return None, None, None, None


# def select_strikes_atm_half_price(chain, atm_strike):

#     # print("\n" + "=" * 80)
#     print(f"🔍 [DEBUG] Selecting strikes | ATM: {atm_strike}")

#     try:
#         df = pd.DataFrame(chain)
#         if df.empty or atm_strike is None:
#             print("❌ Empty option chain or ATM missing")
#             return None, None, None, None

#         # Ensure strike_price is int
#         df["strike_price"] = df["strike_price"].astype(int)

#         ce = df[df["option_type"] == "CE"].copy()
#         pe = df[df["option_type"] == "PE"].copy()

#         # ATM rows
#         atm_pe = pe[pe["strike_price"] == atm_strike]
#         atm_ce = ce[ce["strike_price"] == atm_strike]

#         if atm_pe.empty or atm_ce.empty:
#             print("❌ ATM option not found in chain")
#             return None, None, None, None

#         atm_pe_price = atm_pe["ltp"].iloc[0]
#         atm_ce_price = atm_ce["ltp"].iloc[0]

#         print(f"📌 ATM PE Price: {atm_pe_price}")
#         print(f"📌 ATM CE Price: {atm_ce_price}")

#         # ================= BUY LEGS (ATM) =================
#         buy_pe_row = atm_pe.iloc[0].to_dict()
#         buy_ce_row = atm_ce.iloc[0].to_dict()

#         # ================= SELL PE (ITM PE → strike > ATM) =================
#         pe_target = atm_pe_price * 2
#         print(f"🔴 SELL PE Target (2× ATM PE): {pe_target}")

#         pe_candidates = pe[pe["strike_price"] > atm_strike].copy()
#         pe_candidates["price_diff"] = (pe_candidates["ltp"] - pe_target).abs()

#         # print("🔹 Top ITM PE candidates (closest to target):")
#         # print(
#         #     pe_candidates.sort_values("price_diff")[
#         #         ["strike_price", "ltp", "price_diff"]
#         #     ].head(5)
#         # )

#         sell_pe_row = pe_candidates.nsmallest(1, "price_diff").iloc[0].to_dict()

#         # ================= SELL CE (ITM CE → strike < ATM) =================
#         ce_target = atm_ce_price * 2
#         print(f"🔵 SELL CE Target (2× ATM CE): {ce_target}")

#         ce_candidates = ce[ce["strike_price"] < atm_strike].copy()
#         ce_candidates["price_diff"] = (ce_candidates["ltp"] - ce_target).abs()

#         # print("🔹 Top ITM CE candidates (closest to target):")
#         # print(
#         #     ce_candidates.sort_values("price_diff")[
#         #         ["strike_price", "ltp", "price_diff"]
#         #     ].head(5)
#         # )

#         sell_ce_row = ce_candidates.nsmallest(1, "price_diff").iloc[0].to_dict()

#         # ================= FINAL OUTPUT =================
#         print("\n✅ [DEBUG] FINAL STRIKES SELECTED:")
#         print(f"   BUY  PE : {buy_pe_row['symbol']} @ {buy_pe_row['ltp']}")
#         print(f"   SELL PE : {sell_pe_row['symbol']} @ {sell_pe_row['ltp']}")
#         print(f"   BUY  CE : {buy_ce_row['symbol']} @ {buy_ce_row['ltp']}")
#         print(f"   SELL CE : {sell_ce_row['symbol']} @ {sell_ce_row['ltp']}")
#         print("=" * 80 + "\n")

#         return buy_pe_row, sell_pe_row, buy_ce_row, sell_ce_row

#     except Exception as e:
#         logging.error(f"Error in select_strikes_atm_half_price: {e}", exc_info=True)
#         print(f"❌ Exception: {e}")
#         return None, None, None, None


# Order management with improved error handling
@handle_errors
def cancel_order(fyers, order_id):
    print(f"🔍 [DEBUG] Cancelling order: {order_id}")
    try:
        resp = fyers.cancel_order(data={"id": order_id})
        logging.info(f"Cancelled order {order_id}: {resp}")
        print(f"✅ [DEBUG] Order {order_id} cancelled: {resp}")
        return resp
    except Exception as e:
        logging.error(f"Exception while cancelling order {order_id}: {e}", exc_info=True)
        print(f"❌ [DEBUG] Error cancelling order {order_id}: {e}")
        raise


@handle_errors
def get_order_status_by_id(fyers, order_id):
    print(f"🔍 [DEBUG] Getting status for order: {order_id}")
    try:
        orderbook = fyers.orderbook()
        for o in orderbook.get("orderBook", []):
            if o.get("id") == order_id:
                status = o.get("status")
                print(f"✅ [DEBUG] Order {order_id} status: {status}")
                return status
        print(f"⚠️ [DEBUG] Order {order_id} not found in orderbook")
        return None
    except Exception as e:
        logging.warning(f"Could not fetch order status for {order_id}: {e}")
        print(f"❌ [DEBUG] Error getting order status for {order_id}: {e}")
        return None


@handle_errors
def place_order_and_check(fyers, order):
    print(f"🔍 [DEBUG] Placing order: {order}")
    try:
        resp = fyers.place_order(data=order)
        logging.info(f"Order placed for {order['symbol']}: {resp}")
        print(f"✅ [DEBUG] Order placed: {resp}")

        if resp.get("s") == "ok":
            oid = resp.get("id")
            time.sleep(2)  # Wait for order to process
            status = get_order_status_by_id(fyers, oid)
            if status in [1, 5]:  # Rejected or canceled
                logging.error(f"Order {oid} was rejected or canceled. Status: {status}")
                print(f"❌ [DEBUG] Order {oid} was rejected or canceled. Status: {status}")
                return None, status
            logging.info(f"Order {oid} status: {status}")
            print(f"✅ [DEBUG] Order {oid} status: {status}")
            return oid, status
        else:
            logging.error(f"Order failed: {resp}")
            print(f"❌ [DEBUG] Order failed: {resp}")
            return None, None
    except Exception as e:
        logging.exception(f"Place order error: {e}")
        print(f"❌ [DEBUG] Place order error: {e}")
        raise


def has_open_orders_for_last_signal(fyers, session_state):
    print(f"🔍 [DEBUG] Checking open orders for last signal")

    # First check if we have any actual positions
    try:
        pos_resp = fyers.positions()
        if pos_resp.get("s") == "ok":
            net_positions = [p for p in pos_resp.get("netPositions", [])
                             if abs(p.get("netQty", 0)) != 0]
            if not net_positions:
                print(f"✅ [DEBUG] No active positions found")
                session_state.last_signal_order_ids = []  # Clear stale order IDs
                return False
            else:
                print(f"📊 [DEBUG] Found {len(net_positions)} active positions")
                for p in net_positions:
                    print(f"  - {p.get('symbol')}: {p.get('netQty')} units")
                return True
    except Exception as e:
        print(f"❌ [DEBUG] Error checking positions: {e}")

    # Fallback to order book check
    ids = session_state.live_last_signal_order_ids
    if not ids:
        print("✅ [DEBUG] No order IDs for last signal")
        return False

    try:
        ob = fyers.orderbook()
        if ob and "orderBook" in ob:
            # Check for open orders (status 2 = open, 1 = completed, 5 = cancelled)
            open_orders = [o for o in ob["orderBook"]
                           if o.get("id") in ids and o.get("status") == 2]
            has_open = len(open_orders) > 0
            print(f"✅ [DEBUG] Open orders for last signal: {has_open} ({len(open_orders)} orders)")
            return has_open
        print("⚠️ [DEBUG] No order book data")
        return False
    except Exception as e:
        logging.warning(f"Could not check open orders: {e}")
        print(f"❌ [DEBUG] Error checking open orders: {e}")
        return False


def handle_basket_orders_atomic(session_state, signal, sell_pe, buy_pe, sell_ce, buy_ce, fyers, data_logger):
    print(f"\n🔍 [DEBUG] Handling basket orders for signal: {signal}")

    # ------- simple lock to avoid overlapping runs -------
    if session_state._hb_lock:
        print("⚠️ [DEBUG] Another rebalance is already running. Skipping this cycle.")
        return []
    session_state._hb_lock = True

    placed_ids = []
    try:
        lot = Config.LOT_SIZE
        current_signal = session_state.last_signal
        print(f"🔄 [DEBUG] Current signal: {current_signal}, Incoming signal: {signal}")

        # ---------- helper: wait until positions are flat ----------
        def _wait_until_flat(timeout=28, interval=2):
            """Poll positions until no netQty remains, or timeout."""
            print(f"⏳ [DEBUG] Waiting up to {timeout}s for positions to flatten...")
            end = time.time() + timeout
            while time.time() < end:
                pos_resp = fyers.positions()
                print(f"📡 [DEBUG] Polled positions response: {pos_resp}")
                if pos_resp.get("s") == "ok":
                    still_open = [p for p in pos_resp.get("netPositions", [])
                                  if abs(p.get("netQty", 0)) != 0]
                    if not still_open:
                        print("✅ [DEBUG] All positions are flat now.")
                        return True
                    else:
                        print(f"⏳ [DEBUG] Still open positions: "
                              f"{[(p['symbol'], p['netQty']) for p in still_open]}")
                else:
                    print(f"❌ [DEBUG] Positions API error while waiting: {pos_resp}")
                time.sleep(interval)
            print("❌ [DEBUG] Timeout: positions did not flatten in time.")
            return False

        # ---------- current positions ----------
        pos_resp = fyers.positions()
        print(f"📡 [DEBUG] Initial positions API response: {pos_resp}")
        net_positions = []
        if pos_resp.get("s") == "ok":
            net_positions = [p for p in pos_resp.get("netPositions", [])
                             if abs(p.get("netQty", 0)) != 0]

        print(f"🔍 [DEBUG] Found {len(net_positions)} active positions at start:")
        for p in net_positions:
            print(f"  - {p.get('symbol')}: {p.get('netQty')} units")

        # ============================================================
        # 1) Handle HOLD signal (maintain existing positions)
        # ============================================================
        if signal == "HOLD":
            print("📊 [DEBUG] HOLD signal → Maintaining existing positions.")
            # Do nothing, just keep existing positions
            return []

        # ============================================================
        # 2) Handle SIDEWAYS signal (exit all positions)
        # ============================================================
        if signal == "SIDEWAYS" and Config.EXIT_ON_SIDEWAYS == True:
            print("📊 [DEBUG] SIDEWAYS signal -> EXIT_ON_SIDEWAYS == True -> Exiting all positions.")

            if not net_positions:
                print("✅ [DEBUG] No positions to exit for SIDEWAYS signal.")
                session_state.last_signal = signal
                return []

            try:
                # Track PNL for exit
                timestamp = datetime.now(pytz.timezone("Asia/Kolkata")).strftime("%Y-%m-%d %H:%M:%S")
                for position in net_positions:
                    symbol = position.get('symbol', '')
                    net_qty = position.get('netQty', 0)
                    avg_price = position.get('avgPrice', 0)
                    # For PNL calculation, we'd need current market price
                    # This is simplified - you might want to enhance this
                    data_logger.log_pnl(
                        timestamp=timestamp,
                        signal=signal,
                        entry_price=avg_price,
                        exit_price=avg_price,  # Simplified - use actual exit price
                        quantity=abs(net_qty),
                        pnl=0,  # Simplified - calculate actual PNL
                        trade_type="EXIT"
                    )

                # Exit all positions
                exit_shorts = {"segment": [11], "side": [-1], "productType": ["MARGIN"]}
                print(f"📤 [DEBUG] Sending SHORT exit request: {exit_shorts}")
                resp_short = fyers.exit_positions(data=exit_shorts)
                print(f"📥 [DEBUG] SHORT exit response: {resp_short}")

                exit_longs = {"segment": [11], "side": [1], "productType": ["MARGIN"]}
                print(f"📤 [DEBUG] Sending LONG exit request: {exit_longs}")
                resp_long = fyers.exit_positions(data=exit_longs)
                print(f"📥 [DEBUG] LONG exit response: {resp_long}")

                # Verify flattening
                if not _wait_until_flat(timeout=60, interval=2):
                    print("❌ [DEBUG] Flattening failed after exit. Manual check needed.")
                    return placed_ids

                print("✅ [DEBUG] All positions successfully exited for SIDEWAYS signal.")
                session_state.last_signal = signal
                return []

            except Exception as e:
                print(f"❌ [DEBUG] Exception during SIDEWAYS exit sequence: {str(e)}")
                return placed_ids
        if signal == "SIDEWAYS" and Config.EXIT_ON_SIDEWAYS == False:
            print("📊 [DEBUG] SIDEWAYS signal -> EXIT_ON_SIDEWAYS == False -> Holding all positions.")
            return []
        # ============================================================
        # 3) FLATTEN on SIGNAL CHANGE (BUY/SELL to different BUY/SELL)
        # ============================================================
        if current_signal in ["BUY", "SELL"] and current_signal != signal and net_positions:
            print(f"⚠️ [DEBUG] Signal changed ({current_signal} → {signal}). "
                  f"Attempting to exit ALL open positions step by step...")

            try:
                # Track PNL for exit
                timestamp = datetime.now(pytz.timezone("Asia/Kolkata")).strftime("%Y-%m-%d %H:%M:%S")
                for position in net_positions:
                    symbol = position.get('symbol', '')
                    net_qty = position.get('netQty', 0)
                    avg_price = position.get('avgPrice', 0)
                    # Simplified PNL tracking
                    data_logger.log_pnl(
                        timestamp=timestamp,
                        signal=current_signal,
                        entry_price=avg_price,
                        exit_price=avg_price,  # Use actual exit price if available
                        quantity=abs(net_qty),
                        pnl=0,  # Calculate actual PNL
                        trade_type="EXIT"
                    )

                # Step 1: Exit SHORT legs
                exit_shorts = {"segment": [11], "side": [-1], "productType": ["MARGIN"]}
                print(f"📤 [DEBUG] Sending SHORT exit request: {exit_shorts}")
                resp_short = fyers.exit_positions(data=exit_shorts)
                print(f"📥 [DEBUG] SHORT exit response: {resp_short}")

                # Step 2: Exit LONG legs
                exit_longs = {"segment": [11], "side": [1], "productType": ["MARGIN"]}
                print(f"📤 [DEBUG] Sending LONG exit request: {exit_longs}")
                resp_long = fyers.exit_positions(data=exit_longs)
                print(f"📥 [DEBUG] LONG exit response: {resp_long}")

                # Step 3: Verify flattening
                if not _wait_until_flat(timeout=60, interval=2):
                    print("❌ [DEBUG] Flattening failed after exit. Manual check needed.")
                    return placed_ids

                print("✅ [DEBUG] All positions successfully exited for signal change.")

            except Exception as e:
                print(f"❌ [DEBUG] Exception during exit sequence: {str(e)}")
                return placed_ids

        # ============================================================
        # 4) ENTER NEW BASKET for BUY/SELL signals (only if nothing is open)
        # ============================================================
        # signal_map = {
        #     "BUY": {"enter_hedge": buy_pe, "enter_short": sell_pe},
        #     "SELL": {"enter_hedge": buy_ce, "enter_short": sell_ce}
        # }
        signal_map = {
            "BUY": {"enter_hedge": buy_ce, "enter_short": sell_ce},
            "SELL": {"enter_hedge": buy_pe, "enter_short": sell_pe}
        }
        pos_resp = fyers.positions()
        print(f"📡 [DEBUG] Positions before entry: {pos_resp}")
        current_positions = []
        if pos_resp.get("s") == "ok":
            current_positions = [p for p in pos_resp.get("netPositions", [])
                                 if abs(p.get("netQty", 0)) != 0]

        if current_positions:
            print("⚠️ [DEBUG] Some positions are STILL open → Skipping new entry.")
            for p in current_positions:
                print(f"  - OPEN: {p.get('symbol')} {p.get('netQty')}")
            return placed_ids

        # Basket entry
        enter_hedge = signal_map[signal]["enter_hedge"]
        enter_short = signal_map[signal]["enter_short"]

        print(f"📥 [DEBUG] Preparing new {signal} basket entry:")
        print(f"  - Hedge leg (BUY): {enter_hedge}")
        print(f"  - Short leg (SELL): {enter_short}")

        entry_basket = [
            {
                "symbol": enter_hedge["symbol"],
                "qty": lot,
                "type": 2,
                "side": 1,
                "productType": "MARGIN",
                "validity": "DAY",
            },
            {
                "symbol": enter_short["symbol"],
                "qty": lot,
                "type": 2,
                "side": -1,
                "productType": "MARGIN",
                "validity": "DAY",
            }
        ]

        print(f"📤 [DEBUG] Sending basket order request: {entry_basket}")
        entry_resp = fyers.place_basket_orders(data=entry_basket)
        print(f"📥 [DEBUG] Basket order response: {entry_resp}")

        if entry_resp and entry_resp.get("s") == "ok":
            for item in entry_resp.get("data", []):
                body = item.get("body", {})
                if body.get("s") == "ok" and body.get("id"):
                    placed_ids.append(body["id"])

            # Track entry for PNL
            timestamp = datetime.now(pytz.timezone("Asia/Kolkata")).strftime("%Y-%m-%d %H:%M:%S")
            if enter_hedge and "ltp" in enter_hedge:
                data_logger.log_pnl(
                    timestamp=timestamp,
                    signal=signal,
                    entry_price=enter_hedge["ltp"],
                    exit_price=0,
                    quantity=lot,
                    pnl=0,
                    trade_type="ENTRY"
                )

            session_state.last_signal = signal
            print(f"✅ [DEBUG] Successfully entered new {signal} basket orders → IDs: {placed_ids}")
        else:
            msg = entry_resp.get("message", "Unknown error") if isinstance(entry_resp, dict) else "Unknown error"
            print(f"❌ [DEBUG] Basket order FAILED. Reason: {msg}")

        return placed_ids

    except Exception as e:
        print(f"❌ [DEBUG] Fatal error in handle_basket_orders_atomic: {str(e)}")
        return []
    finally:
        session_state._hb_lock = False
        print("🔓 [DEBUG] Lock released.\n")


# Data display functions with improved formatting
def format_and_show(chain, title, ltp, show_signals=False, fyers_api=None, session_state=None):
    print(f"🔍 [DEBUG] Formatting and displaying data for: {title}")
    df = pd.DataFrame(chain)
    if df.empty:
        print(f"ℹ️ [DEBUG] No data for {title}")
        return None, None, None

    # Process CE and PE data
    ce = df[df["option_type"] == "CE"]
    pe = df[df["option_type"] == "PE"]

    # Define columns and rename them
    cols = ["symbol", "strike_price", "oi", "volume", "ltp", "ask", "bid",
            "ltpch", "ltpchp", "oich", "oichp", "prev_oi"]

    ce_df = ce[cols].rename(columns={
        "strike_price": "Strike",
        "oi": "OI",
        "volume": "Vol",
        "ltpch": "LTPCh",
        "ltpchp": "LTPChP",
        "oich": "OICh",
        "oichp": "OIChP",
        "prev_oi": "PrevOI"
    })

    pe_df = pe[cols].rename(columns={
        "strike_price": "Strike",
        "oi": "OI",
        "volume": "Vol",
        "ltpch": "LTPCh",
        "ltpchp": "LTPChP",
        "oich": "OICh",
        "oichp": "OIChP",
        "prev_oi": "PrevOI"
    })

    # Merge CE and PE data
    merged = pd.merge(
        ce_df.add_prefix("CE_"),
        pe_df.add_prefix("PE_"),
        left_on="CE_Strike",
        right_on="PE_Strike",
        how="outer"
    ).rename(columns={"CE_Strike": "Strike"}).drop("PE_Strike", axis=1)

    # Find ATM strike
    atm = None
    if ltp is not None and not merged["Strike"].dropna().empty:
        atm = min(merged["Strike"].dropna(), key=lambda x: abs(x - ltp))

    print(f"\n📈 {title}")

    if show_signals and atm is not None:
        # Calculate all required metrics
        strikes = sorted(merged["Strike"].dropna().unique().tolist())
        idx = strikes.index(atm)
        signal, metrics = compute_signals(merged, atm, ltp, fyers_api=fyers_api, session_state=session_state)
        # Display results with improved formatting
        print(f"✅ Signal: {signal}")

    # Display the dataframe
    print(f"📊 ATM Strike: {atm} | Underlying LTP: {ltp}")
    # print(merged.to_string(index=False))

    if show_signals and atm is not None:
        return signal, atm, metrics
    return None, atm, None


@handle_errors
def update_all_data(session_state, cid, token, sym):
    print(f"🔍 [DEBUG] Updating all data for {sym}")
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    enforce_rate_limit(session_state)
    session_state.option_chain_api_count += 1

    meta = fy.optionchain(data={"symbol": sym, "timestamp": ""})
    if meta.get("code") != 200:
        print(f"❌ [DEBUG] Option chain API error: {meta}")
        logging.error("Failed to fetch expiry data")
        print("❌ [DEBUG] Failed to fetch expiry data")
        return None, None, None

    exp = sorted(
        [(e["date"], e.get("expiry")) for e in meta["data"]["expiryData"]],
        key=lambda x: datetime.strptime(x[0], "%d-%m-%Y")
    )
    today = datetime.today().date()
    dates = [datetime.strptime(d, "%d-%m-%Y").date() for d, _ in exp]
    idx = next((i for i, d in enumerate(dates) if d >= today), 0)
    curr_date, curr_ts = exp[idx]

    ltp = get_underlying_ltp(session_state, cid, token, sym)
    chain = get_option_chain_data(session_state, cid, token, sym, expiry_ts=curr_ts)

    print(f"✅ [DEBUG] Data update complete")
    return ltp, chain, curr_date


def clear_screen():
    """Clear the terminal screen"""
    os.system('cls' if os.name == 'nt' else 'clear')


def get_user_input(prompt, default=None, input_type=str):
    """Get user input with optional default value"""
    try:
        if default is not None:
            user_input = input(f"{prompt} [{default}]: ").strip()
            if user_input == "":
                return default
            return input_type(user_input)
        else:
            return input_type(input(f"{prompt}: ").strip())
    except ValueError:
        print("❌ Invalid input. Please try again.")
        return get_user_input(prompt, default, input_type)


def settings_menu(session_state):
    """Display and handle settings menu"""
    while True:
        clear_screen()
        print("\n" + "=" * 50)
        print("⚙️ SETTINGS")
        print("=" * 50)
        print(f"1. Client ID: {session_state.cid}")
        print(f"2. Access Token: {'*' * len(session_state.token) if session_state.token else 'Not set'}")
        print(f"3. Lot Size: {Config.LOT_SIZE}")
        print("4. 🔙 Back to Main Menu")

        choice = get_user_input("Select option", input_type=int)

        if choice == 1:
            session_state.cid = get_user_input("Enter Client ID", session_state.cid)
        elif choice == 2:
            session_state.token = get_user_input("Enter Access Token", session_state.token)
        elif choice == 3:
            Config.LOT_SIZE = get_user_input("Enter Lot Size", Config.LOT_SIZE, int)
        elif choice == 4:
            break
        else:
            print("❌ Invalid option. Please try again.")


# Main application
def main():
    print("🚀 Starting Live Auto Trading Application")
    # Initialize session state
    session_state = SessionState()
    load_credentials(session_state)

    # Initialize data logger and dashboard
    data_logger = DataLogger()
    dashboard = TerminalDashboard(data_logger)

    # Default symbol
    sym = 'NSE:NIFTY50-INDEX'

    while True:
        clear_screen()
        print("\n" + "=" * 100)
        print("📈 FYERS ALGO TRADING - LIVE AUTO TRADE")
        print("=" * 50)
        print("1. 📈 Start Live Trading (with Auto Dashboard)")
        print("2. ⚙️ Settings")
        print("3. 📊 Generate Static Plot")
        print("4. 🚪 Exit")
        print("=" * 50)

        choice = get_user_input("Select option", input_type=int)

        if choice == 1:  # Live Trading
            clear_screen()
            print("\n" + "=" * 100)
            print("📈 LIVE AUTO TRADING")
            print("=" * 100)

            # Check credentials
            if not (session_state.cid and session_state.token):
                print("❌ Please set Client ID and Access Token in Settings first.")
                input("Press Enter to continue...")
                continue

            # Get trading mode
            auto_trade = get_user_input("Enable Auto Trade? (y/n)", "y").lower() == 'y'

            if not auto_trade:
                print("ℹ️ Auto trade disabled. Returning to main menu.")
                input("Press Enter to continue...")
                continue

            print("🔄 Starting live trading loop...")
            print("📊 Live dashboard will update automatically every cycle...")

            try:
                iteration_count = 0
                while True:
                    iteration_count += 1

                    # Display dashboard every iteration
                    dashboard.display_live_dashboard()

                    print(f"\n🔄 [DEBUG] Starting iteration {iteration_count} at {datetime.now().strftime('%H:%M:%S')}")

                    # Update data
                    ltp, chain, curr_date = update_all_data(session_state, session_state.cid, session_state.token, sym)

                    ist = pytz.timezone("Asia/Kolkata")
                    print(f"🕒 Data Updated: {datetime.now(ist).strftime('%Y-%m-%d %H:%M:%S')}")

                    if ltp:
                        print(f"✅ Underlying LTP: {ltp}")

                    if chain:
                        fy = fyersModel.FyersModel(client_id=session_state.cid, token=session_state.token,
                                                   is_async=False,
                                                   log_path="")
                        signal, atm, metrics = format_and_show(chain, f"Current Expiry: {curr_date}", ltp,
                                                               show_signals=True,
                                                               fyers_api=fy, session_state=session_state)

                        # Log data with metrics
                        if signal and ltp:
                            timestamp = datetime.now(ist).strftime("%Y-%m-%d %H:%M:%S")
                            data_logger.log_data(
                                timestamp=timestamp,
                                underlying_ltp=ltp,
                                signal=signal,
                                atm_strike=atm,
                                expiry_date=curr_date,
                                ce_placement_avg=metrics.get('ce_placement_avg', 0),
                                pe_placement_avg=metrics.get('pe_placement_avg', 0),
                                net_flow=metrics.get('net_flow', 0),
                                direction_ratio=metrics.get('direction_ratio', 0),
                                ce_z_score=metrics.get('ce_z_score', 0),
                                pe_z_score=metrics.get('pe_z_score', 0),
                                using_dynamic_thresholds=metrics.get('using_dynamic_thresholds', False)
                            )

                        # Select strikes
                        buy_pe, sell_pe, buy_ce, sell_ce = select_strikes_atm_half_price(chain, atm)

                        # Validate pairs
                        valid_buy = (sell_pe is not None and buy_pe is not None)
                        valid_sell = (sell_ce is not None and buy_ce is not None)

                        # Trading logic - handle all signal types including HOLD
                        if signal == "HOLD":
                            print("📊 HOLD signal → Maintaining existing positions.")
                            # No action needed, just continue holding

                        elif signal == "BUY" and not valid_buy:
                            print("⚠️ Missing option data for BUY signal. Unable to place trade.")
                        elif signal == "SELL" and not valid_sell:
                            print("⚠️ Missing option data for SELL signal. Unable to place trade.")
                        elif signal in ("BUY", "SELL"):
                            if session_state.live_last_signal == signal and has_open_orders_for_last_signal(fy,
                                                                                                            session_state):
                                print(f"ℹ️ Basket for {signal} already open.")
                            else:
                                ids = handle_basket_orders_atomic(session_state, signal, sell_pe, buy_pe, sell_ce,
                                                                  buy_ce, fy, data_logger)
                                session_state.live_last_signal = signal
                                session_state.live_last_signal_order_ids = ids
                        elif signal == "SIDEWAYS":
                            handle_basket_orders_atomic(session_state, signal, sell_pe, buy_pe, sell_ce, buy_ce, fy,
                                                        data_logger)
                        else:
                            print("ℹ️ No action.")

                    print(f"⏳ Waiting {Config.REFRESH_INTERVAL} seconds before next update...")
                    # time.sleep(Config.REFRESH_INTERVAL)
                    wait_until_next_interval(Config.REFRESH_INTERVAL)

            except KeyboardInterrupt:
                print("\n⏹️ Live trading stopped by user")
                input("Press Enter to continue...")

            except Exception as e:
                print(f"❌ Error in live trading: {str(e)}")
                input("Press Enter to continue...")

        elif choice == 2:  # Settings
            settings_menu(session_state)

        elif choice == 3:  # Generate Static Plot
            print("📊 Generating static plot...")
            plot_file = generate_static_plot()
            if plot_file:
                print(f"✅ Plot saved as: {plot_file}")
            input("Press Enter to continue...")

        elif choice == 4:  # Exit
            print("👋 Exiting... Goodbye!")
            break

        else:
            print("❌ Invalid option. Please try again.")
            input("Press Enter to continue...")


if __name__ == "__main__":
    main()