import time
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import pytz
from fyers_apiv3 import fyersModel
import logging
import uuid
from functools import lru_cache
import os
import subprocess
import sys
import json
from typing import Dict, List, Any, Optional, Tuple
from collections import Counter
import matplotlib.pyplot as plt
import csv
import math
from streamlit import session_state



# Constants
class Config:
    REFRESH_INTERVAL = 15  # seconds
    API_RATE_LIMIT = 200
    API_WINDOW = 60  # seconds
    LOT_SIZE = 130  # nifty lot size
    MAX_RETRIES = 3
    RETRY_DELAY = 2  # seconds
    EXIT_ON_SIDEWAYS = True
    MAX_DAILY_ORDERS = 24  # Maximum number of executed orders per day

    # Added defaults required by compute_score and strike selection
    ROLLING_WINDOW = 30
    STRIKE_GAP = 50  # Nifty strike gap


# Initialize logging
logging.basicConfig(
    filename="trading_app.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)


def get_next_aligned_time(interval_seconds):
    """Get next time aligned to the interval"""
    now = datetime.now()
    current_seconds = (now - now.replace(hour=0, minute=0, second=0, microsecond=0)).total_seconds()
    intervals_passed = current_seconds // interval_seconds
    next_aligned_seconds = (intervals_passed + 1) * interval_seconds

    next_time = now.replace(hour=0, minute=0, second=0, microsecond=0) + timedelta(seconds=next_aligned_seconds)
    return next_time


def wait_until_next_interval(interval_seconds):
    """Wait until next aligned interval"""
    next_time = get_next_aligned_time(interval_seconds)
    wait_seconds = (next_time - datetime.now()).total_seconds()

    if wait_seconds > 0:
        print(f"⏳ Next update at {next_time.strftime('%H:%M:%S')} (waiting {wait_seconds:.1f}s)")
        time.sleep(wait_seconds)


# Data Logging Class (PNL CSV removed per request)
class DataLogger:
    def __init__(self, filename="trading_data.csv"):
        self.filename = filename
        # PNL CSV logic removed intentionally
        self._ensure_header()

    def _ensure_header(self):
        """Create trading data file with headers if it doesn't exist"""
        try:
            with open(self.filename, 'r') as f:
                pass
        except FileNotFoundError:
            with open(self.filename, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'timestamp', 'underlying_ltp', 'signal'
                    # 'atm_strike', 'expiry_date', 'dominant_option',
                    # 'option_score', 'underlying_score'
                ])

    def log_data(self, timestamp, underlying_ltp, signal, atm_strike,
                 expiry_date, dominant_option='',
                 option_score=0.0, underlying_score=0.0):
        """Log trading data to CSV file with Z-score metrics"""
        try:
            # Ensure consistent types / safe string coercion
            row = [
                str(timestamp),
                float(underlying_ltp) if underlying_ltp is not None else "",
                str(signal) if signal is not None else ""
                # int(atm_strike) if (atm_strike is not None and not pd.isna(atm_strike)) else "",
                # str(expiry_date) if expiry_date is not None else "",
                # str(dominant_option) if dominant_option is not None else "",
                # float(option_score) if option_score is not None else "",
                # float(underlying_score) if underlying_score is not None else ""

            ]
            with open(self.filename, 'a', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(row)
            print(f"✅ Data logged: {timestamp} - LTP: {underlying_ltp}, Signal: {signal}")
        except Exception as e:
            logging.exception("Error logging trading data")
            print(f"❌ Error logging data: {e}")

    def read_data(self, limit=None):
        """Read logged trading data from CSV file"""
        try:
            df = pd.read_csv(self.filename)
            if limit:
                return df.tail(limit)
            return df
        except Exception as e:
            logging.exception("Error reading trading data")
            print(f"❌ Error reading data: {e}")
            return pd.DataFrame()


# Terminal-based Live Dashboard (PNL display removed)
class TerminalDashboard:
    def __init__(self, data_logger, session_state=None):
        self.data_logger = data_logger
        self.session_state = session_state
        self.last_update = None

    def display_live_dashboard(self):
        """Display live dashboard in terminal"""
        try:
            # Clear screen
            os.system('cls' if os.name == 'nt' else 'clear')

            # Read latest data
            df = self.data_logger.read_data(limit=20)

            print("\n" + "=" * 100)
            print("📊 LIVE TRADING DASHBOARD")
            print("=" * 100)
            print(f"Last Update: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
            print("-" * 100)

            # Display daily order count if session_state is available
            if self.session_state:
                print(f"📈 DAILY ORDER COUNT: {self.session_state.daily_executed_orders}/{Config.MAX_DAILY_ORDERS}")
                print("-" * 100)

            if df.empty:
                print("🔄 Waiting for trading data...")
                return

            # Convert timestamp
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            df = df.sort_values('timestamp')

            # Display current status
            latest = df.iloc[-1]
            # Use safe access with defaults if columns missing or NaN
            ltp = latest.get('underlying_ltp', 0) if isinstance(latest, pd.Series) else 0
            print(f"\n📈 CURRENT STATUS:")
            try:
                print(f"   Nifty LTP: {float(ltp):.2f}")
            except Exception:
                print(f"   Nifty LTP: {ltp}")
            print(f"   Signal: {latest.get('signal', '')}")
            print(f"   ATM Strike: {latest.get('atm_strike', '')}")
            print(f"   Expiry Date: {latest.get('expiry_date', '')}")

            # Display recent signals
            print(f"\n🔄 RECENT SIGNALS (Last 5):")
            recent_signals = df.tail(5)[['timestamp', 'underlying_ltp', 'signal']]
            for _, row in recent_signals.iterrows():
                signal_color = {
                    'BUY': '🟢',
                    'SELL': '🔴',
                    'SIDEWAYS': '🟡',
                    'HOLD': '⚪'
                }.get(row['signal'], '⚪')

                print(
                    f"   {row['timestamp'].strftime('%H:%M:%S')} - {signal_color} {row['signal']} - LTP: {row['underlying_ltp']:.2f}")

            # P&L CSV removed — do not display P&L summary

            # Display signal statistics
            signal_counts = df['signal'].value_counts()
            print(f"\n📊 SIGNAL STATISTICS:")
            for signal, count in signal_counts.items():
                percentage = (count / len(df)) * 100
                print(f"   {signal}: {count} times ({percentage:.1f}%)")

            print("\n" + "=" * 100)
            print(f"🔄 Next update in {Config.REFRESH_INTERVAL} seconds... (Press Ctrl+C to stop)")
            print("=" * 100)

        except Exception as e:
            logging.exception("Error displaying dashboard")
            # print(f"❌ Error displaying dashboard: {e}")


# Plotting Functions (PNL plotting removed)
def generate_static_plot():
    """Generate a static plot that can be viewed manually"""
    try:
        data_logger = DataLogger()
        df = data_logger.read_data()

        if df.empty:
            print("❌ No data available for plotting")
            return

        # Convert timestamp
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        df = df.sort_values('timestamp')

        # Create the plot
        fig, ax1 = plt.subplots(1, 1, figsize=(15, 6))

        # Plot Nifty LTP
        ax1.plot(df['timestamp'], df['underlying_ltp'], 'b-', label='Nifty LTP', linewidth=2)
        ax1.set_ylabel('Nifty LTP', color='blue')
        ax1.tick_params(axis='y', labelcolor='blue')
        ax1.grid(True, alpha=0.3)

        # Add signals
        buy_signals = df[df['signal'] == 'BUY']
        sell_signals = df[df['signal'] == 'SELL']
        sideways_signals = df[df['signal'] == 'SIDEWAYS']

        if not buy_signals.empty:
            ax1.scatter(buy_signals['timestamp'], buy_signals['underlying_ltp'],
                        color='green', s=100, label='BUY', marker='^', alpha=0.8)

        if not sell_signals.empty:
            ax1.scatter(sell_signals['timestamp'], sell_signals['underlying_ltp'],
                        color='red', s=100, label='SELL', marker='v', alpha=0.8)

        if not sideways_signals.empty:
            ax1.scatter(sideways_signals['timestamp'], sideways_signals['underlying_ltp'],
                        color='orange', s=80, label='SIDEWAYS', marker='s', alpha=0.6)

        ax1.legend()
        ax1.set_title('Nifty LTP vs Trading Signals')

        plt.tight_layout()

        # Save plot
        plot_filename = f"trading_plot_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
        plt.savefig(plot_filename, dpi=300, bbox_inches='tight')
        plt.close()

        print(f"✅ Plot saved as: {plot_filename}")
        return plot_filename

    except Exception as e:
        logging.exception("Error generating plot")
        print(f"❌ Error generating plot: {e}")
        return None


# Error handling decorator
def handle_errors(func):
    def wrapper(*args, **kwargs):
        retries = 0
        while retries < Config.MAX_RETRIES:
            try:
                return func(*args, **kwargs)
            except Exception as e:
                retries += 1
                logging.error(f"Error in {func.__name__} (attempt {retries}): {str(e)}", exc_info=True)
                if retries < Config.MAX_RETRIES:
                    time.sleep(Config.RETRY_DELAY)
                else:
                    print(f"❌ Operation failed after {Config.MAX_RETRIES} attempts: {str(e)}")
                    return None

    return wrapper


# Function to get daily executed order count from Fyers
def get_daily_executed_order_count(fyers):
    """
    Fetch today's executed order count directly from Fyers orderbook
    Returns number of successfully executed orders today (status=2)
    """
    try:
        response = fyers.orderbook()

        if response.get("s") != "ok":
            print(f"⚠️ [DEBUG] Failed to fetch orderbook: {response.get('message', 'Unknown error')}")
            return 0

        # Count orders with status=2 (Traded/Filled)
        executed_orders = [order for order in response.get("orderBook", [])
                           if order.get("status") == 2]

        count = len(executed_orders)
        print(f"📊 [DEBUG] Daily executed orders (from Fyers): {count}")

        return count

    except Exception as e:
        print(f"❌ [DEBUG] Error fetching orderbook: {e}")
        return 0


# Initialize all session state in one place
class SessionState:
    def __init__(self):
        self.option_chain_api_count = 0
        self.quote_api_count = 0
        self.api_window_start = datetime.now()
        self.last_signal = None
        self.last_signal_order_ids = []
        self.live_last_signal = None
        self.live_last_signal_order_ids = []
        self.signal_history = []
        self.signal_buffer = []  # For majority signal calculation
        self.cid = ""
        self.token = ""
        self._hb_lock = False
        self.trade_tracker = {}  # kept for compatibility
        self.last_trade_time = None  # cooldown anchor (set after SIDEWAYS exit)
        self.opening_straddle = None  # opening ATM straddle value
        self.opening_date = None  # date when opening straddle was captured
        self.cooldown_warned = False
        self.ce_score_prev = 0.0
        self.pe_score_prev = 0.0
        self.peak_score = 0.0         # Tracks high-water mark for exits
        self.current_position = None  # Tracks open trade type ("CE", "PE", or None)
        # New attributes for daily order limit
        self.daily_executed_orders = 0
        self.last_order_sync = None

    def get(self, key, default=None):
        """Dictionary-like get method for session state attributes"""
        return getattr(self, key, default)

    def sync_order_count_with_fyers(self, fyers):
        """Sync the daily order count with Fyers orderbook"""
        today = datetime.now().date()

        # Reset if new day (though Fyers API only returns current day anyway)
        if self.last_order_sync != today:
            print(f"📅 [DEBUG] New trading day detected - resetting order counter")
            self.daily_executed_orders = 0
            self.last_order_sync = today

        # Fetch from Fyers
        current_count = get_daily_executed_order_count(fyers)
        self.daily_executed_orders = current_count

        print(f"📊 [DEBUG] Order count synced: {self.daily_executed_orders}/{Config.MAX_DAILY_ORDERS}")

    def can_place_order(self, fyers=None):
        """Check if we can place more orders today"""
        if fyers:
            # Always get fresh count before checking
            self.sync_order_count_with_fyers(fyers)

        if self.daily_executed_orders >= Config.MAX_DAILY_ORDERS:
            print(f"⛔ [DEBUG] Daily order limit ({Config.MAX_DAILY_ORDERS}) reached.")
            return False

        remaining = Config.MAX_DAILY_ORDERS - self.daily_executed_orders
        print(f"✅ [DEBUG] Orders remaining today: {remaining}")
        return True


# Load credentials from environment variables
def load_credentials(session_state):
    """Load credentials from JSON file or environment variables"""
    try:
        # Try to load from JSON file first
        with open('fyers_credentials.json', 'r') as f:
            creds = json.load(f)
            session_state.cid = creds.get('client_id', '')
            session_state.token = creds.get('access_token', '')
            print("✅ Credentials loaded from JSON file")
    except FileNotFoundError:
        # Fall back to environment variables if file doesn't exist
        print("⚠️ JSON file not found, checking environment variables")
        # use consistent env var names
        session_state.cid = os.getenv("FYERS_CID", session_state.cid)
        session_state.token = os.getenv("FYERS_TOKEN", session_state.token)
    except Exception as e:
        print(f"❌ Error loading credentials: {str(e)}")
        # Fall back to environment variables
        session_state.cid = os.getenv("FYERS_CID", session_state.cid)
        session_state.token = os.getenv("FYERS_TOKEN", session_state.token)


# Rate limiting with improved logic
def enforce_rate_limit(session_state):
    now = datetime.now()
    window = now - session_state.api_window_start
    total_calls = session_state.option_chain_api_count + session_state.quote_api_count

    if window.total_seconds() > Config.API_WINDOW:
        session_state.api_window_start = now
        session_state.option_chain_api_count = 0
        session_state.quote_api_count = 0
    elif total_calls >= Config.API_RATE_LIMIT:
        wait = Config.API_WINDOW - int(window.total_seconds())
        if wait > 0:
            logging.warning(f"Approaching rate limit, waiting {wait}s...")
            print(f"⚠️ Approaching rate limit, waiting {wait}s...")
            time.sleep(wait)
        session_state.api_window_start = datetime.now()
        session_state.option_chain_api_count = 0
        session_state.quote_api_count = 0


# API calls with retry logic
@handle_errors
def get_option_chain_data(session_state, cid, token, sym, expiry_ts=""):
    # NOTE: Removed lru_cache usage because session_state is not hashable and caching caused issues.
    print(f"🔍 [DEBUG] Fetching option chain data for {sym}, expiry: {expiry_ts or 'nearest'}")
    enforce_rate_limit(session_state)
    session_state.option_chain_api_count += 1
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    resp = fy.optionchain(data={"symbol": sym, "timestamp": expiry_ts})
    if not resp or resp.get("code") != 200:
        error_msg = f"Option chain error ({expiry_ts or 'nearest'}): {resp.get('message', 'Unknown') if isinstance(resp, dict) else resp}"
        logging.error(error_msg)
        print(f"❌ {error_msg}")
        return None
    print(f"✅ [DEBUG] Option chain data fetched successfully")
    return resp["data"]["optionsChain"]


@handle_errors
def get_underlying_ltp(session_state, cid, token, sym):
    print(f"🔍 [DEBUG] Fetching underlying LTP for {sym}")
    enforce_rate_limit(session_state)
    session_state.quote_api_count += 1
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    resp = fy.quotes(data={"symbols": sym})
    if not resp or resp.get("code") != 200 or not resp.get("d"):
        error_msg = f"Quotes API error ({resp.get('code') if isinstance(resp, dict) else 'N/A'}): {resp.get('message', 'Unknown') if isinstance(resp, dict) else resp}"
        logging.error(error_msg)
        print(f"❌ {error_msg}")
        return None
    ltp = resp["d"][0]["v"]["lp"]
    print(f"✅ [DEBUG] Underlying LTP: {ltp}")
    return ltp


@handle_errors
def get_symbol_ltp(session_state, cid, token, symbol):
    print(f"🔍 [DEBUG] Fetching LTP for {symbol}")
    enforce_rate_limit(session_state)
    session_state.quote_api_count += 1
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    resp = fy.quotes(data={"symbols": symbol})
    if not resp or resp.get("code") != 200 or not resp.get("d"):
        error_msg = f"Quotes API error for {symbol}: {resp.get('message', 'Unknown') if isinstance(resp, dict) else resp}"
        logging.error(error_msg)
        print(f"❌ {error_msg}")
        return None
    ltp = resp["d"][0]["v"]["lp"]
    print(f"✅ [DEBUG] Symbol LTP: {ltp}")
    return ltp


 MAX_HISTORY = 4

 def majority_signal(history, is_entry=False):
     if not history:
         return "HOLD"

     last = history[-1]

     if is_entry:
         if len(history) < 4:
             return "HOLD"
         if all(s == last for s in history[-4:]) and last in ("BUY", "SELL"):
             return last
         return "HOLD"

     else:
         if len(history) < 2:
             return "HOLD"
         if all(s == "SIDEWAYS" for s in history[-2:]):
             return "SIDEWAYS"
         return "HOLD"

#MAX_HISTORY = 2
#
#def majority_signal(history, is_entry=False):
#    if not history:
#        return "HOLD"
#
#    last = history[-1]
#
#    # --- ENTRY MODE (Requires candle consensus) ---
#    if is_entry:
#        if len(history) < 2:
#            return "HOLD"
#        
#        if all(s == last for s in history[-2:]) and last in ("BUY", "SELL"):
#            return last
#        return "HOLD"
#    
#    # --- EXIT MODE (Instant Kill Switch) ---
#    else:
#        # If the latest signal is SIDEWAYS, we return it immediately (no majority needed)
#        if last == "SIDEWAYS":
#            return "SIDEWAYS"
#        
#        # Otherwise, we default to HOLD to stay in the trade
#        return "HOLD"

   
def compute_signals(
    merged_df,
    atm_strike,
    ltp,
    fyers_api=None,
    session_state=None
):
    """
    Price-only signal using quotes API, with VWAP gate (atp).
    Entry: CE_avg > 1.2 * PE_avg AND VWAP confirms (CE above ATP, PE below ATP) -> BUY
           PE_avg > 1.2 * CE_avg AND VWAP confirms (PE above ATP, CE below ATP) -> SELL
    Exit: Track spread = CE_avg - PE_avg (BUY) or PE_avg - CE_avg (SELL)
          Exit when spread < peak_spread * 0.5
    Returns: (confirmed_signal, metrics)
    """
    print("\n" + "=" * 90)
    print("🚀 [DEBUG] compute_signals (PRICE-ONLY with VWAP) STARTED")
    print(f"📌 LTP: {ltp}, ATM Strike: {atm_strike}")
    print("=" * 90)

    metrics = {'signal': 'HOLD', 'underlying_score': 0}
    now = datetime.now()
    COOLDOWN_MINUTES = 5
    STRADDLE_MULTIPLIER = 0.5

    # ---------- 1. Get current position ----------
    current_position = None
    if fyers_api is not None:
        try:
            pos_resp = fyers_api.positions()
            if pos_resp.get("s") == "ok":
                for p in pos_resp.get("netPositions", []):
                    qty = p.get("netQty", 0)
                    sym = (p.get("symbol") or "").upper()
                    if qty > 0:
                        if sym.endswith("CE"):
                            current_position = "CE"
                        elif sym.endswith("PE"):
                            current_position = "PE"
            print(f"✅ [DEBUG] Current Position: {current_position}")
        except Exception as e:
            print(f"❌ [DEBUG] Position fetch error: {e}")

    # ---------- 2. Straddle regime gate (unchanged) ----------
    if session_state is not None and fyers_api is not None:
        opening_date = session_state.get("opening_date")
        if opening_date != now.date():
            print("🧭 Capturing opening straddle...")
            q = fyers_api.quotes({"symbols": "NSE:NIFTY50-INDEX"})
            if q.get("s") != "ok":
                print("❌ Failed to fetch NIFTY open")
                return "HOLD", metrics
            nifty_open = q["d"][0]["v"]["open_price"]
            session_state.day_open = nifty_open

            atm_open = min(merged_df["Strike"], key=lambda x: abs(x - nifty_open))
            row = merged_df[merged_df["Strike"] == atm_open].iloc[0]
            ce_sym = row.get("CE_symbol")
            pe_sym = row.get("PE_symbol")
            if not ce_sym or not pe_sym:
                print("❌ ATM symbols missing")
                return "HOLD", metrics

            q_opt = fyers_api.quotes({"symbols": f"{ce_sym},{pe_sym}"})
            if q_opt.get("s") != "ok":
                print("❌ Failed to fetch ATM straddle quotes")
                return "HOLD", metrics

            ce_open = q_opt["d"][0]["v"]["open_price"]
            pe_open = q_opt["d"][1]["v"]["open_price"]
            opening_straddle = ce_open + pe_open
            session_state.opening_straddle = opening_straddle
            session_state.opening_date = now.date()
            print(f"📊 Opening straddle = {opening_straddle:.2f}")

        if session_state.get("opening_straddle"):
            quote_resp = fyers_api.quotes({"symbols": "NSE:NIFTY50-INDEX"})
            if quote_resp.get("s") == "ok" and quote_resp.get("d"):
                v = quote_resp["d"][0]["v"]
                day_high = v.get("high_price")
                day_low = v.get("low_price")
                if day_high and day_low:
                    realized_range = day_high - day_low
                    threshold = STRADDLE_MULTIPLIER * session_state.opening_straddle
                    if realized_range < threshold:
                        print("🛑 Regime BLOCK → HOLD")
                        print(f"Realised Range: {realized_range}"
                              f"Threshold: {threshold}"
                              ) 
                        return "HOLD", metrics
                    else:
                        print("✅ Regime PASSED")
                else:
                    print("⚠️ Could not get day high/low – skipping regime gate")
            else:
                print("⚠️ Quote API for NIFTY failed – skipping regime gate")

    # ---------- 3. Build symbol list (IMPROVED STRIKE SELECTION) ----------
    
    gap = Config.STRIKE_GAP
    
    # Separate CE and PE strike logic
    ce_strikes = [atm_strike - gap, atm_strike - 2 * gap, atm_strike - 3 * gap]
    pe_strikes = [atm_strike + gap, atm_strike + 2 * gap, atm_strike + 3 * gap]
    
    symbols = []
    ce_symbols = []
    pe_symbols = []
    
    print(f"🔍 [DEBUG] CE Strikes: {ce_strikes}")
    print(f"🔍 [DEBUG] PE Strikes: {pe_strikes}")
    
    # ---- CE symbols ----
    for s in ce_strikes:
        row = merged_df[merged_df["Strike"] == s]
        if not row.empty:
            ce = row.iloc[0].get("CE_symbol")
            print(f"   CE Strike {s}: {ce}")
            if pd.notna(ce) and ce:
                symbols.append(ce)
                ce_symbols.append(ce)
            else:
                print(f"   ⚠️ CE missing for strike {s}")
        else:
            print(f"   ⚠️ No row for CE strike {s}")
    
    # ---- PE symbols ----
    for s in pe_strikes:
        row = merged_df[merged_df["Strike"] == s]
        if not row.empty:
            pe = row.iloc[0].get("PE_symbol")
            print(f"   PE Strike {s}: {pe}")
            if pd.notna(pe) and pe:
                symbols.append(pe)
                pe_symbols.append(pe)
            else:
                print(f"   ⚠️ PE missing for strike {s}")
        else:
            print(f"   ⚠️ No row for PE strike {s}")

    # Safety check
    if not symbols:
        print("❌ No valid symbols found – cannot fetch quotes")
        return "HOLD", metrics
    
    print(f"📡 [DEBUG] Requesting quotes for {len(symbols)} symbols: {symbols}")

    # ---------- 4. Fetch quotes and process with safety checks ----------
    if fyers_api is None:
        print("❌ fyers_api is None – cannot fetch quotes")
        return "HOLD", metrics

    resp = fyers_api.quotes({"symbols": ",".join(symbols)})
    print(f"📥 [DEBUG] Quotes API raw response (truncated): s={resp.get('s')}, code={resp.get('code')}, d length={len(resp.get('d', []))}")

    if resp.get("s") != "ok":
        print(f"❌ Quotes API error: {resp.get('message', 'Unknown error')}")
        return "HOLD", metrics

    if "d" not in resp or not isinstance(resp["d"], list):
        print("❌ Quotes response missing 'd' array or not a list")
        return "HOLD", metrics

    ce_prices, pe_prices = [], []
    ce_atps, pe_atps = [], []

    for idx, item in enumerate(resp["d"]):
        print(f"🔍 [DEBUG] Processing quote item {idx}: n={item.get('n')}, s={item.get('s')}")
        if not isinstance(item, dict):
            print(f"   ⚠️ Item {idx} is not a dict – skipping")
            continue

        # Extract symbol from 'n' (short name) or fallback to 'v'['symbol']
        sym = item.get("n")
        if not sym and "v" in item and isinstance(item["v"], dict):
            sym = item["v"].get("symbol")
        if not sym:
            print(f"   ⚠️ Item {idx} has no symbol (n or v.symbol) – skipping")
            continue

        if "v" not in item or not isinstance(item["v"], dict):
            print(f"   ⚠️ Item {idx} missing 'v' dict – skipping")
            continue

        v = item["v"]
        if "lp" not in v:
            print(f"   ⚠️ Symbol {sym} missing 'lp' – skipping")
            continue

        lp = v["lp"]
        atp = v.get("atp", lp)   # fallback to lp if atp missing
        print(f"   ✅ Symbol: {sym}, lp={lp}, atp={atp}")

        if sym.endswith("CE"):
            ce_prices.append(lp)
            ce_atps.append(atp)
        elif sym.endswith("PE"):
            pe_prices.append(lp)
            pe_atps.append(atp)
        else:
            print(f"   ⚠️ Unknown option type for {sym} (must end with CE or PE)")

    if not ce_prices or not pe_prices:
        print(f"❌ Missing prices: CE count={len(ce_prices)}, PE count={len(pe_prices)}")
        return "HOLD", metrics

    ce_avg = sum(ce_prices) / len(ce_prices)
    pe_avg = sum(pe_prices) / len(pe_prices)
    ce_atp_avg = sum(ce_atps) / len(ce_atps) if ce_atps else ce_avg
    pe_atp_avg = sum(pe_atps) / len(pe_atps) if pe_atps else pe_avg

    print(f"📊 CE avg price = {ce_avg:.2f}, ATP avg = {ce_atp_avg:.2f}")
    print(f"📊 PE avg price = {pe_avg:.2f}, ATP avg = {pe_atp_avg:.2f}")

    # VWAP confirmation flags
    ce_above_vwap = ce_avg > ce_atp_avg
    pe_below_vwap = pe_avg < pe_atp_avg
    pe_above_vwap = pe_avg > pe_atp_avg
    ce_below_vwap = ce_avg < ce_atp_avg

    vwap_confirms_buy = ce_above_vwap and pe_below_vwap
    vwap_confirms_sell = pe_above_vwap and ce_below_vwap
    print(f"📌 VWAP: BUY confirm = {vwap_confirms_buy}, SELL confirm = {vwap_confirms_sell}")

    # ============================================================
    # 🔥 NEW SECTION: BUFFER + WARMUP + CHANGE
    # ============================================================

    if session_state is not None:
        if not hasattr(session_state, "ce_list"):
            session_state.ce_list = []
            session_state.pe_list = []

        session_state.ce_list.append(ce_avg)
        session_state.pe_list.append(pe_avg)

        # keep last 12 values (~3 min)
        session_state.ce_list = session_state.ce_list[-12:]
        session_state.pe_list = session_state.pe_list[-12:]

    MIN_POINTS = 12  # ~3 min

    if session_state is not None and len(session_state.ce_list) < MIN_POINTS:
        print(f"⏳ Warming up... ({len(session_state.ce_list)}/{MIN_POINTS})")
        return "HOLD", metrics

    ce_change, pe_change = 0, 0

    if session_state is not None:
        ce_old = session_state.ce_list[0]
        pe_old = session_state.pe_list[0]

        # simplified + safe calculation
        ce_change = (ce_avg - ce_old) / ce_old if ce_old else 0
        pe_change = (pe_avg - pe_old) / pe_old if pe_old else 0

        print(
            f"📈 Price change CE list Length:({len(session_state.ce_list)} pts): PE list Length:({len(session_state.pe_list)} pts): "
            f"CE = {ce_change:.2%}, PE = {pe_change:.2%}"
        )   

    # ============================================================
    # 🔥 SKEW FROM EXISTING BUFFERS (PRO ADD-ON)
    # ============================================================
    skew_list = []

    if session_state is not None:
        for ce, pe in zip(session_state.ce_list, session_state.pe_list):
            if pe:
                skew_list.append(ce / pe)

    # --- Warmup ---
    MIN_SKEW_POINTS = 12  # ~3 min

    if len(skew_list) < MIN_SKEW_POINTS:
        print(f"⏳ Skew warming up... ({len(skew_list)}/{MIN_SKEW_POINTS})")
        return "HOLD", metrics

    # --- Current skew ---
    skew = ce_avg / pe_avg if pe_avg else 1.0

    # --- Stats ---
    mean_skew = np.mean(skew_list)
    std_skew = np.std(skew_list)

    z_score = (skew - mean_skew) / std_skew if std_skew > 0 else 0

    print(f"📊 Skew={skew:.3f}, Mean={mean_skew:.3f}, Z={z_score:.2f}")
    # ---------- 5. Entry and exit logic ----------
    NOISE_BAND = 0.005  # 0.5% — filters micro-fluctuations

    ce_rising = ce_change > NOISE_BAND
    ce_falling = ce_change < -NOISE_BAND
    pe_rising = pe_change > NOISE_BAND
    pe_falling = pe_change < -NOISE_BAND
    raw_signal = "HOLD"

    if current_position is None:
        # BUY condition
        if  vwap_confirms_buy and z_score > 1.5 and ce_rising and pe_falling :
            raw_signal = "BUY"
            if session_state is not None:
                session_state.peak_spread = ce_avg - pe_avg
            print(f"✅ BUY signal triggered (ratio {z_score:.2f})")
        # SELL condition
        elif vwap_confirms_sell and z_score < -1.5 and pe_rising and ce_falling :
            raw_signal = "SELL"
            if session_state is not None:
                session_state.peak_spread = pe_avg - ce_avg
            print(f"✅ SELL signal triggered (ratio {z_score:.2f})")
        else:
            raw_signal = "HOLD"
            print("⏸️ No entry condition met")

    elif current_position == "CE":
        spread = ce_avg - pe_avg
        if session_state is not None:
            peak = session_state.get("peak_spread", spread)
            peak = max(peak, spread)
            session_state.peak_spread = peak
            print("="*75)
            print(f"📈 BUY active: spread={spread:.2f}, peak={peak:.2f}, StopAt={peak*0.5:.2f}")
            print("="*75)
            if spread >= peak * 0.5:
                raw_signal = "HOLD"
            else:
                raw_signal = "SIDEWAYS"
                session_state.peak_spread = 0.0
                print(f"🛑 BUY exit triggered")
        else:
            raw_signal = "HOLD"

    elif current_position == "PE":
        spread = pe_avg - ce_avg
        if session_state is not None:
            peak = session_state.get("peak_spread", spread)
            peak = max(peak, spread)
            session_state.peak_spread = peak
            print("="*75)
            print(f"📉 SELL active: spread={spread:.2f}, peak={peak:.2f}, StopAt={peak*0.5:.2f}")
            print("="*75)
            if spread >= peak * 0.5:
                raw_signal = "HOLD"
            else:
                raw_signal = "SIDEWAYS"
                session_state.peak_spread = 0.0
                print(f"🛑 SELL exit triggered")
        else:
            raw_signal = "HOLD"

    # ---------- 6. Majority confirmation (unchanged) ----------
    history = []
    if session_state is not None:
        history = list(session_state.get("signal_history", []))
    history.append(raw_signal)
    history = history[-MAX_HISTORY:]   # MAX_HISTORY should be defined globally (e.g., 2)
    if session_state is not None:
        session_state.signal_history = history

    has_position = current_position is not None
    confirmed_signal = majority_signal(history, is_entry=not has_position)

    print(f"📊 Signal history: {history} (is_entry={current_position is None}) → Confirm Signal: {confirmed_signal}")

    if has_position:
        if confirmed_signal == "SIDEWAYS":
            if session_state is not None:
                session_state.peak_spread = 0.0
                session_state.signal_history = []
            confirmed_signal = "SIDEWAYS"
        else:
            confirmed_signal = "HOLD"
    else:
        confirmed_signal = confirmed_signal if confirmed_signal in ["BUY", "SELL"] else "HOLD"
        if session_state is not None:
            if confirmed_signal == "BUY":
                session_state.peak_spread = ce_avg - pe_avg
            elif confirmed_signal == "SELL":
                session_state.peak_spread = pe_avg - ce_avg

    metrics["signal"] = confirmed_signal
    print(f"🎯 Confirmed signal: {confirmed_signal}")

    # ---------- 7. Cooldown visibility (optional prints) ----------
    if session_state is not None:
        last_trade_time = session_state.get("last_trade_time")
        if last_trade_time:
            elapsed_mins = (now - last_trade_time).total_seconds() / 60
            if elapsed_mins < COOLDOWN_MINUTES:
                print(f"⏳ Cooldown active – {elapsed_mins:.1f} min elapsed")
            else:
                print("✅ Cooldown completed")
        else:
            if not getattr(session_state, "cooldown_warned", False):
                print("⚠️ No cooldown anchor set (no SIDEWAYS exit yet)")
                session_state.cooldown_warned = True

    # ---------- 8. Cooldown enforcement (BUY/SELL only) ----------
    if session_state is not None and confirmed_signal in ("BUY", "SELL"):
        last_trade_time = session_state.get("last_trade_time")
        if last_trade_time:
            elapsed_mins = (now - last_trade_time).total_seconds() / 60
            if elapsed_mins < COOLDOWN_MINUTES:
                print(f"🛑 Cooldown active ({elapsed_mins:.1f} min) → HOLD")
                confirmed_signal = "HOLD"
                metrics["signal"] = "HOLD"

    # ---------- 9. Prepare extra quote data for logging ----------
    quote_data = {
        'ce_avg': ce_avg,
        'ce_atp_avg': ce_atp_avg,
        'pe_avg': pe_avg,
        'pe_atp_avg': pe_atp_avg,
        'buy_confirm': vwap_confirms_buy,
        'sell_confirm': vwap_confirms_sell,
        'signal_history': history,
        'confirmed_signal': confirmed_signal
    }
    print("\n" + "=" * 90)
    print("\n📊 Log Summary")

    print(f"ce_avg: {ce_avg}",end=" ")
    print(f"ce_atp_avg: {ce_atp_avg}")
    print(f"pe_avg: {pe_avg}",end=" ")
    print(f"pe_atp_avg: {pe_atp_avg}")
    print(f"buy_confirm: {vwap_confirms_buy}")
    print(f"sell_confirm: {vwap_confirms_sell}")
    print(
          f"session_state.ce_list: {session_state.ce_list} \n"
          f"session_state.pe_list: {session_state.pe_list}"
          )
    print(f"skew_list: {skew_list}")
    print(
            f"📈 Price change CE list Length:({len(session_state.ce_list)} pts): PE list Length:({len(session_state.pe_list)} pts): "
            f"CE = {ce_change:.2%}, PE = {pe_change:.2%}"
            )   

    print(f"📊 Skew={skew:.3f}, Mean={mean_skew:.3f}, Z={z_score:.2f}")
    print(f"signal_history: {history}")
    print(f"confirmed_signal: {confirmed_signal}")
    if current_position == "CE":
        print(f"📈 BUY active: spread={spread:.2f}, peak={peak:.2f}, StopAt={peak*0.5:.2f}")
    elif current_position == "PE":
        print(f"📉 SELL active: spread={spread:.2f}, peak={peak:.2f}, StopAt={peak*0.5:.2f}")
    
    print("\n" + "=" * 90)

    return confirmed_signal, metrics

def select_strikes_atm_half_price(chain, atm_strike):
    """
    Strategy:
      - BUY ATM (both CE & PE)
      - SELL OTM where LTP ≈  ATM LTP / 4
    """
    print(f"🔍 [DEBUG] Selecting strikes for ATM Strike: {atm_strike}")
    try:
        df = pd.DataFrame(chain)
        if df.empty or atm_strike is None:
            print("⚠️ [DEBUG] No data or ATM strike for selection")
            return None, None, None, None

        ce = df[df["option_type"] == "CE"].copy()
        pe = df[df["option_type"] == "PE"].copy()

        # ---------------- ATM Buy legs ----------------
        atm_pe_row = pe[pe["strike_price"] == atm_strike]
        atm_ce_row = ce[ce["strike_price"] == atm_strike]

        buy_pe_row = atm_pe_row.iloc[0].to_dict() if not atm_pe_row.empty else None
        buy_ce_row = atm_ce_row.iloc[0].to_dict() if not atm_ce_row.empty else None

        # ---------------- OTM Sell legs (half price) ----------------
        sell_pe_row, sell_ce_row = None, None

        if buy_pe_row and "ltp" in buy_pe_row and buy_pe_row["ltp"] > 0:
            target = buy_pe_row["ltp"] / 4
            # Only consider OTM PEs (strike < ATM strike)
            pe_candidates = pe[pe["strike_price"] < atm_strike].copy()
            pe_candidates["ltp_diff"] = (pe_candidates["ltp"] - target).abs()
            if not pe_candidates.empty:
                sell_pe_row = pe_candidates.nsmallest(1, "ltp_diff").iloc[0].to_dict()

        if buy_ce_row and "ltp" in buy_ce_row and buy_ce_row["ltp"] > 0:
            target = buy_ce_row["ltp"] / 4
            # Only consider OTM CEs (strike > ATM strike)
            ce_candidates = ce[ce["strike_price"] > atm_strike].copy()
            ce_candidates["ltp_diff"] = (ce_candidates["ltp"] - target).abs()
            if not ce_candidates.empty:
                sell_ce_row = ce_candidates.nsmallest(1, "ltp_diff").iloc[0].to_dict()

        print(f"✅ [DEBUG] Strike selection complete:")
        print(
            f"   - BUY PE : {buy_pe_row['symbol'] if buy_pe_row else 'None'} @ {buy_pe_row['ltp'] if buy_pe_row else 'N/A'}")
        # print(f"   - SELL PE : {sell_pe_row['symbol'] if sell_pe_row else 'None'} @ {sell_pe_row['ltp'] if sell_pe_row else 'N/A'}")
        print(
            f"   - BUY CE : {buy_ce_row['symbol'] if buy_ce_row else 'None'} @ {buy_ce_row['ltp'] if buy_ce_row else 'N/A'}")
        # print(f"   - SELL CE : {sell_ce_row['symbol'] if sell_ce_row else 'None'} @ {sell_ce_row['ltp'] if sell_ce_row else 'N/A'}")

        return buy_pe_row, sell_pe_row, buy_ce_row, sell_ce_row

    except Exception as e:
        logging.error(f"Error in select_strikes_atm_half_price: {str(e)}", exc_info=True)
        print(f"❌ [DEBUG] Error in select_strikes_atm_half_price: {str(e)}")
        return None, None, None, None


# Order management with improved error handling
@handle_errors
def cancel_order(fyers, order_id):
    print(f"🔍 [DEBUG] Cancelling order: {order_id}")
    try:
        resp = fyers.cancel_order(data={"id": order_id})
        logging.info(f"Cancelled order {order_id}: {resp}")
        print(f"✅ [DEBUG] Order {order_id} cancelled: {resp}")
        return resp
    except Exception as e:
        logging.error(f"Exception while cancelling order {order_id}: {e}", exc_info=True)
        print(f"❌ [DEBUG] Error cancelling order {order_id}: {e}")
        raise


@handle_errors
def get_order_status_by_id(fyers, order_id):
    print(f"🔍 [DEBUG] Getting status for order: {order_id}")
    try:
        orderbook = fyers.orderbook()
        for o in orderbook.get("orderBook", []):
            if o.get("id") == order_id:
                status = o.get("status")
                print(f"✅ [DEBUG] Order {order_id} status: {status}")
                return status
        print(f"⚠️ [DEBUG] Order {order_id} not found in orderbook")
        return None
    except Exception as e:
        logging.warning(f"Could not fetch order status for {order_id}: {e}")
        print(f"❌ [DEBUG] Error getting order status for {order_id}: {e}")
        return None


@handle_errors
def place_order_and_check(fyers, order):
    print(f"🔍 [DEBUG] Placing order: {order}")
    try:
        resp = fyers.place_order(data=order)
        logging.info(f"Order placed for {order['symbol']}: {resp}")
        print(f"✅ [DEBUG] Order placed: {resp}")

        if resp.get("s") == "ok":
            oid = resp.get("id")
            time.sleep(2)  # Wait for order to process
            status = get_order_status_by_id(fyers, oid)
            if status in [1, 5]:  # Rejected or canceled
                logging.error(f"Order {oid} was rejected or canceled. Status: {status}")
                print(f"❌ [DEBUG] Order {oid} was rejected or canceled. Status: {status}")
                return None, status
            logging.info(f"Order {oid} status: {status}")
            print(f"✅ [DEBUG] Order {oid} status: {status}")
            return oid, status
        else:
            logging.error(f"Order failed: {resp}")
            print(f"❌ [DEBUG] Order failed: {resp}")
            return None, None
    except Exception as e:
        logging.exception(f"Place order error: {e}")
        print(f"❌ [DEBUG] Place order error: {e}")
        raise


def has_open_orders_for_last_signal(fyers, session_state):
    print(f"🔍 [DEBUG] Checking open orders for last signal")

    # First check if we have any actual positions
    try:
        pos_resp = fyers.positions()
        if pos_resp.get("s") == "ok":
            net_positions = [p for p in pos_resp.get("netPositions", [])
                             if abs(p.get("netQty", 0)) != 0]
            if not net_positions:
                print(f"✅ [DEBUG] No active positions found")
                session_state.last_signal_order_ids = []  # Clear stale order IDs
                return False
            else:
                print(f"📊 [DEBUG] Found {len(net_positions)} active positions")
                for p in net_positions:
                    print(f"  - {p.get('symbol')}: {p.get('netQty')} units")
                return True
    except Exception as e:
        print(f"❌ [DEBUG] Error checking positions: {e}")

    # Fallback to order book check
    ids = session_state.live_last_signal_order_ids
    if not ids:
        print("✅ [DEBUG] No order IDs for last signal")
        return False

    try:
        ob = fyers.orderbook()
        if ob and "orderBook" in ob:
            # Check for open orders (status 2 = open, 1 = completed, 5 = cancelled)
            open_orders = [o for o in ob["orderBook"]
                           if o.get("id") in ids and o.get("status") == 2]
            has_open = len(open_orders) > 0
            print(f"✅ [DEBUG] Open orders for last signal: {has_open} ({len(open_orders)} orders)")
            return has_open
        print("⚠️ [DEBUG] No order book data")
        return False
    except Exception as e:
        logging.warning(f"Could not check open orders: {e}")
        print(f"❌ [DEBUG] Error checking open orders: {e}")
        return False


def handle_basket_orders_atomic(session_state, signal, sell_pe, buy_pe, sell_ce, buy_ce, fyers, data_logger):
    print(f"\n🔍 [DEBUG] Handling basket orders for signal: {signal}")

    # ------- simple lock to avoid overlapping runs -------
    if session_state._hb_lock:
        print("⚠️ [DEBUG] Another rebalance is already running. Skipping this cycle.")
        return []
    session_state._hb_lock = True

    placed_ids = []
    try:
        lot = Config.LOT_SIZE
        current_signal = session_state.last_signal
        print(f"🔄 [DEBUG] Current signal: {current_signal}, Incoming signal: {signal}")

        # ---------- helper: wait until positions are flat ----------
        def _wait_until_flat(timeout=28, interval=2):
            """Poll positions until no netQty remains, or timeout."""
            print(f"⏳ [DEBUG] Waiting up to {timeout}s for positions to flatten...")
            end = time.time() + timeout
            while time.time() < end:
                pos_resp = fyers.positions()
                print(f"📡 [DEBUG] Polled positions response: {pos_resp}")
                if pos_resp.get("s") == "ok":
                    still_open = [p for p in pos_resp.get("netPositions", [])
                                  if abs(p.get("netQty", 0)) != 0]
                    if not still_open:
                        print("✅ [DEBUG] All positions are flat now.")
                        return True
                    else:
                        print(f"⏳ [DEBUG] Still open positions: "
                              f"{[(p['symbol'], p['netQty']) for p in still_open]}")
                else:
                    print(f"❌ [DEBUG] Positions API error while waiting: {pos_resp}")
                time.sleep(interval)
            print("❌ [DEBUG] Timeout: positions did not flatten in time.")
            return False

        # ---------- current positions ----------
        pos_resp = fyers.positions()
        # print(f"📡 [DEBUG] Initial positions API response: {pos_resp}")
        net_positions = []
        if pos_resp.get("s") == "ok":
            net_positions = [p for p in pos_resp.get("netPositions", [])
                             if abs(p.get("netQty", 0)) != 0]

        print(f"🔍 [DEBUG] Found {len(net_positions)} active positions at start:")
        for p in net_positions:
            print(f"  - {p.get('symbol')}: {p.get('netQty')} units")

        # ============================================================
        # 1) Handle HOLD signal (maintain existing positions)
        # ============================================================
        if signal == "HOLD":
            print("📊 [DEBUG] HOLD signal → Maintaining existing positions.")
            # Do nothing, just keep existing positions
            return []

        # ============================================================
        # 2) Handle SIDEWAYS signal (exit all positions)
        # ============================================================
        if signal == "SIDEWAYS" and Config.EXIT_ON_SIDEWAYS == True:
            print("📊 [DEBUG] SIDEWAYS signal -> EXIT_ON_SIDEWAYS == True -> Exiting all positions.")

            if not net_positions:
                print("✅ [DEBUG] No positions to exit for SIDEWAYS signal.")
                session_state.last_signal = signal
                return []

            try:
                # NOTE: PNL CSV logic removed. We keep prints for traceability.
                timestamp = datetime.now(pytz.timezone("Asia/Kolkata")).strftime("%Y-%m-%d %H:%M:%S")
                for position in net_positions:
                    symbol = position.get('symbol', '')
                    net_qty = position.get('netQty', 0)
                    avg_price = position.get('avgPrice', 0)
                    print(f"ℹ️ Exiting position {symbol} qty={net_qty} avg_price={avg_price} at {timestamp}")

                # Exit all positions
                exit_shorts = {"segment": [11], "side": [-1], "productType": ["MARGIN"]}
                print(f"📤 [DEBUG] Sending SHORT exit request: {exit_shorts}")
                resp_short = fyers.exit_positions(data=exit_shorts)
                print(f"📥 [DEBUG] SHORT exit response: {resp_short}")

                exit_longs = {"segment": [11], "side": [1], "productType": ["MARGIN"]}
                print(f"📤 [DEBUG] Sending LONG exit request: {exit_longs}")
                resp_long = fyers.exit_positions(data=exit_longs)
                print(f"📥 [DEBUG] LONG exit response: {resp_long}")

                # Verify flattening
                if not _wait_until_flat(timeout=60, interval=2):
                    print("❌ [DEBUG] Flattening failed after exit. Manual check needed.")
                    return placed_ids

                print("✅ [DEBUG] All positions successfully exited for SIDEWAYS signal.")
                session_state.last_signal = signal
                session_state.last_trade_time = datetime.now()
                print("🕒 [DEBUG] Cooldown started after SIDEWAYS exit")
                return []

            except Exception as e:
                print(f"❌ [DEBUG] Exception during SIDEWAYS exit sequence: {str(e)}")
                return placed_ids
        if signal == "SIDEWAYS" and Config.EXIT_ON_SIDEWAYS == False:
            print("📊 [DEBUG] SIDEWAYS signal -> EXIT_ON_SIDEWAYS == False -> Holding all positions.")
            return []
        # ============================================================
        # 3) FLATTEN on SIGNAL CHANGE (BUY/SELL to different BUY/SELL)
        # ============================================================
        if current_signal in ["BUY", "SELL"] and current_signal != signal and net_positions:
            print(f"⚠️ [DEBUG] Signal changed ({current_signal} → {signal}). "
                  f"Attempting to exit ALL open positions step by step...")

            try:
                timestamp = datetime.now(pytz.timezone("Asia/Kolkata")).strftime("%Y-%m-%d %H:%M:%S")
                for position in net_positions:
                    symbol = position.get('symbol', '')
                    net_qty = position.get('netQty', 0)
                    avg_price = position.get('avgPrice', 0)
                    print(f"ℹ️ Exiting position {symbol} qty={net_qty} avg_price={avg_price} at {timestamp}")

                # Step 1: Exit SHORT legs
                exit_shorts = {"segment": [11], "side": [-1], "productType": ["MARGIN"]}
                print(f"📤 [DEBUG] Sending SHORT exit request: {exit_shorts}")
                resp_short = fyers.exit_positions(data=exit_shorts)
                print(f"📥 [DEBUG] SHORT exit response: {resp_short}")

                # Step 2: Exit LONG legs
                exit_longs = {"segment": [11], "side": [1], "productType": ["MARGIN"]}
                print(f"📤 [DEBUG] Sending LONG exit request: {exit_longs}")
                resp_long = fyers.exit_positions(data=exit_longs)
                print(f"📥 [DEBUG] LONG exit response: {resp_long}")

                # Step 3: Verify flattening
                if not _wait_until_flat(timeout=60, interval=2):
                    print("❌ [DEBUG] Flattening failed after exit. Manual check needed.")
                    return placed_ids

                print("✅ [DEBUG] All positions successfully exited for signal change.")

            except Exception as e:
                print(f"❌ [DEBUG] Exception during exit sequence: {str(e)}")
                return placed_ids

        # ============================================================
        # 4) ENTER NEW BASKET for BUY/SELL signals (ATM BUY only per request)
        # ============================================================
        signal_map = {
            "BUY": {"enter_hedge": buy_ce, "enter_short": None},
            "SELL": {"enter_hedge": buy_pe, "enter_short": None}
        }
        pos_resp = fyers.positions()
        # print(f"📡 [DEBUG] Positions before entry: {pos_resp}")
        current_positions = []
        if pos_resp.get("s") == "ok":
            current_positions = [p for p in pos_resp.get("netPositions", [])
                                 if abs(p.get("netQty", 0)) != 0]

        if current_positions:
            print("⚠️ [DEBUG] Some positions are STILL open → Skipping new entry.")
            for p in current_positions:
                print(f"  - OPEN: {p.get('symbol')} {p.get('netQty')}")
            return placed_ids

        # Basket entry - build legs conditionally (ATM buy only)
        enter_hedge = signal_map[signal]["enter_hedge"]
        enter_short = signal_map[signal]["enter_short"]

        print(f"📥 [DEBUG] Preparing new {signal} basket entry:")
        print(f"  - ATM BUY leg: {enter_hedge}")
        if enter_short:
            print(f"  - (Would have been SELL leg): {enter_short}")

        entry_basket = []
        if enter_hedge:
            # validate shape before accessing keys
            if not isinstance(enter_hedge, dict) or "symbol" not in enter_hedge:
                print("❌ [DEBUG] Invalid ATM buy leg data. Aborting entry.")
                return placed_ids
            entry_basket.append({
                "symbol": enter_hedge["symbol"],
                "qty": lot,
                "type": 2,
                "side": 1,  # BUY
                "productType": "MARGIN",
                "validity": "DAY",
            })

        if enter_short:
            if not isinstance(enter_short, dict) or "symbol" not in enter_short:
                print("❌ [DEBUG] Invalid short leg data. Skipping short leg.")
            else:
                entry_basket.append({
                    "symbol": enter_short["symbol"],
                    "qty": lot,
                    "type": 2,
                    "side": -1,  # SELL
                    "productType": "MARGIN",
                    "validity": "DAY",
                })

        if not entry_basket:
            print("❌ [DEBUG] No valid legs to submit for basket entry. Aborting.")
            return placed_ids

        print(f"📤 [DEBUG] Sending basket order request: {entry_basket}")
        entry_resp = fyers.place_basket_orders(data=entry_basket)
        print(f"📥 [DEBUG] Basket order response: {entry_resp}")

        if entry_resp and entry_resp.get("s") == "ok":
            for item in entry_resp.get("data", []):
                body = item.get("body", {})
                if body.get("s") == "ok" and body.get("id"):
                    placed_ids.append(body["id"])

            # NOTE: PNL CSV logic removed. Keep a trace print instead.
            timestamp = datetime.now(pytz.timezone("Asia/Kolkata")).strftime("%Y-%m-%d %H:%M:%S")
            if enter_hedge and isinstance(enter_hedge, dict) and "ltp" in enter_hedge:
                print(
                    f"ℹ️ Logged ENTRY event (no PNL CSV): {signal} {enter_hedge.get('symbol')} @ {enter_hedge.get('ltp')} at {timestamp}")

            session_state.last_signal = signal
            print(f"✅ [DEBUG] Successfully entered new {signal} basket orders → IDs: {placed_ids}")
        else:
            msg = entry_resp.get("message", "Unknown error") if isinstance(entry_resp, dict) else "Unknown error"
            print(f"❌ [DEBUG] Basket order FAILED. Reason: {msg}")

        return placed_ids

    except Exception as e:
        logging.exception("Fatal error in handle_basket_orders_atomic")
        print(f"❌ [DEBUG] Fatal error in handle_basket_orders_atomic: {str(e)}")
        return []
    finally:
        session_state._hb_lock = False
        print("🔓 [DEBUG] Lock released.\n")


# Data display functions with improved formatting
def format_and_show(chain, title, ltp, show_signals=False, fyers_api=None, session_state=None):
    print(f"🔍 [DEBUG] Formatting and displaying data for: {title}")
    df = pd.DataFrame(chain)
    if df.empty:
        print(f"ℹ️ [DEBUG] No data for {title}")
        return None, None, None

    # Process CE and PE data
    ce = df[df["option_type"] == "CE"]
    pe = df[df["option_type"] == "PE"]

    # Define columns and rename them
    cols = ["symbol", "strike_price", "oi", "volume", "ltp", "ask", "bid",
            "ltpch", "ltpchp", "oich", "oichp", "prev_oi"]

    ce_df = ce[cols].rename(columns={
        "strike_price": "Strike",
        "oi": "OI",
        "volume": "Vol",
        "ltpch": "LTPCh",
        "ltpchp": "LTPChP",
        "oich": "OICh",
        "oichp": "OIChP",
        "prev_oi": "PrevOI"
    })

    pe_df = pe[cols].rename(columns={
        "strike_price": "Strike",
        "oi": "OI",
        "volume": "Vol",
        "ltpch": "LTPCh",
        "ltpchp": "LTPChP",
        "oich": "OICh",
        "oichp": "OIChP",
        "prev_oi": "PrevOI"
    })

    # Merge CE and PE data
    merged = pd.merge(
        ce_df.add_prefix("CE_"),
        pe_df.add_prefix("PE_"),
        left_on="CE_Strike",
        right_on="PE_Strike",
        how="outer"
    ).rename(columns={"CE_Strike": "Strike"}).drop("PE_Strike", axis=1)

    # Find ATM strike
    atm = None
    if ltp is not None and not merged["Strike"].dropna().empty:
        atm = min(merged["Strike"].dropna(), key=lambda x: abs(x - ltp))

    print(f"\n📈 {title}")

    if show_signals and atm is not None:
        # Calculate all required metrics
        strikes = sorted(merged["Strike"].dropna().unique().tolist())
        idx = strikes.index(atm)
        signal, metrics = compute_signals(merged, atm, ltp, fyers_api=fyers_api, session_state=session_state)
        # Display results with improved formatting
        print(f"✅ Signal: {signal}")

    # Display the dataframe
    print(f"📊 ATM Strike: {atm} | Underlying LTP: {ltp}")
    # print(merged.to_string(index=False))

    if show_signals and atm is not None:
        return signal, atm, metrics
    return None, atm, None


@handle_errors
def update_all_data(session_state, cid, token, sym):
    print(f"🔍 [DEBUG] Updating all data for {sym}")
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    enforce_rate_limit(session_state)
    session_state.option_chain_api_count += 1

    meta = fy.optionchain(data={"symbol": sym, "timestamp": ""})
    if meta.get("code") != 200:
        print(f"❌ [DEBUG] Option chain API error: {meta}")
        logging.error("Failed to fetch expiry data")
        print("❌ [DEBUG] Failed to fetch expiry data")
        return None, None, None

    exp = sorted(
        [(e["date"], e.get("expiry")) for e in meta["data"]["expiryData"]],
        key=lambda x: datetime.strptime(x[0], "%d-%m-%Y")
    )
    today = datetime.today().date()
    dates = [datetime.strptime(d, "%d-%m-%Y").date() for d, _ in exp]
    idx = next((i for i, d in enumerate(dates) if d >= today), 0)
    curr_date, curr_ts = exp[idx]

    ltp = get_underlying_ltp(session_state, cid, token, sym)
    chain = get_option_chain_data(session_state, cid, token, sym, expiry_ts=curr_ts)

    print(f"✅ [DEBUG] Data update complete")
    return ltp, chain, curr_date


def clear_screen():
    """Clear the terminal screen"""
    os.system('cls' if os.name == 'nt' else 'clear')


def get_user_input(prompt, default=None, input_type=str):
    """Get user input with optional default value"""
    try:
        if default is not None:
            user_input = input(f"{prompt} [{default}]: ").strip()
            if user_input == "":
                return default
            return input_type(user_input)
        else:
            return input_type(input(f"{prompt}: ").strip())
    except ValueError:
        print("❌ Invalid input. Please try again.")
        return get_user_input(prompt, default, input_type)


def settings_menu(session_state):
    """Display and handle settings menu"""
    while True:
        clear_screen()
        print("\n" + "=" * 50)
        print("⚙️ SETTINGS")
        print("=" * 50)
        print(f"1. Client ID: {session_state.cid}")
        print(f"2. Access Token: {'*' * len(session_state.token) if session_state.token else 'Not set'}")
        print(f"3. Lot Size: {Config.LOT_SIZE}")
        print(f"4. Max Daily Orders: {Config.MAX_DAILY_ORDERS}")
        print("5. 🔙 Back to Main Menu")

        choice = get_user_input("Select option", input_type=int)

        if choice == 1:
            session_state.cid = get_user_input("Enter Client ID", session_state.cid)
        elif choice == 2:
            session_state.token = get_user_input("Enter Access Token", session_state.token)
        elif choice == 3:
            Config.LOT_SIZE = get_user_input("Enter Lot Size", Config.LOT_SIZE, int)
        elif choice == 4:
            Config.MAX_DAILY_ORDERS = get_user_input("Enter Max Daily Orders", Config.MAX_DAILY_ORDERS, int)
        elif choice == 5:
            break
        else:
            print("❌ Invalid option. Please try again.")


# Main application
def main():
    print("🚀 Starting Live Auto Trading Application")
    # Initialize session state
    session_state = SessionState()
    load_credentials(session_state)

    # Initialize data logger and dashboard
    data_logger = DataLogger()
    dashboard = TerminalDashboard(data_logger, session_state)

    # Default symbol
    sym = 'NSE:NIFTY50-INDEX'

    while True:
        clear_screen()
        print("\n" + "=" * 100)
        print("📈 FYERS ALGO TRADING - LIVE AUTO TRADE")
        print("=" * 50)
        print("1. 📈 Start Live Trading (with Auto Dashboard)")
        print("2. ⚙️ Settings")
        print("3. 📊 Generate Static Plot")
        print("4. 🚪 Exit")
        print("=" * 50)

        choice = get_user_input("Select option", input_type=int)

        if choice == 1:  # Live Trading
            clear_screen()
            print("\n" + "=" * 100)
            print("📈 LIVE AUTO TRADING")
            print("=" * 100)

            # Check credentials
            if not (session_state.cid and session_state.token):
                print("❌ Please set Client ID and Access Token in Settings first.")
                input("Press Enter to continue...")
                continue

            # Get trading mode
            auto_trade = get_user_input("Enable Auto Trade? (y/n)", "y").lower() == 'y'

            if not auto_trade:
                print("ℹ️ Auto trade disabled. Returning to main menu.")
                input("Press Enter to continue...")
                continue

            print("🔄 Starting live trading loop...")
            print("📊 Live dashboard will update automatically every cycle...")

            try:
                iteration_count = 0
                while True:
                    iteration_count += 1

                    # Display dashboard every iteration
                    dashboard.display_live_dashboard()

                    print(f"\n🔄 [DEBUG] Starting iteration {iteration_count} at {datetime.now().strftime('%H:%M:%S')}")

                    # Update data
                    ltp, chain, curr_date = update_all_data(session_state, session_state.cid, session_state.token, sym)

                    ist = pytz.timezone("Asia/Kolkata")
                    print(f"🕒 Data Updated: {datetime.now(ist).strftime('%Y-%m-%d %H:%M:%S')}")

                    if ltp:
                        print(f"✅ Underlying LTP: {ltp}")

                    if chain:
                        fy = fyersModel.FyersModel(client_id=session_state.cid, token=session_state.token,
                                                   is_async=False,
                                                   log_path="")

                        # Sync order count at the start of each iteration
                        session_state.sync_order_count_with_fyers(fy)

                        signal, atm, metrics = format_and_show(chain, f"Current Expiry: {curr_date}", ltp,
                                                               show_signals=True,
                                                               fyers_api=fy, session_state=session_state)

                        # Log data with metrics
                        if signal and ltp:
                            timestamp = datetime.now(ist).strftime("%Y-%m-%d %H:%M:%S")
                            # metrics may be None in some edge cases; guard access
                            if not metrics:
                                metrics = {}
                            data_logger.log_data(
                                timestamp=timestamp,
                                underlying_ltp=ltp,
                                atm_strike=atm,
                                expiry_date=curr_date,
                                dominant_option=metrics.get("dominant_option", ""),
                                option_score=metrics.get("option_score", 0.0),
                                underlying_score=metrics.get("underlying_score", 0.0),
                                signal=signal
                            )

                        # Select strikes
                        buy_pe, sell_pe, buy_ce, sell_ce = select_strikes_atm_half_price(chain, atm)

                        # VALIDATION CHANGED: we now only require the ATM BUY leg for each signal
                        valid_buy = (buy_ce is not None)  # For BUY signal, ATM CE buy leg must exist
                        valid_sell = (buy_pe is not None)  # For SELL signal, ATM PE buy leg must exist

                        # Trading logic - handle all signal types including HOLD
                        if signal == "HOLD":
                            print("📊 HOLD signal → Maintaining existing positions.")
                            # No action needed, just continue holding

                        elif signal == "BUY" and not valid_buy:
                            print("⚠️ Missing ATM CE buy data for BUY signal. Unable to place trade.")
                        elif signal == "SELL" and not valid_sell:
                            print("⚠️ Missing ATM PE buy data for SELL signal. Unable to place trade.")
                        elif signal in ("BUY", "SELL"):
                            # Check daily order limit before placing new trades
                            if not session_state.can_place_order(fy):
                                print("⛔ [DEBUG] Trade skipped due to daily order limit")
                                print("📊 HOLD signal → Daily order limit reached.")
                            elif session_state.live_last_signal == signal and has_open_orders_for_last_signal(fy,
                                                                                                              session_state):
                                print(f"ℹ️ ATM BUY for {signal} already open.")
                            else:
                                # Note: function signature expects (session_state, signal, sell_pe, buy_pe, sell_ce, buy_ce, fyers, data_logger)
                                ids = handle_basket_orders_atomic(session_state, signal, sell_pe, buy_pe, sell_ce,
                                                                  buy_ce, fy, data_logger)
                                session_state.live_last_signal = signal
                                session_state.live_last_signal_order_ids = ids
                        elif signal == "SIDEWAYS":
                            handle_basket_orders_atomic(session_state, signal, sell_pe, buy_pe, sell_ce, buy_ce, fy,
                                                        data_logger)
                        else:
                            print("ℹ️ No action.")

                    print(f"⏳ Waiting {Config.REFRESH_INTERVAL} seconds before next update...")
                    # time.sleep(Config.REFRESH_INTERVAL)
                    wait_until_next_interval(Config.REFRESH_INTERVAL)

            except KeyboardInterrupt:
                print("\n⏹️ Live trading stopped by user")
                input("Press Enter to continue...")

            except Exception as e:
                logging.exception("Error in live trading loop")
                print(f"❌ Error in live trading: {str(e)}")
                input("Press Enter to continue...")

        elif choice == 2:  # Settings
            settings_menu(session_state)

        elif choice == 3:  # Generate Static Plot
            print("📊 Generating static plot...")
            plot_file = generate_static_plot()
            if plot_file:
                print(f"✅ Plot saved as: {plot_file}")
            input("Press Enter to continue...")

        elif choice == 4:  # Exit
            print("👋 Exiting... Goodbye!")
            break

        else:
            print("❌ Invalid option. Please try again.")
            input("Press Enter to continue...")


if __name__ == "__main__":
    main()