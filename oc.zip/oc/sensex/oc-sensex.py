#!/usr/bin/env python3
"""
Gamma‑Flow Convergence Strategy – Small Account Edition (No Premium Cap)
Dynamic stop loss tied to daily loss limit, triple‑confirmed entries,
VIX filter, trend filter, and robust intraday risk management.
"""

import time
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import pytz
from fyers_apiv3 import fyersModel
import logging
import json
import csv
import os
from collections import deque

# -----------------------------------------------------------------------------
# CONFIGURATION
# -----------------------------------------------------------------------------
class Config:
    SYMBOL = "BSE:SENSEX-INDEX"
    STRIKE_COUNT = 25
    REFRESH_INTERVAL = 60          # seconds
    API_RATE_LIMIT = 200
    API_WINDOW = 60                # seconds
    LOT_SIZE = 20                  # Sensex weekly options lot
    MAX_RETRIES = 3
    RETRY_DELAY = 2

    # Strategy parameters
    MAX_HISTORY_SNAPSHOTS = 60
    EMA_HALFLIFE = 15              # minutes
    SCORE_WARMUP = 30              # minutes before first signal
    SKEW_OTM_DELTA = 0.25
    VIX_DECLINE_THRESH = -0.5      # points
    EXIT_TIME_HHMM = (15, 0)       # 3:00 PM
    COOLDOWN_MINUTES = 5
    TREND_MA_PERIOD = 30           # 30‑min SMA

    # Risk & Capital
    CAPITAL = 40000.0
    MAX_DAILY_LOSS_PCT = 0.05      # ₹2,000 max daily loss
    MAX_CONSECUTIVE_LOSSES = 2     # halt trading after this many losers in a row
    MAX_TOTAL_TRADES_PER_DAY = 3   # maximum completed trades per day

# -----------------------------------------------------------------------------
# LOGGING
# -----------------------------------------------------------------------------
logging.basicConfig(
    filename="gamma_flow_v2.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)

# -----------------------------------------------------------------------------
# TIME UTILS
# -----------------------------------------------------------------------------
def get_next_aligned_time(interval_seconds):
    now = datetime.now()
    current_seconds = (now - now.replace(hour=0, minute=0, second=0, microsecond=0)).total_seconds()
    intervals_passed = current_seconds // interval_seconds
    next_aligned_seconds = (intervals_passed + 1) * interval_seconds
    return now.replace(hour=0, minute=0, second=0, microsecond=0) + timedelta(seconds=next_aligned_seconds)

def wait_until_next_interval(interval_seconds):
    next_time = get_next_aligned_time(interval_seconds)
    wait_seconds = (next_time - datetime.now()).total_seconds()
    if wait_seconds > 0:
        print(f"⏳ Next update at {next_time.strftime('%H:%M:%S')} (waiting {wait_seconds:.1f}s)")
        time.sleep(wait_seconds)

# -----------------------------------------------------------------------------
# DATA LOGGERS (CSV) – extended columns for daily risk
# -----------------------------------------------------------------------------
class SignalLogger:
    def __init__(self, filename="gamma_signal_log.csv"):
        self.filename = filename
        if not os.path.exists(filename):
            with open(filename, 'w', newline='') as f:
                w = csv.writer(f)
                w.writerow([
                    'timestamp', 'underlying_ltp',
                    'net_gamma', 'skew', 'skew_momentum', 'net_dvol',
                    'bull_score', 'bear_score',
                    'signal', 'position',
                    'atm_strike', 'entry_premium',
                    'vix_ltp', 'vix_change_5m',
                    'trend_filter',
                    'daily_pnl', 'day_trading_stopped',
                    'remarks'
                ])

    def log(self, timestamp, ltp, net_gamma, skew, skew_momentum, net_dvol,
            bull_score, bear_score, signal, position, atm_strike=0,
            entry_premium=0.0, vix_ltp=0.0, vix_change_5m=0.0,
            trend_filter="", daily_pnl=0.0, day_trading_stopped=False, remarks=""):
        row = [
            timestamp, ltp,
            f"{net_gamma:.6f}", f"{skew:.2f}", f"{skew_momentum:.2f}", f"{net_dvol:.0f}",
            bull_score, bear_score,
            signal, position,
            atm_strike, entry_premium, vix_ltp, vix_change_5m,
            trend_filter,
            f"{daily_pnl:.2f}", day_trading_stopped,
            remarks
        ]
        with open(self.filename, 'a', newline='') as f:
            csv.writer(f).writerow(row)

class TradeLogger:
    def __init__(self, filename="gamma_trade_log.csv"):
        self.filename = filename
        if not os.path.exists(filename):
            with open(filename, 'w', newline='') as f:
                w = csv.writer(f)
                w.writerow([
                    'timestamp', 'event', 'symbol', 'qty', 'price',
                    'order_ids', 'comment', 'daily_pnl'
                ])

    def log(self, timestamp, event, symbol='', qty='', price='',
            order_ids='', comment='', daily_pnl=0.0):
        with open(self.filename, 'a', newline='') as f:
            csv.writer(f).writerow([timestamp, event, symbol, qty, price,
                                    order_ids, comment, f"{daily_pnl:.2f}"])

# -----------------------------------------------------------------------------
# SESSION STATE
# -----------------------------------------------------------------------------
class SessionState:
    def __init__(self):
        # Credentials
        self.cid = ""
        self.token = ""
        # Rate limit
        self.api_window_start = datetime.now()
        self.option_chain_api_count = 0
        self.quote_api_count = 0
        # Current position
        self.position = None          # 'CE' or 'PE'
        self.entry_symbol = None
        self.entry_price = None       # average entry premium
        self.entry_qty = 0
        self.stop_price = None        # dynamic stop price
        self.last_trade_time = None   # for cooldown
        # Daily risk
        self.daily_pnl = 0.0
        self.consecutive_losses = 0
        self.total_trades_today = 0
        self.daily_max_loss = Config.CAPITAL * Config.MAX_DAILY_LOSS_PCT
        self.day_trading_stopped = False
        self.last_trading_date = None
        # Rolling data
        self.snapshots = deque(maxlen=Config.MAX_HISTORY_SNAPSHOTS)   # (timestamp, options_list, und_ltp, vix_ltp)
        self.oi_cache = {}
        self.vol_cache = {}
        # EMAs
        self.net_gamma_ema = None
        self.net_dvol_ema = None
        self.skew_smooth_ema = None
        self.skew_smooth_history = deque(maxlen=5)
        # Trend
        self.trend_ma = None

    def reset_daily_risk(self):
        today = datetime.now().date()
        if self.last_trading_date != today:
            self.daily_pnl = 0.0
            self.consecutive_losses = 0
            self.total_trades_today = 0
            self.day_trading_stopped = False
            self.last_trading_date = today
            print("🔄 New trading day – risk limits reset")

    def can_place_trade(self):
        """Full risk check before entry."""
        if self.total_trades_today >= Config.MAX_TOTAL_TRADES_PER_DAY:
            print(f"⛔ Max daily trades ({Config.MAX_TOTAL_TRADES_PER_DAY}) reached")
            return False
        if self.consecutive_losses >= Config.MAX_CONSECUTIVE_LOSSES:
            print(f"⛔ {Config.MAX_CONSECUTIVE_LOSSES} consecutive losses – trading halted")
            return False
        if self.daily_pnl <= -self.daily_max_loss:
            print(f"⛔ Daily max loss ₹{self.daily_max_loss:.0f} reached")
            return False
        if self.day_trading_stopped:
            print("⛔ Trading stopped for the day")
            return False
        return True

    def update_on_exit(self, exit_price):
        """Calculate trade P&L and update daily stats."""
        if self.entry_price and self.entry_qty:
            pnl = (exit_price - self.entry_price) * self.entry_qty
            self.daily_pnl += pnl
            self.total_trades_today += 1

            if pnl < 0:
                self.consecutive_losses += 1
                print(f"📉 Loss: ₹{pnl:.0f} | Consecutive losses: {self.consecutive_losses}")
            else:
                self.consecutive_losses = 0
                print(f"📈 Profit: ₹{pnl:.0f} | Loss streak reset")

            if self.daily_pnl <= -self.daily_max_loss:
                self.day_trading_stopped = True
                print("🛑 Daily loss limit breached – trading halted for the day")
            if self.consecutive_losses >= Config.MAX_CONSECUTIVE_LOSSES:
                self.day_trading_stopped = True
                print("🛑 Consecutive loss limit breached – trading halted for the day")
        # Clear position
        self.position = None
        self.entry_symbol = None
        self.entry_price = None
        self.entry_qty = 0
        self.stop_price = None
        self.last_trade_time = datetime.now()
        return self.daily_pnl

# -----------------------------------------------------------------------------
# API HELPERS
# -----------------------------------------------------------------------------
def handle_errors(func):
    def wrapper(*args, **kwargs):
        retries = 0
        while retries < Config.MAX_RETRIES:
            try:
                return func(*args, **kwargs)
            except Exception as e:
                retries += 1
                logging.error(f"Error in {func.__name__} (attempt {retries}): {str(e)}", exc_info=True)
                if retries < Config.MAX_RETRIES:
                    time.sleep(Config.RETRY_DELAY)
                else:
                    print(f"❌ Operation failed after {Config.MAX_RETRIES} attempts: {str(e)}")
                    return None
    return wrapper

def enforce_rate_limit(state):
    now = datetime.now()
    window = now - state.api_window_start
    total_calls = state.option_chain_api_count + state.quote_api_count
    if window.total_seconds() > Config.API_WINDOW:
        state.api_window_start = now
        state.option_chain_api_count = 0
        state.quote_api_count = 0
    elif total_calls >= Config.API_RATE_LIMIT:
        wait = Config.API_WINDOW - int(window.total_seconds())
        if wait > 0:
            print(f"⚠️ Rate limit, waiting {wait}s")
            time.sleep(wait)
        state.api_window_start = datetime.now()
        state.option_chain_api_count = 0
        state.quote_api_count = 0

@handle_errors
def fetch_option_chain(state, cid, token, symbol):
    enforce_rate_limit(state)
    state.option_chain_api_count += 1
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    resp = fy.optionchain(data={
        "symbol": symbol,
        "strikecount": Config.STRIKE_COUNT,
        "timestamp": "",
        "greeks": "1"
    })
    if not resp or resp.get("code") != 200:
        raise Exception(f"Option chain error: {resp}")
    return resp["data"]

@handle_errors
def get_underlying_ltp(state, cid, token, symbol):
    enforce_rate_limit(state)
    state.quote_api_count += 1
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    resp = fy.quotes(data={"symbols": symbol})
    if not resp or resp.get("code") != 200 or not resp.get("d"):
        raise Exception("Quotes error")
    return resp["d"][0]["v"]["lp"]

@handle_errors
def get_option_ltp(state, cid, token, symbol):
    enforce_rate_limit(state)
    state.quote_api_count += 1
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    resp = fy.quotes(data={"symbols": symbol})
    if resp and resp.get("code") == 200 and resp.get("d"):
        return resp["d"][0]["v"]["lp"]
    return None

@handle_errors
def fetch_intraday_1min(state, symbol, minutes=120):
    now = datetime.now()
    last_complete_epoch = int(time.time()) - 60
    from_epoch = last_complete_epoch - (minutes * 60)
    fy = fyersModel.FyersModel(client_id=state.cid, token=state.token, is_async=False, log_path="")
    resp = fy.history({
        "symbol": symbol,
        "resolution": "1",
        "date_format": 0,
        "range_from": from_epoch,
        "range_to": last_complete_epoch,
        "cont_flag": 1
    })
    if resp.get("s") != "ok" or not resp.get("candles"):
        return None
    df = pd.DataFrame(resp["candles"], columns=["epoch", "open", "high", "low", "close", "volume"])
    return df.sort_values('epoch')

# -----------------------------------------------------------------------------
# ORDER MANAGEMENT
# -----------------------------------------------------------------------------
@handle_errors
def place_entry(state, fyers, symbol, qty):
    order = {
        "symbol": symbol,
        "qty": qty,
        "type": 2,               # market
        "side": 1,               # buy
        "productType": "MARGIN",
        "validity": "DAY",
        "limitPrice": 0.0,
        "stopPrice": 0.0
    }
    resp = fyers.place_order(data=order)
    if resp.get("s") == "ok":
        order_id = resp.get("id")
        time.sleep(2)
        status = get_order_status(fyers, order_id)
        return order_id, status
    return None, None

@handle_errors
def exit_position(fyers, state, trade_logger, exit_price, reason=""):
    """Exit current position and update daily P&L."""
    # First update P&L (before clearing position)
    state.update_on_exit(exit_price)

    resp_pos = fyers.positions()
    if resp_pos.get("s") == "ok":
        for p in resp_pos.get("netPositions", []):
            qty = p.get("netQty", 0)
            sym = p.get("symbol", "")
            if qty != 0:
                side = 1 if qty > 0 else -1
                exit_data = {
                    "segment": [11],
                    "side": [side],
                    "productType": ["MARGIN"]
                }
                fyers.exit_positions(data=exit_data)
                trade_logger.log(
                    datetime.now(pytz.timezone("Asia/Kolkata")).strftime("%Y-%m-%d %H:%M:%S"),
                    "EXIT", sym, qty, exit_price, '', reason,
                    state.daily_pnl  # now reflects updated P&L
                )
                print(f"🚪 Exiting {sym} ({qty}) @ {exit_price:.2f} - {reason}")

@handle_errors
def get_order_status(fyers, order_id):
    orderbook = fyers.orderbook()
    for o in orderbook.get("orderBook", []):
        if o.get("id") == order_id:
            return o.get("status")
    return None

# -----------------------------------------------------------------------------
# OPTION METRICS COMPUTATION
# -----------------------------------------------------------------------------
def compute_option_metrics(state, snapshot):
    options = [o for o in snapshot if o.get("option_type") != ""]
    ce_list = [o for o in options if o["option_type"] == "CE"]
    pe_list = [o for o in options if o["option_type"] == "PE"]

    # Gamma‑weighted OI flow
    ce_gamma_delta_oi = 0.0
    pe_gamma_delta_oi = 0.0
    ce_total_oi = 0.0
    pe_total_oi = 0.0

    for opt in ce_list:
        sym = opt["symbol"]
        oi = opt["oi"]
        delta_oi = oi - state.oi_cache.get(sym, oi)
        state.oi_cache[sym] = oi
        gamma = opt.get("greeks", {}).get("gamma", 0)
        ce_gamma_delta_oi += gamma * delta_oi
        ce_total_oi += oi

    for opt in pe_list:
        sym = opt["symbol"]
        oi = opt["oi"]
        delta_oi = oi - state.oi_cache.get(sym, oi)
        state.oi_cache[sym] = oi
        gamma = opt.get("greeks", {}).get("gamma", 0)
        pe_gamma_delta_oi += gamma * delta_oi
        pe_total_oi += oi

    norm_g_ce = ce_gamma_delta_oi / ce_total_oi if ce_total_oi else 0
    norm_g_pe = pe_gamma_delta_oi / pe_total_oi if pe_total_oi else 0
    net_gamma_raw = norm_g_ce - norm_g_pe

    print(f"📊 GAMMA FLOW: CE gamma×ΔOI={ce_gamma_delta_oi:.6f} (total OI {ce_total_oi:.0f}), PE gamma×ΔOI={pe_gamma_delta_oi:.6f} (total OI {pe_total_oi:.0f})")
    print(f"   Normalised CE: {norm_g_ce:.6f}, PE: {norm_g_pe:.6f} → NetGamma raw: {net_gamma_raw:.6f}")

    # Delta‑adjusted volume flow
    ce_delta_dvol = 0.0
    pe_delta_dvol = 0.0
    for opt in ce_list:
        sym = opt["symbol"]
        vol = opt["volume"]
        delta_vol = vol - state.vol_cache.get(sym, vol)
        state.vol_cache[sym] = vol
        delta = abs(opt.get("greeks", {}).get("delta", 0))
        ce_delta_dvol += delta * delta_vol
    for opt in pe_list:
        sym = opt["symbol"]
        vol = opt["volume"]
        delta_vol = vol - state.vol_cache.get(sym, vol)
        state.vol_cache[sym] = vol
        delta = abs(opt.get("greeks", {}).get("delta", 0))
        pe_delta_dvol += delta * delta_vol
    net_dvol_raw = ce_delta_dvol - pe_delta_dvol

    print(f"📊 DELTA VOL: CE ΔVol={ce_delta_dvol:.0f}, PE ΔVol={pe_delta_dvol:.0f} → NetDVol raw: {net_dvol_raw:.0f}")

    # IV Skew (OTM 25‑delta)
    ce_with_delta = [(abs(o["greeks"].get("delta", 0.5) - Config.SKEW_OTM_DELTA),
                      o["greeks"]["iv"]) for o in ce_list if "greeks" in o and "iv" in o["greeks"]]
    pe_with_delta = [(abs(o["greeks"].get("delta", 0.5) - Config.SKEW_OTM_DELTA),
                      o["greeks"]["iv"]) for o in pe_list if "greeks" in o and "iv" in o["greeks"]]
    ce_iv = min(ce_with_delta, key=lambda x: x[0])[1] if ce_with_delta else 0
    pe_iv = min(pe_with_delta, key=lambda x: x[0])[1] if pe_with_delta else 0
    skew = ce_iv - pe_iv

    print(f"📊 SKEW: OTM CE IV={ce_iv:.2f}%, PE IV={pe_iv:.2f}% → Skew={skew:.2f}%")

    return {
        "net_gamma_raw": net_gamma_raw,
        "net_dvol_raw": net_dvol_raw,
        "skew": skew,
    }

# -----------------------------------------------------------------------------
# EMAS & SCORES
# -----------------------------------------------------------------------------
def update_emas(state, net_gamma_raw, net_dvol_raw, skew):
    alpha = 2.0 / (Config.EMA_HALFLIFE + 1)

    if state.net_gamma_ema is None:
        state.net_gamma_ema = net_gamma_raw
    else:
        state.net_gamma_ema = alpha * net_gamma_raw + (1 - alpha) * state.net_gamma_ema

    if state.net_dvol_ema is None:
        state.net_dvol_ema = net_dvol_raw
    else:
        state.net_dvol_ema = alpha * net_dvol_raw + (1 - alpha) * state.net_dvol_ema

    if state.skew_smooth_ema is None:
        state.skew_smooth_ema = skew
    else:
        state.skew_smooth_ema = alpha * skew + (1 - alpha) * state.skew_smooth_ema

    print(f"📈 EMA (α={alpha:.3f}): NetGamma EMA={state.net_gamma_ema:.6f}, NetDVol EMA={state.net_dvol_ema:.0f}, Skew EMA={state.skew_smooth_ema:.2f}%")
    return state.net_gamma_ema, state.net_dvol_ema, state.skew_smooth_ema

def compute_skew_momentum(state, current_skew_smooth):
    state.skew_smooth_history.append(current_skew_smooth)
    if len(state.skew_smooth_history) >= 5:
        old_val = state.skew_smooth_history[0]
        momentum = current_skew_smooth - old_val
        print(f"📈 Skew momentum (5min): {momentum:.2f}%")
        return momentum
    print(f"📈 Skew momentum: waiting for 5 minutes of data (have {len(state.skew_smooth_history)})")
    return 0.0

def compute_scores(state):
    net_gamma = state.net_gamma_ema if state.net_gamma_ema is not None else 0
    net_dvol = state.net_dvol_ema if state.net_dvol_ema is not None else 0
    skew_momentum = compute_skew_momentum(state, state.skew_smooth_ema)

    bull = (1 if net_gamma > 0 else 0) + (1 if skew_momentum > 0 else 0) + (1 if net_dvol > 0 else 0)
    bear = (1 if net_gamma < 0 else 0) + (1 if skew_momentum < 0 else 0) + (1 if net_dvol < 0 else 0)

    print(f"🎯 SCORES: NetGamma>0? {net_gamma>0}, SkewMom>0? {skew_momentum>0}, NetDVol>0? {net_dvol>0} → Bull={bull}/3, Bear={bear}/3")
    return bull, bear, skew_momentum

# -----------------------------------------------------------------------------
# TREND FILTER (30‑min SMA of index closes)
# -----------------------------------------------------------------------------
def compute_trend_filter(state, symbol):
    df = fetch_intraday_1min(state, symbol, minutes=60)
    if df is None or len(df) < Config.TREND_MA_PERIOD:
        print("📉 TREND: insufficient data for 30‑min SMA (need at least 30 candles)")
        return None
    closes = df['close'].tail(Config.TREND_MA_PERIOD)
    state.trend_ma = closes.mean()
    print(f"📉 TREND: 30‑min SMA = {state.trend_ma:.2f}")
    return state.trend_ma

# -----------------------------------------------------------------------------
# ATM STRIKE FINDER
# -----------------------------------------------------------------------------
def get_atm_strike(options, und_ltp):
    strikes = sorted(list(set(o["strike_price"] for o in options if o.get("strike_price") > 0)))
    if not strikes:
        return None
    atm = min(strikes, key=lambda x: abs(x - und_ltp))
    print(f"📍 ATM strike: {atm} (Underlying {und_ltp})")
    return atm

# -----------------------------------------------------------------------------
# MAIN TRADING LOOP
# -----------------------------------------------------------------------------
def main():
    print("🚀 Gamma‑Flow Convergence Trader – Small Account (No Premium Cap)")
    state = SessionState()

    # Credentials
    try:
        with open('fyers_credentials.json') as f:
            creds = json.load(f)
            state.cid = creds['client_id']
            state.token = creds['access_token']
    except:
        state.cid = os.getenv("FYERS_CID", "")
        state.token = os.getenv("FYERS_TOKEN", "")

    signal_log = SignalLogger("gamma_signal_log.csv")
    trade_log = TradeLogger("gamma_trade_log.csv")

    fy = fyersModel.FyersModel(client_id=state.cid, token=state.token,
                               is_async=False, log_path="")

    # Initial fetch to populate caches
    print("⏳ Fetching first option chain...")
    data = fetch_option_chain(state, state.cid, state.token, Config.SYMBOL)
    if not data:
        print("❌ Initial fetch failed. Exiting.")
        return
    options = data["optionsChain"]
    for opt in options:
        if opt.get("option_type") != "":
            state.oi_cache[opt["symbol"]] = opt["oi"]
            state.vol_cache[opt["symbol"]] = opt["volume"]
    state.snapshots.append((
        datetime.now(),
        options,
        next(o["ltp"] for o in options if o["option_type"] == ""),
        data.get("indiavixData", {}).get("ltp", 0)
    ))
    print(f"✅ Initialised. Warmup phase: {len(state.snapshots)}/{Config.SCORE_WARMUP} snapshots collected.\n")

    while True:
        try:
            wait_until_next_interval(Config.REFRESH_INTERVAL)
            now_ist = datetime.now(pytz.timezone("Asia/Kolkata"))

            # Reset daily risk if new day
            state.reset_daily_risk()

            # Market hours check
            if now_ist.time() < datetime.strptime("09:15", "%H:%M").time():
                continue   # market not open yet
            if now_ist.time() > datetime.strptime("15:29", "%H:%M").time():
                print("🕒 Market closed. Shutting down.")
                break

            # Fetch fresh option chain
            print("\n📡 Fetching option chain...")
            data = fetch_option_chain(state, state.cid, state.token, Config.SYMBOL)
            if not data:
                print("❌ Chain fetch failed. Retrying next cycle.")
                continue
            options = data["optionsChain"]
            und_ltp = next(o["ltp"] for o in options if o["option_type"] == "")
            vix_ltp = data.get("indiavixData", {}).get("ltp", 0)

            state.snapshots.append((now_ist, options, und_ltp, vix_ltp))
            print(f"📦 Snapshot count: {len(state.snapshots)} (warmup target: {Config.SCORE_WARMUP})")

            # Compute raw metrics
            metrics = compute_option_metrics(state, options)
            net_gamma_raw = metrics["net_gamma_raw"]
            net_dvol_raw = metrics["net_dvol_raw"]
            skew = metrics["skew"]

            # Update EMAs
            net_gamma_ema, net_dvol_ema, skew_smooth = update_emas(state, net_gamma_raw, net_dvol_raw, skew)
            skew_momentum = compute_skew_momentum(state, skew_smooth)
            bull_score, bear_score, _ = compute_scores(state)

            # Trend filter
            trend_ma = compute_trend_filter(state, Config.SYMBOL)
            if trend_ma is not None:
                above_trend = und_ltp > trend_ma
                trend_str = f"30‑MA: {trend_ma:.2f}, {'above' if above_trend else 'below'}"
            else:
                above_trend = True   # not enough data → no filter
                trend_str = "insufficient data, filter skipped"

            # VIX decline check
            vix_change_5m = 0.0
            if len(state.snapshots) >= 5:
                vix_5m_ago = state.snapshots[-5][3] if len(state.snapshots[-5]) > 3 else 0
                if vix_5m_ago:
                    vix_change_5m = vix_ltp - vix_5m_ago
            vix_declining_sharply = vix_change_5m < Config.VIX_DECLINE_THRESH

            # Signal logic
            warmup = len(state.snapshots) >= Config.SCORE_WARMUP
            if not warmup:
                print(f"⏳ WARMUP: {len(state.snapshots)}/{Config.SCORE_WARMUP} snapshots (no trading until warmup complete)")

            raw_signal = "HOLD"
            remarks = ""

            if warmup and not state.day_trading_stopped:
                if state.position is None:
                    # Entry conditions
                    print(f"🔍 Entry check: Bull={bull_score}, Above trend={above_trend}, VIX decline={vix_declining_sharply}")
                    if bull_score == 3 and above_trend and not vix_declining_sharply:
                        raw_signal = "BUY"
                        print("✅ BUY signal triggered")
                    elif bear_score == 3 and not above_trend and not vix_declining_sharply:
                        raw_signal = "SELL"
                        print("✅ SELL signal triggered")
                    else:
                        print("❌ Entry conditions not met")
                else:
                    # Exit conditions
                    exit_now = False
                    # Composite collapse
                    if (state.position == "CE" and bull_score <= 1) or \
                       (state.position == "PE" and bear_score <= 1):
                        exit_now = True
                        remarks = "Composite collapse"
                        print(f"🚨 Exit: Composite collapse (position {state.position}, bull={bull_score}, bear={bear_score})")
                    # Time exit
                    if now_ist.time() >= datetime.strptime(f"{Config.EXIT_TIME_HHMM[0]}:{Config.EXIT_TIME_HHMM[1]}", "%H:%M").time():
                        exit_now = True
                        remarks = "Time exit"
                        print(f"🚨 Exit: Time exit reached")
                    # Dynamic stop loss
                    if state.stop_price and state.entry_symbol:
                        current_premium = get_option_ltp(state, state.cid, state.token, state.entry_symbol)
                        if current_premium:
                            print(f"🔎 Stop check: current LTP {current_premium:.2f} vs stop {state.stop_price:.2f}")
                            if current_premium <= state.stop_price:
                                exit_now = True
                                remarks = f"Dynamic stop (<= {state.stop_price:.2f})"
                                print(f"🚨 Exit: Dynamic stop triggered (LTP {current_premium:.2f} <= stop {state.stop_price:.2f})")
                        else:
                            print("⚠️ Could not fetch LTP for stop check")

                    if exit_now:
                        raw_signal = "EXIT"
            else:
                remarks = "Warming up" if not warmup else "Trading stopped"
                if state.day_trading_stopped:
                    print("🛑 Trading is stopped for the day")

            # Cooldown override
            if state.last_trade_time and raw_signal in ("BUY", "SELL"):
                elapsed = (now_ist - state.last_trade_time).total_seconds() / 60
                if elapsed < Config.COOLDOWN_MINUTES:
                    raw_signal = "HOLD"
                    remarks = f"Cooldown {Config.COOLDOWN_MINUTES - elapsed:.1f} min left"
                    print(f"⏳ Cooldown active: {elapsed:.1f} min since last trade, need {Config.COOLDOWN_MINUTES} min")

            # Log signal
            atm_strike = get_atm_strike(options, und_ltp)
            signal_log.log(
                timestamp=now_ist.strftime("%Y-%m-%d %H:%M:%S"),
                ltp=und_ltp,
                net_gamma=net_gamma_ema,
                skew=skew_smooth,
                skew_momentum=skew_momentum,
                net_dvol=net_dvol_ema,
                bull_score=bull_score,
                bear_score=bear_score,
                signal=raw_signal,
                position=state.position or "None",
                atm_strike=atm_strike or 0,
                entry_premium=state.entry_price or 0,
                vix_ltp=vix_ltp,
                vix_change_5m=vix_change_5m,
                trend_filter=trend_str,
                daily_pnl=state.daily_pnl,
                day_trading_stopped=state.day_trading_stopped,
                remarks=remarks
            )

            # Console summary
            print("\n" + "=" * 80)
            print(f"📊 {now_ist.strftime('%H:%M:%S')}  |  LTP: {und_ltp:.2f}  |  VIX: {vix_ltp:.2f}")
            print(f"   NetGamma: {net_gamma_ema:.6f}  |  Skew: {skew_smooth:.2f} (mom {skew_momentum:.2f})  |  DVol: {net_dvol_ema:.0f}")
            print(f"   Bull: {bull_score}/3  |  Bear: {bear_score}/3  |  Trend: {trend_str}  |  VIXΔ5m: {vix_change_5m:+.2f}")
            print(f"   Position: {state.position or 'None'}  |  Signal: {raw_signal}  ({remarks})")
            print(f"   Daily P&L: ₹{state.daily_pnl:.0f}  |  Trades: {state.total_trades_today}  |  Stopped: {state.day_trading_stopped}")
            print("=" * 80)

            # Execution
            if raw_signal == "EXIT" and state.position:
                # Fetch current LTP for the exit
                exit_ltp = get_option_ltp(state, state.cid, state.token, state.entry_symbol)
                if exit_ltp:
                    exit_position(fy, state, trade_log, exit_ltp, reason=remarks)
                else:
                    print("❌ Could not fetch LTP for exit. Attempting to exit anyway (P&L may be distorted).")
                    exit_position(fy, state, trade_log, 0, reason="Exit without LTP")

            elif raw_signal in ("BUY", "SELL") and state.position is None and state.can_place_trade():
                opt_type = "CE" if raw_signal == "BUY" else "PE"
                atm_strike = get_atm_strike(options, und_ltp)
                if atm_strike:
                    symbol_cand = None
                    for o in options:
                        if o["option_type"] == opt_type and o["strike_price"] == atm_strike:
                            symbol_cand = o["symbol"]
                            break
                    if symbol_cand:
                        premium = get_option_ltp(state, state.cid, state.token, symbol_cand)
                        if premium and premium > 0:
                            qty = Config.LOT_SIZE  # fixed 1 lot
                            # Calculate dynamic stop based on remaining daily loss
                            remaining_loss = state.daily_max_loss + state.daily_pnl  # how much more we can lose today
                            print(f"💰 Entry: Premium={premium:.2f}, Remaining daily loss budget={remaining_loss:.0f}")
                            if remaining_loss <= 0:
                                print("⚠️ No remaining daily loss budget – skipping trade")
                                continue
                            max_loss_per_share = remaining_loss / Config.LOT_SIZE
                            stop_price = premium - max_loss_per_share
                            print(f"🛑 Dynamic stop: max loss per share={max_loss_per_share:.2f}, stop price={stop_price:.2f}")
                            if stop_price <= 0:
                                print("⚠️ Premium too high for daily loss limit – skipping trade")
                                continue

                            # Place entry
                            print(f"🔵 Entering {raw_signal}: {symbol_cand} x {qty} @ {premium:.2f} (Stop: {stop_price:.2f})")
                            order_id, status = place_entry(state, fy, symbol_cand, qty)
                            if order_id and status not in (1, 5):
                                trade_log.log(
                                    now_ist.strftime("%Y-%m-%d %H:%M:%S"),
                                    "ENTRY", symbol_cand, qty, premium, order_id,
                                    f"{raw_signal} signal", state.daily_pnl
                                )
                                state.position = opt_type
                                state.entry_symbol = symbol_cand
                                state.entry_price = premium
                                state.entry_qty = qty
                                state.stop_price = stop_price
                                state.last_trade_time = now_ist
                                print(f"✅ Order placed. Stop set at ₹{stop_price:.2f} (max loss ₹{max_loss_per_share * Config.LOT_SIZE:.0f})")
                            else:
                                print(f"❌ Order failed: {order_id}, status {status}")
                        else:
                            print("❌ Could not fetch LTP for option.")
                    else:
                        print("❌ ATM symbol not found.")
                else:
                    print("❌ ATM strike not found.")

        except KeyboardInterrupt:
            print("\n⏹️ Stopped by user")
            break
        except Exception as e:
            logging.exception("Error in main loop")
            print(f"❌ Error: {e}")
            time.sleep(5)

if __name__ == "__main__":
    main()