import time
import numpy as np
from datetime import datetime
import pytz
from fyers_apiv3 import fyersModel
from fyers_apiv3.FyersWebsocket import data_ws
import logging
import os
import json
from collections import deque
import csv
import threading
import traceback

# ============================================================
# PAPER TRADE FLAG
# ============================================================
PAPER_MODE = True   # Change to False for live trading

# ============================================================
# CONFIGURATION
# ============================================================
class Config:
    SAMPLE_INTERVAL = 1
    OPTION_CHAIN_INTERVAL = 30

    WINDOW_SECONDS = 300        # x minutes (rolling window)
    WINDOW_BARS = WINDOW_SECONDS
    REQUIRED_BARS = WINDOW_SECONDS + 1

    ATM_RANGE = 2
    LOT_SIZE = 195
    MAX_DAILY_ENTRIES = 100
    API_RATE_LIMIT = 200
    API_WINDOW = 60
    MAX_RETRIES = 3
    RETRY_DELAY = 2

    WS_HEARTBEAT_TIMEOUT = 10
    MIN_TRAILING_DISTANCE = 0.5

# ============================================================
# LOGGING
# ============================================================
logging.basicConfig(
    filename="trading_app.log",
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)

def log_debug(msg):
    logging.debug(msg)

def log_console(msg):
    print(msg, flush=True)
    logging.info(msg)

IST = pytz.timezone("Asia/Kolkata")

def now_ist():
    return datetime.now(IST)

def timestamp_ist():
    return now_ist().strftime("%Y-%m-%d %H:%M:%S")

# ============================================================
# ERROR HANDLER
# ============================================================
def handle_errors(func):
    def wrapper(*args, **kwargs):
        for retry in range(Config.MAX_RETRIES):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                log_debug(f"{func.__name__} attempt {retry+1} failed: {e}\n{traceback.format_exc()}")
                if retry < Config.MAX_RETRIES-1:
                    time.sleep(Config.RETRY_DELAY)
                else:
                    log_debug(f"{func.__name__} permanently failed")
                    return None, None, None, None, []
    return wrapper

# ============================================================
# DATA LOGGER (simplified – old frozen columns removed)
# ============================================================
class DataLogger:
    def __init__(self, filename="trading_data.csv"):
        self.filename = filename
        self._ensure_header()

    def _ensure_header(self):
        if not os.path.exists(self.filename):
            with open(self.filename, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'timestamp', 'ltp', 'straddle', 'ce_interp', 'pe_interp',
                    'rolling_max_ltp', 'rolling_min_ltp',
                    'rolling_max_straddle', 'rolling_min_straddle',
                    'rolling_max_ce', 'rolling_min_ce', 'mid_ce',
                    'rolling_max_pe', 'rolling_min_pe', 'mid_pe',
                    'held_symbol', 'held_entry_premium', 'held_current_premium',
                    'trailing_offset', 'trailing_stop',
                    'held_pnl', 'total_paper_pnl', 'daily_entries', 'bars_collected',
                    'decision_reason'
                ])

    def log_data(self, timestamp, ltp, straddle, ce_interp, pe_interp,
                 rolling_max_ltp, rolling_min_ltp,
                 rolling_max_straddle, rolling_min_straddle,
                 rolling_max_ce, rolling_min_ce, mid_ce,
                 rolling_max_pe, rolling_min_pe, mid_pe,
                 active_positions, total_pnl, daily_entries, bars_collected,
                 decision_reason):

        held_s = ''
        held_e = 0.0
        held_c = 0.0
        trail_off = 0.0
        trail_stop = 0.0
        held_p = 0.0

        if len(active_positions) > 0:
            pos = active_positions[0]
            held_s = pos.get('symbol', '')
            held_e = pos.get('entry_premium', 0.0) or 0.0
            held_c = pos.get('current_premium', held_e) or 0.0
            trail_off = pos.get('trailing_offset', 0.0) or 0.0
            # trail_stop displayed as current LTP ± offset (depends on entry type)
            # We can compute it from current_ltp and offset, but we'll approximate using entry_ltp
            entry_ltp = pos.get('entry_ltp', 0.0)
            if pos.get('entry_type') == 'CE':
                trail_stop = entry_ltp - trail_off
            else:
                trail_stop = entry_ltp + trail_off
            if held_e > 0 and held_c > 0:
                held_p = (held_c - held_e) * Config.LOT_SIZE

        with open(self.filename, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                str(timestamp),
                round(ltp, 2) if ltp else 0.0,
                round(straddle, 2) if straddle else 0.0,
                round(ce_interp, 2) if ce_interp else 0.0,
                round(pe_interp, 2) if pe_interp else 0.0,
                round(rolling_max_ltp, 2),
                round(rolling_min_ltp, 2),
                round(rolling_max_straddle, 2),
                round(rolling_min_straddle, 2),
                round(rolling_max_ce, 2),
                round(rolling_min_ce, 2),
                round(mid_ce, 2),
                round(rolling_max_pe, 2),
                round(rolling_min_pe, 2),
                round(mid_pe, 2),
                held_s,
                round(held_e, 2),
                round(held_c, 2),
                round(trail_off, 2),
                round(trail_stop, 2),
                round(held_p, 2),
                round(total_pnl, 2),
                daily_entries,
                bars_collected,
                decision_reason
            ])

# ============================================================
# SESSION STATE (removed pending/frozen fields)
# ============================================================
class SessionState:
    def __init__(self):
        self.lock = threading.RLock()
        self.option_chain_api_count = 0
        self.api_window_start = now_ist()
        self.cid = ""
        self.token = ""
        self.daily_entries = 0
        self.position_state = "FLAT"
        self.eod_square_off_triggered = False
        self.warmup_start_time = None

        self.sold_time = {}
        self.symbol_histories = {}
        self.live_ltp = {}
        self.live_vwap = {}
        self.live_volume = {}

        self.option_chain = []
        self.fut_price = None
        self.expiry_date = None
        self.atm_strike = None
        self.option_symbols = []

        self.strike_to_symbols = {}

        self.active_positions = []
        self.india_vix = 15.0
        self.paper_realized_pnl = 0.0

        self.decision_reason = ""
        self.running = False
        self._order_lock = False

        # Rolling histories
        self.ltp_history = deque(maxlen=Config.REQUIRED_BARS)
        self.straddle_history = deque(maxlen=Config.REQUIRED_BARS)
        self.ce_history = deque(maxlen=Config.REQUIRED_BARS)
        self.pe_history = deque(maxlen=Config.REQUIRED_BARS)
        self.bars_collected = 0

        # Rolling extremes (updated every tick)
        self.rolling_max_ltp = 0.0
        self.rolling_min_ltp = 0.0
        self.rolling_max_straddle = 0.0
        self.rolling_min_straddle = 0.0
        self.rolling_max_ce = 0.0
        self.rolling_min_ce = 0.0
        self.rolling_max_pe = 0.0
        self.rolling_min_pe = 0.0

        self.current_ltp = 0.0
        self.current_straddle = 0.0
        self.current_ce = 0.0
        self.current_pe = 0.0

        self.straddle_data_live = False
        self.last_data_time = None

    def start_warmup(self):
        with self.lock:
            if self.warmup_start_time is None:
                self.warmup_start_time = time.time()
                log_console(f"⏳ Warmup started. Need {Config.REQUIRED_BARS} bars of data.")

    def is_warming_up(self):
        return self.bars_collected < Config.REQUIRED_BARS

    def warmup_remaining(self):
        return max(0, Config.REQUIRED_BARS - self.bars_collected)

    def update_ws(self, symbol, ltp, vwap, volume):
        with self.lock:
            self.last_data_time = time.time()
            if symbol == "NSE:INDIAVIX-INDEX":
                if ltp is not None:
                    self.india_vix = float(ltp)
                return
            if ltp is not None:
                self.live_ltp[symbol] = float(ltp)
            if vwap is not None:
                self.live_vwap[symbol] = float(vwap)
            if volume is not None:
                self.live_volume[symbol] = int(volume)
            if symbol.endswith(('CE','PE')) or symbol == "NSE:NIFTY50-INDEX":
                if symbol not in self.symbol_histories:
                    self.symbol_histories[symbol] = deque(maxlen=10000)
                if ltp is not None:
                    self.symbol_histories[symbol].append((time.time(), float(ltp), float(vwap) if vwap else 0.0))

    def get_ltp(self, symbol):
        with self.lock:
            return self.live_ltp.get(symbol)

    def update_chain(self, chain, fut_price, expiry_date, atm_strike, option_symbols):
        with self.lock:
            self.option_chain = chain
            self.fut_price = float(fut_price) if fut_price else 0.0
            self.expiry_date = expiry_date
            self.atm_strike = int(atm_strike) if atm_strike else None
            self.option_symbols = option_symbols

            self.strike_to_symbols = {}
            for opt in chain:
                strike = opt.get("strike_price")
                if strike is None:
                    continue
                ot = opt.get("option_type")
                sym = opt.get("symbol")
                if ot == "CE":
                    if strike not in self.strike_to_symbols:
                        self.strike_to_symbols[strike] = [None, None]
                    self.strike_to_symbols[strike][0] = sym
                elif ot == "PE":
                    if strike not in self.strike_to_symbols:
                        self.strike_to_symbols[strike] = [None, None]
                    self.strike_to_symbols[strike][1] = sym

    def reset_for_new_day(self):
        with self.lock:
            if self.active_positions:
                log_console(f"⚠️ {len(self.active_positions)} position(s) still tracked, not resetting.")
                return
            self.daily_entries = 0
            self.eod_square_off_triggered = False
            self.position_state = "FLAT"
            self.paper_realized_pnl = 0.0
            self.warmup_start_time = None
            self.sold_time.clear()
            self.decision_reason = ""
            self.bars_collected = 0
            self.ltp_history.clear()
            self.straddle_history.clear()
            self.ce_history.clear()
            self.pe_history.clear()
            self.active_positions.clear()
            self.last_data_time = None
            self.straddle_data_live = False

# ============================================================
# WEBSOCKET MANAGER (unchanged)
# ============================================================
class MarketWSManager:
    def __init__(self, session_state, access_token):
        self.session = session_state
        self.access_token = access_token
        self.ws = None
        self.subscribed = set()
        self.running = False
        self.ws_thread = None

    def on_message(self, message):
        symbol = message.get("symbol")
        if symbol:
            ltp = message.get("ltp")
            vwap = message.get("avg_trade_price")
            volume = message.get("vol_traded_today")
            self.session.update_ws(symbol, ltp, vwap, volume)

    def on_error(self, msg):
        log_console(f"WS error: {msg}")

    def on_close(self, msg):
        log_console(f"WS closed: {msg}. Automatic reconnection is enabled.")

    def on_open(self):
        log_console("✅ WebSocket on_open() triggered")
        if self.subscribed:
            self.ws.subscribe(list(self.subscribed), "SymbolUpdate")
        self.ws.keep_running()

    def _ws_connect(self):
        try:
            self.ws = data_ws.FyersDataSocket(
                access_token=self.access_token,
                log_path="",
                litemode=False,
                write_to_file=False,
                reconnect=True,
                on_connect=self.on_open,
                on_close=self.on_close,
                on_error=self.on_error,
                on_message=self.on_message
            )
            self.ws.connect()
        except Exception as e:
            log_console(f"❌ WebSocket connection thread crashed: {e}")
            log_debug(traceback.format_exc())
        finally:
            log_console("WebSocket thread finished.")

    def start(self):
        if self.running:
            return
        self.running = True
        self.ws_thread = threading.Thread(target=self._ws_connect, daemon=True)
        self.ws_thread.start()

    def subscribe(self, symbols):
        new_symbols = set(symbols) - self.subscribed
        if new_symbols:
            if self.ws:
                self.ws.subscribe(list(new_symbols), "SymbolUpdate")
            self.subscribed.update(new_symbols)

    def stop(self):
        self.running = False
        if self.ws:
            self.ws.close_connection()
        if self.ws_thread and self.ws_thread.is_alive():
            self.ws_thread.join(timeout=2)

    def is_alive(self):
        return self.ws_thread and self.ws_thread.is_alive()

# ============================================================
# REST API (unchanged)
# ============================================================
def enforce_rate_limit(session):
    now = now_ist()
    window = (now - session.api_window_start).total_seconds()
    if window > Config.API_WINDOW:
        session.api_window_start = now
        session.option_chain_api_count = 0
    elif session.option_chain_api_count >= Config.API_RATE_LIMIT:
        wait = Config.API_WINDOW - window
        if wait > 0:
            time.sleep(wait)
        session.api_window_start = now
        session.option_chain_api_count = 0

@handle_errors
def fetch_option_chain(session, index_symbol):
    enforce_rate_limit(session)
    session.option_chain_api_count += 1
    fy = fyersModel.FyersModel(client_id=session.cid, token=session.token, is_async=False, log_path="")
    meta = fy.optionchain(data={"symbol": index_symbol, "timestamp": ""})
    if meta.get("code") != 200:
        return None, None, None, None, []

    fut_price = None
    for item in meta["data"]["optionsChain"]:
        if item.get("option_type") == "":
            fut_price = item.get("fp")
            break
    if fut_price is None:
        fut_price = meta["data"].get("fp", 0.0)

    exp_list = sorted([(e["date"], e["expiry"]) for e in meta["data"]["expiryData"]],
                      key=lambda x: datetime.strptime(x[0], "%d-%m-%Y"))
    today = now_ist().date()
    idx = 0
    for i, (d_str, _) in enumerate(exp_list):
        if datetime.strptime(d_str, "%d-%m-%Y").date() >= today:
            idx = i
            break
    curr_date, expiry_ts = exp_list[idx]

    payload = {"symbol": index_symbol, "strikecount": Config.ATM_RANGE, "timestamp": expiry_ts, "greeks": "1"}
    session.option_chain_api_count += 1
    resp = fy.optionchain(data=payload)
    if resp.get("code") != 200:
        return None, None, None, None, []

    chain = resp["data"]["optionsChain"]
    for opt in chain:
        greeks = opt.get("greeks", {})
        opt["delta"] = greeks.get("delta", 0.0) if greeks else 0.0
        opt["gamma"] = greeks.get("gamma", 0.0) if greeks else 0.0
        opt["oi"] = opt.get("oi", 0)

    option_symbols = [opt["symbol"] for opt in chain if opt.get("option_type") in ("CE","PE")]
    return chain, fut_price, curr_date, expiry_ts, option_symbols

# ============================================================
# CHAIN POLLER (unchanged)
# ============================================================
def chain_poller(session, ws_manager, index_symbol):
    while session.running:
        try:
            chain, fut_price, expiry_date, _, opt_symbols = fetch_option_chain(session, index_symbol)
            if chain is not None:
                underlying_ltp = session.get_ltp(index_symbol)
                if underlying_ltp is None:
                    underlying_ltp = fut_price
                strikes = sorted(set(opt["strike_price"] for opt in chain if opt.get("option_type") in ("CE","PE")))
                if strikes and underlying_ltp:
                    atm = min(strikes, key=lambda x: abs(x - underlying_ltp))
                else:
                    atm = None
                session.update_chain(chain, fut_price, expiry_date, atm, opt_symbols)
                all_syms = [index_symbol, "NSE:INDIAVIX-INDEX"] + opt_symbols
                ws_manager.subscribe(all_syms)
            time.sleep(Config.OPTION_CHAIN_INTERVAL)
        except Exception as e:
            log_debug(f"Chain poller error: {e}\n{traceback.format_exc()}")
            time.sleep(Config.OPTION_CHAIN_INTERVAL)

# ============================================================
# LIVE INTERPOLATION (unchanged)
# ============================================================
def get_interpolated_straddle_live(session, spot):
    strike_map = session.strike_to_symbols
    if not strike_map:
        session.straddle_data_live = False
        return None, None, None

    strikes = sorted(strike_map.keys())
    low_strike = None
    high_strike = None
    for s in strikes:
        if s <= spot:
            low_strike = s
        elif s > spot:
            high_strike = s
            break

    if low_strike is None or high_strike is None:
        session.straddle_data_live = False
        return None, None, None

    ce_low_sym, pe_low_sym = strike_map[low_strike]
    ce_high_sym, pe_high_sym = strike_map[high_strike]

    all_live = True

    def get_ltp_fallback(symbol):
        nonlocal all_live
        ltp = session.get_ltp(symbol)
        if ltp is not None and ltp > 0:
            return ltp
        log_debug(f"⚠️ No WS price for {symbol}, falling back to option chain snapshot")
        for opt in session.option_chain:
            if opt["symbol"] == symbol:
                all_live = False
                return opt.get("ltp", 0.0)
        all_live = False
        return None

    ce_low = get_ltp_fallback(ce_low_sym) if ce_low_sym else None
    ce_high = get_ltp_fallback(ce_high_sym) if ce_high_sym else None
    pe_low = get_ltp_fallback(pe_low_sym) if pe_low_sym else None
    pe_high = get_ltp_fallback(pe_high_sym) if pe_high_sym else None

    session.straddle_data_live = all_live

    if None in (ce_low, ce_high, pe_low, pe_high):
        return None, None, None

    w = (spot - low_strike) / (high_strike - low_strike)
    ce_interp = ce_low * (1 - w) + ce_high * w
    pe_interp = pe_low * (1 - w) + pe_high * w
    straddle = ce_interp + pe_interp

    return ce_interp, pe_interp, straddle

def get_real_atm_premium(session, spot, option_type):
    chain = session.option_chain
    if not chain:
        return None
    target = "CE" if option_type == "CE" else "PE"
    best = None
    best_dist = float('inf')
    for opt in chain:
        if opt.get("option_type") != target:
            continue
        strike = opt.get("strike_price")
        if strike is None:
            continue
        dist = abs(strike - spot)
        if dist < best_dist:
            best_dist = dist
            best = opt.get("ltp")
    return best

# ============================================================
# STATE MACHINE (NEW ENTRY/EXIT LOGIC)
# ============================================================
def process_snapshot(session, fyers, execute_trades=False):
    if getattr(session, '_order_lock', False):
        return
    session._order_lock = True
    try:
        with session.lock:
            spot = session.get_ltp("NSE:NIFTY50-INDEX")
            if spot is None or spot <= 0:
                session.decision_reason = "No LTP"
                session._order_lock = False
                return

            ce_interp, pe_interp, straddle = get_interpolated_straddle_live(session, spot)
            if straddle is None or straddle <= 0:
                session.decision_reason = "No straddle (waiting for chain)"
                session._order_lock = False
                return

            session.current_ltp = spot
            session.current_straddle = straddle
            session.current_ce = ce_interp
            session.current_pe = pe_interp

            # Update rolling histories
            session.ltp_history.append(spot)
            session.straddle_history.append(straddle)
            session.ce_history.append(ce_interp)
            session.pe_history.append(pe_interp)

            if session.bars_collected < Config.REQUIRED_BARS:
                session.bars_collected += 1

            # Compute rolling max/min from previous bars (exclude current)
            if len(session.ltp_history) >= 2:
                prev_ltp = list(session.ltp_history)[:-1]
                prev_strad = list(session.straddle_history)[:-1]
                prev_ce = list(session.ce_history)[:-1]
                prev_pe = list(session.pe_history)[:-1]
                if prev_ltp:
                    session.rolling_max_ltp = max(prev_ltp)
                    session.rolling_min_ltp = min(prev_ltp)
                if prev_strad:
                    session.rolling_max_straddle = max(prev_strad)
                    session.rolling_min_straddle = min(prev_strad)
                if prev_ce:
                    session.rolling_max_ce = max(prev_ce)
                    session.rolling_min_ce = min(prev_ce)
                if prev_pe:
                    session.rolling_max_pe = max(prev_pe)
                    session.rolling_min_pe = min(prev_pe)

            # Warmup check
            if session.is_warming_up():
                session.decision_reason = f"Warming up ({session.bars_collected}/{Config.REQUIRED_BARS})"
                session._order_lock = False
                return

            # ================================================
            # EXIT LOGIC (fixed offset trailing stop on LTP)
            # ================================================
            if session.active_positions:
                pos = session.active_positions[0]
                offset = pos["trailing_offset"]

                if pos["entry_type"] == "CE":
                    stop = spot - offset
                    session.decision_reason = (f"Holding CE | Offset: {offset:.2f} | "
                                               f"Stop: {stop:.2f} | LTP: {spot:.2f}")
                    if spot <= stop and execute_trades:
                        held_symbol = pos["symbol"]
                        if PAPER_MODE:
                            current_premium = session.get_ltp(held_symbol)
                            if current_premium is None:
                                for opt in session.option_chain:
                                    if opt["symbol"] == held_symbol:
                                        current_premium = opt.get("ltp", 0)
                                        break
                            if current_premium is None or current_premium == 0:
                                current_premium = pos["entry_premium"]
                            pnl = (current_premium - pos["entry_premium"]) * Config.LOT_SIZE
                            session.paper_realized_pnl += pnl
                            log_console(f"📉 CE exit | LTP {spot:.2f} ≤ stop {stop:.2f} | P&L={pnl:+.2f}")
                            session.active_positions.clear()
                            session.position_state = "FLAT"
                        else:
                            order = {"symbol": held_symbol, "qty": Config.LOT_SIZE, "type": 2,
                                     "side": -1, "productType": "MARGIN", "validity": "DAY"}
                            resp = fyers.place_order(data=order)
                            if resp.get("s") == "ok":
                                session.active_positions.clear()
                                session.position_state = "FLAT"
                                log_console(f"📉 CE exit live | LTP {spot:.2f} ≤ stop {stop:.2f}")
                            else:
                                log_console(f"❌ Failed to exit {held_symbol}: {resp}")
                        session._order_lock = False
                        return

                else:  # PE
                    stop = spot + offset
                    session.decision_reason = (f"Holding PE | Offset: {offset:.2f} | "
                                               f"Stop: {stop:.2f} | LTP: {spot:.2f}")
                    if spot >= stop and execute_trades:
                        held_symbol = pos["symbol"]
                        if PAPER_MODE:
                            current_premium = session.get_ltp(held_symbol)
                            if current_premium is None:
                                for opt in session.option_chain:
                                    if opt["symbol"] == held_symbol:
                                        current_premium = opt.get("ltp", 0)
                                        break
                            if current_premium is None or current_premium == 0:
                                current_premium = pos["entry_premium"]
                            pnl = (current_premium - pos["entry_premium"]) * Config.LOT_SIZE
                            session.paper_realized_pnl += pnl
                            log_console(f"📈 PE exit | LTP {spot:.2f} ≥ stop {stop:.2f} | P&L={pnl:+.2f}")
                            session.active_positions.clear()
                            session.position_state = "FLAT"
                        else:
                            order = {"symbol": held_symbol, "qty": Config.LOT_SIZE, "type": 2,
                                     "side": -1, "productType": "MARGIN", "validity": "DAY"}
                            resp = fyers.place_order(data=order)
                            if resp.get("s") == "ok":
                                session.active_positions.clear()
                                session.position_state = "FLAT"
                                log_console(f"📈 PE exit live | LTP {spot:.2f} ≥ stop {stop:.2f}")
                            else:
                                log_console(f"❌ Failed to exit {held_symbol}: {resp}")
                        session._order_lock = False
                        return

                # Update current premium (actual chain/WS price)
                current_premium = session.get_ltp(pos["symbol"])
                if current_premium is None:
                    for opt in session.option_chain:
                        if opt["symbol"] == pos["symbol"]:
                            current_premium = opt.get("ltp", 0)
                            break
                pos["current_premium"] = current_premium if current_premium else pos["entry_premium"]
                session._order_lock = False
                return

            # ================================================
            # ENTRY LOGIC (original asymmetric rules)
            # ================================================
            if session.daily_entries >= Config.MAX_DAILY_ENTRIES:
                session.decision_reason = "Max daily entries reached"
                session._order_lock = False
                return

            # Buy signal: LTP > rolling_max AND straddle > rolling_max
            buy_signal = (spot > session.rolling_max_ltp) and (straddle > session.rolling_max_straddle)
            # Sell signal (asymmetric): LTP < rolling_min AND straddle > rolling_max
            sell_signal = (spot < session.rolling_min_ltp) and (straddle > session.rolling_max_straddle)

            if buy_signal and sell_signal:
                # Resolve conflict: prefer the side with greater deviation
                delta_buy = spot - session.rolling_max_ltp
                delta_sell = session.rolling_min_ltp - spot
                if delta_buy >= delta_sell:
                    sell_signal = False
                else:
                    buy_signal = False

            if not buy_signal and not sell_signal:
                session.decision_reason = "IDLE (no breakout)"
                session._order_lock = False
                return

            if buy_signal:
                entry_type = "CE"
                log_console(f"🔔 BUY CE: LTP {spot:.2f} > {session.rolling_max_ltp:.2f} AND "
                            f"Straddle {straddle:.2f} > {session.rolling_max_straddle:.2f}")
            else:
                entry_type = "PE"
                log_console(f"🔔 BUY PE: LTP {spot:.2f} < {session.rolling_min_ltp:.2f} AND "
                            f"Straddle {straddle:.2f} > {session.rolling_max_straddle:.2f}")

            # Actual ATM premium from chain (NOT interpolated)
            entry_premium = get_real_atm_premium(session, spot, entry_type)
            if entry_premium is None or entry_premium <= 0:
                session.decision_reason = f"Invalid actual premium for {entry_type}"
                session._order_lock = False
                return

            # Find the actual ATM symbol
            symbol = None
            min_dist = float('inf')
            for opt in session.option_chain:
                if opt.get("option_type") == entry_type:
                    strike = opt.get("strike_price")
                    if strike is not None:
                        dist = abs(strike - spot)
                        if dist < min_dist:
                            min_dist = dist
                            symbol = opt["symbol"]
            if symbol is None:
                session.decision_reason = f"No ATM {entry_type} symbol found"
                session._order_lock = False
                return

            # Trailing offset = rolling_max_ltp - midpoint (midpoint = (max+min)/2)
            mid_ltp = (session.rolling_max_ltp + session.rolling_min_ltp) / 2.0
            distance = session.rolling_max_ltp - mid_ltp   # same as (high - low)/2

            if distance < Config.MIN_TRAILING_DISTANCE:
                distance = Config.MIN_TRAILING_DISTANCE

            # Execute entry with actual ATM premium
            if execute_trades:
                if PAPER_MODE:
                    session.active_positions.append({
                        "symbol": symbol,
                        "entry_premium": entry_premium,
                        "entry_type": entry_type,
                        "entry_ltp": spot,
                        "current_premium": entry_premium,
                        "trailing_offset": distance,
                    })
                    session.daily_entries += 1
                    session.position_state = "ACTIVE"
                    log_console(f"🟢 BOUGHT {symbol} @ {entry_premium:.2f} | "
                                f"Entry LTP {spot:.2f} | Offset={distance:.2f}")
                else:
                    order = {"symbol": symbol, "qty": Config.LOT_SIZE, "type": 2,
                             "side": 1, "productType": "MARGIN", "validity": "DAY"}
                    resp = fyers.place_order(data=order)
                    if resp.get("s") == "ok":
                        session.active_positions.append({
                            "symbol": symbol,
                            "entry_premium": entry_premium,
                            "entry_type": entry_type,
                            "entry_ltp": spot,
                            "current_premium": entry_premium,
                            "trailing_offset": distance,
                        })
                        session.daily_entries += 1
                        session.position_state = "ACTIVE"
                        log_console(f"🟢 BOUGHT {symbol} @ {entry_premium:.2f} | "
                                    f"LTP {spot:.2f} | Offset={distance:.2f} (ID: {resp.get('id')})")
                    else:
                        log_console(f"❌ Failed to buy {symbol}: {resp}")
                session.decision_reason = f"Entered {symbol} | Offset={distance:.2f}"
            else:
                log_console(f"✅ Signal ({entry_type}) – trades disabled")
                session.decision_reason = f"Signal ({entry_type}) – trades disabled"

            session._order_lock = False
            return

    except Exception as e:
        log_console(f"process_snapshot error: {e}")
        log_debug(traceback.format_exc())
        session.decision_reason = f"Error: {str(e)}"
    finally:
        session._order_lock = False

# ============================================================
# SAMPLER THREAD (updated data_logger call)
# ============================================================
def sampler(session, data_logger, auto_trade, fyers):
    log_debug("Sampler thread started")
    first_run = True
    while session.running:
        start = now_ist()
        try:
            if first_run:
                session.start_warmup()
                first_run = False

            process_snapshot(session, fyers, execute_trades=auto_trade)

            total_pnl = session.paper_realized_pnl
            for pos in session.active_positions:
                current = pos.get("current_premium", pos["entry_premium"])
                if current and pos.get("entry_premium"):
                    total_pnl += (current - pos["entry_premium"]) * Config.LOT_SIZE

            with session.lock:
                for pos in session.active_positions:
                    current_premium = session.get_ltp(pos["symbol"])
                    if current_premium is None:
                        for opt in session.option_chain:
                            if opt["symbol"] == pos["symbol"]:
                                current_premium = opt.get("ltp", 0)
                                break
                    pos["current_premium"] = current_premium if current_premium else pos["entry_premium"]

            mid_ce = (session.rolling_max_ce + session.rolling_min_ce) / 2.0 if session.rolling_max_ce else 0.0
            mid_pe = (session.rolling_max_pe + session.rolling_min_pe) / 2.0 if session.rolling_max_pe else 0.0

            data_logger.log_data(
                timestamp=timestamp_ist(),
                ltp=session.current_ltp,
                straddle=session.current_straddle,
                ce_interp=session.current_ce,
                pe_interp=session.current_pe,
                rolling_max_ltp=session.rolling_max_ltp,
                rolling_min_ltp=session.rolling_min_ltp,
                rolling_max_straddle=session.rolling_max_straddle,
                rolling_min_straddle=session.rolling_min_straddle,
                rolling_max_ce=session.rolling_max_ce,
                rolling_min_ce=session.rolling_min_ce,
                mid_ce=mid_ce,
                rolling_max_pe=session.rolling_max_pe,
                rolling_min_pe=session.rolling_min_pe,
                mid_pe=mid_pe,
                active_positions=session.active_positions,
                total_pnl=total_pnl,
                daily_entries=session.daily_entries,
                bars_collected=session.bars_collected,
                decision_reason=session.decision_reason
            )

            elapsed = (now_ist() - start).total_seconds()
            if elapsed < Config.SAMPLE_INTERVAL:
                time.sleep(Config.SAMPLE_INTERVAL - elapsed)

        except Exception as e:
            log_debug(f"Sampler error: {e}\n{traceback.format_exc()}")
            time.sleep(1)

# ============================================================
# DASHBOARD (simplified – removed frozen‑level display)
# ============================================================
class TerminalDashboard:
    def __init__(self, data_logger, session_state):
        self.data_logger = data_logger
        self.session_state = session_state

    def display(self):
        try:
            os.system('cls' if os.name == 'nt' else 'clear')
            mode = "PAPER" if PAPER_MODE else "LIVE"
            print("\n" + "="*120)
            print(f"📊 {mode} TRADING DASHBOARD – Straddle Breakout + Trailing Stop")
            print("="*120)

            with self.session_state.lock:
                daily_entries = self.session_state.daily_entries
                vix = self.session_state.india_vix
                realized = self.session_state.paper_realized_pnl
                decision_reason = self.session_state.decision_reason
                bars_collected = self.session_state.bars_collected
                warmup = self.session_state.is_warming_up()
                warmup_rem = self.session_state.warmup_remaining()

                ltp = self.session_state.current_ltp
                straddle = self.session_state.current_straddle
                ce = self.session_state.current_ce
                pe = self.session_state.current_pe

                rolling_max_ltp = self.session_state.rolling_max_ltp
                rolling_min_ltp = self.session_state.rolling_min_ltp
                rolling_max_straddle = self.session_state.rolling_max_straddle
                rolling_min_straddle = self.session_state.rolling_min_straddle
                rolling_max_ce = self.session_state.rolling_max_ce
                rolling_min_ce = self.session_state.rolling_min_ce
                rolling_max_pe = self.session_state.rolling_max_pe
                rolling_min_pe = self.session_state.rolling_min_pe
                mid_ce = (rolling_max_ce + rolling_min_ce) / 2.0 if rolling_max_ce else 0.0
                mid_pe = (rolling_max_pe + rolling_min_pe) / 2.0 if rolling_max_pe else 0.0

                active_positions = self.session_state.active_positions[:]
                live_data = self.session_state.straddle_data_live
                last_data = self.session_state.last_data_time
                last_data_str = datetime.fromtimestamp(last_data).strftime("%H:%M:%S") if last_data else "No data yet"

            window_min = Config.WINDOW_SECONDS / 60.0
            window_label = f"{int(window_min)} min" if window_min == int(window_min) else f"{Config.WINDOW_SECONDS}s"

            if warmup:
                status = f"🔥 WARMUP [{bars_collected}/{Config.REQUIRED_BARS}]"
            else:
                status = f"✅ ACTIVE [{bars_collected}/{Config.REQUIRED_BARS}]"

            pos_str = "NEUTRAL"
            if active_positions:
                pos = active_positions[0]
                offset = pos.get('trailing_offset', 0)
                entry_type = pos.get('entry_type', '?')
                if entry_type == 'CE':
                    stop = ltp - offset
                else:
                    stop = ltp + offset
                current = pos.get('current_premium', pos.get('entry_premium', 0))
                entry = pos.get('entry_premium', 0)
                pnl = ((current - entry) * Config.LOT_SIZE) if current and entry else 0
                pos_str = (f"{entry_type} "
                          f"Entry={entry:.2f} "
                          f"Stop={stop:.2f} "
                          f"P&L={pnl:+.2f}")

            print(f"Last Update: {timestamp_ist()}   |   WS Last Data: {last_data_str}")
            print(f"📈 Daily Entries: {daily_entries}/{Config.MAX_DAILY_ENTRIES}")
            print(f"📊 India VIX: {vix:.2f}")
            print(f"💰 Realized P&L: {realized:+.2f}")

            if warmup:
                print(f"⏳ WARMING UP... {warmup_rem} bars remaining")
            else:
                print("✅ WARMUP COMPLETE – Trading active")

            print("\n" + "-"*80)
            print("📊 SNAPSHOT DATA")
            print("-"*80)
            print(f"  LTP: {ltp:.2f} | Straddle: {straddle:.2f}")
            print(f"  Data source: {'🔴 LIVE (WebSocket)' if live_data else '🟡 STALE (Option chain fallback)'}")
            print(f"  CE (ATM interp): {ce:.2f} | PE (ATM interp): {pe:.2f}")
            print(f"  Rolling LTP:  Max {rolling_max_ltp:.2f}  |  Min {rolling_min_ltp:.2f}")
            print(f"  Rolling Straddle:  Max {rolling_max_straddle:.2f}  |  Min {rolling_min_straddle:.2f}")
            print(f"  Rolling CE:  Max {rolling_max_ce:.2f}  |  Min {rolling_min_ce:.2f}  |  Mid {mid_ce:.2f}")
            print(f"  Rolling PE:  Max {rolling_max_pe:.2f}  |  Min {rolling_min_pe:.2f}  |  Mid {mid_pe:.2f}")

            print("\n" + "-"*80)
            print("📌 POSITION & EXIT (TRAILING STOP)")
            print("-"*80)
            if active_positions:
                pos = active_positions[0]
                offset = pos.get('trailing_offset', 0)
                current = pos.get('current_premium', pos.get('entry_premium', 0))
                entry = pos.get('entry_premium', 0)
                pnl = ((current - entry) * Config.LOT_SIZE) if current and entry else 0
                entry_type = pos.get('entry_type', '?')
                if entry_type == 'CE':
                    stop = ltp - offset
                else:
                    stop = ltp + offset
                print(f"  Symbol: {pos.get('symbol','?')}")
                print(f"  Entry Premium: {entry:.2f} | Current: {current:.2f} | P&L: {pnl:+.2f}")
                print(f"  Trailing Offset: {offset:.2f} (frozen at entry)")
                print(f"  Current Stop: {stop:.2f} (LTP {'- offset' if entry_type=='CE' else '+ offset'})")
                print(f"  Exit: when LTP {'≤' if entry_type=='CE' else '≥'} {stop:.2f}")
            else:
                print("  No active position (FLAT)")

            print("\n" + "-"*80)
            print("🧠 STATUS")
            print("-"*80)
            print(f"  {status}")
            print(f"  Position: {pos_str}")
            print(f"  Decision: {decision_reason}")

            print("\n" + "-"*80)
            print("⚙️ CONFIGURATION")
            print("-"*80)
            print(f"  Rolling Window: {window_label}")
            print(f"  Entry rules: LTP breakout + Straddle breakout (asymmetric for sell)")
            print(f"  Trailing Stop: LTP ± (rolling_max – midpoint) of underlying")
            print(f"  Min Trailing Distance: {Config.MIN_TRAILING_DISTANCE}")
            print(f"  Lot Size: {Config.LOT_SIZE}")

            print("\n" + "="*120)
        except Exception as e:
            log_debug(f"Dashboard error: {e}")

# ============================================================
# HEARTBEAT MONITOR (unchanged)
# ============================================================
def heartbeat_monitor(session, ws_manager):
    while session.running:
        time.sleep(Config.WS_HEARTBEAT_TIMEOUT // 2)
        last = session.last_data_time
        if last is not None and (time.time() - last) > Config.WS_HEARTBEAT_TIMEOUT:
            log_console(f"⚠️ No WS data for >{Config.WS_HEARTBEAT_TIMEOUT}s, triggering reconnection...")
            ws_manager.stop()
            time.sleep(2)
            ws_manager.start()

# ============================================================
# CREDENTIALS & MAIN (unchanged)
# ============================================================
def load_credentials(session):
    try:
        with open('fyers_credentials.json', 'r') as f:
            creds = json.load(f)
            session.cid = creds.get('client_id', '')
            session.token = creds.get('access_token', '')
        log_console(f"Loaded credentials: {session.cid}")
    except Exception as e:
        log_console(f"Failed to load credentials file: {e} – falling back to env vars")
        session.cid = os.getenv("FYERS_CID", "")
        session.token = os.getenv("FYERS_TOKEN", "")
        log_console(f"Using env vars: {session.cid}")

def main():
    log_console("Starting Straddle + Price Breakout Strategy (Trailing Stop on Underlying)...")
    session = SessionState()
    load_credentials(session)
    data_logger = DataLogger()
    dashboard = TerminalDashboard(data_logger, session)
    index_symbol = "NSE:NIFTY50-INDEX"
    vix_symbol = "NSE:INDIAVIX-INDEX"

    poller_thread = None
    sampler_thread = None
    heartbeat_thread = None
    ws_manager = None
    fyers = None

    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        print("="*50)
        mode = "PAPER" if PAPER_MODE else "LIVE"
        print(f"📈 FYERS ALGO TRADING ({mode} MODE)")
        print("1. Start Trading")
        print("2. Settings")
        print("3. Exit")
        choice = input("Select option: ").strip()
        if choice == "1":
            if not (session.cid and session.token):
                print("❌ Set credentials first")
                input("Press Enter...")
                continue

            session.reset_for_new_day()

            auto_trade = input("Enable Auto Trade? (y/n): ").lower() == 'y'
            log_console(f"Auto trade: {'ON' if auto_trade else 'OFF'}")

            ws_manager = MarketWSManager(session, session.token)
            ws_manager.start()
            ws_manager.subscribe([index_symbol, vix_symbol])
            session.running = True

            fyers = fyersModel.FyersModel(client_id=session.cid, token=session.token, is_async=False, log_path="")
            poller_thread = threading.Thread(target=chain_poller, args=(session, ws_manager, index_symbol), daemon=True)
            sampler_thread = threading.Thread(target=sampler, args=(session, data_logger, auto_trade, fyers), daemon=True)
            heartbeat_thread = threading.Thread(target=heartbeat_monitor, args=(session, ws_manager), daemon=True)

            poller_thread.start()
            sampler_thread.start()
            heartbeat_thread.start()

            print("\n✅ Trading started. Press Ctrl+C to stop.\n")
            try:
                while True:
                    dashboard.display()
                    time.sleep(1)
            except KeyboardInterrupt:
                log_console("\n🛑 Stopping trading...")
                session.running = False
                ws_manager.stop()

                if sampler_thread is not None:
                    sampler_thread.join(timeout=5)
                if poller_thread is not None:
                    poller_thread.join(timeout=Config.OPTION_CHAIN_INTERVAL + 5)
                if heartbeat_thread is not None:
                    heartbeat_thread.join(timeout=2)

                if session.active_positions:
                    log_console(f"Attempting to close {len(session.active_positions)} open position(s)...")
                    process_snapshot(session, fyers, execute_trades=True)

                with session.lock:
                    if session.active_positions:
                        log_console(f"⚠️ {len(session.active_positions)} position(s) could not be closed. Check broker manually.")
                    else:
                        session.eod_square_off_triggered = False
                        session.daily_entries = 0
                        session.paper_realized_pnl = 0.0
                        session.warmup_start_time = None
                        session.sold_time.clear()
                        log_console("✅ Trading stopped and state reset. You can start again.")
        elif choice == "2":
            print("\n⚙️ SETTINGS")
            new_cid = input(f"Client ID [{session.cid}]: ").strip()
            if new_cid:
                session.cid = new_cid
            new_token = input("Access token: ").strip()
            if new_token:
                session.token = new_token
            with open('fyers_credentials.json', 'w') as f:
                json.dump({"client_id": session.cid, "access_token": session.token}, f)
            print("✅ Saved")
            input("Press Enter...")
        elif choice == "3":
            if session.running:
                session.running = False
                if ws_manager:
                    ws_manager.stop()
            if session.active_positions:
                log_console(f"⚠️ Exiting with {len(session.active_positions)} position(s) still tracked.")
            break

if __name__ == "__main__":
    main()