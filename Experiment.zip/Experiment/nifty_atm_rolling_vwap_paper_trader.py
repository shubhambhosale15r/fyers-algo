
import csv
import os
import threading
import time
import traceback
from collections import deque
from dataclasses import dataclass
from datetime import datetime, time as dt_time
from typing import Dict, List, Optional, Tuple

import pytz
from fyers_apiv3 import fyersModel
from fyers_apiv3.FyersWebsocket import data_ws


# ============================================================
# CONFIG
# ============================================================

class Config:
    # --------------------------------------------------------
    # Fyers
    # --------------------------------------------------------
    CLIENT_ID = os.getenv("FYERS_CLIENT_ID", "YOUR_CLIENT_ID-100")
    ACCESS_TOKEN = os.getenv("FYERS_ACCESS_TOKEN", "YOUR_ACCESS_TOKEN")

    INDEX_SYMBOL = "NSE:NIFTY50-INDEX"

    # --------------------------------------------------------
    # Strategy
    # --------------------------------------------------------
    PAPER_MODE = True

    # Option-chain polling interval.
    OPTION_CHAIN_INTERVAL_SEC = 30

    # Rolling VWAP windows.
    VWAP_FAST_SEC = 60
    VWAP_SLOW_SEC = 300

    # Need a genuinely populated 5-minute window before entry.
    REQUIRE_FULL_5M_WARMUP = True

    # Maximum number of simultaneously open paper positions.
    MAX_OPEN_POSITIONS = 1

    # --------------------------------------------------------
    # Paper execution
    # --------------------------------------------------------
    # For a bought option, use ask for paper entry and bid for
    # paper exit when valid. This is more realistic than using
    # LTP for both sides.
    USE_ASK_FOR_ENTRY = True
    USE_BID_FOR_EXIT = True

    # NIFTY lot size. Change this when the applicable contract
    # lot size changes.
    LOT_SIZE = 65

    # Set to 0.0 to disable the daily limits.
    DAILY_MAX_LOSS_PCT = 0.0
    DAILY_TARGET_PCT = 0.0

    # Capital is only used for the optional daily limits.
    PAPER_CAPITAL = 100000.0

    # --------------------------------------------------------
    # Intraday timing - Asia/Kolkata
    # --------------------------------------------------------
    TIMEZONE = "Asia/Kolkata"
    MARKET_START = dt_time(9, 15)
    LAST_ENTRY_TIME = dt_time(15, 00)
    FORCE_EXIT_TIME = dt_time(15, 05)
    MARKET_END = dt_time(15, 30)

    # --------------------------------------------------------
    # Terminal
    # --------------------------------------------------------
    PRINT_EVERY_TICK = True
    DASHBOARD_INTERVAL_SEC = 1

    # --------------------------------------------------------
    # CSV
    # --------------------------------------------------------
    LOG_DIR = "vwap_logs"

    # --------------------------------------------------------
    # WebSocket
    # --------------------------------------------------------
    WS_LOG_PATH = ""
    WS_LITEMODE = False
    WS_WRITE_TO_FILE = False
    WS_RECONNECT = True


# ============================================================
# DATA STRUCTURES
# ============================================================

@dataclass
class Tick:
    ltt: int
    ltp: float
    ltq: int
    vol_traded_today: int
    bid: float
    ask: float
    received_at: float

    @property
    def timestamp(self) -> float:
        return float(self.ltt)

    @property
    def pv(self) -> float:
        return self.ltp * self.ltq


@dataclass
class ContractInfo:
    symbol: str
    strike: int
    option_type: str
    offset_name: str  # ATM-1 / ATM / ATM+1


@dataclass
class Position:
    side: str                 # CE / PE
    symbol: str
    strike: int
    option_type: str
    entry_time: str
    entry_price: float
    entry_ltp: float
    entry_bid: float
    entry_ask: float
    entry_vwap_1m: float
    entry_vwap_5m: float
    entry_vwap_diff: float
    quantity: int


# ============================================================
# HELPERS
# ============================================================

class TimeHelper:
    TZ = pytz.timezone(Config.TIMEZONE)

    @classmethod
    def now(cls) -> datetime:
        return datetime.now(cls.TZ)

    @classmethod
    def now_str(cls) -> str:
        return cls.now().strftime("%Y-%m-%d %H:%M:%S")

    @classmethod
    def epoch_to_str(cls, epoch: int) -> str:
        try:
            return datetime.fromtimestamp(int(epoch), cls.TZ).strftime(
                "%Y-%m-%d %H:%M:%S"
            )
        except Exception:
            return ""

    @classmethod
    def current_time_only(cls) -> dt_time:
        return cls.now().time().replace(microsecond=0)


def safe_float(value, default=0.0) -> float:
    try:
        if value is None:
            return default
        return float(value)
    except Exception:
        return default


def safe_int(value, default=0) -> int:
    try:
        if value is None:
            return default
        return int(value)
    except Exception:
        return default


def is_valid_price(value: float) -> bool:
    return value is not None and value > 0


# ============================================================
# CSV LOGGER
# ============================================================

class CSVLogger:
    def __init__(self):
        os.makedirs(Config.LOG_DIR, exist_ok=True)

        date_str = TimeHelper.now().strftime("%Y%m%d")

        self.tick_file = os.path.join(
            Config.LOG_DIR, f"tick_data_{date_str}.csv"
        )
        self.trade_file = os.path.join(
            Config.LOG_DIR, f"paper_trades_{date_str}.csv"
        )
        self.event_file = os.path.join(
            Config.LOG_DIR, f"events_{date_str}.csv"
        )

        self.lock = threading.Lock()

        self.tick_fields = [
            "log_time",
            "ltt",
            "ltt_ist",
            "symbol",
            "strike",
            "option_type",
            "offset_name",
            "ltp",
            "ltq",
            "vol_traded_today",
            "bid",
            "ask",
            "rolling_qty_1m",
            "rolling_qty_5m",
            "vwap_1m",
            "vwap_5m",
            "vwap_diff",
            "vwap_spread_pct",
            "previous_vwap_diff",
            "cross_signal",
            "warmup_ready",
            "is_atm",
            "position",
        ]

        self.trade_fields = [
            "event_time",
            "action",
            "side",
            "symbol",
            "strike",
            "option_type",
            "quantity",
            "entry_time",
            "entry_price",
            "entry_ltp",
            "entry_bid",
            "entry_ask",
            "entry_vwap_1m",
            "entry_vwap_5m",
            "entry_vwap_diff",
            "exit_time",
            "exit_price",
            "exit_ltp",
            "exit_bid",
            "exit_ask",
            "exit_vwap_1m",
            "exit_vwap_5m",
            "exit_vwap_diff",
            "gross_pnl_points",
            "gross_pnl_rupees",
            "estimated_charges",
            "net_pnl_rupees",
            "reason",
        ]

        self.event_fields = [
            "event_time",
            "event",
            "message",
            "symbol",
            "strike",
            "option_type",
            "details",
        ]

        self._ensure_header(self.tick_file, self.tick_fields)
        self._ensure_header(self.trade_file, self.trade_fields)
        self._ensure_header(self.event_file, self.event_fields)

    @staticmethod
    def _ensure_header(path: str, fields: List[str]):
        if not os.path.exists(path) or os.path.getsize(path) == 0:
            with open(path, "w", newline="", encoding="utf-8") as f:
                csv.writer(f).writerow(fields)

    def write_tick(self, row: dict):
        with self.lock:
            with open(self.tick_file, "a", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(
                    f,
                    fieldnames=self.tick_fields,
                    extrasaction="ignore",
                )
                writer.writerow(row)

    def write_trade(self, row: dict):
        with self.lock:
            with open(self.trade_file, "a", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(
                    f,
                    fieldnames=self.trade_fields,
                    extrasaction="ignore",
                )
                writer.writerow(row)

    def write_event(self, row: dict):
        with self.lock:
            with open(self.event_file, "a", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(
                    f,
                    fieldnames=self.event_fields,
                    extrasaction="ignore",
                )
                writer.writerow(row)


# ============================================================
# ROLLING VWAP ENGINE
# ============================================================

class RollingVWAP:
    """
    Maintains a trade-weighted rolling VWAP using:
        sum(LTP * LTQ) / sum(LTQ)

    Time is based on Fyers last_traded_time (epoch seconds).
    """

    def __init__(self):
        self.ticks = deque()

        self.sum_pv = 0.0
        self.sum_qty = 0

        # Last unique websocket payload signature.
        #
        # We include cumulative traded volume because two genuine
        # trades can have the same second/LTP/LTQ but cumulative
        # exchange volume can still increase.
        self.last_signature: Optional[Tuple] = None

    def reset(self):
        self.ticks.clear()
        self.sum_pv = 0.0
        self.sum_qty = 0
        self.last_signature = None

    def add_tick(self, tick: Tick):
        signature = (
            tick.ltt,
            round(tick.ltp, 8),
            tick.ltq,
            tick.vol_traded_today,
        )

        if signature == self.last_signature:
            return False

        self.last_signature = signature

        if tick.ltt <= 0 or tick.ltp <= 0 or tick.ltq <= 0:
            return True

        self.ticks.append(tick)
        self.sum_pv += tick.pv
        self.sum_qty += tick.ltq

        return True

    def remove_before(self, cutoff_epoch: float):
        while self.ticks and self.ticks[0].timestamp < cutoff_epoch:
            old = self.ticks.popleft()
            self.sum_pv -= old.pv
            self.sum_qty -= old.ltq

        # Avoid tiny floating residuals.
        if abs(self.sum_pv) < 1e-10:
            self.sum_pv = 0.0
        if self.sum_qty < 0:
            self.sum_qty = 0

    def value(self) -> Optional[float]:
        if self.sum_qty <= 0:
            return None
        return self.sum_pv / self.sum_qty

    def quantity(self) -> int:
        return self.sum_qty

    def first_timestamp(self) -> Optional[int]:
        if not self.ticks:
            return None
        return self.ticks[0].ltt

    def latest_timestamp(self) -> Optional[int]:
        if not self.ticks:
            return None
        return self.ticks[-1].ltt


class SymbolVWAPState:
    def __init__(self):
        self.engine_1m = RollingVWAP()
        self.engine_5m = RollingVWAP()

        self.previous_diff: Optional[float] = None

        self.last_tick: Optional[Tick] = None
        self.last_update_wallclock = 0.0

    def reset(self):
        self.engine_1m.reset()
        self.engine_5m.reset()
        self.previous_diff = None
        self.last_tick = None
        self.last_update_wallclock = 0.0

    def update(self, tick: Tick):
        if tick.ltq <= 0 or tick.ltp <= 0 or tick.ltt <= 0:
            return False

        # Use one engine for the raw unique-tick gate, then add the
        # same accepted trade to both rolling windows.
        #
        # We do this with a temporary signature check in each engine;
        # both engines therefore reject the same duplicate.
        accepted = self.engine_5m.add_tick(tick)
        accepted_1m = self.engine_1m.add_tick(tick)

        accepted = accepted or accepted_1m

        if not accepted:
            return False

        # Remove old observations from each window.
        self.engine_1m.remove_before(tick.ltt - Config.VWAP_FAST_SEC)
        self.engine_5m.remove_before(tick.ltt - Config.VWAP_SLOW_SEC)

        self.last_tick = tick
        self.last_update_wallclock = time.time()

        return True

    def vwap_1m(self) -> Optional[float]:
        return self.engine_1m.value()

    def vwap_5m(self) -> Optional[float]:
        return self.engine_5m.value()

    def qty_1m(self) -> int:
        return self.engine_1m.quantity()

    def qty_5m(self) -> int:
        return self.engine_5m.quantity()

    def warmup_ready(self) -> bool:
        v1 = self.vwap_1m()
        v5 = self.vwap_5m()

        if v1 is None or v5 is None:
            return False

        if self.qty_1m() <= 0 or self.qty_5m() <= 0:
            return False

        if not Config.REQUIRE_FULL_5M_WARMUP:
            return True

        first_ts = self.engine_5m.first_timestamp()
        latest_ts = self.engine_5m.latest_timestamp()

        if first_ts is None or latest_ts is None:
            return False

        return (latest_ts - first_ts) >= Config.VWAP_SLOW_SEC

    def metrics(self):
        v1 = self.vwap_1m()
        v5 = self.vwap_5m()

        if v1 is None or v5 is None or v5 == 0:
            return {
                "vwap_1m": None,
                "vwap_5m": None,
                "diff": None,
                "spread_pct": None,
                "previous_diff": self.previous_diff,
                "cross": None,
                "warmup_ready": False,
            }

        diff = v1 - v5
        spread_pct = (diff / v5) * 100.0

        prev = self.previous_diff

        cross = None

        if self.warmup_ready():
            if prev is not None:
                if prev <= 0 and diff > 0:
                    cross = "CE_CROSS_UP"
                elif prev >= 0 and diff < 0:
                    cross = "PE_CROSS_DOWN"

        # Update only AFTER evaluating the cross, so the current
        # tick compares against the immediately preceding state.
        self.previous_diff = diff

        return {
            "vwap_1m": v1,
            "vwap_5m": v5,
            "diff": diff,
            "spread_pct": spread_pct,
            "previous_diff": prev,
            "cross": cross,
            "warmup_ready": self.warmup_ready(),
        }


# ============================================================
# PAPER TRADER
# ============================================================

class PaperTrader:
    def __init__(self, logger: CSVLogger):
        self.logger = logger

        self.position: Optional[Position] = None

        self.realized_pnl = 0.0
        self.trade_count = 0

        self.lock = threading.RLock()

    def _estimated_charges(self, entry_price: float, exit_price: float) -> float:
        """
        Placeholder only.

        Keep this separate so the strategy can later be updated with
        the exact current broker/exchange charge model.
        """
        return 0.0

    def can_enter(self) -> bool:
        with self.lock:
            if self.position is not None:
                return False

            if Config.MAX_OPEN_POSITIONS <= 0:
                return False

            if not self._within_daily_limits():
                return False

            now_t = TimeHelper.current_time_only()

            return (
                Config.MARKET_START <= now_t < Config.LAST_ENTRY_TIME
            )

    def _within_daily_limits(self) -> bool:
        capital = Config.PAPER_CAPITAL

        if capital <= 0:
            return True

        if Config.DAILY_MAX_LOSS_PCT > 0:
            max_loss = capital * Config.DAILY_MAX_LOSS_PCT / 100.0
            if self.realized_pnl <= -max_loss:
                return False

        if Config.DAILY_TARGET_PCT > 0:
            target = capital * Config.DAILY_TARGET_PCT / 100.0
            if self.realized_pnl >= target:
                return False

        return True

    def entry_execution_price(self, tick: Tick) -> float:
        if Config.USE_ASK_FOR_ENTRY and is_valid_price(tick.ask):
            return tick.ask
        return tick.ltp

    def exit_execution_price(self, tick: Tick) -> float:
        if Config.USE_BID_FOR_EXIT and is_valid_price(tick.bid):
            return tick.bid
        return tick.ltp

    def enter(
        self,
        contract: ContractInfo,
        tick: Tick,
        metrics: dict,
        reason: str,
    ) -> bool:

        with self.lock:
            if not self.can_enter():
                return False

            price = self.entry_execution_price(tick)

            if price <= 0:
                return False

            now_str = TimeHelper.now_str()

            self.position = Position(
                side=contract.option_type,
                symbol=contract.symbol,
                strike=contract.strike,
                option_type=contract.option_type,
                entry_time=now_str,
                entry_price=price,
                entry_ltp=tick.ltp,
                entry_bid=tick.bid,
                entry_ask=tick.ask,
                entry_vwap_1m=metrics["vwap_1m"],
                entry_vwap_5m=metrics["vwap_5m"],
                entry_vwap_diff=metrics["diff"],
                quantity=Config.LOT_SIZE,
            )

            self.logger.write_event({
                "event_time": now_str,
                "event": "PAPER_ENTRY",
                "message": reason,
                "symbol": contract.symbol,
                "strike": contract.strike,
                "option_type": contract.option_type,
                "details": (
                    f"price={price},ltp={tick.ltp},"
                    f"vwap1={metrics['vwap_1m']},"
                    f"vwap5={metrics['vwap_5m']},"
                    f"diff={metrics['diff']}"
                ),
            })

            print("\n" + "=" * 72)
            print("************** PAPER ENTRY **************")
            print(f"TIME        : {now_str}")
            print(f"ACTION      : BUY {contract.option_type}")
            print(f"SYMBOL      : {contract.symbol}")
            print(f"STRIKE      : {contract.strike}")
            print(f"ENTRY PRICE : {price:.2f}")
            print(f"LTP         : {tick.ltp:.2f}")
            print(f"BID         : {tick.bid:.2f}")
            print(f"ASK         : {tick.ask:.2f}")
            print(f"1M VWAP     : {metrics['vwap_1m']:.4f}")
            print(f"5M VWAP     : {metrics['vwap_5m']:.4f}")
            print(f"VWAP DIFF   : {metrics['diff']:.4f}")
            print(f"QUANTITY    : {Config.LOT_SIZE}")
            print(f"REASON      : {reason}")
            print("=" * 72 + "\n")

            return True

    def exit(
        self,
        tick: Tick,
        metrics: dict,
        reason: str,
    ) -> Optional[dict]:

        with self.lock:
            if self.position is None:
                return None

            pos = self.position

            exit_price = self.exit_execution_price(tick)

            if exit_price <= 0:
                return None

            pnl_points = exit_price - pos.entry_price
            gross_pnl = pnl_points * pos.quantity

            charges = self._estimated_charges(
                pos.entry_price,
                exit_price,
            )

            net_pnl = gross_pnl - charges

            self.realized_pnl += net_pnl
            self.trade_count += 1

            now_str = TimeHelper.now_str()

            row = {
                "event_time": now_str,
                "action": "EXIT",
                "side": pos.side,
                "symbol": pos.symbol,
                "strike": pos.strike,
                "option_type": pos.option_type,
                "quantity": pos.quantity,
                "entry_time": pos.entry_time,
                "entry_price": pos.entry_price,
                "entry_ltp": pos.entry_ltp,
                "entry_bid": pos.entry_bid,
                "entry_ask": pos.entry_ask,
                "entry_vwap_1m": pos.entry_vwap_1m,
                "entry_vwap_5m": pos.entry_vwap_5m,
                "entry_vwap_diff": pos.entry_vwap_diff,
                "exit_time": now_str,
                "exit_price": exit_price,
                "exit_ltp": tick.ltp,
                "exit_bid": tick.bid,
                "exit_ask": tick.ask,
                "exit_vwap_1m": metrics.get("vwap_1m"),
                "exit_vwap_5m": metrics.get("vwap_5m"),
                "exit_vwap_diff": metrics.get("diff"),
                "gross_pnl_points": pnl_points,
                "gross_pnl_rupees": gross_pnl,
                "estimated_charges": charges,
                "net_pnl_rupees": net_pnl,
                "reason": reason,
            }

            self.logger.write_trade(row)

            self.logger.write_event({
                "event_time": now_str,
                "event": "PAPER_EXIT",
                "message": reason,
                "symbol": pos.symbol,
                "strike": pos.strike,
                "option_type": pos.option_type,
                "details": (
                    f"entry={pos.entry_price},exit={exit_price},"
                    f"gross={gross_pnl},charges={charges},"
                    f"net={net_pnl},daily={self.realized_pnl}"
                ),
            })

            print("\n" + "=" * 72)
            print("*************** PAPER EXIT ***************")
            print(f"TIME        : {now_str}")
            print(f"ACTION      : SELL {pos.option_type}")
            print(f"SYMBOL      : {pos.symbol}")
            print(f"STRIKE      : {pos.strike}")
            print(f"ENTRY PRICE : {pos.entry_price:.2f}")
            print(f"EXIT PRICE  : {exit_price:.2f}")
            print(f"POINTS P&L  : {pnl_points:.2f}")
            print(f"GROSS P&L   : {gross_pnl:.2f}")
            print(f"CHARGES     : {charges:.2f}")
            print(f"NET P&L     : {net_pnl:.2f}")
            print(f"DAILY NET   : {self.realized_pnl:.2f}")
            print(f"REASON      : {reason}")
            print("=" * 72 + "\n")

            self.position = None

            return row

    def force_exit_if_needed(
        self,
        tick_lookup: Dict[str, Tick],
        metrics_lookup: Dict[str, dict],
    ):
        if self.position is None:
            return

        now_t = TimeHelper.current_time_only()

        if now_t < Config.FORCE_EXIT_TIME:
            return

        pos = self.position

        tick = tick_lookup.get(pos.symbol)
        metrics = metrics_lookup.get(pos.symbol)

        if tick is None:
            return

        if metrics is None:
            metrics = {
                "vwap_1m": None,
                "vwap_5m": None,
                "diff": None,
            }

        self.exit(
            tick,
            metrics,
            "FORCED_MARKET_CLOSE",
        )


# ============================================================
# MAIN STRATEGY
# ============================================================

class VWAPPaperStrategy:
    def __init__(self):
        self.tz = pytz.timezone(Config.TIMEZONE)

        self.rest = fyersModel.FyersModel(
            client_id=Config.CLIENT_ID,
            token=Config.ACCESS_TOKEN,
            is_async=False,
            log_path="",
        )

        self.ws = data_ws.FyersDataSocket(
            access_token=Config.ACCESS_TOKEN,
            log_path=Config.WS_LOG_PATH,
            litemode=Config.WS_LITEMODE,
            write_to_file=Config.WS_WRITE_TO_FILE,
            reconnect=Config.WS_RECONNECT,
            on_connect=self.on_open,
            on_close=self.on_close,
            on_error=self.on_error,
            on_message=self.on_message,
        )

        self.logger = CSVLogger()
        self.paper = PaperTrader(self.logger)

        self.lock = threading.RLock()

        # Current six contracts:
        # ATM-1 CE/PE, ATM CE/PE, ATM+1 CE/PE
        self.contracts: Dict[str, ContractInfo] = {}

        # Symbol -> rolling VWAP state
        self.states: Dict[str, SymbolVWAPState] = {}

        # Latest tick for every subscribed symbol.
        self.latest_ticks: Dict[str, Tick] = {}

        # Current ATM strike.
        self.atm_strike: Optional[int] = None

        # Current desired websocket subscriptions.
        self.subscribed_symbols = set()

        # When websocket is connected.
        self.ws_connected = False

        self.running = True

        self.chain_thread = threading.Thread(
            target=self.option_chain_loop,
            name="option-chain-loop",
            daemon=True,
        )

        self.dashboard_thread = threading.Thread(
            target=self.dashboard_loop,
            name="dashboard-loop",
            daemon=True,
        )

    # --------------------------------------------------------
    # Connection callbacks
    # --------------------------------------------------------

    def on_open(self):
        print("[WS] Connected.")
        self.ws_connected = True

        symbols = self.get_desired_symbols()

        if symbols:
            try:
                self.ws.subscribe(
                    symbols=list(symbols),
                    data_type="SymbolUpdate",
                )
                self.subscribed_symbols = set(symbols)

                print(
                    f"[WS] Initial subscription: {len(symbols)} symbols"
                )

                self.logger.write_event({
                    "event_time": TimeHelper.now_str(),
                    "event": "SUBSCRIBE",
                    "message": "Initial subscription",
                    "symbol": "",
                    "strike": "",
                    "option_type": "",
                    "details": ",".join(sorted(symbols)),
                })

            except Exception as e:
                print(f"[WS] Initial subscribe error: {e}")
                traceback.print_exc()

        # Keep websocket loop alive.
        self.ws.keep_running()

    def on_close(self, message):
        print(f"[WS] Connection closed: {message}")
        self.ws_connected = False

        self.logger.write_event({
            "event_time": TimeHelper.now_str(),
            "event": "WS_CLOSE",
            "message": str(message),
            "symbol": "",
            "strike": "",
            "option_type": "",
            "details": "",
        })

    def on_error(self, message):
        print(f"[WS] Error: {message}")

        self.logger.write_event({
            "event_time": TimeHelper.now_str(),
            "event": "WS_ERROR",
            "message": str(message),
            "symbol": "",
            "strike": "",
            "option_type": "",
            "details": "",
        })

    # --------------------------------------------------------
    # Option-chain handling
    # --------------------------------------------------------

    def fetch_option_chain(self):
        payload = {
            "symbol": Config.INDEX_SYMBOL,
            "strikecount": 3,
            "timestamp": "",
            "greeks": "1",
        }

        response = self.rest.optionchain(data=payload)

        if not isinstance(response, dict):
            raise RuntimeError(
                f"Unexpected optionchain response type: {type(response)}"
            )

        if response.get("s") != "ok":
            raise RuntimeError(
                f"Optionchain failed: {response}"
            )

        data = response.get("data", {})

        if not data:
            raise RuntimeError("Optionchain data is empty.")

        return data

    def parse_atm_contracts(self, chain_data) -> Tuple[int, Dict[str, ContractInfo]]:
        chain = chain_data.get("optionsChain", [])

        if not chain:
            raise RuntimeError("optionsChain is empty.")

        underlying_ltp = None

        # Option-chain response includes an index/root row.
        for item in chain:
            option_type = item.get("option_type", "")
            strike = safe_int(item.get("strike_price"), -1)

            if option_type == "" and strike == -1:
                underlying_ltp = safe_float(item.get("ltp"), 0.0)
                break

        if underlying_ltp is None or underlying_ltp <= 0:
            # Fallback: use the first root-like row with no option type.
            for item in chain:
                if not item.get("option_type"):
                    candidate = safe_float(item.get("ltp"), 0.0)
                    if candidate > 0:
                        underlying_ltp = candidate
                        break

        if underlying_ltp is None or underlying_ltp <= 0:
            raise RuntimeError(
                "Could not determine NIFTY underlying LTP from option chain."
            )

        contracts_by_strike = {}

        for item in chain:
            option_type = str(item.get("option_type", "")).upper()
            strike = safe_int(item.get("strike_price"), -1)
            symbol = str(item.get("symbol", ""))

            if option_type not in ("CE", "PE"):
                continue

            if strike <= 0 or not symbol:
                continue

            contracts_by_strike.setdefault(strike, {})[option_type] = symbol

        strikes = sorted(contracts_by_strike.keys())

        if len(strikes) < 3:
            raise RuntimeError(
                f"Not enough option strikes in option chain. Found: {strikes}"
            )

        atm_strike = min(
            strikes,
            key=lambda strike: abs(strike - underlying_ltp)
        )

        lower_strikes = [s for s in strikes if s < atm_strike]
        upper_strikes = [s for s in strikes if s > atm_strike]

        if not lower_strikes or not upper_strikes:
            raise RuntimeError(
                f"Unable to find strikes around ATM {atm_strike}"
            )

        atm_minus_1 = max(lower_strikes)
        atm_plus_1 = min(upper_strikes)

        selected: Dict[str, ContractInfo] = {}

        wanted = [
            ("ATM-1", atm_minus_1),
            ("ATM", atm_strike),
            ("ATM+1", atm_plus_1),
        ]

        for offset_name, strike in wanted:
            strike_data = contracts_by_strike.get(strike, {})

            for option_type in ("CE", "PE"):
                symbol = strike_data.get(option_type)

                if not symbol:
                    raise RuntimeError(
                        f"Missing {option_type} for strike {strike}"
                    )

                selected[symbol] = ContractInfo(
                    symbol=symbol,
                    strike=strike,
                    option_type=option_type,
                    offset_name=offset_name,
                )

        print(
            f"[CHAIN] NIFTY LTP={underlying_ltp:.2f} | "
            f"ATM={atm_strike} | "
            f"ATM-1={atm_minus_1} | "
            f"ATM+1={atm_plus_1}"
        )

        return atm_strike, selected

    def get_desired_symbols(self) -> List[str]:
        with self.lock:
            symbols = set(self.contracts.keys())

            # Keep an open position subscribed even after ATM moves.
            if self.paper.position is not None:
                symbols.add(self.paper.position.symbol)

            return sorted(symbols)

    def update_subscriptions(self, new_contracts: Dict[str, ContractInfo]):
        with self.lock:
            old_symbols = set(self.contracts.keys())
            new_symbols = set(new_contracts.keys())

            position_symbol = (
                self.paper.position.symbol
                if self.paper.position is not None
                else None
            )

            # Symbols we can remove from the current ATM group.
            to_unsubscribe = old_symbols - new_symbols

            # Never remove the open-position symbol.
            if position_symbol:
                to_unsubscribe.discard(position_symbol)

            # New ATM group symbols that are not already subscribed.
            to_subscribe = new_symbols - self.subscribed_symbols

            try:
                if self.ws_connected and to_unsubscribe:
                    self.ws.unsubscribe(
                        symbols=sorted(to_unsubscribe),
                        data_type="SymbolUpdate",
                    )

                    self.subscribed_symbols -= to_unsubscribe

                    print(
                        "[WS] Unsubscribed: "
                        + ", ".join(sorted(to_unsubscribe))
                    )

                if self.ws_connected and to_subscribe:
                    self.ws.subscribe(
                        symbols=sorted(to_subscribe),
                        data_type="SymbolUpdate",
                    )

                    self.subscribed_symbols |= to_subscribe

                    print(
                        "[WS] Subscribed: "
                        + ", ".join(sorted(to_subscribe))
                    )

            except Exception as e:
                print(f"[WS] Subscription update error: {e}")
                traceback.print_exc()

            # Replace current contract map.
            #
            # Only reset VWAP state for contracts that are newly
            # discovered or represent a new contract symbol.
            previous_symbols = set(self.contracts.keys())

            for symbol in new_symbols:
                if symbol not in previous_symbols:
                    self.states[symbol] = SymbolVWAPState()

            # Remove state for old ATM contracts unless they are
            # currently being held as an open position.
            for symbol in list(self.states.keys()):
                if symbol not in new_symbols and symbol != position_symbol:
                    del self.states[symbol]

            self.contracts = dict(new_contracts)

            # Ensure every current contract has a state.
            for symbol in new_symbols:
                self.states.setdefault(symbol, SymbolVWAPState())

    def refresh_option_chain(self):
        try:
            atm_strike, new_contracts = self.parse_atm_contracts(
                self.fetch_option_chain()
            )

            with self.lock:
                old_atm = self.atm_strike
                atm_changed = old_atm != atm_strike
                self.atm_strike = atm_strike

            if atm_changed:
                print(
                    f"[ATM] Changed: {old_atm} -> {atm_strike}"
                )

                self.logger.write_event({
                    "event_time": TimeHelper.now_str(),
                    "event": "ATM_CHANGED",
                    "message": f"{old_atm} -> {atm_strike}",
                    "symbol": "",
                    "strike": atm_strike,
                    "option_type": "",
                    "details": ",".join(sorted(new_contracts.keys())),
                })

            self.update_subscriptions(new_contracts)

        except Exception as e:
            print(f"[CHAIN] Refresh error: {e}")
            traceback.print_exc()

            self.logger.write_event({
                "event_time": TimeHelper.now_str(),
                "event": "CHAIN_ERROR",
                "message": str(e),
                "symbol": "",
                "strike": "",
                "option_type": "",
                "details": traceback.format_exc(),
            })

    def option_chain_loop(self):
        while self.running:
            try:
                now_t = TimeHelper.current_time_only()

                if (
                    Config.MARKET_START
                    <= now_t
                    <= Config.MARKET_END
                ):
                    self.refresh_option_chain()

                time.sleep(Config.OPTION_CHAIN_INTERVAL_SEC)

            except Exception:
                traceback.print_exc()
                time.sleep(5)

    # --------------------------------------------------------
    # WebSocket market-data callback
    # --------------------------------------------------------

    def on_message(self, message):
        try:
            if not isinstance(message, dict):
                return

            msg_type = message.get("type")

            if msg_type != "sf":
                # Connection/subscribe/depth/etc. messages are not
                # part of the tick VWAP calculation.
                return

            symbol = str(message.get("symbol", ""))

            if not symbol:
                return

            with self.lock:
                contract = self.contracts.get(symbol)

                # Also accept an open-position symbol after ATM changes.
                if contract is None and self.paper.position is not None:
                    if symbol == self.paper.position.symbol:
                        contract = ContractInfo(
                            symbol=symbol,
                            strike=self.paper.position.strike,
                            option_type=self.paper.position.option_type,
                            offset_name="OPEN_POSITION",
                        )

                if contract is None:
                    return

            ltt = safe_int(message.get("last_traded_time"), 0)
            ltp = safe_float(message.get("ltp"), 0.0)
            ltq = safe_int(message.get("last_traded_qty"), 0)
            volume = safe_int(message.get("vol_traded_today"), 0)
            bid = safe_float(message.get("bid_price"), 0.0)
            ask = safe_float(message.get("ask_price"), 0.0)

            if ltt <= 0 or ltp <= 0 or ltq <= 0:
                return

            now_t = TimeHelper.current_time_only()

            # Ignore out-of-market timestamps.
            ltt_dt = datetime.fromtimestamp(ltt, self.tz)
            ltt_time = ltt_dt.time()

            if not (
                Config.MARKET_START
                <= ltt_time
                <= Config.MARKET_END
            ):
                return

            tick = Tick(
                ltt=ltt,
                ltp=ltp,
                ltq=ltq,
                vol_traded_today=volume,
                bid=bid,
                ask=ask,
                received_at=time.time(),
            )

            with self.lock:
                state = self.states.setdefault(
                    symbol,
                    SymbolVWAPState(),
                )

                accepted = state.update(tick)

                if not accepted:
                    return

                metrics = state.metrics()

                self.latest_ticks[symbol] = tick

                position_name = (
                    self.paper.position.side
                    if self.paper.position
                    else "NONE"
                )

                is_atm = (
                    contract.offset_name == "ATM"
                )

                # Write every accepted tick to CSV.
                self.logger.write_tick({
                    "log_time": TimeHelper.now_str(),
                    "ltt": ltt,
                    "ltt_ist": TimeHelper.epoch_to_str(ltt),
                    "symbol": symbol,
                    "strike": contract.strike,
                    "option_type": contract.option_type,
                    "offset_name": contract.offset_name,
                    "ltp": tick.ltp,
                    "ltq": tick.ltq,
                    "vol_traded_today": tick.vol_traded_today,
                    "bid": tick.bid,
                    "ask": tick.ask,
                    "rolling_qty_1m": state.qty_1m(),
                    "rolling_qty_5m": state.qty_5m(),
                    "vwap_1m": metrics["vwap_1m"],
                    "vwap_5m": metrics["vwap_5m"],
                    "vwap_diff": metrics["diff"],
                    "vwap_spread_pct": metrics["spread_pct"],
                    "previous_vwap_diff": metrics["previous_diff"],
                    "cross_signal": metrics["cross"],
                    "warmup_ready": metrics["warmup_ready"],
                    "is_atm": is_atm,
                    "position": position_name,
                })

                if Config.PRINT_EVERY_TICK:
                    self.print_tick(
                        contract,
                        tick,
                        state,
                        metrics,
                    )

                # ------------------------------------------------
                # POSITION EXIT
                # ------------------------------------------------
                #
                # IMPORTANT:
                # The crossover must be evaluated on this exact
                # accepted tick. Do not recalculate metrics later
                # from a dashboard thread, because doing so would
                # overwrite the previous_diff needed to identify
                # the crossover.

                self.handle_position_exit_on_tick(
                    contract,
                    tick,
                    metrics,
                )

                # ------------------------------------------------
                # SIGNAL LOGIC: ATM ONLY
                # ------------------------------------------------

                if is_atm and metrics["cross"] is not None:
                    self.handle_signal(
                        contract,
                        tick,
                        state,
                        metrics,
                    )

        except Exception as e:
            print(f"[WS MESSAGE ERROR] {e}")
            traceback.print_exc()

    # --------------------------------------------------------
    # Signal handling
    # --------------------------------------------------------

    def handle_signal(
        self,
        contract: ContractInfo,
        tick: Tick,
        state: SymbolVWAPState,
        metrics: dict,
    ):
        cross = metrics["cross"]

        # CE:
        # Previous 1m VWAP <= previous 5m VWAP
        # Current  1m VWAP >  current 5m VWAP
        if (
            contract.option_type == "CE"
            and cross == "CE_CROSS_UP"
        ):
            self.handle_ce_signal(
                contract,
                tick,
                state,
                metrics,
            )

        # PE:
        # Previous 1m VWAP >= previous 5m VWAP
        # Current  1m VWAP <  current 5m VWAP
        elif (
            contract.option_type == "PE"
            and cross == "PE_CROSS_DOWN"
        ):
            self.handle_pe_signal(
                contract,
                tick,
                state,
                metrics,
            )

    def handle_ce_signal(
        self,
        contract: ContractInfo,
        tick: Tick,
        state: SymbolVWAPState,
        metrics: dict,
    ):
        print(
            f"[SIGNAL] ATM CE CROSS UP | "
            f"{contract.symbol} | "
            f"1m={metrics['vwap_1m']:.4f} | "
            f"5m={metrics['vwap_5m']:.4f} | "
            f"diff={metrics['diff']:.4f}"
        )

        if self.paper.position is not None:
            self.logger.write_event({
                "event_time": TimeHelper.now_str(),
                "event": "SIGNAL_IGNORED",
                "message": "ATM CE crossover but position already open",
                "symbol": contract.symbol,
                "strike": contract.strike,
                "option_type": contract.option_type,
                "details": "Existing position prevents second entry",
            })
            return

        if not self.paper.can_enter():
            self.logger.write_event({
                "event_time": TimeHelper.now_str(),
                "event": "SIGNAL_IGNORED",
                "message": "ATM CE crossover but entry blocked",
                "symbol": contract.symbol,
                "strike": contract.strike,
                "option_type": contract.option_type,
                "details": "Time/risk/position rule blocked entry",
            })
            return

        self.paper.enter(
            contract,
            tick,
            metrics,
            "ATM CE 1m VWAP crossed ABOVE 5m VWAP",
        )

    def handle_pe_signal(
        self,
        contract: ContractInfo,
        tick: Tick,
        state: SymbolVWAPState,
        metrics: dict,
    ):
        print(
            f"[SIGNAL] ATM PE CROSS DOWN | "
            f"{contract.symbol} | "
            f"1m={metrics['vwap_1m']:.4f} | "
            f"5m={metrics['vwap_5m']:.4f} | "
            f"diff={metrics['diff']:.4f}"
        )

        if self.paper.position is not None:
            self.logger.write_event({
                "event_time": TimeHelper.now_str(),
                "event": "SIGNAL_IGNORED",
                "message": "ATM PE crossover but position already open",
                "symbol": contract.symbol,
                "strike": contract.strike,
                "option_type": contract.option_type,
                "details": "Existing position prevents second entry",
            })
            return

        if not self.paper.can_enter():
            self.logger.write_event({
                "event_time": TimeHelper.now_str(),
                "event": "SIGNAL_IGNORED",
                "message": "ATM PE crossover but entry blocked",
                "symbol": contract.symbol,
                "strike": contract.strike,
                "option_type": contract.option_type,
                "details": "Time/risk/position rule blocked entry",
            })
            return

        self.paper.enter(
            contract,
            tick,
            metrics,
            "ATM PE 1m VWAP crossed BELOW 5m VWAP",
        )

    # --------------------------------------------------------
    # Position exit
    # --------------------------------------------------------

    def handle_position_exit_on_tick(
        self,
        contract: ContractInfo,
        tick: Tick,
        metrics: dict,
    ):
        """
        Exit is evaluated only on an accepted market-data tick.

        CE position:
            1m VWAP crosses BELOW 5m VWAP -> exit

        PE position:
            1m VWAP crosses ABOVE 5m VWAP -> exit

        This uses the crossover already calculated in metrics(),
        before previous_diff gets overwritten by another call.
        """
        pos = self.paper.position

        if pos is None:
            return

        # Only the actual held contract should control its exit.
        if contract.symbol != pos.symbol:
            return

        cross = metrics.get("cross")

        if cross is None:
            return

        if pos.side == "CE" and cross == "PE_CROSS_DOWN":
            self.paper.exit(
                tick,
                metrics,
                "HELD CE 1m VWAP crossed BELOW 5m VWAP",
            )

        elif pos.side == "PE" and cross == "CE_CROSS_UP":
            self.paper.exit(
                tick,
                metrics,
                "HELD PE 1m VWAP crossed ABOVE 5m VWAP",
            )

    # --------------------------------------------------------
    # Tick terminal display
    # --------------------------------------------------------

    def print_tick(
        self,
        contract: ContractInfo,
        tick: Tick,
        state: SymbolVWAPState,
        metrics: dict,
    ):
        v1 = metrics["vwap_1m"]
        v5 = metrics["vwap_5m"]
        diff = metrics["diff"]
        spread = metrics["spread_pct"]

        v1_text = f"{v1:.4f}" if v1 is not None else "NA"
        v5_text = f"{v5:.4f}" if v5 is not None else "NA"
        diff_text = f"{diff:.4f}" if diff is not None else "NA"
        spread_text = f"{spread:.4f}%" if spread is not None else "NA"

        signal = metrics["cross"] or "-"

        print(
            f"[TICK] "
            f"{TimeHelper.epoch_to_str(tick.ltt)} | "
            f"{contract.offset_name:5s} "
            f"{contract.option_type} | "
            f"{contract.strike} | "
            f"LTP={tick.ltp:.2f} | "
            f"LTQ={tick.ltq} | "
            f"1mVWAP={v1_text} | "
            f"5mVWAP={v5_text} | "
            f"Diff={diff_text} | "
            f"Spread={spread_text} | "
            f"Cross={signal}"
        )

    # --------------------------------------------------------
    # Dashboard
    # --------------------------------------------------------

    def dashboard_loop(self):
        while self.running:
            try:
                time.sleep(Config.DASHBOARD_INTERVAL_SEC)

                if not self.running:
                    break

                self.print_dashboard()

                # Force-close at configured time if position is still open.
                self.paper.force_exit_if_needed(
                    self.latest_ticks,
                    self.collect_metrics_lookup(),
                )

            except Exception as e:
                print(f"[DASHBOARD ERROR] {e}")
                traceback.print_exc()

    def collect_metrics_lookup(self) -> Dict[str, dict]:
        result = {}

        with self.lock:
            for symbol, state in self.states.items():
                v1 = state.vwap_1m()
                v5 = state.vwap_5m()

                if v1 is not None and v5 is not None:
                    diff = v1 - v5
                    result[symbol] = {
                        "vwap_1m": v1,
                        "vwap_5m": v5,
                        "diff": diff,
                    }

        return result

    def print_dashboard(self):
        now = TimeHelper.now()

        with self.lock:
            atm = self.atm_strike

            pos = self.paper.position

            position_text = "NONE"

            if pos:
                position_text = (
                    f"LONG {pos.side} "
                    f"{pos.symbol} "
                    f"@ {pos.entry_price:.2f}"
                )

            print("\n" + "-" * 110)
            print(
                f"VWAP PAPER TRADER | "
                f"{now.strftime('%Y-%m-%d %H:%M:%S')} | "
                f"ATM={atm} | "
                f"Position={position_text} | "
                f"Realized P&L={self.paper.realized_pnl:.2f} | "
                f"Trades={self.paper.trade_count}"
            )
            print("-" * 110)

            for symbol, contract in sorted(
                self.contracts.items(),
                key=lambda x: (
                    x[1].strike,
                    x[1].option_type,
                ),
            ):
                state = self.states.get(symbol)
                tick = self.latest_ticks.get(symbol)

                if state is None:
                    continue

                v1 = state.vwap_1m()
                v5 = state.vwap_5m()

                diff = (
                    v1 - v5
                    if v1 is not None and v5 is not None
                    else None
                )

                ltp = tick.ltp if tick else None
                qty1 = state.qty_1m()
                qty5 = state.qty_5m()

                print(
                    f"{contract.offset_name:5s} "
                    f"{contract.option_type} "
                    f"{contract.strike:>6} | "
                    f"LTP={ltp if ltp is not None else 'NA':>8} | "
                    f"1mVWAP={v1 if v1 is not None else 'NA':>10} | "
                    f"5mVWAP={v5 if v5 is not None else 'NA':>10} | "
                    f"Diff={diff if diff is not None else 'NA':>10} | "
                    f"Qty1m={qty1:>8} | "
                    f"Qty5m={qty5:>8} | "
                    f"Ready={'Y' if state.warmup_ready() else 'N'}"
                )

            print("-" * 110)

    # --------------------------------------------------------
    # Startup / shutdown
    # --------------------------------------------------------

    def start(self):
        print("=" * 72)
        print("NIFTY ATM OPTION ROLLING VWAP PAPER TRADER")
        print("=" * 72)
        print(f"Paper mode            : {Config.PAPER_MODE}")
        print(f"Index                 : {Config.INDEX_SYMBOL}")
        print(f"Fast VWAP window      : {Config.VWAP_FAST_SEC}s")
        print(f"Slow VWAP window      : {Config.VWAP_SLOW_SEC}s")
        print(f"Option chain interval : {Config.OPTION_CHAIN_INTERVAL_SEC}s")
        print(f"Lot size              : {Config.LOT_SIZE}")
        print(f"Logs                  : {Config.LOG_DIR}")
        print("=" * 72)

        if "YOUR_" in Config.CLIENT_ID or "YOUR_" in Config.ACCESS_TOKEN:
            raise RuntimeError(
                "Please set FYERS client ID and access token in Config "
                "or environment variables first."
            )

        # We need the six symbols BEFORE opening websocket so that
        # on_open can subscribe immediately.
        print("[INIT] Fetching option chain...")
        self.refresh_option_chain()

        # Start chain refresh and dashboard threads.
        self.chain_thread.start()
        self.dashboard_thread.start()

        print("[WS] Connecting...")
        self.ws.connect()

    def shutdown(self):
        self.running = False

        print("\n[SHUTDOWN] Stopping strategy...")

        try:
            if self.paper.position is not None:
                pos = self.paper.position
                tick = self.latest_ticks.get(pos.symbol)

                if tick:
                    state = self.states.get(pos.symbol)

                    metrics = {
                        "vwap_1m": state.vwap_1m() if state else None,
                        "vwap_5m": state.vwap_5m() if state else None,
                        "diff": (
                            state.vwap_1m() - state.vwap_5m()
                            if state
                            and state.vwap_1m() is not None
                            and state.vwap_5m() is not None
                            else None
                        ),
                    }

                    self.paper.exit(
                        tick,
                        metrics,
                        "PROGRAM_SHUTDOWN",
                    )

        except Exception:
            traceback.print_exc()

        try:
            self.ws.close()
        except Exception:
            pass

        print("[SHUTDOWN] Done.")


# ============================================================
# MAIN
# ============================================================

if __name__ == "__main__":
    strategy = VWAPPaperStrategy()

    try:
        strategy.start()

        while strategy.running:
            time.sleep(1)

    except KeyboardInterrupt:
        print("\n[MAIN] Ctrl+C received.")

    except Exception as e:
        print(f"\n[FATAL] {e}")
        traceback.print_exc()

    finally:
        strategy.shutdown()
