import time
import numpy as np
from datetime import datetime
import pytz
from fyers_apiv3 import fyersModel
from fyers_apiv3.FyersWebsocket import data_ws
import logging
import os
import json
from collections import deque
import csv
import threading
import traceback

# ============================================================
# PAPER TRADE FLAG
# ============================================================
PAPER_MODE = True   # Change to False for live trading

# ============================================================
# CONFIGURATION – ALL PARAMETERS ARE HERE
# ============================================================
class Config:
    # Sampling and window
    SAMPLE_INTERVAL = 1                 # seconds between snapshots
    OPTION_CHAIN_INTERVAL = 30          # seconds between chain updates
    WINDOW_SECONDS = 300                # 5 minutes rolling window for underlying LTP
    REQUIRED_BARS = WINDOW_SECONDS      # number of samples needed for warm-up

    # Entry thresholds
    RATIO_BUY_CE = 0.9                  # ratio < this & LTP <= min -> buy CE
    RATIO_BUY_PE = 1.1                  # ratio > this & LTP >= max -> buy PE

    # SL / Target multipliers (range is frozen at entry)
    # For CE: SL = entry_ltp - range, Target = entry_ltp + 2*range
    # For PE: SL = entry_ltp + range, Target = entry_ltp - 2*range

    # Execution
    LOT_SIZE = 195
    MAX_DAILY_ENTRIES = 100
    ATM_RANGE = 2
    API_RATE_LIMIT = 200
    API_WINDOW = 60
    MAX_RETRIES = 3
    RETRY_DELAY = 2

    # Entry confirmation
    ENTRY_PRICE_RANGE_PERCENT = 1.0     # ±1% around interpolated price at signal
    ENTRY_WAIT_TIMEOUT_SECONDS = 30
    OPTION_PRICE_STALE_SECONDS = 5

# ============================================================
# LOGGING
# ============================================================
logging.basicConfig(
    filename="trading_app.log",
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)

def log_debug(msg):
    logging.debug(msg)

def log_console(msg):
    print(msg, flush=True)
    logging.info(msg)

IST = pytz.timezone("Asia/Kolkata")

def now_ist():
    return datetime.now(IST)

def timestamp_ist():
    return now_ist().strftime("%Y-%m-%d %H:%M:%S")

# ============================================================
# ERROR HANDLER
# ============================================================
def handle_errors(func):
    def wrapper(*args, **kwargs):
        for retry in range(Config.MAX_RETRIES):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                log_debug(f"{func.__name__} attempt {retry+1} failed: {e}\n{traceback.format_exc()}")
                if retry < Config.MAX_RETRIES-1:
                    time.sleep(Config.RETRY_DELAY)
                else:
                    log_debug(f"{func.__name__} permanently failed")
                    return None, None, None, None, []
    return wrapper

# ============================================================
# DATA LOGGER (updated)
# ============================================================
class DataLogger:
    def __init__(self, filename="trading_data.csv"):
        self.filename = filename
        self._ensure_header()

    @staticmethod
    def _expected_header():
        return [
            'timestamp', 'ltp', 'straddle',
            'interp_ce', 'interp_pe', 'ratio',
            'real_atm_ce', 'real_atm_pe',
            'rolling_min_ltp', 'rolling_max_ltp',
            'held_symbol', 'entry_type', 'entry_premium', 'current_premium',
            'entry_ltp', 'frozen_min', 'frozen_max', 'range',
            'sl_ltp', 'target_ltp', 'current_ltp',
            'held_pnl', 'total_paper_pnl', 'daily_entries', 'bars_collected',
            'decision_reason'
        ]

    def _ensure_header(self):
        expected = self._expected_header()
        if not os.path.exists(self.filename) or os.path.getsize(self.filename) == 0:
            with open(self.filename, 'w', newline='') as f:
                csv.writer(f).writerow(expected)
            return
        try:
            with open(self.filename, 'r', newline='') as f:
                existing = next(csv.reader(f), [])
            if existing != expected:
                base, ext = os.path.splitext(self.filename)
                backup = f"{base}_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}{ext or '.csv'}"
                os.replace(self.filename, backup)
                log_console(f"⚠️ Existing CSV header differs. Old file backed up as {backup}")
                with open(self.filename, 'w', newline='') as f:
                    csv.writer(f).writerow(expected)
        except Exception as e:
            log_debug(f"CSV header check failed: {e}")

    def log_data(self, timestamp, ltp, straddle,
                 interp_ce, interp_pe, ratio,
                 real_atm_ce, real_atm_pe,
                 rolling_min_ltp, rolling_max_ltp,
                 active_positions, total_pnl, daily_entries, bars_collected,
                 decision_reason):

        held_s = ''
        held_type = ''
        held_entry = 0.0
        held_curr = 0.0
        entry_ltp = 0.0
        frozen_min = 0.0
        frozen_max = 0.0
        range_val = 0.0
        sl_ltp = 0.0
        target_ltp = 0.0
        current_ltp = ltp or 0.0
        held_p = 0.0

        if len(active_positions) > 0:
            pos = active_positions[0]
            held_s = pos.get('symbol', '')
            held_type = pos.get('entry_type', '')
            held_entry = pos.get('entry_premium', 0.0) or 0.0
            held_curr = pos.get('current_premium', held_entry) or 0.0
            entry_ltp = pos.get('entry_ltp', 0.0) or 0.0
            frozen_min = pos.get('frozen_min', 0.0) or 0.0
            frozen_max = pos.get('frozen_max', 0.0) or 0.0
            range_val = pos.get('range_val', 0.0) or 0.0
            sl_ltp = pos.get('sl_ltp', 0.0) or 0.0
            target_ltp = pos.get('target_ltp', 0.0) or 0.0
            if held_entry > 0 and held_curr > 0:
                held_p = (held_curr - held_entry) * Config.LOT_SIZE

        with open(self.filename, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                str(timestamp),
                round(ltp, 2) if ltp else 0.0,
                round(straddle, 2) if straddle else 0.0,
                round(interp_ce, 2) if interp_ce else 0.0,
                round(interp_pe, 2) if interp_pe else 0.0,
                round(ratio, 4) if ratio else '',
                round(real_atm_ce, 2) if real_atm_ce else 0.0,
                round(real_atm_pe, 2) if real_atm_pe else 0.0,
                round(rolling_min_ltp, 2) if rolling_min_ltp else 0.0,
                round(rolling_max_ltp, 2) if rolling_max_ltp else 0.0,
                held_s,
                held_type,
                round(held_entry, 2),
                round(held_curr, 2),
                round(entry_ltp, 2),
                round(frozen_min, 2),
                round(frozen_max, 2),
                round(range_val, 2),
                round(sl_ltp, 2),
                round(target_ltp, 2),
                round(current_ltp, 2),
                round(held_p, 2),
                round(total_pnl, 2),
                daily_entries,
                bars_collected,
                decision_reason
            ])

# ============================================================
# SESSION STATE
# ============================================================
class SessionState:
    def __init__(self):
        self.lock = threading.RLock()
        self.option_chain_api_count = 0
        self.api_window_start = now_ist()
        self.cid = ""
        self.token = ""
        self.daily_entries = 0
        self.position_state = "FLAT"      # FLAT / WAITING / ACTIVE
        self.pending_signal = None
        self.eod_square_off_triggered = False

        self.live_ltp = {}
        self.live_ltp_time = {}

        self.option_chain = []
        self.fut_price = None
        self.expiry_date = None
        self.atm_strike = None
        self.option_symbols = []

        self.strike_to_symbols = {}

        self.active_positions = []
        self.india_vix = 15.0
        self.paper_realized_pnl = 0.0

        self.decision_reason = ""
        self.running = False
        self._order_lock = False

        # Rolling history for underlying LTP
        self.ltp_history = deque(maxlen=Config.REQUIRED_BARS)

        # Current values
        self.current_interp_ce = 0.0
        self.current_interp_pe = 0.0
        self.current_ratio = None
        self.current_ltp = 0.0
        self.current_straddle = 0.0

        self.last_data_time = None
        self.bars_collected = 0

    def update_ws(self, symbol, ltp, vwap, volume):
        with self.lock:
            self.last_data_time = time.time()
            if ltp is not None:
                self.live_ltp[symbol] = float(ltp)
                self.live_ltp_time[symbol] = time.time()
            if symbol == "NSE:INDIAVIX-INDEX":
                if ltp is not None:
                    self.india_vix = float(ltp)

    def get_ltp(self, symbol):
        with self.lock:
            return self.live_ltp.get(symbol)

    def get_ltp_time(self, symbol):
        with self.lock:
            return self.live_ltp_time.get(symbol)

    def update_chain(self, chain, fut_price, expiry_date, atm_strike, option_symbols):
        with self.lock:
            self.option_chain = chain
            self.fut_price = float(fut_price) if fut_price else 0.0
            self.expiry_date = expiry_date
            self.atm_strike = int(atm_strike) if atm_strike else None
            self.option_symbols = option_symbols

            self.strike_to_symbols = {}
            for opt in chain:
                strike = opt.get("strike_price")
                if strike is None:
                    continue
                ot = opt.get("option_type")
                sym = opt.get("symbol")
                if ot == "CE":
                    if strike not in self.strike_to_symbols:
                        self.strike_to_symbols[strike] = [None, None]
                    self.strike_to_symbols[strike][0] = sym
                elif ot == "PE":
                    if strike not in self.strike_to_symbols:
                        self.strike_to_symbols[strike] = [None, None]
                    self.strike_to_symbols[strike][1] = sym

    def reset_for_new_day(self):
        with self.lock:
            if self.active_positions:
                log_console(f"⚠️ {len(self.active_positions)} position(s) still tracked, not resetting.")
                return
            self.daily_entries = 0
            self.eod_square_off_triggered = False
            self.position_state = "FLAT"
            self.pending_signal = None
            self.paper_realized_pnl = 0.0
            self.decision_reason = ""
            self.active_positions.clear()
            self.live_ltp.clear()
            self.live_ltp_time.clear()
            self.ltp_history.clear()
            self.bars_collected = 0

# ============================================================
# WEBSOCKET MANAGER (simplified)
# ============================================================
class MarketWSManager:
    def __init__(self, session_state, access_token):
        self.session = session_state
        self.access_token = access_token
        self.ws = None
        self.subscribed = set()
        self.running = False
        self.ws_thread = None

    def on_message(self, message):
        symbol = message.get("symbol")
        if symbol:
            ltp = message.get("ltp")
            vwap = message.get("avg_trade_price")
            volume = message.get("vol_traded_today")
            self.session.update_ws(symbol, ltp, vwap, volume)

    def on_error(self, msg):
        log_console(f"WS error: {msg}")

    def on_close(self, msg):
        log_console(f"WS closed: {msg}. Automatic reconnection is enabled.")

    def on_open(self):
        log_console("✅ WebSocket on_open() triggered")
        if self.subscribed:
            self.ws.subscribe(list(self.subscribed), "SymbolUpdate")
        self.ws.keep_running()

    def _ws_connect(self):
        try:
            self.ws = data_ws.FyersDataSocket(
                access_token=self.access_token,
                log_path="",
                litemode=False,
                write_to_file=False,
                reconnect=True,
                on_connect=self.on_open,
                on_close=self.on_close,
                on_error=self.on_error,
                on_message=self.on_message
            )
            self.ws.connect()
        except Exception as e:
            log_console(f"❌ WebSocket connection thread crashed: {e}")
            log_debug(traceback.format_exc())
        finally:
            log_console("WebSocket thread finished.")

    def start(self):
        if self.running:
            return
        self.running = True
        self.ws_thread = threading.Thread(target=self._ws_connect, daemon=True)
        self.ws_thread.start()

    def subscribe(self, symbols):
        new_symbols = set(symbols) - self.subscribed
        if not new_symbols:
            return
        if self.ws:
            try:
                self.ws.subscribe(list(new_symbols), "SymbolUpdate")
            except Exception as e:
                log_console(f"⚠️ Subscribe request failed for {sorted(new_symbols)}: {e}")
                log_debug(traceback.format_exc())
        else:
            log_debug(f"subscribe() called before WS was ready; relying on on_open() to send: {sorted(new_symbols)}")
        self.subscribed.update(new_symbols)

    def stop(self):
        self.running = False
        if self.ws:
            self.ws.close_connection()
        if self.ws_thread and self.ws_thread.is_alive():
            self.ws_thread.join(timeout=2)

# ============================================================
# REST API (unchanged)
# ============================================================
def enforce_rate_limit(session):
    now = now_ist()
    window = (now - session.api_window_start).total_seconds()
    if window > Config.API_WINDOW:
        session.api_window_start = now
        session.option_chain_api_count = 0
    elif session.option_chain_api_count >= Config.API_RATE_LIMIT:
        wait = Config.API_WINDOW - window
        if wait > 0:
            time.sleep(wait)
        session.api_window_start = now
        session.option_chain_api_count = 0

@handle_errors
def fetch_option_chain(session, index_symbol):
    enforce_rate_limit(session)
    session.option_chain_api_count += 1
    fy = fyersModel.FyersModel(client_id=session.cid, token=session.token, is_async=False, log_path="")
    meta = fy.optionchain(data={"symbol": index_symbol, "timestamp": ""})
    if meta.get("code") != 200:
        return None, None, None, None, []

    fut_price = None
    for item in meta["data"]["optionsChain"]:
        if item.get("option_type") == "":
            fut_price = item.get("fp")
            break
    if fut_price is None:
        fut_price = meta["data"].get("fp", 0.0)

    exp_list = sorted([(e["date"], e["expiry"]) for e in meta["data"]["expiryData"]],
                      key=lambda x: datetime.strptime(x[0], "%d-%m-%Y"))
    today = now_ist().date()
    idx = 0
    for i, (d_str, _) in enumerate(exp_list):
        if datetime.strptime(d_str, "%d-%m-%Y").date() >= today:
            idx = i
            break
    curr_date, expiry_ts = exp_list[idx]

    payload = {"symbol": index_symbol, "strikecount": Config.ATM_RANGE, "timestamp": expiry_ts, "greeks": "1"}
    session.option_chain_api_count += 1
    resp = fy.optionchain(data=payload)
    if resp.get("code") != 200:
        return None, None, None, None, []

    chain = resp["data"]["optionsChain"]
    for opt in chain:
        greeks = opt.get("greeks", {})
        opt["delta"] = greeks.get("delta", 0.0) if greeks else 0.0
        opt["gamma"] = greeks.get("gamma", 0.0) if greeks else 0.0
        opt["oi"] = opt.get("oi", 0)

    option_symbols = [opt["symbol"] for opt in chain if opt.get("option_type") in ("CE","PE")]
    return chain, fut_price, curr_date, expiry_ts, option_symbols

# ============================================================
# CHAIN POLLER
# ============================================================
def chain_poller(session, ws_manager, index_symbol):
    while session.running:
        try:
            chain, fut_price, expiry_date, _, opt_symbols = fetch_option_chain(session, index_symbol)
            if chain is not None:
                underlying_ltp = session.get_ltp(index_symbol)
                if underlying_ltp is None:
                    underlying_ltp = fut_price
                strikes = sorted(set(opt["strike_price"] for opt in chain if opt.get("option_type") in ("CE","PE")))
                if strikes and underlying_ltp:
                    atm = min(strikes, key=lambda x: abs(x - underlying_ltp))
                else:
                    atm = None
                session.update_chain(chain, fut_price, expiry_date, atm, opt_symbols)
                all_syms = [index_symbol, "NSE:INDIAVIX-INDEX"] + opt_symbols
                ws_manager.subscribe(all_syms)
            time.sleep(Config.OPTION_CHAIN_INTERVAL)
        except Exception as e:
            log_debug(f"Chain poller error: {e}\n{traceback.format_exc()}")
            time.sleep(Config.OPTION_CHAIN_INTERVAL)

# ============================================================
# INTERPOLATION HELPERS
# ============================================================
def get_interpolated_option_prices_live(session, spot):
    strike_map = session.strike_to_symbols
    if not strike_map:
        return None

    strikes = sorted(strike_map.keys())
    low_strike = None
    high_strike = None

    for s in strikes:
        if s <= spot:
            low_strike = s
        elif s > spot:
            high_strike = s
            break

    if low_strike is None or high_strike is None:
        return None

    ce_low_sym, pe_low_sym = strike_map[low_strike]
    ce_high_sym, pe_high_sym = strike_map[high_strike]

    required_symbols = [ce_low_sym, ce_high_sym, pe_low_sym, pe_high_sym]
    if any(sym is None for sym in required_symbols):
        return None

    now = time.time()
    for sym in required_symbols:
        ts = session.get_ltp_time(sym)
        if ts is None or (now - ts) > Config.OPTION_PRICE_STALE_SECONDS:
            return None

    ce_low = session.get_ltp(ce_low_sym)
    ce_high = session.get_ltp(ce_high_sym)
    pe_low = session.get_ltp(pe_low_sym)
    pe_high = session.get_ltp(pe_high_sym)

    if None in (ce_low, ce_high, pe_low, pe_high):
        return None

    width = high_strike - low_strike
    if width <= 0:
        return None

    w = (spot - low_strike) / width

    ce_interp = ce_low * (1 - w) + ce_high * w
    pe_interp = pe_low * (1 - w) + pe_high * w

    if ce_interp <= 0 or pe_interp <= 0:
        return None

    return {
        "ce": float(ce_interp),
        "pe": float(pe_interp),
        "straddle": float(ce_interp + pe_interp),
        "low_strike": low_strike,
        "high_strike": high_strike,
    }

def get_current_real_atm_contract(session, spot, option_type):
    chain = session.option_chain
    if not chain:
        return None, None, None

    target = "CE" if option_type == "CE" else "PE"
    best_opt = None
    best_dist = float("inf")

    for opt in chain:
        if opt.get("option_type") != target:
            continue
        strike = opt.get("strike_price")
        if strike is None:
            continue
        dist = abs(strike - spot)
        if dist < best_dist:
            best_dist = dist
            best_opt = opt

    if best_opt is None:
        return None, None, None

    symbol = best_opt.get("symbol")
    strike = best_opt.get("strike_price")
    premium = session.get_ltp(symbol) if symbol else None

    if premium is None or premium <= 0:
        premium = best_opt.get("ltp")

    if premium is None or premium <= 0:
        return symbol, None, strike

    return symbol, float(premium), strike

def clear_pending_signal(session):
    session.pending_signal = None
    if not session.active_positions:
        session.position_state = "FLAT"

def is_within_entry_range(reference_price, current_price):
    if reference_price is None or current_price is None:
        return False
    if reference_price <= 0 or current_price <= 0:
        return False
    pct = Config.ENTRY_PRICE_RANGE_PERCENT / 100.0
    lower = reference_price * (1.0 - pct)
    upper = reference_price * (1.0 + pct)
    return lower <= current_price <= upper

# ============================================================
# CREATE POSITION (with SL/Target based on underlying)
# ============================================================
def create_position(session, symbol, entry_premium, entry_type, entry_ltp, frozen_min, frozen_max):
    range_val = frozen_max - frozen_min
    if entry_type == "CE":
        sl_ltp = entry_ltp - range_val
        target_ltp = entry_ltp + 2 * range_val
    else:  # PE
        sl_ltp = entry_ltp + range_val
        target_ltp = entry_ltp - 2 * range_val

    pos = {
        "symbol": symbol,
        "entry_premium": entry_premium,
        "entry_type": entry_type,
        "entry_ltp": entry_ltp,
        "current_premium": entry_premium,
        "frozen_min": frozen_min,
        "frozen_max": frozen_max,
        "range_val": range_val,
        "sl_ltp": sl_ltp,
        "target_ltp": target_ltp,
    }

    session.active_positions.append(pos)
    session.daily_entries += 1
    session.position_state = "ACTIVE"

    log_console(
        f"🎯 ENTRY {entry_type} | Symbol={symbol} | Premium={entry_premium:.2f} | "
        f"Entry LTP={entry_ltp:.2f} | Frozen Min={frozen_min:.2f} Max={frozen_max:.2f} Range={range_val:.2f} | "
        f"SL LTP={sl_ltp:.2f} Target LTP={target_ltp:.2f}"
    )
    return pos

# ============================================================
# STATE MACHINE
# ============================================================
def process_snapshot(session, fyers, execute_trades=False):
    if getattr(session, '_order_lock', False):
        return

    session._order_lock = True
    try:
        with session.lock:
            now = time.time()

            # Expire pending signal if timeout
            if session.pending_signal is not None:
                pending_elapsed = now - session.pending_signal["signal_time"]
                if pending_elapsed >= Config.ENTRY_WAIT_TIMEOUT_SECONDS:
                    expired_type = session.pending_signal["entry_type"]
                    clear_pending_signal(session)
                    session.decision_reason = (
                        f"{expired_type} pending signal expired after "
                        f"{pending_elapsed:.1f}s; waiting for a new signal"
                    )
                    log_console(f"⏰ Pending {expired_type} signal expired after {pending_elapsed:.1f}s")
                    return

            spot = session.get_ltp("NSE:NIFTY50-INDEX")
            if spot is None or spot <= 0:
                session.decision_reason = "No index LTP"
                return

            index_ts = session.get_ltp_time("NSE:NIFTY50-INDEX")
            if index_ts is None or (now - index_ts) > Config.OPTION_PRICE_STALE_SECONDS:
                session.decision_reason = "Index LTP stale; skipping this snapshot"
                return

            interp = get_interpolated_option_prices_live(session, spot)
            if interp is None:
                session.decision_reason = "Interpolated CE/PE unavailable or stale"
                return

            interp_ce = interp["ce"]
            interp_pe = interp["pe"]
            straddle = interp["straddle"]
            ratio = interp_ce / interp_pe if interp_pe > 0 else None

            session.current_ltp = spot
            session.current_straddle = straddle
            session.current_interp_ce = interp_ce
            session.current_interp_pe = interp_pe
            session.current_ratio = ratio

            # Update rolling LTP history
            session.ltp_history.append(spot)
            if session.bars_collected < Config.REQUIRED_BARS:
                session.bars_collected += 1

            # Compute rolling min/max for underlying LTP
            rolling_min_ltp = min(session.ltp_history) if len(session.ltp_history) == Config.REQUIRED_BARS else None
            rolling_max_ltp = max(session.ltp_history) if len(session.ltp_history) == Config.REQUIRED_BARS else None

            # ------------------------------------------------------------
            # ACTIVE POSITION – check SL and Target based on underlying LTP
            # ------------------------------------------------------------
            if session.active_positions:
                pos = session.active_positions[0]
                entry_type = pos["entry_type"]
                # Update current option premium
                current_premium = session.get_ltp(pos["symbol"])
                if current_premium is not None and current_premium > 0:
                    pos["current_premium"] = current_premium
                else:
                    current_premium = pos["current_premium"]

                sl_ltp = pos["sl_ltp"]
                target_ltp = pos["target_ltp"]

                exit_triggered = False
                exit_reason = ""

                # For CE: SL below entry, target above entry
                # For PE: SL above entry, target below entry
                if entry_type == "CE":
                    if spot <= sl_ltp:
                        exit_triggered = True
                        exit_reason = f"SL hit (LTP {spot:.2f} <= {sl_ltp:.2f})"
                    elif spot >= target_ltp:
                        exit_triggered = True
                        exit_reason = f"Target hit (LTP {spot:.2f} >= {target_ltp:.2f})"
                else:  # PE
                    if spot >= sl_ltp:
                        exit_triggered = True
                        exit_reason = f"SL hit (LTP {spot:.2f} >= {sl_ltp:.2f})"
                    elif spot <= target_ltp:
                        exit_triggered = True
                        exit_reason = f"Target hit (LTP {spot:.2f} <= {target_ltp:.2f})"

                session.decision_reason = (
                    f"Holding {entry_type} | Curr LTP={spot:.2f} | "
                    f"SL={sl_ltp:.2f} Target={target_ltp:.2f}"
                )

                if not exit_triggered or not execute_trades:
                    return

                # Exit trade
                held_symbol = pos["symbol"]
                if PAPER_MODE:
                    exit_premium = session.get_ltp(held_symbol)
                    if exit_premium is None or exit_premium <= 0:
                        exit_premium = pos["entry_premium"]
                    pnl = (exit_premium - pos["entry_premium"]) * Config.LOT_SIZE
                    session.paper_realized_pnl += pnl
                    session.active_positions.clear()
                    session.position_state = "FLAT"
                    log_console(
                        f"🔴 PAPER EXIT {entry_type} {held_symbol} | "
                        f"Reason={exit_reason} | "
                        f"Premium {exit_premium:.2f} | P&L={pnl:+.2f}"
                    )
                    session.decision_reason = f"{entry_type} exited by {exit_reason}"
                    return

                # Live exit order
                order = {
                    "symbol": held_symbol,
                    "qty": Config.LOT_SIZE,
                    "type": 2,
                    "side": -1,
                    "productType": "MARGIN",
                    "validity": "DAY",
                }
                resp = fyers.place_order(data=order)
                if resp.get("s") == "ok":
                    session.active_positions.clear()
                    session.position_state = "FLAT"
                    log_console(
                        f"🔴 LIVE EXIT {entry_type} {held_symbol} | "
                        f"Reason={exit_reason} | Order ID: {resp.get('id')}"
                    )
                    session.decision_reason = f"{entry_type} live exit submitted"
                else:
                    log_console(f"❌ Failed to exit {held_symbol}: {resp}")
                    session.decision_reason = f"Live exit failed: {resp}"
                return

            # ------------------------------------------------------------
            # WAITING FOR ENTRY CONFIRMATION
            # ------------------------------------------------------------
            if session.pending_signal is not None:
                pending = session.pending_signal
                elapsed = now - pending["signal_time"]

                selected_interp = interp_ce if pending["entry_type"] == "CE" else interp_pe
                reference = pending["reference_price"]

                if not is_within_entry_range(reference, selected_interp):
                    remaining = max(0.0, Config.ENTRY_WAIT_TIMEOUT_SECONDS - elapsed)
                    session.decision_reason = (
                        f"WAITING {pending['entry_type']} | "
                        f"Interp={selected_interp:.2f} | "
                        f"Range={reference*(1-0.01):.2f}-{reference*(1+0.01):.2f} | "
                        f"{remaining:.1f}s left"
                    )
                    return

                # Confirmation: get real ATM contract
                entry_type = pending["entry_type"]
                symbol, entry_premium, real_atm_strike = get_current_real_atm_contract(session, spot, entry_type)

                if symbol is None or entry_premium is None or entry_premium <= 0:
                    remaining = max(0.0, Config.ENTRY_WAIT_TIMEOUT_SECONDS - elapsed)
                    session.decision_reason = (
                        f"{entry_type} interpolation confirmed, but real ATM "
                        f"contract/premium unavailable; {remaining:.1f}s left"
                    )
                    return

                if not execute_trades:
                    clear_pending_signal(session)
                    session.decision_reason = f"{entry_type} confirmed; auto-trading disabled"
                    log_console(f"✅ {entry_type} confirmed by interpolated price; auto-trading disabled")
                    return

                if PAPER_MODE:
                    # Frozen underlying min/max at entry
                    frozen_min = rolling_min_ltp
                    frozen_max = rolling_max_ltp
                    # They should not be None at this point because we have warmup
                    create_position(session, symbol, entry_premium, entry_type, spot, frozen_min, frozen_max)
                    clear_pending_signal(session)
                    session.position_state = "ACTIVE"
                    session.decision_reason = f"PAPER entered {symbol} after confirmation"
                    log_console(
                        f"🟢 PAPER BUY {symbol} @ {entry_premium:.2f} | "
                        f"ATM Strike={real_atm_strike} | "
                        f"Interp={selected_interp:.2f} within ±1% of {reference:.2f}"
                    )
                    return

                # LIVE: submit order
                pending["order_submission_attempted"] = True
                order = {
                    "symbol": symbol,
                    "qty": Config.LOT_SIZE,
                    "type": 2,
                    "side": 1,
                    "productType": "MARGIN",
                    "validity": "DAY",
                }
                resp = fyers.place_order(data=order)

                if resp.get("s") == "ok":
                    frozen_min = rolling_min_ltp
                    frozen_max = rolling_max_ltp
                    create_position(session, symbol, entry_premium, entry_type, spot, frozen_min, frozen_max)
                    clear_pending_signal(session)
                    session.position_state = "ACTIVE"
                    session.decision_reason = f"LIVE entry submitted for {symbol}"
                    log_console(
                        f"🟢 LIVE BUY {symbol} @ {entry_premium:.2f} | "
                        f"Order ID: {resp.get('id')}"
                    )
                else:
                    clear_pending_signal(session)
                    session.decision_reason = f"Live entry failed: {resp}"
                    log_console(f"❌ LIVE entry failed for {symbol}: {resp}")
                return

            # ------------------------------------------------------------
            # FLAT: check warmup and signal conditions
            # ------------------------------------------------------------
            if session.bars_collected < Config.REQUIRED_BARS:
                session.decision_reason = (
                    f"Warming up ({session.bars_collected}/{Config.REQUIRED_BARS})"
                )
                return

            if session.daily_entries >= Config.MAX_DAILY_ENTRIES:
                session.decision_reason = "Max daily entries reached"
                return

            if ratio is None:
                session.decision_reason = "Ratio unavailable"
                return

            # Signal detection based on underlying LTP rolling min/max
            buy_ce = False
            buy_pe = False

            # CE signal: ratio < RATIO_BUY_CE AND spot <= rolling_min_ltp
            if ratio < Config.RATIO_BUY_CE and spot <= rolling_min_ltp:
                buy_ce = True

            # PE signal: ratio > RATIO_BUY_PE AND spot >= rolling_max_ltp
            if ratio > Config.RATIO_BUY_PE and spot >= rolling_max_ltp:
                buy_pe = True

            if buy_ce and buy_pe:
                # Both cannot be true simultaneously
                session.decision_reason = "Both signals triggered unexpectedly – ignoring"
                return

            if not buy_ce and not buy_pe:
                session.decision_reason = (
                    f"IDLE | Ratio={ratio:.4f} | LTP min={rolling_min_ltp:.2f} max={rolling_max_ltp:.2f} | "
                    f"Spot={spot:.2f}"
                )
                return

            # Generate pending signal
            entry_type = "CE" if buy_ce else "PE"
            reference_price = interp_ce if entry_type == "CE" else interp_pe
            pct = Config.ENTRY_PRICE_RANGE_PERCENT / 100.0

            session.pending_signal = {
                "entry_type": entry_type,
                "signal_time": now,
                "signal_spot": float(spot),
                "signal_interp_ce": float(interp_ce),
                "signal_interp_pe": float(interp_pe),
                "reference_price": float(reference_price),
            }
            session.position_state = "WAITING"

            lower = reference_price * (1.0 - pct)
            upper = reference_price * (1.0 + pct)

            session.decision_reason = (
                f"{entry_type} signal recorded | Ratio={ratio:.4f} | "
                f"Ref={reference_price:.2f} | Range={lower:.2f}-{upper:.2f} | "
                f"Timeout={Config.ENTRY_WAIT_TIMEOUT_SECONDS}s"
            )
            log_console(
                f"🔔 {entry_type} SIGNAL | Spot={spot:.2f} | Ratio={ratio:.4f} | "
                f"CE={interp_ce:.2f}, PE={interp_pe:.2f} | "
                f"Reference={reference_price:.2f} | Range={lower:.2f}-{upper:.2f}"
            )
            return

    except Exception as e:
        log_console(f"process_snapshot error: {e}")
        log_debug(traceback.format_exc())
        session.decision_reason = f"Error: {str(e)}"
    finally:
        session._order_lock = False

# ============================================================
# SAMPLER THREAD
# ============================================================
def sampler(session, data_logger, auto_trade, fyers):
    log_debug("Sampler thread started")
    while session.running:
        start = now_ist()
        try:
            process_snapshot(session, fyers, execute_trades=auto_trade)

            # Compute interpolated and real ATM values for logging
            spot = session.get_ltp("NSE:NIFTY50-INDEX")
            interp_ce = interp_pe = real_atm_ce = real_atm_pe = 0.0
            ratio = None
            if spot is not None and spot > 0:
                interp = get_interpolated_option_prices_live(session, spot)
                if interp is not None:
                    interp_ce = interp.get("ce", 0.0)
                    interp_pe = interp.get("pe", 0.0)
                    if interp_pe > 0:
                        ratio = interp_ce / interp_pe
                sym_ce, prem_ce, _ = get_current_real_atm_contract(session, spot, "CE")
                if prem_ce is not None:
                    real_atm_ce = float(prem_ce)
                sym_pe, prem_pe, _ = get_current_real_atm_contract(session, spot, "PE")
                if prem_pe is not None:
                    real_atm_pe = float(prem_pe)

            # Rolling min/max of underlying LTP
            with session.lock:
                rolling_min_ltp = min(session.ltp_history) if len(session.ltp_history) == Config.REQUIRED_BARS else None
                rolling_max_ltp = max(session.ltp_history) if len(session.ltp_history) == Config.REQUIRED_BARS else None

            # Total P&L
            total_pnl = session.paper_realized_pnl
            for pos in session.active_positions:
                current = pos.get("current_premium", pos["entry_premium"])
                if current and pos.get("entry_premium"):
                    total_pnl += (current - pos["entry_premium"]) * Config.LOT_SIZE

            # Update current premium for active positions
            with session.lock:
                for pos in session.active_positions:
                    current_premium = session.get_ltp(pos["symbol"])
                    if current_premium is None:
                        for opt in session.option_chain:
                            if opt["symbol"] == pos["symbol"]:
                                current_premium = opt.get("ltp", 0)
                                break
                    pos["current_premium"] = current_premium if current_premium else pos["entry_premium"]

            data_logger.log_data(
                timestamp=timestamp_ist(),
                ltp=spot,
                straddle=session.current_straddle,
                interp_ce=interp_ce,
                interp_pe=interp_pe,
                ratio=ratio,
                real_atm_ce=real_atm_ce,
                real_atm_pe=real_atm_pe,
                rolling_min_ltp=rolling_min_ltp,
                rolling_max_ltp=rolling_max_ltp,
                active_positions=session.active_positions,
                total_pnl=total_pnl,
                daily_entries=session.daily_entries,
                bars_collected=session.bars_collected,
                decision_reason=session.decision_reason
            )

            elapsed = (now_ist() - start).total_seconds()
            if elapsed < Config.SAMPLE_INTERVAL:
                time.sleep(Config.SAMPLE_INTERVAL - elapsed)

        except Exception as e:
            log_debug(f"Sampler error: {e}\n{traceback.format_exc()}")
            time.sleep(1)

# ============================================================
# DASHBOARD
# ============================================================
class TerminalDashboard:
    def __init__(self, data_logger, session_state):
        self.data_logger = data_logger
        self.session_state = session_state

    def display(self):
        try:
            os.system('cls' if os.name == 'nt' else 'clear')
            mode = "PAPER" if PAPER_MODE else "LIVE"
            print("\n" + "="*90)
            print(f"📊 {mode} TRADING DASHBOARD – Underlying Rolling Min/Max + SL/Target")
            print("="*90)

            with self.session_state.lock:
                daily_entries = self.session_state.daily_entries
                vix = self.session_state.india_vix
                realized = self.session_state.paper_realized_pnl
                decision_reason = self.session_state.decision_reason
                bars_collected = self.session_state.bars_collected
                warmup = bars_collected < Config.REQUIRED_BARS

                ltp = self.session_state.current_ltp
                straddle = self.session_state.current_straddle
                ratio = self.session_state.current_ratio
                interp_ce = self.session_state.current_interp_ce
                interp_pe = self.session_state.current_interp_pe

                rolling_min_ltp = min(self.session_state.ltp_history) if len(self.session_state.ltp_history) == Config.REQUIRED_BARS else None
                rolling_max_ltp = max(self.session_state.ltp_history) if len(self.session_state.ltp_history) == Config.REQUIRED_BARS else None

                active_positions = self.session_state.active_positions[:]
                pending_signal = self.session_state.pending_signal.copy() if self.session_state.pending_signal else None
                last_data = self.session_state.last_data_time
                last_data_str = datetime.fromtimestamp(last_data).strftime("%H:%M:%S") if last_data else "No data yet"

            status = "⏳ WARMING UP" if warmup else f"✅ ACTIVE ({bars_collected}/{Config.REQUIRED_BARS})"

            pos_str = "NEUTRAL"
            if active_positions:
                pos = active_positions[0]
                entry_type = pos.get('entry_type', '?')
                entry = pos.get('entry_premium', 0)
                current = pos.get('current_premium', entry)
                pnl = ((current - entry) * Config.LOT_SIZE) if current and entry else 0
                sl_ltp = pos.get('sl_ltp', 0)
                target_ltp = pos.get('target_ltp', 0)
                entry_ltp = pos.get('entry_ltp', 0)
                pos_str = (f"{entry_type} | Entry Prem={entry:.2f} | Curr Prem={current:.2f} | "
                           f"Entry LTP={entry_ltp:.2f} | SL LTP={sl_ltp:.2f} Target LTP={target_ltp:.2f} | "
                           f"P&L={pnl:+.2f}")

            print(f"Last Update: {timestamp_ist()}   |   WS Last Data: {last_data_str}")
            print(f"📈 Daily Entries: {daily_entries}/{Config.MAX_DAILY_ENTRIES}")
            print(f"📊 India VIX: {vix:.2f}   |   💰 Realized P&L: {realized:+.2f}")
            print(f"⏳ Status: {status}")

            print("\n" + "-"*90)
            print("📊 SNAPSHOT DATA")
            print("-"*90)
            print(f"  LTP: {ltp:.2f}   |   Straddle: {straddle:.2f}")
            print(f"  Interp CE: {interp_ce:.2f}   PE: {interp_pe:.2f}   Ratio: {ratio:.4f}" if ratio else "  Ratio: N/A")
            if not warmup:
                print(f"  Rolling LTP: min={rolling_min_ltp:.2f} max={rolling_max_ltp:.2f}")
                print(f"  Signal rules: BUY CE if ratio<{Config.RATIO_BUY_CE} and LTP<=min | "
                      f"BUY PE if ratio>{Config.RATIO_BUY_PE} and LTP>=max")
            else:
                print(f"  Waiting for {Config.REQUIRED_BARS - bars_collected} more LTP bars...")

            print("\n" + "-"*90)
            print("📌 POSITION & EXIT LEVELS")
            print("-"*90)
            if active_positions:
                print(f"  Symbol: {pos.get('symbol','?')}")
                print(f"  {pos_str}")
                print(f"  Frozen Range = {pos.get('range_val',0):.2f}")
                print(f"  SL LTP = {sl_ltp:.2f}   Target LTP = {target_ltp:.2f}")
                print(f"  Current LTP = {ltp:.2f}")
            else:
                if pending_signal:
                    elapsed = time.time() - pending_signal["signal_time"]
                    ref = pending_signal["reference_price"]
                    pct = Config.ENTRY_PRICE_RANGE_PERCENT / 100.0
                    print(f"  WAITING: {pending_signal['entry_type']} | Ref interp={ref:.2f} | "
                          f"Range={ref*(1-pct):.2f}-{ref*(1+pct):.2f} | "
                          f"Elapsed={elapsed:.1f}s/{Config.ENTRY_WAIT_TIMEOUT_SECONDS}s")
                else:
                    print("  No active position (FLAT)")

            print("\n" + "-"*90)
            print("🧠 STATUS")
            print("-"*90)
            print(f"  Position: {pos_str}")
            print(f"  Decision: {decision_reason}")

            print("\n" + "-"*90)
            print("⚙️ CONFIGURATION")
            print("-"*90)
            print(f"  Window: {Config.WINDOW_SECONDS}s ({Config.REQUIRED_BARS} bars)")
            print(f"  Buy CE: Ratio < {Config.RATIO_BUY_CE} and LTP <= rolling min")
            print(f"  Buy PE: Ratio > {Config.RATIO_BUY_PE} and LTP >= rolling max")
            print(f"  SL/Target: based on underlying LTP range (frozen at entry)")
            print(f"  Lot Size: {Config.LOT_SIZE}")

            print("\n" + "="*90)
        except Exception as e:
            log_debug(f"Dashboard error: {e}")

# ============================================================
# CREDENTIALS & MAIN
# ============================================================
def load_credentials(session):
    try:
        with open('fyers_credentials.json', 'r') as f:
            creds = json.load(f)
            session.cid = creds.get('client_id', '')
            session.token = creds.get('access_token', '')
        log_console(f"Loaded credentials: {session.cid}")
    except Exception as e:
        log_console(f"Failed to load credentials file: {e} – falling back to env vars")
        session.cid = os.getenv("FYERS_CID", "")
        session.token = os.getenv("FYERS_TOKEN", "")
        log_console(f"Using env vars: {session.cid}")

def main():
    log_console("Starting Underlying Rolling Min Strategy with SL/Target...")
    session = SessionState()
    load_credentials(session)
    data_logger = DataLogger()
    dashboard = TerminalDashboard(data_logger, session)
    index_symbol = "NSE:NIFTY50-INDEX"
    vix_symbol = "NSE:INDIAVIX-INDEX"

    poller_thread = None
    sampler_thread = None
    ws_manager = None
    fyers = None

    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        print("="*50)
        mode = "PAPER" if PAPER_MODE else "LIVE"
        print(f"📈 FYERS ALGO TRADING ({mode} MODE)")
        print("1. Start Trading")
        print("2. Settings")
        print("3. Exit")
        choice = input("Select option: ").strip()
        if choice == "1":
            if not (session.cid and session.token):
                print("❌ Set credentials first")
                input("Press Enter...")
                continue

            session.reset_for_new_day()

            auto_trade = input("Enable Auto Trade? (y/n): ").lower() == 'y'
            log_console(f"Auto trade: {'ON' if auto_trade else 'OFF'}")

            ws_manager = MarketWSManager(session, session.token)
            ws_manager.start()
            ws_manager.subscribe([index_symbol, vix_symbol])
            session.running = True

            fyers = fyersModel.FyersModel(client_id=session.cid, token=session.token, is_async=False, log_path="")
            poller_thread = threading.Thread(target=chain_poller, args=(session, ws_manager, index_symbol), daemon=True)
            sampler_thread = threading.Thread(target=sampler, args=(session, data_logger, auto_trade, fyers), daemon=True)

            poller_thread.start()
            sampler_thread.start()

            print("\n✅ Trading started. Press Ctrl+C to stop.\n")
            try:
                while True:
                    dashboard.display()
                    time.sleep(1)
            except KeyboardInterrupt:
                log_console("\n🛑 Stopping trading...")
                session.running = False
                ws_manager.stop()

                if sampler_thread is not None:
                    sampler_thread.join(timeout=5)
                if poller_thread is not None:
                    poller_thread.join(timeout=Config.OPTION_CHAIN_INTERVAL + 5)

                if session.active_positions:
                    log_console(f"Attempting to close {len(session.active_positions)} open position(s)...")
                    process_snapshot(session, fyers, execute_trades=True)

                with session.lock:
                    if session.active_positions:
                        log_console(f"⚠️ {len(session.active_positions)} position(s) could not be closed. Check broker manually.")
                    else:
                        session.eod_square_off_triggered = False
                        session.daily_entries = 0
                        session.paper_realized_pnl = 0.0
                        log_console("✅ Trading stopped and state reset. You can start again.")
        elif choice == "2":
            print("\n⚙️ SETTINGS")
            new_cid = input(f"Client ID [{session.cid}]: ").strip()
            if new_cid:
                session.cid = new_cid
            new_token = input("Access token: ").strip()
            if new_token:
                session.token = new_token
            with open('fyers_credentials.json', 'w') as f:
                json.dump({"client_id": session.cid, "access_token": session.token}, f)
            print("✅ Saved")
            input("Press Enter...")
        elif choice == "3":
            if session.running:
                session.running = False
                if ws_manager:
                    ws_manager.stop()
            if session.active_positions:
                log_console(f"⚠️ Exiting with {len(session.active_positions)} position(s) still tracked.")
            break

if __name__ == "__main__":
    main()