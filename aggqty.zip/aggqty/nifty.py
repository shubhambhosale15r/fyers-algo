"""
HVTP Indicator – Nifty ATM Options (Paper Trading)
CRITICAL FIX: When a symbol is unsubscribed, any open position in that symbol is closed.
Now safe to run during live market.
"""

import time
import threading
import csv
import os
import sys
from datetime import datetime, timedelta
from collections import defaultdict, deque
from fyers_apiv3 import fyersModel
from fyers_apiv3.FyersWebsocket import data_ws

# ===================== CONFIGURATION =====================
INDEX_SYMBOL = "NSE:NIFTY50-INDEX"
STRIKE_INTERVAL = 50
WINDOW_MINUTES = 5
WARMUP_SECONDS = 300
OPTION_CHAIN_INTERVAL = 15
TRADE_QTY = 65
ACCESS_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOlsiZDoxIiwiZDoyIiwieDowIiwieDoxIiwieDoyIl0sImF0X2hhc2giOiJnQUFBQUFCcW9WX2Y1Ql9CdVlrb2VmdnZnbFBTR045QzFjSy1qMVFXT1hmMDk4ZlpxVWNuYmMzeHFIaVpIMXM0UEhBUlN2ZEhWWFlkZFhDOU5uSnNFSFpRM0ZOVTVrQi13UTZSVmFiTWM3T1V0TVJLZnNndGFnWT0iLCJkaXNwbGF5X25hbWUiOiIiLCJvbXMiOiJLMSIsImhzbV9rZXkiOiIyZDA2MWI2YmI5NjIxOTQwOGM2MDg5MWIzMjdiNTlkYmY3YTdiN2RlZGZhNWQ5OWNiZWI5YTU3NyIsImlzRGRwaUVuYWJsZWQiOiJOIiwiaXNNdGZFbmFibGVkIjoiTiIsImZ5X2lkIjoiRkFBMzE0OTUiLCJhcHBUeXBlIjoyMDAsImV4cCI6MTc4OTAwMDIwMCwiaWF0IjoxNzg4OTYwNzM1LCJpc3MiOiJhcGkuZnllcnMuaW4iLCJuYmYiOjE3ODg5NjA3MzUsInN1YiI6ImFjY2Vzc190b2tlbiJ9.IoFWD0NRsCHlYBxEO0EPuyNBhhO4z_grfrUlR9DTgwY"
CLIENT_ID = "J0ENYFX9ME-200"
LOG_FILE = "hvtp_trades.csv"
DASHBOARD_INTERVAL = 1.0
RECENT_LOG_LINES = 5

# ===================== GLOBAL STATE =====================
trade_data = defaultdict(lambda: deque(maxlen=10000))
hvtp_cache = {}
warmup_start = {}                         # symbol -> system time of first message
current_position = None                   # {'symbol': str, 'entry_price': float}
position_lock = threading.Lock()
subscribed_symbols = set()
fyers_ws = None
data_lock = threading.Lock()
last_update_time = {}
log_history = deque(maxlen=100)

# ===================== HELPERS =====================
def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def get_atm_strike(spot_price):
    return round(spot_price / STRIKE_INTERVAL) * STRIKE_INTERVAL

def compute_hvtp(symbol):
    with data_lock:
        now = datetime.now()
        cutoff = now - timedelta(minutes=WINDOW_MINUTES)
        recent = [(ts, p, q) for ts, p, q in trade_data[symbol] if ts >= cutoff]
        if not recent:
            return None
        vol_by_price = defaultdict(int)
        for _, p, q in recent:
            vol_by_price[p] += q
        return max(vol_by_price, key=vol_by_price.get)

def log_to_csv(timestamp, symbol, ltp, hvtp, status, action, position_status):
    file_exists = os.path.isfile(LOG_FILE)
    with open(LOG_FILE, mode='a', newline='') as f:
        writer = csv.writer(f)
        if not file_exists:
            writer.writerow(["Timestamp", "Symbol", "LTP", "HVTP", "Status", "Action", "Position"])
        writer.writerow([
            timestamp.strftime("%Y-%m-%d %H:%M:%S"),
            symbol, ltp, hvtp if hvtp is not None else "", status, action, position_status
        ])

def add_log_line(msg):
    log_history.append(msg)
    print(msg)

def format_num(val, decimals=2):
    if val is None:
        return "N/A"
    try:
        return f"{float(val):.{decimals}f}"
    except (ValueError, TypeError):
        return "N/A"

def format_log_line(timestamp, symbol, ltp, hvtp, status, action, pos_info=""):
    return (f"[{timestamp.strftime('%H:%M:%S')}] {symbol} | "
            f"LTP:{format_num(ltp)} HVTP:{format_num(hvtp)} "
            f"Status:{status} Action:{action} {pos_info}")

def close_position_if_symbol(symbol):
    """If we have an open position in this symbol, exit it."""
    global current_position
    with position_lock:
        if current_position is not None and current_position['symbol'] == symbol:
            # Log exit
            exit_price = current_position['entry_price']  # we don't have current LTP here, but we'll log with placeholder
            # We'll use the latest LTP from trade_data if available
            with data_lock:
                if trade_data[symbol]:
                    latest_ltp = trade_data[symbol][-1][1]
                else:
                    latest_ltp = exit_price
            action = "SELL (UNSUB)"
            pos_status = "EXIT"
            # Log with current time
            now = datetime.now()
            log_to_csv(now, symbol, latest_ltp, hvtp_cache.get(symbol), "UNSUB", action, pos_status)
            log_line = format_log_line(now, symbol, latest_ltp, hvtp_cache.get(symbol), "UNSUB", action, f"Exit due to unsubscribe")
            add_log_line(log_line)
            current_position = None
            return True
    return False

# ===================== DASHBOARD THREAD =====================
def dashboard_loop():
    while True:
        time.sleep(DASHBOARD_INTERVAL)
        clear_screen()
        now = datetime.now()

        lines = []
        lines.append("=" * 80)
        lines.append(f"HVTP DASHBOARD – {now.strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append(f"Position: {current_position['symbol'] if current_position else 'None'}")
        lines.append("-" * 80)
        lines.append(f"{'Symbol':<25} {'Trades':<6} {'Warmup (clock)':<16} {'Last Update':<20} {'HVTP':<8} {'LTP':<8} {'Status':<10}")
        lines.append("-" * 80)

        with data_lock:
            for sym in sorted(subscribed_symbols):
                cutoff = now - timedelta(minutes=WINDOW_MINUTES)
                count = sum(1 for ts, _, _ in trade_data[sym] if ts >= cutoff)

                last_upd = last_update_time.get(sym)
                last_str = last_upd.strftime("%H:%M:%S") if last_upd else "N/A"

                start = warmup_start.get(sym)
                if start:
                    elapsed = (now - start).total_seconds()
                    if elapsed < WARMUP_SECONDS:
                        warmup_str = f"{elapsed:.0f}s / {WARMUP_SECONDS}s"
                    else:
                        warmup_str = f"READY ({elapsed:.0f}s)"
                else:
                    warmup_str = "WAITING"

                hvtp = hvtp_cache.get(sym)
                hvtp_str = format_num(hvtp)

                latest_ltp = None
                if trade_data[sym]:
                    latest_ltp = trade_data[sym][-1][1]
                ltp_str = format_num(latest_ltp)

                if elapsed >= WARMUP_SECONDS and count > 0:
                    if hvtp is not None and latest_ltp is not None:
                        if latest_ltp > hvtp:
                            status_str = "ABOVE"
                        elif latest_ltp < hvtp:
                            status_str = "BELOW"
                        else:
                            status_str = "AT"
                    else:
                        status_str = "NO HVTP"
                else:
                    status_str = "WARMUP" if elapsed < WARMUP_SECONDS else "NO DATA"

                lines.append(f"{sym:<25} {count:<6} {warmup_str:<16} {last_str:<20} {hvtp_str:<8} {ltp_str:<8} {status_str:<10}")

        lines.append("=" * 80)
        lines.append("NOTE: CSV logs only when a trade update arrives (not every second).")
        lines.append("RECENT LOGS (last {}):".format(RECENT_LOG_LINES))
        recent_logs = list(log_history)[-RECENT_LOG_LINES:]
        for log_line in recent_logs:
            lines.append(log_line)

        sys.stdout.write("\n".join(lines) + "\n")
        sys.stdout.flush()

# ===================== WEBSOCKET CALLBACKS =====================
def onmessage(message):
    global current_position, hvtp_cache, warmup_start, last_update_time
    try:
        if message.get('type') != 'sf':
            return
        symbol = message['symbol']
        ltp = message['ltp']
        ltq = message['last_traded_qty']
        ltt = message['last_traded_time']

        trade_time = datetime.fromtimestamp(ltt)
        last_update_time[symbol] = trade_time

        with data_lock:
            trade_data[symbol].append((trade_time, ltp, ltq))

        if symbol not in warmup_start:
            warmup_start[symbol] = datetime.now()
            add_log_line(f"[WARMUP] Started collecting data for {symbol} at {trade_time.strftime('%H:%M:%S')}")

        elapsed = (datetime.now() - warmup_start[symbol]).total_seconds()
        if elapsed < WARMUP_SECONDS:
            hvtp = compute_hvtp(symbol)
            status = "WARMUP"
            action = "WARMUP"
            pos_status = f"Warming up ({elapsed:.1f}s / {WARMUP_SECONDS}s)"
            log_to_csv(trade_time, symbol, ltp, hvtp, status, action, pos_status)
            log_line = format_log_line(trade_time, symbol, ltp, hvtp, status, action, pos_status)
            add_log_line(log_line)
            return

        # --- Warmup complete ---
        hvtp = compute_hvtp(symbol)
        if hvtp is None:
            return
        hvtp_cache[symbol] = hvtp

        if ltp > hvtp:
            status = "ABOVE"
        elif ltp < hvtp:
            status = "BELOW"
        else:
            status = "AT"

        action = "HOLD"
        pos_status = "NONE"

        with position_lock:
            if current_position is None:
                if status == "ABOVE":
                    current_position = {'symbol': symbol, 'entry_price': ltp}
                    action = "BUY"
                    pos_status = f"LONG {symbol}"
                    log_to_csv(trade_time, symbol, ltp, hvtp, status, action, pos_status)
                    log_line = format_log_line(trade_time, symbol, ltp, hvtp, status, action, f"Qty={TRADE_QTY}")
                    add_log_line(log_line)
                else:
                    pos_status = "NO POSITION"
                    log_to_csv(trade_time, symbol, ltp, hvtp, status, action, pos_status)
                    log_line = format_log_line(trade_time, symbol, ltp, hvtp, status, action, pos_status)
                    add_log_line(log_line)
            else:
                if current_position['symbol'] == symbol:
                    if status == "BELOW":
                        action = "SELL"
                        pos_status = "EXIT"
                        log_to_csv(trade_time, symbol, ltp, hvtp, status, action, pos_status)
                        log_line = format_log_line(trade_time, symbol, ltp, hvtp, status, action, f"Exit at {ltp:.2f}")
                        add_log_line(log_line)
                        current_position = None
                    else:
                        pos_status = f"HOLD {symbol}"
                        log_to_csv(trade_time, symbol, ltp, hvtp, status, action, pos_status)
                        log_line = format_log_line(trade_time, symbol, ltp, hvtp, status, action, "Holding")
                        add_log_line(log_line)
                else:
                    pos_status = f"IGNORE (pos in {current_position['symbol']})"
                    log_to_csv(trade_time, symbol, ltp, hvtp, status, action, pos_status)
                    log_line = format_log_line(trade_time, symbol, ltp, hvtp, status, action, pos_status)
                    add_log_line(log_line)

    except Exception as e:
        add_log_line(f"Error in onmessage: {e}")

def onerror(message):
    add_log_line(f"WebSocket Error: {message}")

def onclose(message):
    add_log_line(f"WebSocket Closed: {message}")

def onopen():
    global subscribed_symbols
    if subscribed_symbols:
        fyers_ws.subscribe(symbols=list(subscribed_symbols), data_type="SymbolUpdate")
        add_log_line(f"Subscribed to: {subscribed_symbols}")
    else:
        add_log_line("No symbols to subscribe.")
    fyers_ws.keep_running()

# ===================== FETCH OPTION CHAIN =====================
def fetch_option_chain_and_update():
    global subscribed_symbols, warmup_start
    try:
        fyers = fyersModel.FyersModel(client_id=CLIENT_ID, token=ACCESS_TOKEN, is_async=False, log_path="")
        data = {
            "symbol": INDEX_SYMBOL,
            "strikecount": 2,
            "timestamp": "",
            "greeks": "0"
        }
        response = fyers.optionchain(data=data)
        if response.get('s') != 'ok':
            add_log_line(f"Option chain error: {response}")
            return

        options_chain = response.get('data', {}).get('optionsChain', [])
        underlying = None
        for item in options_chain:
            if item.get('option_type') == '' and item.get('strike_price') == -1:
                underlying = item
                break
        if not underlying:
            add_log_line("Underlying not found in option chain")
            return
        spot_price = underlying.get('ltp') or underlying.get('fp')
        if not spot_price:
            add_log_line("Could not get spot price")
            return

        atm_strike = get_atm_strike(spot_price)
        atm_ce = atm_pe = None
        for item in options_chain:
            opt_type = item.get('option_type')
            strike = item.get('strike_price')
            if opt_type == 'CE' and strike == atm_strike:
                atm_ce = item.get('symbol')
            elif opt_type == 'PE' and strike == atm_strike:
                atm_pe = item.get('symbol')
        if not atm_ce or not atm_pe:
            add_log_line(f"Could not find both CE and PE for strike {atm_strike}")
            return

        new_symbols = {atm_ce, atm_pe}

        if fyers_ws:
            to_unsubscribe = subscribed_symbols - new_symbols
            to_subscribe = new_symbols - subscribed_symbols

            # --- CRITICAL FIX: Close position if symbol is being unsubscribed ---
            for sym in to_unsubscribe:
                if close_position_if_symbol(sym):
                    add_log_line(f"Closed position for {sym} due to strike change")

            if to_unsubscribe:
                fyers_ws.unsubscribe(symbols=list(to_unsubscribe), data_type="SymbolUpdate")
                add_log_line(f"Unsubscribed: {to_unsubscribe}")
                for sym in to_unsubscribe:
                    if sym in warmup_start:
                        del warmup_start[sym]

            if to_subscribe:
                fyers_ws.subscribe(symbols=list(to_subscribe), data_type="SymbolUpdate")
                add_log_line(f"Subscribed: {to_subscribe}")

            subscribed_symbols = new_symbols
            add_log_line(f"Current symbols: {subscribed_symbols}")
        else:
            subscribed_symbols = new_symbols
            add_log_line(f"WebSocket not connected; symbols set to: {subscribed_symbols}")

    except Exception as e:
        add_log_line(f"Error fetching option chain: {e}")

def periodic_update():
    while True:
        fetch_option_chain_and_update()
        time.sleep(OPTION_CHAIN_INTERVAL)

# ===================== MAIN =====================
def main():
    global fyers_ws

    threading.Thread(target=periodic_update, daemon=True).start()
    threading.Thread(target=dashboard_loop, daemon=True).start()

    fyers_ws = data_ws.FyersDataSocket(
        access_token=ACCESS_TOKEN,
        log_path="",
        litemode=False,
        write_to_file=False,
        reconnect=True,
        on_connect=onopen,
        on_close=onclose,
        on_error=onerror,
        on_message=onmessage
    )
    fyers_ws.connect()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        add_log_line("Stopping...")
        fyers_ws.close()
        add_log_line("Disconnected.")

if __name__ == "__main__":
    main()