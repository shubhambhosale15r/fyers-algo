import time
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import pytz
from fyers_apiv3 import fyersModel
from fyers_apiv3.FyersWebsocket import data_ws
import logging
import os
import json
from collections import deque
import csv
import threading
import traceback

# ============================================================
# CONFIGURATION
# ============================================================
class Config:
    SAMPLE_INTERVAL = 1
    OPTION_CHAIN_INTERVAL = 30
    ROLLING_WINDOW_SIZE = 15 * 60
    TRAIL_STOP_PCT = 0.25
    LOT_SIZE = 195
    MAX_DAILY_ORDERS = 8
    API_RATE_LIMIT = 200
    API_WINDOW = 60
    MAX_RETRIES = 3
    RETRY_DELAY = 2

# ============================================================
# LOGGING (file only for debug, console only for important events)
# ============================================================
logging.basicConfig(
    filename="trading_app.log",
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)

def log_debug(msg):
    """Write to log file only, not console"""
    logging.debug(msg)

def log_console(msg):
    """Write to both console and log file"""
    print(msg, flush=True)
    logging.info(msg)

IST = pytz.timezone("Asia/Kolkata")

def now_ist():
    return datetime.now(IST)

def timestamp_ist():
    return now_ist().strftime("%Y-%m-%d %H:%M:%S")

# ============================================================
# ERROR HANDLER
# ============================================================
def handle_errors(func):
    def wrapper(*args, **kwargs):
        for retry in range(Config.MAX_RETRIES):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                log_debug(f"{func.__name__} attempt {retry+1} failed: {e}\n{traceback.format_exc()}")
                if retry < Config.MAX_RETRIES-1:
                    time.sleep(Config.RETRY_DELAY)
                else:
                    log_debug(f"{func.__name__} permanently failed")
                    return None
    return wrapper

# ============================================================
# DATA LOGGER (CSV)
# ============================================================
class DataLogger:
    def __init__(self, filename="trading_data.csv"):
        self.filename = filename
        self._ensure_header()

    def _ensure_header(self):
        if not os.path.exists(self.filename):
            with open(self.filename, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'timestamp', 'underlying_ltp', 'fut_price', 'signal', 'atm_strike',
                    'expiry_date', 'idwp', 'inof', 'cumul_idwp', 'cumul_inof',
                    'vwap_composite', 'cumul_vwap_composite' ,'position' ,  'std_inof', 'std_composite'
                ])

    def log_data(self, timestamp, underlying_ltp, fut_price, signal, atm_strike,
                 expiry_date, idwp, inof, cumul_idwp, cumul_inof,
                 vwap_composite, cumul_vwap_composite, position,std_inof=0.0,std_composite=0.0):
        with open(self.filename, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                str(timestamp), underlying_ltp, fut_price, signal, atm_strike,
                expiry_date, round(idwp,2), round(inof,2), round(cumul_idwp,2),
                round(cumul_inof,2), round(vwap_composite,2), round(cumul_vwap_composite,2) , position,  round(std_inof,2), round(std_composite,2)
            ])

    def read_data(self, limit=None):
        try:
            df = pd.read_csv(self.filename)
            return df.tail(limit) if limit else df
        except:
            return pd.DataFrame()
def get_strike_details(session):
    """Return list of dicts for ATM and adjacent strikes with live data."""
    details = []
    with session.lock:
        if not session.option_chain or session.atm_strike is None:
            return details
        
        fut = session.fut_price
        atm = session.atm_strike
        
        # Get all strikes from chain
        all_strikes = sorted(set(opt["strike_price"] for opt in session.option_chain if opt.get("option_type") in ("CE","PE")))
        if not all_strikes or atm not in all_strikes:
            return details
        
        idx = all_strikes.index(atm)
        selected = [atm]
        if idx > 0:
            selected.append(all_strikes[idx-1])
        if idx < len(all_strikes)-1:
            selected.append(all_strikes[idx+1])
        
        for strike in selected:
            ce = next((o for o in session.option_chain if o["strike_price"] == strike and o["option_type"] == "CE"), None)
            pe = next((o for o in session.option_chain if o["strike_price"] == strike and o["option_type"] == "PE"), None)
            if not ce or not pe:
                continue
            
            ce_ltp = session.get_ltp(ce["symbol"]) or ce.get("ltp", 0)
            pe_ltp = session.get_ltp(pe["symbol"]) or pe.get("ltp", 0)
            ce_vwap = session.get_vwap(ce["symbol"]) or ce_ltp
            pe_vwap = session.get_vwap(pe["symbol"]) or pe_ltp
            ce_vol = session.get_volume(ce["symbol"]) or ce.get("volume", 0)
            pe_vol = session.get_volume(pe["symbol"]) or pe.get("volume", 0)
            ce_delta = ce.get("greeks", {}).get("delta", 0)
            pe_delta = abs(pe.get("greeks", {}).get("delta", 0))
            
            parity = (ce_ltp - pe_ltp) / (ce_ltp + pe_ltp)
            inof = (ce_vol * ce_delta) - (pe_vol * pe_delta)
            ce_mom = ce_ltp - ce_vwap
            pe_mom = pe_ltp - pe_vwap
            
            details.append({
                "strike": strike,
                "ce_ltp": ce_ltp,
                "ce_vwap": ce_vwap,
                "pe_ltp": pe_ltp,
                "pe_vwap": pe_vwap,
                "parity": parity,
                "inof": inof,
                "ce_mom": ce_mom,
                "pe_mom": pe_mom
            })
    return details
# ============================================================
# DASHBOARD
# ============================================================
class TerminalDashboard:
    def __init__(self, data_logger, session_state):
        self.data_logger = data_logger
        self.session_state = session_state

    def display(self):
        try:
            os.system('cls' if os.name == 'nt' else 'clear')
            df = self.data_logger.read_data(limit=1)
            print("\n" + "="*120)
            print("📊 LIVE TRADING DASHBOARD")
            print("="*120)
            print(f"Last Update: {timestamp_ist()}")
            print(f"📈 DAILY ORDER COUNT: {self.session_state.daily_executed_orders}/{Config.MAX_DAILY_ORDERS}")
            
            # Warmup status
            window_size = len(self.session_state.inof_window)
            if not self.session_state.window_filled:
                print(f"⏳ WARMING UP: {window_size}/{Config.ROLLING_WINDOW_SIZE} samples (need 15 min of 1-sec data)")
            else:
                print(f"✅ WINDOW FULL: {window_size} samples")
            
            print("\n" + "-"*80)
            print("📈 CURRENT SIGNAL VALUES")
            print("-"*80)
            
            if not df.empty:
                latest = df.iloc[-1]
                print(f"   Nifty LTP: {latest['underlying_ltp']}")
                print(f"   Signal: {latest['signal']}")
                print(f"   Position: {self.session_state.position}")
                print(f"   ATM Strike: {latest['atm_strike']}")
                print(f"   Raw inof: {latest['inof']:.2f}")
                print(f"   Raw VWAP Composite: {latest['vwap_composite']:.2f}")
                print(f"   Cumulative inof (EMA): {latest['cumul_inof']:.2f}")
                print(f"   Cumulative VWAP Composite (EMA): {latest['cumul_vwap_composite']:.2f}")
                # Show standard deviations if available
                # if 'std_inof' in latest and latest['std_inof'] > 0:
                print(f"\n📊 VOLATILITY STATS (15-min rolling):")
                print(f"   Std Dev of raw inof: {latest['std_inof']:.2f}")
                print(f"   Std Dev of raw composite: {latest['std_composite']:.2f}")
            else:
                print("   Waiting for first data point...")
            
            # Per‑strike details (live)
            strike_details = get_strike_details(self.session_state)
            if strike_details:
                print("\n" + "-"*80)
                print("🔍 PER‑STRIKE DETAILS (Live from WebSocket)")
                print("-"*80)
                # Header
                print(f"{'Strike':>8} | {'CE LTP':>8} | {'CE VWAP':>8} | {'PE LTP':>8} | {'PE VWAP':>8} | {'Parity':>10} | {'Inof':>15} | {'CE Mom':>8} | {'PE Mom':>8}")
                print("-"*80)
                for d in strike_details:
                    print(f"{d['strike']:8} | {d['ce_ltp']:8.2f} | {d['ce_vwap']:8.2f} | {d['pe_ltp']:8.2f} | {d['pe_vwap']:8.2f} | {d['parity']:10.2f} | {d['inof']:15.0f} | {d['ce_mom']:8.2f} | {d['pe_mom']:8.2f}")
            
            # Position‑specific info
            pos = self.session_state.position
            
            if pos == "LONG":
                if self.session_state.window_filled and 'std_inof' in latest and latest['std_inof'] > 0:
                    thresh = self.session_state.peak_cumul_inof - (2 * latest['std_inof'])
                    print(f"\n📈 LONG POSITION ACTIVE")
                    print(f"   Peak cumul_inof: {self.session_state.peak_cumul_inof:.2f}")
                    print(f"   2σ Exit threshold: {thresh:.2f} (cumul_inof below this exits)")
                else:
                    # fallback to fixed percentage
                    thresh = self.session_state.peak_cumul_inof * (1 - Config.TRAIL_STOP_PCT)
                    print(f"\n📈 LONG POSITION ACTIVE (fallback fixed %)")
                    print(f"   Peak cumul_inof: {self.session_state.peak_cumul_inof:.2f}")
                    print(f"   Exit threshold: {thresh:.2f}")
            elif pos == "SHORT":
                if self.session_state.window_filled and 'std_inof' in latest and latest['std_inof'] > 0:
                    thresh = self.session_state.trough_cumul_inof + (2 * latest['std_inof'])
                    print(f"\n📉 SHORT POSITION ACTIVE")
                    print(f"   Trough cumul_inof: {self.session_state.trough_cumul_inof:.2f}")
                    print(f"   2σ Exit threshold: {thresh:.2f} (cumul_inof above this exits)")
                else:
                    thresh = self.session_state.trough_cumul_inof * (1 - Config.TRAIL_STOP_PCT)
                    print(f"\n📉 SHORT POSITION ACTIVE (fallback fixed %)")
                    print(f"   Trough cumul_inof: {self.session_state.trough_cumul_inof:.2f}")
                    print(f"   Exit threshold: {thresh:.2f}")
            elif self.session_state.window_filled:
                print(f"\n💤 FLAT - Ready for entry")
            else:
                print(f"\n💤 FLAT - Warming up")
            
            print("\n" + "="*120)
        except Exception as e:
            log_debug(f"Dashboard error: {e}")
# ============================================================
# SESSION STATE
# ============================================================
class SessionState:
    def __init__(self):
        self.lock = threading.RLock()
        self.option_chain_api_count = 0
        self.quote_api_count = 0
        self.api_window_start = now_ist()
        self.cid = ""
        self.token = ""
        self._hb_lock = False
        self.daily_executed_orders = 0
        self.last_order_sync = None
        self.position = "FLAT"
        self.peak_cumul_inof = 0.0
        self.trough_cumul_inof = 0.0
        self.prev_cumul_composite = 0.0
        self.prev_cumul_inof = 0.0
        self.idwp_window = deque(maxlen=Config.ROLLING_WINDOW_SIZE)
        self.inof_window = deque(maxlen=Config.ROLLING_WINDOW_SIZE)
        self.composite_window = deque(maxlen=Config.ROLLING_WINDOW_SIZE)
        self.window_filled = False
        self.live_ltp = {}
        self.live_vwap = {}
        self.live_volume = {}
        self.option_chain = []
        self.fut_price = None
        self.expiry_date = None
        self.atm_strike = None
        self.option_symbols = []
        self.running = False

    def update_ws(self, symbol, ltp, vwap, volume):
        with self.lock:
            if ltp is not None:
                self.live_ltp[symbol] = float(ltp)
            if vwap is not None:
                self.live_vwap[symbol] = float(vwap)
            if volume is not None:
                self.live_volume[symbol] = int(volume)
            # No console print; log to file only
            log_debug(f"Updated {symbol}: LTP={ltp}, VWAP={vwap}, VOL={volume}")

    def get_ltp(self, symbol):
        with self.lock:
            return self.live_ltp.get(symbol)

    def get_vwap(self, symbol):
        with self.lock:
            return self.live_vwap.get(symbol)

    def get_volume(self, symbol):
        with self.lock:
            return self.live_volume.get(symbol)

    def update_chain(self, chain, fut_price, expiry_date, atm_strike, option_symbols):
        with self.lock:
            self.option_chain = chain
            self.fut_price = float(fut_price) if fut_price else 0.0
            self.expiry_date = expiry_date
            self.atm_strike = int(atm_strike) if atm_strike else None
            self.option_symbols = option_symbols
            log_debug(f"Chain updated: ATM={self.atm_strike}, fut={self.fut_price}, {len(option_symbols)} symbols")

    def sync_order_count(self, fyers):
        today = now_ist().date()
        if self.last_order_sync != today:
            self.daily_executed_orders = 0
            self.last_order_sync = today
        try:
            resp = fyers.orderbook()
            if resp.get("s") == "ok":
                self.daily_executed_orders = len([o for o in resp.get("orderBook", []) if o.get("status") == 2])
        except Exception as e:
            log_debug(f"Order sync failed: {e}")

    def can_place_order(self, fyers=None):
        if fyers:
            self.sync_order_count(fyers)
        return self.daily_executed_orders < Config.MAX_DAILY_ORDERS

# ============================================================
# MARKET WEBSOCKET MANAGER
# ============================================================
class MarketWSManager:
    def __init__(self, session_state, access_token):
        self.session = session_state
        self.access_token = access_token
        self.ws = None
        self.subscribed = set()
        self.running = False

    def on_message(self, message):
        symbol = message.get("symbol")
        if symbol:
            ltp = message.get("ltp")
            vwap = message.get("avg_trade_price")
            volume = message.get("vol_traded_today")
            self.session.update_ws(symbol, ltp, vwap, volume)

    def on_error(self, msg):
        log_console(f"WS error: {msg}")

    def on_close(self, msg):
        log_console(f"WS closed: {msg}")
        self.running = False

    def on_open(self):
        log_console("WebSocket connected")
        if self.subscribed:
            log_debug(f"Subscribing to {len(self.subscribed)} symbols")
            self.ws.subscribe(list(self.subscribed), "SymbolUpdate")
        self.ws.keep_running()

    def start(self):
        if self.running:
            return
        self.running = True
        self.ws = data_ws.FyersDataSocket(
            access_token=self.access_token,
            log_path="",
            litemode=False,
            write_to_file=False,
            reconnect=True,
            on_connect=self.on_open,
            on_close=self.on_close,
            on_error=self.on_error,
            on_message=self.on_message
        )
        self.ws.connect()
        log_debug("WebSocket started")

    def subscribe(self, symbols):
        new_symbols = set(symbols) - self.subscribed
        if new_symbols:
            log_debug(f"Subscribing to new symbols: {new_symbols}")
            if self.ws:
                self.ws.subscribe(list(new_symbols), "SymbolUpdate")
            self.subscribed.update(new_symbols)

    def stop(self):
        self.running = False
        if self.ws:
            self.ws.close_connection()

# ============================================================
# REST API HELPERS
# ============================================================
def enforce_rate_limit(session):
    now = now_ist()
    window = (now - session.api_window_start).total_seconds()
    total = session.option_chain_api_count + session.quote_api_count
    if window > Config.API_WINDOW:
        session.api_window_start = now
        session.option_chain_api_count = 0
        session.quote_api_count = 0
    elif total >= Config.API_RATE_LIMIT:
        wait = Config.API_WINDOW - window
        if wait > 0:
            time.sleep(wait)
        session.api_window_start = now
        session.option_chain_api_count = 0
        session.quote_api_count = 0

@handle_errors
def fetch_option_chain(session, index_symbol):
    log_debug("Enter fetch_option_chain")
    enforce_rate_limit(session)
    session.option_chain_api_count += 1
    fy = fyersModel.FyersModel(client_id=session.cid, token=session.token, is_async=False, log_path="")
    meta = fy.optionchain(data={"symbol": index_symbol, "timestamp": ""})
    if meta.get("code") != 200:
        log_debug(f"Meta chain failed: {meta}")
        return None, None, None, None, []
    fut_price = None
    for item in meta["data"]["optionsChain"]:
        if item.get("option_type") == "":
            fut_price = item.get("fp")
            break
    if fut_price is None:
        fut_price = meta["data"].get("fp", 0.0)
    exp_list = sorted([(e["date"], e["expiry"]) for e in meta["data"]["expiryData"]],
                      key=lambda x: datetime.strptime(x[0], "%d-%m-%Y"))
    today = now_ist().date()
    idx = 0
    for i, (d_str, _) in enumerate(exp_list):
        if datetime.strptime(d_str, "%d-%m-%Y").date() >= today:
            idx = i
            break
    curr_date, expiry_ts = exp_list[idx]
    payload = {"symbol": index_symbol, "strikecount": 5, "timestamp": expiry_ts, "greeks": "1"}
    resp = fy.optionchain(data=payload)
    if resp.get("code") != 200:
        log_debug(f"Detailed chain failed: {resp}")
        return None, None, None, None, []
    chain = resp["data"]["optionsChain"]
    option_symbols = [opt["symbol"] for opt in chain if opt.get("option_type") in ("CE","PE")]
    log_debug(f"Got {len(chain)} options, {len(option_symbols)} symbols")
    return chain, fut_price, curr_date, expiry_ts, option_symbols

# ============================================================
# CHAIN POLLER THREAD
# ============================================================
def chain_poller(session, ws_manager, index_symbol):
    log_debug("Chain poller thread started")
    while session.running:
        try:
            log_debug("Polling option chain...")
            chain, fut_price, expiry_date, _, opt_symbols = fetch_option_chain(session, index_symbol)
            if chain is None:
                log_debug("Chain fetch returned None")
            else:
                underlying_ltp = session.get_ltp(index_symbol)
                if underlying_ltp is None:
                    underlying_ltp = fut_price
                strikes = sorted(set(opt["strike_price"] for opt in chain if opt.get("option_type") in ("CE","PE")))
                if strikes and underlying_ltp:
                    atm = min(strikes, key=lambda x: abs(x - underlying_ltp))
                else:
                    atm = None
                session.update_chain(chain, fut_price, expiry_date, atm, opt_symbols)
                all_syms = [index_symbol] + opt_symbols
                ws_manager.subscribe(all_syms)
            time.sleep(Config.OPTION_CHAIN_INTERVAL)
        except Exception as e:
            log_debug(f"Chain poller error: {e}\n{traceback.format_exc()}")
            time.sleep(Config.OPTION_CHAIN_INTERVAL)

# ============================================================
# SIGNAL COMPUTATION (no console prints inside)
# ============================================================
def compute_signal(session):
    try:
        with session.lock:
            if not session.option_chain or session.atm_strike is None:
                return "HOLD", {}
            underlying_ltp = session.get_ltp("NSE:NIFTY50-INDEX")
            if underlying_ltp is None:
                return "HOLD", {}

            strikes = sorted(set(opt["strike_price"] for opt in session.option_chain if opt.get("option_type") in ("CE","PE")))
            if not strikes or session.atm_strike not in strikes:
                return "HOLD", {}
            idx = strikes.index(session.atm_strike)
            selected = [session.atm_strike]
            if idx > 0: selected.append(strikes[idx-1])
            if idx < len(strikes)-1: selected.append(strikes[idx+1])

            idwps, inofs, ce_moms, pe_moms = [], [], [], []
            for strike in selected:
                ce = next((o for o in session.option_chain if o["strike_price"] == strike and o["option_type"] == "CE"), None)
                pe = next((o for o in session.option_chain if o["strike_price"] == strike and o["option_type"] == "PE"), None)
                if not ce or not pe:
                    continue
                ce_ltp = session.get_ltp(ce["symbol"]) or ce.get("ltp", 0)
                pe_ltp = session.get_ltp(pe["symbol"]) or pe.get("ltp", 0)
                ce_vwap = session.get_vwap(ce["symbol"]) or ce_ltp
                pe_vwap = session.get_vwap(pe["symbol"]) or pe_ltp
                ce_vol = session.get_volume(ce["symbol"]) or ce.get("volume", 0)
                pe_vol = session.get_volume(pe["symbol"]) or pe.get("volume", 0)
                ce_delta = ce.get("greeks", {}).get("delta", 0)
                pe_delta = abs(pe.get("greeks", {}).get("delta", 0))
                parity = (ce_ltp - pe_ltp) / (ce_ltp + pe_ltp)
                inof = (ce_vol * ce_delta) - (pe_vol * pe_delta)
                ce_mom = ce_ltp - ce_vwap
                pe_mom = pe_ltp - pe_vwap
                idwps.append(parity)
                inofs.append(inof)
                ce_moms.append(ce_mom)
                pe_moms.append(pe_mom)

            if not idwps:
                return "HOLD", {}

            idwp = sum(idwps)/len(idwps)
            inof = sum(inofs)/len(inofs)
            composite = (sum(ce_moms)/len(ce_moms)) - (sum(pe_moms)/len(pe_moms))

            session.idwp_window.append(idwp)
            session.inof_window.append(inof)
            session.composite_window.append(composite)

            if not session.window_filled:
                if len(session.inof_window) < Config.ROLLING_WINDOW_SIZE:
                    metrics = {"spot": underlying_ltp, "atm_strike": session.atm_strike, "idwp": idwp, "inof": inof,
                               "cumul_idwp": 0.0, "cumul_inof": 0.0, "vwap_composite": composite, "cumul_vwap": 0.0,
                               "std_inof": 0.0, "std_composite": 0.0}
                    return "HOLD", metrics
                else:
                    session.window_filled = True
                    log_console("✓ 15-minute window filled – strategy active")

            # --- Compute EMAs (cumulative values) ---
            alpha = 2 / (Config.ROLLING_WINDOW_SIZE + 1)
            comp_list = list(session.composite_window)
            ema_comp = comp_list[0]
            for v in comp_list[1:]:
                ema_comp = alpha * v + (1-alpha) * ema_comp
            cumul_composite = ema_comp

            idwp_list = list(session.idwp_window)
            ema_idwp = idwp_list[0]
            for v in idwp_list[1:]:
                ema_idwp = alpha * v + (1-alpha) * ema_idwp
            cumul_idwp = ema_idwp

            inof_list = list(session.inof_window)
            ema_inof = inof_list[0]
            for v in inof_list[1:]:
                ema_inof = alpha * v + (1-alpha) * ema_inof
            cumul_inof = ema_inof

            # --- Compute rolling standard deviation of raw values (only when window filled) ---
            if session.window_filled and len(session.inof_window) > 1:
                raw_inof = list(session.inof_window)
                std_inof = np.std(raw_inof)
                raw_composite = list(session.composite_window)
                std_composite = np.std(raw_composite)
            else:
                std_inof = 0.0
                std_composite = 0.0

            # Update peak/trough for cumulative values
            if session.position == "LONG":
                if cumul_inof > session.peak_cumul_inof:
                    session.peak_cumul_inof = cumul_inof
            elif session.position == "SHORT":
                if cumul_inof < session.trough_cumul_inof:
                    session.trough_cumul_inof = cumul_inof

            # --- Exit logic (2-sigma threshold) ---
            signal = "HOLD"
            intended = session.position

            if session.position == "LONG":
                # 2-sigma drop from peak
                if session.window_filled and std_inof > 0:
                    drop = session.peak_cumul_inof - cumul_inof
                    if drop > (2 * std_inof):
                        signal = "EXIT"
                        intended = "FLAT"
                else:
                    # Fallback to fixed percentage if std not available
                    thresh = session.peak_cumul_inof * (1 - Config.TRAIL_STOP_PCT)
                    if cumul_inof < thresh:
                        signal = "EXIT"
                        intended = "FLAT"

            elif session.position == "SHORT":
                if session.window_filled and std_inof > 0:
                    rise = cumul_inof - session.trough_cumul_inof
                    if rise > (2 * std_inof):
                        signal = "EXIT"
                        intended = "FLAT"
                else:
                    thresh = session.trough_cumul_inof * (1 - Config.TRAIL_STOP_PCT)
                    if cumul_inof > thresh:
                        signal = "EXIT"
                        intended = "FLAT"

            # --- Entry logic (unchanged) ---
            if session.position == "FLAT" and signal != "EXIT":
                prev_both_pos = (session.prev_cumul_composite > 0 and session.prev_cumul_inof > 0)
                prev_both_neg = (session.prev_cumul_composite < 0 and session.prev_cumul_inof < 0)
                curr_both_pos = (cumul_composite > 0 and cumul_inof > 0)
                curr_both_neg = (cumul_composite < 0 and cumul_inof < 0)
                if curr_both_pos and not prev_both_pos:
                    signal = "BUY"
                    intended = "LONG"
                elif curr_both_neg and not prev_both_neg:
                    signal = "SELL"
                    intended = "SHORT"

            session.prev_cumul_composite = cumul_composite
            session.prev_cumul_inof = cumul_inof

            metrics = {
                "spot": underlying_ltp, "atm_strike": session.atm_strike, "idwp": idwp, "inof": inof,
                "cumul_idwp": cumul_idwp, "cumul_inof": cumul_inof,
                "vwap_composite": composite, "cumul_vwap": cumul_composite,
                "std_inof": std_inof, "std_composite": std_composite,
                "intended": intended
            }
            return signal, metrics
    except Exception as e:
        log_debug(f"CRASH in compute_signal: {e}\n{traceback.format_exc()}")
        return "HOLD", {}
# ============================================================
# ORDER PLACEMENT
# ============================================================
def place_order(session, signal, atm_ce, atm_pe, fyers, entry_metrics=None):
    if getattr(session, '_hb_lock', False):
        return False
    session._hb_lock = True
    try:
        if signal == "EXIT":
            log_console("🟡 EXIT signal – closing positions")
            fyers.exit_positions(data={"segment": [11], "side": [-1], "productType": ["MARGIN"]})
            fyers.exit_positions(data={"segment": [11], "side": [1], "productType": ["MARGIN"]})
            time.sleep(2)
            session.position = "FLAT"
            session.peak_cumul_inof = 0.0
            session.trough_cumul_inof = 0.0
            log_console("✓ Positions closed")
            return True
        if signal in ("BUY","SELL") and session.can_place_order(fyers):
            leg = atm_ce if signal == "BUY" else atm_pe
            if not leg:
                return False
            order = {
                "symbol": leg["symbol"],
                "qty": Config.LOT_SIZE,
                "type": 2,
                "side": 1,
                "productType": "MARGIN",
                "validity": "DAY",
            }
            side = "LONG" if signal == "BUY" else "SHORT"
            log_console(f"🟢 {signal} signal – placing {side} order")
            resp = fyers.place_order(data=order)
            if resp.get("s") == "ok":
                if signal == "BUY":
                    session.position = "LONG"
                    if entry_metrics:
                        session.peak_cumul_inof = entry_metrics.get("cumul_inof", 0.0)
                else:
                    session.position = "SHORT"
                    if entry_metrics:
                        session.trough_cumul_inof = entry_metrics.get("cumul_inof", 0.0)
                log_console(f"✓ {side} order placed successfully")
                return True
        return False
    except Exception as e:
        log_console(f"Order error: {e}")
        return False
    finally:
        session._hb_lock = False

# ============================================================
# SAMPLER THREAD (no console prints inside)
# ============================================================
last_signal_logged = None

def sampler(session, data_logger, auto_trade, fyers):
    global last_signal_logged
    log_debug("Sampler thread started")
    while session.running:
        start = now_ist()
        try:
            signal, metrics = compute_signal(session)
            if metrics:
                data_logger.log_data(
                    timestamp=timestamp_ist(),
                    underlying_ltp=metrics.get("spot", 0),
                    fut_price=session.fut_price or 0,
                    signal=signal,
                    atm_strike=metrics.get("atm_strike", 0),
                    expiry_date=session.expiry_date or "",
                    idwp=metrics.get("idwp", 0),
                    inof=metrics.get("inof", 0),
                    cumul_idwp=metrics.get("cumul_idwp", 0),
                    cumul_inof=metrics.get("cumul_inof", 0),
                    vwap_composite=metrics.get("vwap_composite", 0),
                    cumul_vwap_composite=metrics.get("cumul_vwap", 0),
                    position=session.position,
                    std_inof=metrics.get("std_inof", 0.0),
                    std_composite=metrics.get("std_composite", 0.0)
                )
                # Log signal change to console only when it changes
                if signal != last_signal_logged and signal != "HOLD":
                    log_console(f"📢 Signal changed to: {signal}")
                    last_signal_logged = signal

            if auto_trade and signal in ("BUY","SELL","EXIT"):
                atm_ce = atm_pe = None
                if session.atm_strike:
                    for opt in session.option_chain:
                        if opt["strike_price"] == session.atm_strike:
                            if opt["option_type"] == "CE":
                                atm_ce = {"symbol": opt["symbol"]}
                            elif opt["option_type"] == "PE":
                                atm_pe = {"symbol": opt["symbol"]}
                if signal == "EXIT":
                    place_order(session, signal, None, None, fyers, None)
                elif signal == "BUY" and atm_ce:
                    place_order(session, signal, atm_ce, None, fyers, metrics)
                elif signal == "SELL" and atm_pe:
                    place_order(session, signal, None, atm_pe, fyers, metrics)
            elapsed = (now_ist() - start).total_seconds()
            if elapsed < Config.SAMPLE_INTERVAL:
                time.sleep(Config.SAMPLE_INTERVAL - elapsed)
        except Exception as e:
            log_debug(f"Sampler error: {e}\n{traceback.format_exc()}")
            time.sleep(1)

# ============================================================
# CREDENTIALS
# ============================================================
def load_credentials(session):
    try:
        with open('fyers_credentials.json', 'r') as f:
            creds = json.load(f)
            session.cid = creds.get('client_id', '')
            session.token = creds.get('access_token', '')
        log_console(f"Loaded credentials: {session.cid}")
    except Exception as e:
        session.cid = os.getenv("FYERS_CID", "")
        session.token = os.getenv("FYERS_TOKEN", "")
        log_console(f"Using env vars: {session.cid}")

# ============================================================
# MAIN
# ============================================================
def main():
    log_console("Starting Algo Trading System...")
    session = SessionState()
    load_credentials(session)
    data_logger = DataLogger()
    dashboard = TerminalDashboard(data_logger, session)
    index_symbol = "NSE:NIFTY50-INDEX"

    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        print("="*50)
        print("📈 FYERS ALGO TRADING (WebSocket + 1s sampling)")
        print("1. Start Live Trading")
        print("2. Settings")
        print("3. Exit")
        choice = input("Select option: ").strip()
        if choice == "1":
            if not (session.cid and session.token):
                print("❌ Set credentials first")
                input("Press Enter...")
                continue
            auto_trade = input("Enable Auto Trade? (y/n): ").lower() == 'y'
            log_console(f"Auto trade: {'ON' if auto_trade else 'OFF'}")
            ws_manager = MarketWSManager(session, session.token)
            ws_manager.start()
            ws_manager.subscribe([index_symbol])
            session.running = True
            threading.Thread(target=chain_poller, args=(session, ws_manager, index_symbol), daemon=True).start()
            fyers = fyersModel.FyersModel(client_id=session.cid, token=session.token, is_async=False, log_path="")
            threading.Thread(target=sampler, args=(session, data_logger, auto_trade, fyers), daemon=True).start()
            print("\n✅ Live trading started. Press Ctrl+C to stop.\n")
            try:
                while True:
                    dashboard.display()
                    time.sleep(2)
            except KeyboardInterrupt:
                session.running = False
                ws_manager.stop()
                log_console("\n🛑 Trading stopped by user")
        elif choice == "2":
            print("\n⚙️ SETTINGS")
            new_cid = input(f"Client ID [{session.cid}]: ").strip()
            if new_cid:
                session.cid = new_cid
            new_token = input("Access token: ").strip()
            if new_token:
                session.token = new_token
            with open('fyers_credentials.json', 'w') as f:
                json.dump({"client_id": session.cid, "access_token": session.token}, f)
            print("✅ Saved")
            input("Press Enter...")
        elif choice == "3":
            break

if __name__ == "__main__":
    main()