import os
import csv
import json
import time
import logging
import threading
import traceback
from datetime import datetime
from collections import deque

import pytz
from fyers_apiv3 import fyersModel
from fyers_apiv3.FyersWebsocket import data_ws


# ============================================================
# CONFIG
# ============================================================

class Config:

    # --------------------------------------------------------
    # Fyers
    # --------------------------------------------------------

    INDEX_SYMBOL = "NSE:NIFTY50-INDEX"

    # --------------------------------------------------------
    # Option chain
    # --------------------------------------------------------

    OPTION_CHAIN_INTERVAL = 30

    CHAIN_STRIKE_BUFFER = 3

    # --------------------------------------------------------
    # Flow
    # --------------------------------------------------------

    FLOW_WINDOW_SECONDS = 300
    FLOW_WARMUP_SECONDS = 300

    FLOW_IMBALANCE_THRESHOLD = 0.20

    # --------------------------------------------------------
    # Dashboard
    # --------------------------------------------------------

    DASHBOARD_INTERVAL = 1

    # --------------------------------------------------------
    # WebSocket reliability
    # --------------------------------------------------------

    # How often watchdog runs
    WATCHDOG_INTERVAL = 15

    # A subscribed symbol is considered stale if we haven't
    # received ANY SymbolUpdate for this many seconds.
    #
    # IMPORTANT:
    # This is based on WebSocket data arrival, NOT accepted
    # trades. Therefore an option does NOT need to trade for
    # its freshness timestamp to update.
    STALE_SYMBOL_SECONDS = 15

    # After resubscription, give the symbol this much time
    # to start producing updates again.
    RESUBSCRIBE_GRACE_SECONDS = 15

    # If absolutely no WebSocket activity is received for
    # this duration, consider the socket unhealthy.
    HEARTBEAT_TIMEOUT_SECONDS = 15

    # Minimum time between forced reconnects.
    RECONNECT_COOLDOWN_SECONDS = 15

    # --------------------------------------------------------
    # Files
    # --------------------------------------------------------

    TRADE_CSV = "flow_trades.csv"
    SNAPSHOT_CSV = "flow_monitor.csv"
    LOG_FILE = "flow_monitor.log"

    # --------------------------------------------------------
    # Terminal
    # --------------------------------------------------------

    PRINT_EVERY_ACCEPTED_TRADE = True


# ============================================================
# IST
# ============================================================

IST = pytz.timezone("Asia/Kolkata")


def now_ist():
    return datetime.now(IST)


def epoch_to_ist(epoch):
    return datetime.fromtimestamp(
        int(epoch),
        tz=IST
    )


def ist_hms(dt=None):
    if dt is None:
        dt = now_ist()

    return dt.strftime("%H:%M:%S")


def ist_timestamp(dt=None):
    if dt is None:
        dt = now_ist()

    return dt.strftime(
        "%Y-%m-%d %H:%M:%S IST"
    )


# ============================================================
# LOGGING
# ============================================================

logging.basicConfig(
    filename=Config.LOG_FILE,
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)


def log_debug(message):
    logging.debug(message)


def log_info(message):
    logging.info(message)


def log_error(message):
    logging.error(message)


# ============================================================
# FLOW MONITOR
# ============================================================

class FlowMonitor:

    def __init__(self):

        self.lock = threading.RLock()

        # ----------------------------------------------------
        # Live market state
        # ----------------------------------------------------

        self.ltp = {}
        self.bid = {}
        self.ask = {}

        # IMPORTANT:
        # This is updated on EVERY SymbolUpdate.
        # It is NOT dependent on volume change or flow
        # classification.
        self.last_update_epoch = {}

        # ----------------------------------------------------
        # Cumulative exchange volume
        # ----------------------------------------------------

        self.previous_volume = {}

        # ----------------------------------------------------
        # Rolling flow
        # ----------------------------------------------------

        self.flow_history = {}
        self.buy_flow = {}
        self.sell_flow = {}

        # ----------------------------------------------------
        # Last accepted trade
        # ----------------------------------------------------

        self.last_trade = {}

        # ----------------------------------------------------
        # ATM tracking
        # ----------------------------------------------------

        self.current_atm = None
        self.current_reference_strikes = []

        self.strike_symbols = {}

        # ----------------------------------------------------
        # Underlying
        # ----------------------------------------------------

        self.nifty_ltp = None
        self.nifty_last_update_epoch = None

        # ----------------------------------------------------
        # Warm-up
        # ----------------------------------------------------

        self.flow_start_epoch = time.time()

        # ----------------------------------------------------
        # Counters
        # ----------------------------------------------------

        self.accepted_trade_count = 0
        self.time_rejected_count = 0
        self.price_rejected_count = 0
        self.invalid_message_count = 0

    # ========================================================
    # WARMUP
    # ========================================================

    def warmup_elapsed(self):

        with self.lock:
            return (
                time.time()
                - self.flow_start_epoch
            )

    def warmup_complete(self):

        return (
            self.warmup_elapsed()
            >= Config.FLOW_WARMUP_SECONDS
        )

    def warmup_remaining(self):

        return max(
            0.0,
            Config.FLOW_WARMUP_SECONDS
            - self.warmup_elapsed()
        )

    # ========================================================
    # ENSURE SYMBOL
    # ========================================================

    def _ensure_symbol(self, symbol):

        if symbol not in self.flow_history:

            self.flow_history[symbol] = deque()

            self.buy_flow[symbol] = 0
            self.sell_flow[symbol] = 0

    # ========================================================
    # PURGE OLD FLOW
    # ========================================================

    def _purge_old_flow(
        self,
        symbol,
        now_epoch
    ):

        self._ensure_symbol(symbol)

        cutoff = (
            now_epoch
            - Config.FLOW_WINDOW_SECONDS
        )

        history = self.flow_history[symbol]

        while history:

            old_epoch, side_code, qty = history[0]

            if old_epoch >= cutoff:
                break

            history.popleft()

            if side_code == 1:
                self.buy_flow[symbol] -= qty
            else:
                self.sell_flow[symbol] -= qty

    # ========================================================
    # ADD FLOW
    # ========================================================

    def _add_flow(
        self,
        symbol,
        side_code,
        qty,
        trade_epoch
    ):

        now_epoch = time.time()

        self._ensure_symbol(symbol)

        self._purge_old_flow(
            symbol,
            now_epoch
        )

        self.flow_history[symbol].append(
            (
                now_epoch,
                side_code,
                int(qty)
            )
        )

        if side_code == 1:
            self.buy_flow[symbol] += int(qty)
        else:
            self.sell_flow[symbol] += int(qty)

        self.last_trade[symbol] = {

            "side":
                "BUY"
                if side_code == 1
                else "SELL",

            "qty":
                int(qty),

            "ltp":
                self.ltp.get(symbol),

            "bid":
                self.bid.get(symbol),

            "ask":
                self.ask.get(symbol),

            "trade_epoch":
                int(trade_epoch),

            "trade_time":
                epoch_to_ist(
                    trade_epoch
                ).strftime(
                    "%H:%M:%S"
                )
        }

    # ========================================================
    # PROCESS SYMBOL UPDATE
    # ========================================================

    def process_tick(
        self,
        symbol,
        ltp,
        bid_price,
        ask_price,
        cumulative_volume,
        last_traded_qty,
        last_traded_time
    ):

        """
        FLOW RULE:

        1. cumulative volume changes

        2. current IST HH:MM:SS ==
           last traded IST HH:MM:SS

        3. LTP == BID
             -> SELL

           LTP == ASK
             -> BUY

        4. Maintain rolling 5-minute flow.

        IMPORTANT:
        Freshness is updated BEFORE any flow filtering.
        """

        # ----------------------------------------------------
        # Basic validation
        # ----------------------------------------------------

        if (
            symbol is None
            or ltp is None
            or bid_price is None
            or ask_price is None
            or cumulative_volume is None
            or last_traded_qty is None
            or last_traded_time is None
        ):

            with self.lock:
                self.invalid_message_count += 1

            return

        try:

            current_volume = int(
                cumulative_volume
            )

            qty = int(
                last_traded_qty
            )

            trade_epoch = int(
                last_traded_time
            )

            ltp = float(ltp)

            bid_price = float(
                bid_price
            )

            ask_price = float(
                ask_price
            )

        except (
            TypeError,
            ValueError
        ):

            with self.lock:
                self.invalid_message_count += 1

            return

        # ----------------------------------------------------
        # SAVE QUOTE + FRESHNESS
        #
        # THIS HAPPENS EVEN IF THE UPDATE WILL LATER BE
        # REJECTED BY FLOW LOGIC.
        # ----------------------------------------------------

        with self.lock:

            self.ltp[symbol] = ltp

            self.bid[symbol] = bid_price

            self.ask[symbol] = ask_price

            self.last_update_epoch[symbol] = time.time()

        # ----------------------------------------------------
        # Ignore invalid LTQ after freshness update
        # ----------------------------------------------------

        if qty <= 0:
            return

        # ----------------------------------------------------
        # VOLUME CHANGE CHECK
        # ----------------------------------------------------

        with self.lock:

            previous = (
                self.previous_volume.get(
                    symbol
                )
            )

            # First message
            if previous is None:

                self.previous_volume[symbol] = (
                    current_volume
                )

                return

            # Volume reset
            if current_volume < previous:

                self.previous_volume[symbol] = (
                    current_volume
                )

                return

            # No new volume
            if current_volume == previous:
                return

            # Store new cumulative volume
            self.previous_volume[symbol] = (
                current_volume
            )

        # ----------------------------------------------------
        # TIME COMPARISON
        # ----------------------------------------------------

        current_ist = now_ist()

        trade_ist = epoch_to_ist(
            trade_epoch
        )

        current_hms = current_ist.strftime(
            "%H:%M:%S"
        )

        trade_hms = trade_ist.strftime(
            "%H:%M:%S"
        )

        if current_hms != trade_hms:

            with self.lock:
                self.time_rejected_count += 1

            log_debug(
                f"TIME REJECT | "
                f"{ist_timestamp(current_ist)} | "
                f"{symbol} | "
                f"TradeTime={trade_hms}"
            )

            return

        # ----------------------------------------------------
        # BID == ASK
        # ----------------------------------------------------

        if bid_price == ask_price:

            with self.lock:
                self.price_rejected_count += 1

            return

        # ----------------------------------------------------
        # CLASSIFY
        # ----------------------------------------------------

        if ltp == bid_price:

            side_code = -1
            side_text = "SELL"

        elif ltp == ask_price:

            side_code = 1
            side_text = "BUY"

        else:

            with self.lock:
                self.price_rejected_count += 1

            return

        # ----------------------------------------------------
        # ADD FLOW
        # ----------------------------------------------------

        with self.lock:

            self._add_flow(
                symbol=symbol,
                side_code=side_code,
                qty=qty,
                trade_epoch=trade_epoch
            )

            self.accepted_trade_count += 1

            current_buy = (
                self.buy_flow[symbol]
            )

            current_sell = (
                self.sell_flow[symbol]
            )

            event = {

                "trade_time_ist":
                    trade_ist.strftime(
                        "%Y-%m-%d %H:%M:%S IST"
                    ),

                "symbol":
                    symbol,

                "side":
                    side_text,

                "ltp":
                    ltp,

                "bid":
                    bid_price,

                "ask":
                    ask_price,

                "qty":
                    qty,

                "cumulative_volume":
                    current_volume
            }

        # ----------------------------------------------------
        # LOG
        # ----------------------------------------------------

        log_info(
            f"FLOW ACCEPTED | "
            f"{ist_timestamp(current_ist)} | "
            f"TradeTime={trade_hms} | "
            f"{symbol} | "
            f"{side_text} | "
            f"LTP={ltp} | "
            f"BID={bid_price} | "
            f"ASK={ask_price} | "
            f"LTQ={qty} | "
            f"CumVol={current_volume} | "
            f"5mBuy={current_buy} | "
            f"5mSell={current_sell}"
        )

        if Config.PRINT_EVERY_ACCEPTED_TRADE:

            print(
                f"TRADE | "
                f"{trade_hms} IST | "
                f"{symbol} | "
                f"{side_text:<4} | "
                f"LTP={ltp:.2f} | "
                f"BID={bid_price:.2f} | "
                f"ASK={ask_price:.2f} | "
                f"LTQ={qty:,}",
                flush=True
            )

        # ----------------------------------------------------
        # Return event so caller can write CSV
        # ----------------------------------------------------

        return event

    # ========================================================
    # GET FLOW
    # ========================================================

    def get_flow(self, symbol):

        if symbol is None:

            return {
                "buy": 0,
                "sell": 0,
                "net": 0,
                "total": 0,
                "imbalance": 0.0,
                "last_trade": None
            }

        with self.lock:

            self._ensure_symbol(symbol)

            self._purge_old_flow(
                symbol,
                time.time()
            )

            buy = self.buy_flow[symbol]

            sell = self.sell_flow[symbol]

            total = buy + sell

            net = buy - sell

            imbalance = (
                net / total
                if total > 0
                else 0.0
            )

            return {
                "buy": buy,
                "sell": sell,
                "net": net,
                "total": total,
                "imbalance": imbalance,
                "last_trade":
                    self.last_trade.get(
                        symbol
                    )
            }

    # ========================================================
    # GET SYMBOL AGE
    # ========================================================

    def get_symbol_age(self, symbol):

        if not symbol:
            return None

        with self.lock:

            last = (
                self.last_update_epoch.get(
                    symbol
                )
            )

        if last is None:
            return None

        return max(
            0.0,
            time.time() - last
        )

    # ========================================================
    # UPDATE ATM
    # ========================================================

    def update_atm(
        self,
        atm_strike,
        strike_symbols,
        reference_strikes
    ):

        with self.lock:

            old_atm = self.current_atm

            self.current_atm = (
                int(atm_strike)
                if atm_strike is not None
                else None
            )

            self.strike_symbols = (
                strike_symbols
            )

            self.current_reference_strikes = (
                list(reference_strikes)
            )

        if old_atm != self.current_atm:

            print(
                f"\nATM CHANGE | "
                f"{ist_timestamp()} | "
                f"Old ATM={old_atm} | "
                f"New ATM={self.current_atm} | "
                f"Tracked={reference_strikes}",
                flush=True
            )

            log_info(
                f"ATM CHANGE | "
                f"old={old_atm} | "
                f"new={self.current_atm} | "
                f"tracked={reference_strikes}"
            )

    # ========================================================
    # GET CURRENT CONTRACTS
    # ========================================================

    def get_current_contracts(self):

        with self.lock:

            result = []

            for strike in (
                self.current_reference_strikes
            ):

                symbols = (
                    self.strike_symbols.get(
                        strike,
                        {}
                    )
                )

                result.append(
                    (
                        strike,
                        symbols.get("CE"),
                        symbols.get("PE")
                    )
                )

            return result

    # ========================================================
    # GET NIFTY
    # ========================================================

    def update_nifty(self, ltp):

        if ltp is None:
            return

        with self.lock:

            self.nifty_ltp = float(
                ltp
            )

            self.nifty_last_update_epoch = (
                time.time()
            )

            # Also maintain generic freshness
            self.last_update_epoch[
                Config.INDEX_SYMBOL
            ] = time.time()

    # ========================================================
    # NIFTY AGE
    # ========================================================

    def get_nifty_age(self):

        with self.lock:

            last = (
                self.nifty_last_update_epoch
            )

        if last is None:
            return None

        return max(
            0.0,
            time.time() - last
        )

    # ========================================================
    # RESET
    # ========================================================

    def reset(self):

        with self.lock:

            self.ltp.clear()
            self.bid.clear()
            self.ask.clear()

            self.last_update_epoch.clear()

            self.previous_volume.clear()

            self.flow_history.clear()
            self.buy_flow.clear()
            self.sell_flow.clear()

            self.last_trade.clear()

            self.current_atm = None

            self.current_reference_strikes.clear()
            self.strike_symbols.clear()

            self.nifty_ltp = None
            self.nifty_last_update_epoch = None

            self.accepted_trade_count = 0
            self.time_rejected_count = 0
            self.price_rejected_count = 0
            self.invalid_message_count = 0

            self.flow_start_epoch = time.time()


# ============================================================
# CSV LOGGER
# ============================================================

class CSVLogger:

    def __init__(self):

        self.trade_file = Config.TRADE_CSV
        self.snapshot_file = Config.SNAPSHOT_CSV

        self.trade_lock = threading.Lock()
        self.snapshot_lock = threading.Lock()

        self._ensure_files()

    # ========================================================
    # CREATE FILES
    # ========================================================

    def _ensure_files(self):

        if (
            not os.path.exists(
                self.trade_file
            )
            or
            os.path.getsize(
                self.trade_file
            ) == 0
        ):

            with open(
                self.trade_file,
                "w",
                newline=""
            ) as f:

                writer = csv.writer(f)

                writer.writerow([
                    "logged_time_ist",
                    "trade_time_ist",
                    "symbol",
                    "side",
                    "ltp",
                    "bid",
                    "ask",
                    "last_traded_qty",
                    "vol_traded_today"
                ])

        if (
            not os.path.exists(
                self.snapshot_file
            )
            or
            os.path.getsize(
                self.snapshot_file
            ) == 0
        ):

            with open(
                self.snapshot_file,
                "w",
                newline=""
            ) as f:

                writer = csv.writer(f)

                writer.writerow([

                    "timestamp_ist",
                    "nifty_ltp",
                    "atm_strike",

                    "strike_1",
                    "strike_1_ce",
                    "strike_1_ce_buy_5m",
                    "strike_1_ce_sell_5m",
                    "strike_1_ce_net_5m",
                    "strike_1_ce_imbalance_5m",
                    "strike_1_pe",
                    "strike_1_pe_buy_5m",
                    "strike_1_pe_sell_5m",
                    "strike_1_pe_net_5m",
                    "strike_1_pe_imbalance_5m",

                    "strike_2",
                    "strike_2_ce",
                    "strike_2_ce_buy_5m",
                    "strike_2_ce_sell_5m",
                    "strike_2_ce_net_5m",
                    "strike_2_ce_imbalance_5m",
                    "strike_2_pe",
                    "strike_2_pe_buy_5m",
                    "strike_2_pe_sell_5m",
                    "strike_2_pe_net_5m",
                    "strike_2_pe_imbalance_5m",

                    "strike_3",
                    "strike_3_ce",
                    "strike_3_ce_buy_5m",
                    "strike_3_ce_sell_5m",
                    "strike_3_ce_net_5m",
                    "strike_3_ce_imbalance_5m",
                    "strike_3_pe",
                    "strike_3_pe_buy_5m",
                    "strike_3_pe_sell_5m",
                    "strike_3_pe_net_5m",
                    "strike_3_pe_imbalance_5m",

                    "warmup_complete",
                    "warmup_remaining_seconds",

                    "accepted_trade_count",
                    "time_rejected_count",
                    "price_rejected_count"
                ])

    # ========================================================
    # WRITE ACCEPTED TRADE
    # ========================================================

    def write_trade(self, event):

        if not event:
            return

        with self.trade_lock:

            with open(
                self.trade_file,
                "a",
                newline=""
            ) as f:

                writer = csv.writer(f)

                writer.writerow([

                    ist_timestamp(),

                    event["trade_time_ist"],

                    event["symbol"],

                    event["side"],

                    event["ltp"],

                    event["bid"],

                    event["ask"],

                    event["qty"],

                    event["cumulative_volume"]
                ])

    # ========================================================
    # WRITE SNAPSHOT
    # ========================================================

    def write_snapshot(
        self,
        monitor,
        contracts
    ):

        row = [

            ist_timestamp(),

            monitor.nifty_ltp,

            monitor.current_atm
        ]

        padded_contracts = (
            list(contracts)[:3]
        )

        while len(padded_contracts) < 3:

            padded_contracts.append(
                (
                    None,
                    None,
                    None
                )
            )

        for strike, ce, pe in (
            padded_contracts
        ):

            row.append(
                strike
                if strike is not None
                else ""
            )

            row.append(
                ce or ""
            )

            ce_flow = (
                monitor.get_flow(ce)
            )

            row.extend([
                ce_flow["buy"],
                ce_flow["sell"],
                ce_flow["net"],
                round(
                    ce_flow["imbalance"],
                    6
                )
            ])

            row.append(
                pe or ""
            )

            pe_flow = (
                monitor.get_flow(pe)
            )

            row.extend([
                pe_flow["buy"],
                pe_flow["sell"],
                pe_flow["net"],
                round(
                    pe_flow["imbalance"],
                    6
                )
            ])

        row.extend([

            monitor.warmup_complete(),

            round(
                monitor.warmup_remaining(),
                1
            ),

            monitor.accepted_trade_count,

            monitor.time_rejected_count,

            monitor.price_rejected_count
        ])

        with self.snapshot_lock:

            with open(
                self.snapshot_file,
                "a",
                newline=""
            ) as f:

                csv.writer(f).writerow(
                    row
                )


# ============================================================
# WEBSOCKET MANAGER
# ============================================================

class MarketWSManager:

    def __init__(
        self,
        monitor,
        access_token,
        csv_logger=None
    ):

        self.monitor = monitor

        self.access_token = (
            access_token
        )

        self.csv_logger = csv_logger

        self.ws = None
        self.ws_thread = None

        self.running = False

        # All symbols that should remain subscribed.
        self.subscribed = set()

        # ----------------------------------------------------
        # WebSocket health
        # ----------------------------------------------------

        self.last_ws_message_epoch = None

        self.ws_connected_epoch = None

        self.last_reconnect_epoch = 0

        # ----------------------------------------------------
        # Resubscription tracking
        #
        # symbol -> timestamp at which we resubscribed
        # ----------------------------------------------------

        self.resubscribe_pending = {}

        # ----------------------------------------------------
        # Locks
        # ----------------------------------------------------

        self.lock = threading.RLock()

        self.watchdog_thread = None

    # ========================================================
    # MESSAGE
    # ========================================================

    def on_message(self, message):

        # Any callback activity counts as WebSocket activity.
        with self.lock:
            self.last_ws_message_epoch = time.time()

        if not isinstance(
            message,
            dict
        ):
            return

        if message.get("type") != "sf":
            return

        symbol = message.get(
            "symbol"
        )

        if not symbol:
            return

        # ----------------------------------------------------
        # Every actual SymbolUpdate clears pending recovery
        # ----------------------------------------------------

        with self.lock:

            if symbol in self.resubscribe_pending:

                previous_resubscribe = (
                    self.resubscribe_pending.pop(
                        symbol
                    )
                )

                recovery_time = (
                    time.time()
                    - previous_resubscribe
                )

                print(
                    f"✅ DATA RECOVERED | "
                    f"{ist_timestamp()} | "
                    f"{symbol} | "
                    f"Recovery={recovery_time:.1f}s",
                    flush=True
                )

                log_info(
                    f"DATA RECOVERED | "
                    f"{symbol} | "
                    f"recovery={recovery_time:.1f}s"
                )

        # ----------------------------------------------------
        # Underlying
        # ----------------------------------------------------

        if (
            symbol
            == Config.INDEX_SYMBOL
        ):

            self.monitor.update_nifty(
                message.get("ltp")
            )

        # ----------------------------------------------------
        # Flow
        # ----------------------------------------------------

        event = (
            self.monitor.process_tick(
                symbol=symbol,

                ltp=message.get(
                    "ltp"
                ),

                bid_price=message.get(
                    "bid_price"
                ),

                ask_price=message.get(
                    "ask_price"
                ),

                cumulative_volume=message.get(
                    "vol_traded_today"
                ),

                last_traded_qty=message.get(
                    "last_traded_qty"
                ),

                last_traded_time=message.get(
                    "last_traded_time"
                )
            )
        )

        # ----------------------------------------------------
        # Write accepted trade immediately
        # ----------------------------------------------------

        if (
            event
            and
            self.csv_logger is not None
        ):

            try:

                self.csv_logger.write_trade(
                    event
                )

            except Exception as e:

                log_error(
                    f"Trade CSV error: {e}"
                )

    # ========================================================
    # ERROR
    # ========================================================

    def on_error(self, message):

        print(
            f"\n❌ WS ERROR: {message}",
            flush=True
        )

        log_error(
            f"WS ERROR: {message}"
        )

    # ========================================================
    # CLOSE
    # ========================================================

    def on_close(self, message):

        print(
            f"\n⚠️ WS CLOSED: "
            f"{message} | "
            f"{ist_timestamp()}",
            flush=True
        )

        log_info(
            f"WS CLOSED: {message}"
        )

    # ========================================================
    # OPEN
    # ========================================================

    def on_open(self):

        with self.lock:

            self.ws_connected_epoch = (
                time.time()
            )

            self.last_ws_message_epoch = (
                time.time()
            )

            # Anything pending from old socket is no longer
            # relevant because we are restoring everything.
            self.resubscribe_pending.clear()

        print(
            f"\n✅ WebSocket connected | "
            f"{ist_timestamp()}",
            flush=True
        )

        log_info(
            "WebSocket connected"
        )

        # ----------------------------------------------------
        # Restore ALL subscriptions
        # ----------------------------------------------------

        with self.lock:
            symbols = list(
                self.subscribed
            )

        if symbols:

            try:

                self.ws.subscribe(
                    symbols,
                    "SymbolUpdate"
                )

                print(
                    f"📡 Restored "
                    f"{len(symbols)} "
                    f"subscriptions",
                    flush=True
                )

                log_info(
                    f"Subscriptions restored: "
                    f"{sorted(symbols)}"
                )

            except Exception as e:

                print(
                    f"❌ Subscription restore failed: "
                    f"{e}",
                    flush=True
                )

                log_error(
                    traceback.format_exc()
                )

        # ----------------------------------------------------
        # Keep socket alive
        # ----------------------------------------------------

        self.ws.keep_running()

    # ========================================================
    # CONNECT
    # ========================================================

    def _connect(self):

        try:

            self.ws = (
                data_ws.FyersDataSocket(
                    access_token=
                        self.access_token,

                    log_path="",

                    litemode=False,

                    write_to_file=False,

                    reconnect=True,

                    on_connect=
                        self.on_open,

                    on_close=
                        self.on_close,

                    on_error=
                        self.on_error,

                    on_message=
                        self.on_message
                )
            )

            self.ws.connect()

        except Exception as e:

            print(
                f"❌ WebSocket crashed: {e}",
                flush=True
            )

            log_error(
                traceback.format_exc()
            )

    # ========================================================
    # START
    # ========================================================

    def start(self):

        if self.running:
            return

        self.running = True

        self.ws_thread = threading.Thread(
            target=self._connect,
            daemon=True,
            name="FyersWS"
        )

        self.ws_thread.start()

        # ----------------------------------------------------
        # Start watchdog
        # ----------------------------------------------------

        self.watchdog_thread = threading.Thread(
            target=self._watchdog_loop,
            daemon=True,
            name="WSWatchdog"
        )

        self.watchdog_thread.start()

    # ========================================================
    # SUBSCRIBE
    # ========================================================

    def subscribe(self, symbols):

        clean = [
            symbol
            for symbol in symbols
            if symbol
        ]

        if not clean:
            return

        new_symbols = (
            set(clean)
            - self.subscribed
        )

        if not new_symbols:
            return

        with self.lock:

            self.subscribed.update(
                new_symbols
            )

        # ----------------------------------------------------
        # Socket not connected yet
        # ----------------------------------------------------

        if not self.ws:

            log_info(
                f"Queued subscription: "
                f"{sorted(new_symbols)}"
            )

            return

        # ----------------------------------------------------
        # Subscribe immediately
        # ----------------------------------------------------

        try:

            self.ws.subscribe(
                list(new_symbols),
                "SymbolUpdate"
            )

            print(
                f"📡 Subscribed "
                f"{len(new_symbols)} new symbols",
                flush=True
            )

            log_info(
                f"Subscribed: "
                f"{sorted(new_symbols)}"
            )

        except Exception as e:

            print(
                f"⚠️ Subscribe failed: {e}",
                flush=True
            )

            log_error(
                traceback.format_exc()
            )

    # ========================================================
    # UNSUBSCRIBE
    # ========================================================

    def _unsubscribe(self, symbols):

        clean = [
            symbol
            for symbol in symbols
            if symbol
        ]

        if not clean:
            return False

        if not self.ws:
            return False

        try:

            self.ws.unsubscribe(
                clean,
                "SymbolUpdate"
            )

            log_info(
                f"Unsubscribed: "
                f"{sorted(clean)}"
            )

            return True

        except Exception as e:

            print(
                f"⚠️ Unsubscribe failed: "
                f"{e}",
                flush=True
            )

            log_error(
                traceback.format_exc()
            )

            return False

    # ========================================================
    # RESUBSCRIBE SYMBOL
    # ========================================================

    def _resubscribe_symbol(self, symbol):

        with self.lock:

            # Prevent repeated resubscription every watchdog
            # cycle while we're waiting for recovery.
            if symbol in self.resubscribe_pending:

                pending_since = (
                    self.resubscribe_pending[
                        symbol
                    ]
                )

                if (
                    time.time()
                    - pending_since
                    <
                    Config.RESUBSCRIBE_GRACE_SECONDS
                ):

                    return False

        print(
            f"\n🔄 STALE DATA | "
            f"{ist_timestamp()} | "
            f"{symbol} | "
            f"Resubscribing...",
            flush=True
        )

        log_info(
            f"STALE DATA | "
            f"{symbol} | "
            f"resubscribing"
        )

        # ----------------------------------------------------
        # Unsubscribe
        # ----------------------------------------------------

        self._unsubscribe(
            [symbol]
        )

        # ----------------------------------------------------
        # Small delay before subscribe
        # ----------------------------------------------------

        time.sleep(0.2)

        # ----------------------------------------------------
        # Subscribe again
        # ----------------------------------------------------

        try:

            if not self.ws:
                return False

            self.ws.subscribe(
                [symbol],
                "SymbolUpdate"
            )

            with self.lock:

                self.resubscribe_pending[
                    symbol
                ] = time.time()

            print(
                f"📡 RESUBSCRIBED | "
                f"{ist_timestamp()} | "
                f"{symbol} | "
                f"Waiting for data...",
                flush=True
            )

            log_info(
                f"RESUBSCRIBED | {symbol}"
            )

            return True

        except Exception as e:

            print(
                f"❌ Resubscribe failed | "
                f"{symbol} | "
                f"{e}",
                flush=True
            )

            log_error(
                traceback.format_exc()
            )

            return False

    # ========================================================
    # FORCE RECONNECT
    # ========================================================

    def _force_reconnect(self, reason):

        now = time.time()

        with self.lock:

            if (
                now
                - self.last_reconnect_epoch
                <
                Config.RECONNECT_COOLDOWN_SECONDS
            ):

                return

            self.last_reconnect_epoch = now

        print(
            f"\n🔴 FORCING WS RECONNECT | "
            f"{ist_timestamp()} | "
            f"Reason={reason}",
            flush=True
        )

        log_error(
            f"FORCING WS RECONNECT | "
            f"reason={reason}"
        )

        # ----------------------------------------------------
        # Close current connection.
        #
        # Fyers SDK has reconnect=True.
        # on_open() will restore subscriptions.
        # ----------------------------------------------------

        try:

            if self.ws:

                self.ws.close_connection()

        except Exception as e:

            log_error(
                f"WS close during reconnect: "
                f"{e}"
            )

    # ========================================================
    # WATCHDOG
    # ========================================================

    def _watchdog_loop(self):

        print(
            f"🛡️ WebSocket watchdog started | "
            f"{ist_timestamp()}",
            flush=True
        )

        log_info(
            "WebSocket watchdog started"
        )

        while self.running:

            try:

                time.sleep(
                    Config.WATCHDOG_INTERVAL
                )

                if not self.running:
                    break

                now = time.time()

                # =================================================
                # 1. SOCKET HEARTBEAT
                # =================================================

                with self.lock:

                    last_message = (
                        self.last_ws_message_epoch
                    )

                    connected_since = (
                        self.ws_connected_epoch
                    )

                # If connected but no callback activity
                if (
                    connected_since is not None
                    and
                    last_message is not None
                    and
                    now - last_message
                    >
                    Config.HEARTBEAT_TIMEOUT_SECONDS
                ):

                    self._force_reconnect(
                        reason=(
                            "No WebSocket "
                            f"activity for "
                            f"{now - last_message:.1f}s"
                        )
                    )

                    continue

                # =================================================
                # 2. SYMBOL FRESHNESS
                # =================================================

                with self.lock:

                    subscribed_symbols = list(
                        self.subscribed
                    )

                    pending = set(
                        self.resubscribe_pending.keys()
                    )

                stale_symbols = []

                for symbol in subscribed_symbols:

                    last_update = (
                        self.monitor.last_update_epoch.get(
                            symbol
                        )
                    )

                    # No update ever received.
                    #
                    # If socket has been connected for
                    # longer than stale threshold, this is
                    # also considered suspicious.
                    if last_update is None:

                        if (
                            connected_since is not None
                            and
                            now - connected_since
                            >
                            Config.STALE_SYMBOL_SECONDS
                        ):

                            stale_symbols.append(
                                (
                                    symbol,
                                    None
                                )
                            )

                        continue

                    age = (
                        now - last_update
                    )

                    if (
                        age
                        >
                        Config.STALE_SYMBOL_SECONDS
                    ):

                        stale_symbols.append(
                            (
                                symbol,
                                age
                            )
                        )

                # =================================================
                # 3. RESUBSCRIBE STALE SYMBOLS
                # =================================================

                for symbol, age in stale_symbols:

                    if symbol in pending:

                        # Already resubscribed.
                        #
                        # Check whether grace period has
                        # expired.
                        with self.lock:

                            pending_since = (
                                self.resubscribe_pending.get(
                                    symbol
                                )
                            )

                        if (
                            pending_since is not None
                            and
                            now - pending_since
                            >
                            Config.RESUBSCRIBE_GRACE_SECONDS
                        ):

                            print(
                                f"\n❌ DATA STILL STALE | "
                                f"{ist_timestamp()} | "
                                f"{symbol} | "
                                f"After resubscribe "
                                f"grace period",
                                flush=True
                            )

                            log_error(
                                f"DATA STILL STALE | "
                                f"{symbol} | "
                                f"after resubscribe"
                            )

                            self._force_reconnect(
                                reason=(
                                    f"{symbol} "
                                    "still stale after "
                                    "resubscribe"
                                )
                            )

                        continue

                    self._resubscribe_symbol(
                        symbol
                    )

            except Exception as e:

                print(
                    f"⚠️ Watchdog error: "
                    f"{e}",
                    flush=True
                )

                log_error(
                    f"Watchdog error: {e}\n"
                    f"{traceback.format_exc()}"
                )

    # ========================================================
    # GET HEALTH
    # ========================================================

    def get_health(self):

        now = time.time()

        with self.lock:

            connected_since = (
                self.ws_connected_epoch
            )

            last_message = (
                self.last_ws_message_epoch
            )

            subscribed_count = len(
                self.subscribed
            )

            pending_count = len(
                self.resubscribe_pending
            )

        heartbeat_age = None

        if last_message is not None:

            heartbeat_age = max(
                0.0,
                now - last_message
            )

        stale_symbols = []

        with self.lock:

            symbols = list(
                self.subscribed
            )

        for symbol in symbols:

            age = (
                self.monitor.get_symbol_age(
                    symbol
                )
            )

            if (
                age is not None
                and
                age > Config.STALE_SYMBOL_SECONDS
            ):

                stale_symbols.append(
                    (
                        symbol,
                        age
                    )
                )

        return {
            "connected":
                connected_since is not None,

            "heartbeat_age":
                heartbeat_age,

            "subscribed_count":
                subscribed_count,

            "pending_resubscribe_count":
                pending_count,

            "stale_symbols":
                stale_symbols
        }

    # ========================================================
    # STOP
    # ========================================================

    def stop(self):

        self.running = False

        print(
            f"🛑 Stopping WS watchdog..."
        )

        try:

            if self.ws:

                self.ws.close_connection()

        except Exception:
            pass

        if (
            self.ws_thread
            and
            self.ws_thread.is_alive()
        ):

            self.ws_thread.join(
                timeout=3
            )

        if (
            self.watchdog_thread
            and
            self.watchdog_thread.is_alive()
        ):

            self.watchdog_thread.join(
                timeout=3
            )


# ============================================================
# OPTION CHAIN MANAGER
# ============================================================

class OptionChainManager:

    def __init__(
        self,
        monitor,
        ws_manager,
        client_id,
        access_token
    ):

        self.monitor = monitor

        self.ws_manager = (
            ws_manager
        )

        self.client_id = client_id

        self.access_token = (
            access_token
        )

        self.running = False

        self.thread = None

    # ========================================================
    # FETCH CHAIN
    # ========================================================

    def fetch_chain(self):

        fyers = (
            fyersModel.FyersModel(
                client_id=
                    self.client_id,

                token=
                    self.access_token,

                is_async=False,

                log_path=""
            )
        )

        response = fyers.optionchain(
            data={
                "symbol":
                    Config.INDEX_SYMBOL,

                "strikecount":
                    Config.CHAIN_STRIKE_BUFFER,

                "timestamp":
                    ""
            }
        )

        if response.get("code") != 200:

            raise RuntimeError(
                f"Option chain API failed: "
                f"{response}"
            )

        chain = (
            response
            .get("data", {})
            .get("optionsChain", [])
        )

        if not chain:

            raise RuntimeError(
                "Empty option chain"
            )

        return chain

    # ========================================================
    # DETERMINE ATM
    # ========================================================

    def determine_atm(self, chain):

        spot = (
            self.monitor.nifty_ltp
        )

        if spot is None:

            for item in chain:

                if (
                    item.get(
                        "option_type"
                    )
                    == ""
                ):

                    fp = item.get(
                        "fp"
                    )

                    if fp is not None:

                        spot = float(fp)

                        break

        if spot is None:
            return None

        strikes = sorted({

            int(
                item["strike_price"]
            )

            for item in chain

            if (
                item.get(
                    "option_type"
                )
                in (
                    "CE",
                    "PE"
                )
            )

            and
            item.get(
                "strike_price"
            ) is not None
        })

        if not strikes:
            return None

        atm = min(
            strikes,
            key=lambda x:
                abs(
                    x - spot
                )
        )

        return atm, strikes

    # ========================================================
    # UPDATE ATM MAP
    # ========================================================

    def update(self):

        chain = self.fetch_chain()

        result = self.determine_atm(
            chain
        )

        if result is None:

            raise RuntimeError(
                "Could not determine ATM"
            )

        atm, strikes = result

        atm_index = strikes.index(
            atm
        )

        # ----------------------------------------------------
        # Adjacent strikes
        # ----------------------------------------------------

        reference_strikes = []

        if atm_index > 0:

            reference_strikes.append(
                strikes[
                    atm_index - 1
                ]
            )

        reference_strikes.append(
            atm
        )

        if (
            atm_index
            < len(strikes) - 1
        ):

            reference_strikes.append(
                strikes[
                    atm_index + 1
                ]
            )

        # ----------------------------------------------------
        # Build symbol map
        # ----------------------------------------------------

        strike_symbols = {}

        for item in chain:

            strike = item.get(
                "strike_price"
            )

            option_type = item.get(
                "option_type"
            )

            symbol = item.get(
                "symbol"
            )

            if (
                strike is None
                or option_type
                not in (
                    "CE",
                    "PE"
                )
                or not symbol
            ):

                continue

            strike = int(strike)

            if (
                strike
                not in strike_symbols
            ):

                strike_symbols[
                    strike
                ] = {
                    "CE": None,
                    "PE": None
                }

            strike_symbols[
                strike
            ][
                option_type
            ] = symbol

        # ----------------------------------------------------
        # Subscribe entire returned chain
        # ----------------------------------------------------

        option_symbols = [

            item.get("symbol")

            for item in chain

            if (
                item.get(
                    "option_type"
                )
                in (
                    "CE",
                    "PE"
                )
            )

            and item.get("symbol")
        ]

        self.ws_manager.subscribe(
            option_symbols
        )

        # Underlying always subscribed
        self.ws_manager.subscribe(
            [
                Config.INDEX_SYMBOL
            ]
        )

        # ----------------------------------------------------
        # Save ATM state
        # ----------------------------------------------------

        self.monitor.update_atm(

            atm_strike=atm,

            strike_symbols=
                strike_symbols,

            reference_strikes=
                reference_strikes
        )

    # ========================================================
    # LOOP
    # ========================================================

    def _run(self):

        while self.running:

            try:

                self.update()

            except Exception as e:

                print(
                    f"\n⚠️ Chain error: "
                    f"{e}",
                    flush=True
                )

                log_error(
                    f"Chain error: {e}\n"
                    f"{traceback.format_exc()}"
                )

            end = (
                time.time()
                + Config.OPTION_CHAIN_INTERVAL
            )

            while (
                self.running
                and
                time.time() < end
            ):

                time.sleep(
                    0.5
                )

    # ========================================================
    # START
    # ========================================================

    def start(self):

        if self.running:
            return

        self.running = True

        self.thread = threading.Thread(
            target=self._run,
            daemon=True,
            name="OptionChain"
        )

        self.thread.start()

    # ========================================================
    # STOP
    # ========================================================

    def stop(self):

        self.running = False

        if (
            self.thread
            and
            self.thread.is_alive()
        ):

            self.thread.join(
                timeout=3
            )


# ============================================================
# DASHBOARD
# ============================================================

class Dashboard:

    def __init__(
        self,
        monitor,
        csv_logger,
        ws_manager
    ):

        self.monitor = monitor
        self.csv = csv_logger
        self.ws_manager = ws_manager

        self.last_snapshot_epoch = 0

    # ========================================================
    # FLOW SIGNAL
    # ========================================================

    def calculate_signal(
        self,
        ce_flow,
        pe_flow
    ):

        # ----------------------------------------------------
        # NEVER generate signal during warmup
        # ----------------------------------------------------

        if not self.monitor.warmup_complete():

            return "WARMING UP"

        ce_imb = (
            ce_flow["imbalance"]
        )

        pe_imb = (
            pe_flow["imbalance"]
        )

        # ----------------------------------------------------
        # BUY CE
        # ----------------------------------------------------

        if (
            ce_imb
            >= Config.FLOW_IMBALANCE_THRESHOLD
            and
            pe_imb >= 0
        ):

            return "BUY CE FLOW"

        # ----------------------------------------------------
        # BUY PE
        # ----------------------------------------------------

        if (
            pe_imb
            <= -Config.FLOW_IMBALANCE_THRESHOLD
            and
            ce_imb <= 0
        ):

            return "BUY PE FLOW"

        return "NEUTRAL"

    # ========================================================
    # FLOW TEXT
    # ========================================================

    @staticmethod
    def flow_text(flow):

        return (

            f"B={flow['buy']:,} | "
            f"S={flow['sell']:,} | "
            f"N={flow['net']:+,} | "
            f"I={flow['imbalance']:+.3f}"
        )

    # ========================================================
    # DISPLAY
    # ========================================================

    def display(self):

        contracts = (
            self.monitor.get_current_contracts()
        )

        nifty = (
            self.monitor.nifty_ltp
        )

        warmup_complete = (
            self.monitor.warmup_complete()
        )

        warmup_remaining = (
            self.monitor.warmup_remaining()
        )

        health = (
            self.ws_manager.get_health()
        )

        os.system(
            "cls"
            if os.name == "nt"
            else "clear"
        )

        print(
            "\n"
            + "=" * 125
        )

        print(
            "🌊 FYERS EXECUTED FLOW MONITOR"
        )

        print(
            "=" * 125
        )

        # ----------------------------------------------------
        # HEADER
        # ----------------------------------------------------

        if nifty is not None:

            print(
                f"Time: {ist_timestamp()} | "
                f"NIFTY: {nifty:.2f}"
            )

        else:

            print(
                f"Time: {ist_timestamp()} | "
                f"NIFTY: N/A"
            )

        print(
            f"ATM: {self.monitor.current_atm}"
            if self.monitor.current_atm is not None
            else "ATM: N/A"
        )

        # ----------------------------------------------------
        # WEBSOCKET HEALTH
        # ----------------------------------------------------

        print(
            "-" * 125
        )

        if health["connected"]:

            heartbeat_age = (
                health["heartbeat_age"]
            )

            if heartbeat_age is None:

                heartbeat_text = "N/A"

            else:

                heartbeat_text = (
                    f"{heartbeat_age:.1f}s"
                )

            if health["stale_symbols"]:

                ws_status = (
                    "⚠️ STALE DATA"
                )

            else:

                ws_status = (
                    "✅ HEALTHY"
                )

            print(
                f"WS STATUS: {ws_status} | "
                f"Last message: {heartbeat_text} ago | "
                f"Subscriptions: "
                f"{health['subscribed_count']} | "
                f"Pending recovery: "
                f"{health['pending_resubscribe_count']}"
            )

        else:

            print(
                "WS STATUS: 🔴 NOT CONNECTED"
            )

        # ----------------------------------------------------
        # Stale symbols
        # ----------------------------------------------------

        if health["stale_symbols"]:

            stale_text = []

            for symbol, age in (
                health["stale_symbols"]
            ):

                stale_text.append(
                    f"{symbol}="
                    f"{age:.0f}s"
                )

            print(
                "STALE: "
                + ", ".join(
                    stale_text
                )
            )

        # ----------------------------------------------------
        # Warm-up
        # ----------------------------------------------------

        print(
            "-" * 125
        )

        if warmup_complete:

            print(
                "FLOW STATUS: "
                "✅ 5-MINUTE WARM-UP COMPLETE"
            )

            print(
                "SIGNAL STATUS: "
                "✅ ENABLED"
            )

        else:

            elapsed = (
                Config.FLOW_WARMUP_SECONDS
                - warmup_remaining
            )

            print(
                f"FLOW STATUS: ⏳ WARMING UP "
                f"| {elapsed:.0f}/"
                f"{Config.FLOW_WARMUP_SECONDS}s"
            )

            print(
                f"SIGNAL STATUS: 🔒 DISABLED "
                f"| {warmup_remaining:.0f}s remaining"
            )

        print(
            "-" * 125
        )

        # ----------------------------------------------------
        # TABLE
        # ----------------------------------------------------

        print(
            "STRIKE".ljust(15)
            +
            "CE SYMBOL".ljust(32)
            +
            "CE 5M FLOW".ljust(35)
            +
            "PE SYMBOL".ljust(32)
            +
            "PE 5M FLOW"
        )

        print(
            "-" * 125
        )

        # ----------------------------------------------------
        # Three tracked strikes
        # ----------------------------------------------------

        for (
            index,
            (
                strike,
                ce_symbol,
                pe_symbol
            )
        ) in enumerate(
            contracts
        ):

            if (
                self.monitor.current_atm
                is not None
            ):

                if (
                    strike
                    <
                    self.monitor.current_atm
                ):

                    label = (
                        f"{strike} ATM-1"
                    )

                elif (
                    strike
                    ==
                    self.monitor.current_atm
                ):

                    label = (
                        f"{strike} ATM"
                    )

                else:

                    label = (
                        f"{strike} ATM+1"
                    )

            else:

                label = str(
                    strike
                )

            ce_flow = (
                self.monitor.get_flow(
                    ce_symbol
                )
            )

            pe_flow = (
                self.monitor.get_flow(
                    pe_symbol
                )
            )

            print(
                label.ljust(15)
                +
                str(
                    ce_symbol
                    or "N/A"
                ).ljust(32)
                +
                self.flow_text(
                    ce_flow
                ).ljust(35)
                +
                str(
                    pe_symbol
                    or "N/A"
                ).ljust(32)
                +
                self.flow_text(
                    pe_flow
                )
            )

        print(
            "-" * 125
        )

        # ----------------------------------------------------
        # ATM SIGNAL
        # ----------------------------------------------------

        atm_ce = None
        atm_pe = None

        if (
            self.monitor.current_atm
            is not None
        ):

            atm_symbols = (
                self.monitor.strike_symbols.get(
                    self.monitor.current_atm,
                    {}
                )
            )

            atm_ce = (
                atm_symbols.get(
                    "CE"
                )
            )

            atm_pe = (
                atm_symbols.get(
                    "PE"
                )
            )

        atm_ce_flow = (
            self.monitor.get_flow(
                atm_ce
            )
        )

        atm_pe_flow = (
            self.monitor.get_flow(
                atm_pe
            )
        )

        signal = (
            self.calculate_signal(
                atm_ce_flow,
                atm_pe_flow
            )
        )

        print(
            f"CURRENT ATM SIGNAL: "
            f"{signal}"
        )

        print(
            f"ATM CE imbalance: "
            f"{atm_ce_flow['imbalance']:+.3f}"
        )

        print(
            f"ATM PE imbalance: "
            f"{atm_pe_flow['imbalance']:+.3f}"
        )

        # ----------------------------------------------------
        # LAST ACCEPTED TRADES
        # ----------------------------------------------------

        print(
            "\n"
            + "-" * 125
        )

        print(
            "LAST ACCEPTED TRADES"
        )

        print(
            "-" * 125
        )

        printed_trade = False

        for strike, ce, pe in contracts:

            for symbol in (
                ce,
                pe
            ):

                if not symbol:
                    continue

                flow = (
                    self.monitor.get_flow(
                        symbol
                    )
                )

                trade = (
                    flow["last_trade"]
                )

                if trade:

                    printed_trade = True

                    print(
                        f"{symbol} | "
                        f"{trade['trade_time']} IST | "
                        f"{trade['side']} | "
                        f"LTP={trade['ltp']:.2f} | "
                        f"BID={trade['bid']:.2f} | "
                        f"ASK={trade['ask']:.2f} | "
                        f"LTQ={trade['qty']:,}"
                    )

        if not printed_trade:

            print(
                "No accepted trades yet."
            )

        # ----------------------------------------------------
        # DIAGNOSTICS
        # ----------------------------------------------------

        print(
            "\n"
            + "-" * 125
        )

        print(
            "DIAGNOSTICS"
        )

        print(
            "-" * 125
        )

        print(
            f"Accepted trades: "
            f"{self.monitor.accepted_trade_count:,} | "
            f"Time rejected: "
            f"{self.monitor.time_rejected_count:,} | "
            f"Price rejected: "
            f"{self.monitor.price_rejected_count:,} | "
            f"Invalid messages: "
            f"{self.monitor.invalid_message_count:,}"
        )

        print(
            "-" * 125
        )

        print(
            "B = buy-side executions | "
            "S = sell-side executions | "
            "N = B-S | "
            "I = (B-S)/(B+S)"
        )

        print(
            "LTP = BID -> SELL | "
            "LTP = ASK -> BUY"
        )

        print(
            "=" * 125
        )

        # ----------------------------------------------------
        # SNAPSHOT
        # ----------------------------------------------------

        try:

            self.csv.write_snapshot(
                self.monitor,
                contracts
            )

        except Exception as e:

            log_error(
                f"Snapshot write error: {e}"
            )


# ============================================================
# CREDENTIALS
# ============================================================

def load_credentials():

    try:

        with open(
            "fyers_credentials.json",
            "r"
        ) as f:

            creds = json.load(f)

        client_id = (
            creds.get(
                "client_id",
                ""
            )
        )

        access_token = (
            creds.get(
                "access_token",
                ""
            )
        )

        return (
            client_id,
            access_token
        )

    except Exception as e:

        print(
            f"⚠️ Could not load "
            f"fyers_credentials.json: {e}"
        )

        return (
            os.getenv(
                "FYERS_CID",
                ""
            ),

            os.getenv(
                "FYERS_TOKEN",
                ""
            )
        )


# ============================================================
# MAIN
# ============================================================

def main():

    print(
        "\n"
        + "=" * 80
    )

    print(
        "🌊 FYERS EXECUTED FLOW EXPERIMENT"
    )

    print(
        "=" * 80
    )

    print(
        "Flow logic:"
    )

    print(
        "  New cumulative volume"
    )

    print(
        "       +"
    )

    print(
        "  Current IST HH:MM:SS == "
        "Last Traded IST HH:MM:SS"
    )

    print(
        "       +"
    )

    print(
        "  LTP == BID  -> SELL += LTQ"
    )

    print(
        "  LTP == ASK  -> BUY += LTQ"
    )

    print(
        "=" * 80
    )

    print(
        "Tracking: ATM-1 / ATM / ATM+1"
    )

    print(
        "Rolling window: 5 minutes"
    )

    print(
        "Warm-up: 5 minutes"
    )

    print(
        f"Stale threshold: "
        f"{Config.STALE_SYMBOL_SECONDS}s"
    )

    print(
        f"Heartbeat timeout: "
        f"{Config.HEARTBEAT_TIMEOUT_SECONDS}s"
    )

    print(
        "=" * 80
    )

    # --------------------------------------------------------
    # Credentials
    # --------------------------------------------------------

    client_id, access_token = (
        load_credentials()
    )

    if (
        not client_id
        or not access_token
    ):

        print(
            "\n❌ Missing Fyers credentials."
        )

        print(
            "Set them in fyers_credentials.json "
            "or FYERS_CID / FYERS_TOKEN."
        )

        return

    # --------------------------------------------------------
    # Components
    # --------------------------------------------------------

    monitor = FlowMonitor()

    csv_logger = CSVLogger()

    ws_manager = MarketWSManager(
        monitor=monitor,
        access_token=access_token,
        csv_logger=csv_logger
    )

    chain_manager = (
        OptionChainManager(
            monitor=monitor,
            ws_manager=ws_manager,
            client_id=client_id,
            access_token=access_token
        )
    )

    dashboard = Dashboard(
        monitor=monitor,
        csv_logger=csv_logger,
        ws_manager=ws_manager
    )

    # --------------------------------------------------------
    # Start WebSocket
    # --------------------------------------------------------

    ws_manager.start()

    # Queue underlying subscription immediately.
    # If socket isn't connected yet, it will be restored
    # automatically from self.subscribed in on_open().
    ws_manager.subscribe(
        [
            Config.INDEX_SYMBOL
        ]
    )

    # --------------------------------------------------------
    # Start option-chain manager
    # --------------------------------------------------------

    chain_manager.start()

    # --------------------------------------------------------
    # Main loop
    # --------------------------------------------------------

    try:

        while True:

            dashboard.display()

            time.sleep(
                Config.DASHBOARD_INTERVAL
            )

    except KeyboardInterrupt:

        print(
            "\n\n🛑 Stopping..."
        )

    except Exception as e:

        print(
            f"\n❌ Main loop error: {e}"
        )

        log_error(
            traceback.format_exc()
        )

    finally:

        print(
            "Stopping option-chain manager..."
        )

        chain_manager.stop()

        print(
            "Stopping WebSocket..."
        )

        ws_manager.stop()

        print(
            "✅ Flow monitor stopped."
        )


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":

    main()