"""
Fyers Algo Trading - Live Auto Trade
Optimized version with improved performance and structure
"""

import time
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import pytz
from fyers_apiv3 import fyersModel
import logging
import os
import json
from typing import Dict, List, Any, Optional, Tuple
import matplotlib.pyplot as plt
import csv
from functools import wraps

# ============================================================================
# CONFIGURATION
# ============================================================================

class Config:
    """Centralized configuration"""
    # Trading parameters
    LOT_SIZE = 40
    MAX_DAILY_ORDERS = 8
    STRIKE_GAP = 100
    
    # Timing parameters
    REFRESH_INTERVAL = 15  # seconds
    COOLDOWN_MINUTES = 5
    
    # API parameters
    API_RATE_LIMIT = 200
    API_WINDOW = 60  # seconds
    MAX_RETRIES = 3
    RETRY_DELAY = 2  # seconds
    
    # Signal parameters
    MAX_HISTORY = 2
    ROLLING_WINDOW = 30
    EXIT_ON_SIDEWAYS = True
    STRADDLE_MULTIPLIER = 0.5
    
    # Order verification
    ORDER_VERIFY_DELAY = 2
    FLATTEN_TIMEOUT = 60
    FLATTEN_POLL_INTERVAL = 2

    


# ============================================================================
# LOGGING SETUP
# ============================================================================

logging.basicConfig(
    filename="trading_app.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)


# ============================================================================
# DECORATORS
# ============================================================================

def handle_errors(func):
    """Error handling decorator with retry logic"""
    @wraps(func)
    def wrapper(*args, **kwargs):
        for attempt in range(1, Config.MAX_RETRIES + 1):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                logging.error(f"Error in {func.__name__} (attempt {attempt}/{Config.MAX_RETRIES}): {e}", exc_info=True)
                if attempt < Config.MAX_RETRIES:
                    time.sleep(Config.RETRY_DELAY)
                else:
                    print(f"❌ {func.__name__} failed after {Config.MAX_RETRIES} attempts: {e}")
                    return None
    return wrapper


# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def get_next_aligned_time(interval_seconds: int) -> datetime:
    """Get next time aligned to the interval"""
    now = datetime.now()
    midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
    current_seconds = (now - midnight).total_seconds()
    intervals_passed = current_seconds // interval_seconds
    next_aligned_seconds = (intervals_passed + 1) * interval_seconds
    return midnight + timedelta(seconds=next_aligned_seconds)


def wait_until_next_interval(interval_seconds: int):
    """Wait until next aligned interval"""
    next_time = get_next_aligned_time(interval_seconds)
    wait_seconds = (next_time - datetime.now()).total_seconds()
    
    if wait_seconds > 0:
        print(f"⏳ Next update at {next_time.strftime('%H:%M:%S')} (waiting {wait_seconds:.1f}s)")
        time.sleep(wait_seconds)


def clear_screen():
    """Clear terminal screen"""
    os.system('cls' if os.name == 'nt' else 'clear')


def get_user_input(prompt: str, default=None, input_type=str):
    """Get user input with optional default value"""
    try:
        display_default = f" [{default}]" if default is not None else ""
        user_input = input(f"{prompt}{display_default}: ").strip()
        
        if user_input == "" and default is not None:
            return default
        
        return input_type(user_input) if user_input else input_type()
    except (ValueError, TypeError):
        print("❌ Invalid input. Please try again.")
        return get_user_input(prompt, default, input_type)


# ============================================================================
# SESSION STATE
# ============================================================================

class SessionState:
    """Manages session state and API tracking"""
    
    def __init__(self):
        # API tracking
        self.option_chain_api_count = 0
        self.quote_api_count = 0
        self.api_window_start = datetime.now()
        
        # Credentials
        self.cid = ""
        self.token = ""
        
        # Trading state
        self.last_signal = None
        self.last_signal_order_ids = []
        self.live_last_signal = None
        self.live_last_signal_order_ids = []
        self.signal_history = []
        self._hb_lock = False
        
        # Timing
        self.last_trade_time = None
        self.last_order_sync = None
        
        # Daily tracking
        self.daily_executed_orders = 0
        
        # Market data
        self.opening_straddle = None
        self.opening_date = None
        self.day_open = None
        
        # Misc
        self.trade_tracker = {}
        self.cooldown_warned = False
    
    def get(self, key: str, default=None):
        """Dictionary-like get method"""
        return getattr(self, key, default)
    
    def sync_order_count_with_fyers(self, fyers):
        """Sync daily order count with Fyers orderbook"""
        today = datetime.now().date()
        
        # Reset on new day
        if self.last_order_sync != today:
            print(f"📅 [DEBUG] New trading day - resetting order counter")
            self.daily_executed_orders = 0
            self.last_order_sync = today
        
        # Fetch from Fyers
        current_count = get_daily_executed_order_count(fyers)
        self.daily_executed_orders = current_count
        
        print(f"📊 [DEBUG] Order count synced: {self.daily_executed_orders}/{Config.MAX_DAILY_ORDERS}")
    
    def can_place_order(self, fyers=None) -> bool:
        """Check if more orders can be placed today"""
        if fyers:
            self.sync_order_count_with_fyers(fyers)
        
        if self.daily_executed_orders >= Config.MAX_DAILY_ORDERS:
            print(f"⛔ [DEBUG] Daily order limit ({Config.MAX_DAILY_ORDERS}) reached")
            return False
        
        remaining = Config.MAX_DAILY_ORDERS - self.daily_executed_orders
        print(f"✅ [DEBUG] Orders remaining today: {remaining}")
        return True


# ============================================================================
# CREDENTIALS MANAGEMENT
# ============================================================================

def load_credentials(session_state: SessionState):
    """Load credentials from JSON file or environment variables"""
    try:
        with open('fyers_credentials.json', 'r') as f:
            creds = json.load(f)
            session_state.cid = creds.get('client_id', '')
            session_state.token = creds.get('access_token', '')
            print("✅ Credentials loaded from JSON file")
            return
    except FileNotFoundError:
        print("⚠️ JSON file not found, checking environment variables")
    except Exception as e:
        print(f"❌ Error loading credentials: {e}")
    
    # Fallback to environment variables
    session_state.cid = os.getenv("FYERS_CID", session_state.cid)
    session_state.token = os.getenv("FYERS_TOKEN", session_state.token)


# ============================================================================
# API RATE LIMITING
# ============================================================================

def enforce_rate_limit(session_state: SessionState):
    """Enforce API rate limits"""
    now = datetime.now()
    window = now - session_state.api_window_start
    total_calls = session_state.option_chain_api_count + session_state.quote_api_count
    
    if window.total_seconds() > Config.API_WINDOW:
        # Reset window
        session_state.api_window_start = now
        session_state.option_chain_api_count = 0
        session_state.quote_api_count = 0
    elif total_calls >= Config.API_RATE_LIMIT:
        # Wait and reset
        wait = Config.API_WINDOW - int(window.total_seconds())
        if wait > 0:
            logging.warning(f"Rate limit reached, waiting {wait}s")
            print(f"⚠️ Rate limit reached, waiting {wait}s")
            time.sleep(wait)
        session_state.api_window_start = datetime.now()
        session_state.option_chain_api_count = 0
        session_state.quote_api_count = 0


# ============================================================================
# FYERS API CALLS
# ============================================================================

@handle_errors
def get_option_chain_data(session_state: SessionState, cid: str, token: str, 
                          sym: str, expiry_ts: str = "") -> Optional[List]:
    """Fetch option chain data"""
    print(f"🔍 [DEBUG] Fetching option chain for {sym}, expiry: {expiry_ts or 'nearest'}")
    enforce_rate_limit(session_state)
    session_state.option_chain_api_count += 1
    
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    resp = fy.optionchain(data={"symbol": sym, "timestamp": expiry_ts})
    
    if not resp or resp.get("code") != 200:
        error_msg = f"Option chain error: {resp.get('message', 'Unknown') if isinstance(resp, dict) else resp}"
        logging.error(error_msg)
        print(f"❌ {error_msg}")
        return None
    
    print("✅ [DEBUG] Option chain data fetched")
    return resp["data"]["optionsChain"]


@handle_errors
def get_underlying_ltp(session_state: SessionState, cid: str, token: str, sym: str) -> Optional[float]:
    """Fetch underlying LTP"""
    print(f"🔍 [DEBUG] Fetching underlying LTP for {sym}")
    enforce_rate_limit(session_state)
    session_state.quote_api_count += 1
    
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    resp = fy.quotes(data={"symbols": sym})
    
    if not resp or resp.get("code") != 200 or not resp.get("d"):
        error_msg = f"Quotes API error: {resp.get('message', 'Unknown') if isinstance(resp, dict) else resp}"
        logging.error(error_msg)
        print(f"❌ {error_msg}")
        return None
    
    ltp = resp["d"][0]["v"]["lp"]
    print(f"✅ [DEBUG] Underlying LTP: {ltp}")
    return ltp


@handle_errors
def get_symbol_ltp(session_state: SessionState, cid: str, token: str, symbol: str) -> Optional[float]:
    """Fetch symbol LTP"""
    print(f"🔍 [DEBUG] Fetching LTP for {symbol}")
    enforce_rate_limit(session_state)
    session_state.quote_api_count += 1
    
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    resp = fy.quotes(data={"symbols": symbol})
    
    if not resp or resp.get("code") != 200 or not resp.get("d"):
        error_msg = f"Quotes API error for {symbol}: {resp.get('message', 'Unknown') if isinstance(resp, dict) else resp}"
        logging.error(error_msg)
        print(f"❌ {error_msg}")
        return None
    
    ltp = resp["d"][0]["v"]["lp"]
    print(f"✅ [DEBUG] Symbol LTP: {ltp}")
    return ltp


def get_daily_executed_order_count(fyers) -> int:
    """Fetch today's executed order count from Fyers"""
    try:
        response = fyers.orderbook()
        
        if response.get("s") != "ok":
            print(f"⚠️ [DEBUG] Failed to fetch orderbook: {response.get('message', 'Unknown')}")
            return 0
        
        # Count executed orders (status=2)
        executed_orders = [
            order for order in response.get("orderBook", [])
            if order.get("status") == 2
        ]
        
        count = len(executed_orders)
        print(f"📊 [DEBUG] Daily executed orders: {count}")
        return count
        
    except Exception as e:
        print(f"❌ [DEBUG] Error fetching orderbook: {e}")
        return 0


@handle_errors
def update_all_data(session_state: SessionState, cid: str, token: str, sym: str) -> Tuple:
    """Update all market data"""
    print(f"🔍 [DEBUG] Updating all data for {sym}")
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    enforce_rate_limit(session_state)
    session_state.option_chain_api_count += 1
    
    # Get expiry data
    meta = fy.optionchain(data={"symbol": sym, "timestamp": ""})
    if meta.get("code") != 200:
        logging.error("Failed to fetch expiry data")
        print("❌ [DEBUG] Failed to fetch expiry data")
        return None, None, None
    
    # Find current expiry
    exp = sorted(
        [(e["date"], e.get("expiry")) for e in meta["data"]["expiryData"]],
        key=lambda x: datetime.strptime(x[0], "%d-%m-%Y")
    )
    today = datetime.today().date()
    dates = [datetime.strptime(d, "%d-%m-%Y").date() for d, _ in exp]
    idx = next((i for i, d in enumerate(dates) if d >= today), 0)
    curr_date, curr_ts = exp[idx]
    
    # Get LTP and chain
    ltp = get_underlying_ltp(session_state, cid, token, sym)
    chain = get_option_chain_data(session_state, cid, token, sym, expiry_ts=curr_ts)
    
    print("✅ [DEBUG] Data update complete")
    return ltp, chain, curr_date


# ============================================================================
# ORDER MANAGEMENT
# ============================================================================

@handle_errors
def cancel_order(fyers, order_id: str):
    """Cancel an order"""
    print(f"🔍 [DEBUG] Cancelling order: {order_id}")
    resp = fyers.cancel_order(data={"id": order_id})
    logging.info(f"Cancelled order {order_id}: {resp}")
    print(f"✅ [DEBUG] Order {order_id} cancelled")
    return resp


@handle_errors
def get_order_status_by_id(fyers, order_id: str) -> Optional[int]:
    """Get order status by ID"""
    print(f"🔍 [DEBUG] Getting status for order: {order_id}")
    orderbook = fyers.orderbook()
    
    for order in orderbook.get("orderBook", []):
        if order.get("id") == order_id:
            status = order.get("status")
            print(f"✅ [DEBUG] Order {order_id} status: {status}")
            return status
    
    print(f"⚠️ [DEBUG] Order {order_id} not found")
    return None


@handle_errors
def place_order_and_check(fyers, order: Dict) -> Tuple:
    """Place order and check status"""
    print(f"🔍 [DEBUG] Placing order: {order}")
    resp = fyers.place_order(data=order)
    logging.info(f"Order placed for {order['symbol']}: {resp}")
    print(f"✅ [DEBUG] Order placed: {resp}")
    
    if resp.get("s") == "ok":
        oid = resp.get("id")
        time.sleep(Config.ORDER_VERIFY_DELAY)
        
        status = get_order_status_by_id(fyers, oid)
        if status in [1, 5]:  # Rejected or canceled
            logging.error(f"Order {oid} rejected/canceled. Status: {status}")
            print(f"❌ [DEBUG] Order {oid} rejected/canceled")
            return None, status
        
        logging.info(f"Order {oid} status: {status}")
        print(f"✅ [DEBUG] Order {oid} status: {status}")
        return oid, status
    
    logging.error(f"Order failed: {resp}")
    print(f"❌ [DEBUG] Order failed")
    return None, None


def has_open_orders_for_last_signal(fyers, session_state: SessionState) -> bool:
    """Check if there are open orders for last signal"""
    print("🔍 [DEBUG] Checking open orders for last signal")
    
    # Check positions first
    try:
        pos_resp = fyers.positions()
        if pos_resp.get("s") == "ok":
            net_positions = [
                p for p in pos_resp.get("netPositions", [])
                if abs(p.get("netQty", 0)) != 0
            ]
            
            if not net_positions:
                print("✅ [DEBUG] No active positions")
                session_state.last_signal_order_ids = []
                return False
            
            print(f"📊 [DEBUG] Found {len(net_positions)} active positions")
            for p in net_positions:
                print(f"  - {p.get('symbol')}: {p.get('netQty')} units")
            return True
    except Exception as e:
        print(f"❌ [DEBUG] Error checking positions: {e}")
    
    # Fallback to orderbook
    ids = session_state.live_last_signal_order_ids
    if not ids:
        print("✅ [DEBUG] No order IDs for last signal")
        return False
    
    try:
        ob = fyers.orderbook()
        if ob and "orderBook" in ob:
            open_orders = [
                o for o in ob["orderBook"]
                if o.get("id") in ids and o.get("status") == 2
            ]
            has_open = len(open_orders) > 0
            print(f"✅ [DEBUG] Open orders: {has_open} ({len(open_orders)} orders)")
            return has_open
        
        print("⚠️ [DEBUG] No orderbook data")
        return False
    except Exception as e:
        logging.warning(f"Could not check open orders: {e}")
        print(f"❌ [DEBUG] Error checking open orders: {e}")
        return False


# ============================================================================
# SIGNAL LOGIC
# ============================================================================

# def majority_signal(history: List[str], is_entry: bool = False) -> str:
#     """Determine majority signal from history"""
#     if not history or len(history) < 2:
#         return "HOLD"
    
#     if is_entry:
#         # Entry: needs ALL 4 signals same
#         if len(history) >= 4 and all(signal == history[0] for signal in history[-4:]):
#             return history[0]
#         return "HOLD"
#     else:
#         # Exit: needs latest 2 signals same (SIDEWAYS)
#         if len(history) >= 2:
#             if history[-1] == "SIDEWAYS" and history[-2] == "SIDEWAYS":
#                 return "SIDEWAYS"
#         return "HOLD"

def majority_signal(history: List[str], is_entry: bool = False) -> str:
    """Determine majority signal from history"""
    if not history or len(history) < 2:
        return "HOLD"
    
    if is_entry:
        # Entry: needs ALL 2 signals same
        if len(history) >= 2 and all(signal == history[0] for signal in history[-2:]):
            return history[0]
        return "HOLD"
    else:
        # Exit: needs latest 2 signals same (SIDEWAYS)
        if len(history) >= 2:
            if history[-1] == "SIDEWAYS" and history[-2] == "SIDEWAYS":
                return "SIDEWAYS"
        return "HOLD"


def fetch_history(symbol: str, session_state: SessionState) -> Optional[pd.DataFrame]:
    """Fetch historical data for a symbol"""
    now = datetime.now()
    current_epoch = int(time.time())
    
    # Calculate last complete candle timestamp
    current_second = now.second
    seconds_into_current_candle = current_second % 15
    
    if seconds_into_current_candle == 0:
        last_complete_epoch = current_epoch - 15
    else:
        last_complete_epoch = current_epoch - seconds_into_current_candle
    
    # Go back 40 minutes
    from_epoch = last_complete_epoch - (40 * 60)
    
    print(f"📥 [DEBUG] Fetching history for {symbol} from {datetime.fromtimestamp(from_epoch)} to {datetime.fromtimestamp(last_complete_epoch)}")
    
    fy = fyersModel.FyersModel(
        client_id=session_state.cid,
        token=session_state.token,
        is_async=False,
        log_path=""
    )
    
    resp = fy.history({
        "symbol": symbol,
        "resolution": "15S",
        "date_format": 0,
        "range_from": from_epoch,
        "range_to": last_complete_epoch,
        "cont_flag": 1
    })
    
    if resp.get("s") != "ok" or not resp.get("candles"):
        print(f"❌ [DEBUG] History fetch failed for {symbol}")
        return None
    
    candles = resp["candles"]
    print(f"📊 [DEBUG] Fetched {len(candles)} candles for {symbol}")
    
    df = pd.DataFrame(
        candles,
        columns=["epoch", "open", "high", "low", "close", "volume"]
    )
    df = df.sort_values('epoch', ascending=True)
    
    return df


#start of day till current time
# def fetch_history(symbol: str, session_state: SessionState) -> Optional[pd.DataFrame]:
#     """Fetch historical data from start of day to current time"""

#     now = datetime.now()
#     current_epoch = int(time.time())

#     # --- Last complete 15-sec candle ---
#     current_second = now.second
#     seconds_into_current_candle = current_second % 15

#     if seconds_into_current_candle == 0:
#         last_complete_epoch = current_epoch - 15
#     else:
#         last_complete_epoch = current_epoch - seconds_into_current_candle

#     # --- Start of day (9:15 AM IST) ---
#     today = now.date()
#     market_open = datetime.combine(today, datetime.min.time()).replace(hour=9, minute=15)
#     from_epoch = int(market_open.timestamp())

#     print(
#         f"📥 [DEBUG] Fetching history for {symbol} from {datetime.fromtimestamp(from_epoch)} to {datetime.fromtimestamp(last_complete_epoch)}")

#     fy = fyersModel.FyersModel(
#         client_id=session_state.cid,
#         token=session_state.token,
#         is_async=False,
#         log_path=""
#     )

#     resp = fy.history({
#         "symbol": symbol,
#         "resolution": "15S",
#         "date_format": 0,
#         "range_from": from_epoch,
#         "range_to": last_complete_epoch,
#         "cont_flag": 1
#     })

#     if resp.get("s") != "ok" or not resp.get("candles"):
#         print(f"❌ [DEBUG] History fetch failed for {symbol}")
#         return None

#     candles = resp["candles"]
#     print(f"📊 [DEBUG] Fetched {len(candles)} candles for {symbol}")

#     df = pd.DataFrame(
#         candles,
#         columns=["epoch", "open", "high", "low", "close", "volume"]
#     )

#     df = df.sort_values('epoch', ascending=True)

#     return df


def compute_score(df: pd.DataFrame, label: str = "") -> Optional[Dict]:
    """Compute momentum score for price series"""
    closes = df["close"]
    if len(closes) < 121:
        print(f"❌ [DEBUG] Not enough candles for {label}, len={len(closes)}")
        return None
    
    # Momentum over different periods (15-second candles)
    R1 = closes.pct_change(4).iloc[-2]    # 1 min
    R3 = closes.pct_change(12).iloc[-2]   # 3 min
    R10 = closes.pct_change(40).iloc[-2]  # 10 min
    R30 = closes.pct_change(120).iloc[-2] # 30 min
    M = (R1 + R3 + R10 + R30) / 4
    
    # Volatility
    sigma = closes.pct_change().std()
    score = M / sigma if sigma and sigma > 0 else 0.0
    
    print(f"📈 [DEBUG] {label} | R1={R1:.4f}, R3={R3:.4f}, R10={R10:.4f}, R30={R30:.4f}, M={M:.4f}, σ={sigma:.4f}, SCORE={score:.4f}")
    
    return {"score": score, "M": M, "sigma": sigma}





def fetch_quotes_avg_atp_ltp(symbols: List[str], fyers_api) -> Tuple:
    """Fetch average ATP and LTP for symbols"""
    print(f"📥 [DEBUG] Fetching quotes for {len(symbols)} {', '.join(symbols)} symbols")
    try:
        resp = fyers_api.quotes({"symbols": ",".join(symbols)})
        if resp.get("s") != "ok":
            print("❌ [DEBUG] Quotes fetch failed")
            return None, None
        
        atps, ltps = [], []
        for d in resp.get("d", []):
            v = d.get("v", {})
            atp = v.get("atp")
            ltp = v.get("lp")
            if atp is not None and ltp is not None:
                atps.append(atp)
                ltps.append(ltp)
        
        if not atps or not ltps:
            print("❌ [DEBUG] No valid ATP/LTP found")
            return None, None
        
        avg_atp = sum(atps) / len(atps)
        avg_ltp = sum(ltps) / len(ltps)
        print(f"📊 [DEBUG] Averages → ATP={avg_atp:.2f}, LTP={avg_ltp:.2f}")
        
        return avg_atp, avg_ltp
    except Exception as e:
        print(f"❌ [DEBUG] Quotes exception: {e}")
        return None, None


def compute_signals(merged_df: pd.DataFrame, atm_strike: float, ltp: float,
                    fyers_api=None, session_state: SessionState = None) -> Tuple:
    """Main signal computation logic with volatility-aware dominance and sigma validation"""
    print("\n" + "=" * 90)
    print("🚀 [DEBUG] compute_signals STARTED")
    print(f"📌 LTP: {ltp}, ATM Strike: {atm_strike}")
    print("=" * 90)

    try:
        now = datetime.now()

        metrics = {
            'signal': "HOLD",
            'raw_signal': "HOLD",
            'dominant_option': None,
            'option_score': 0,
            'underlying_score': 0,
            'history': []
        }

        if fyers_api is None:
            print("❌ [DEBUG] fyers_api is None → HOLD")
            return "HOLD", metrics

        # Step 1: Check current position
        current_position = None
        try:
            pos_resp = fyers_api.positions()
            if pos_resp.get("s") == "ok":
                for p in pos_resp.get("netPositions", []):
                    qty = p.get("netQty", 0)
                    sym = (p.get("symbol") or "").upper()
                    if qty > 0:
                        if sym.endswith("CE"):
                            current_position = "CE"
                        elif sym.endswith("PE"):
                            current_position = "PE"
        except Exception as e:
            print(f"❌ [DEBUG] Position fetch error: {e}")

        print(f"✅ [DEBUG] Current Position: {current_position}")

        # Step 1.5: Capture opening straddle
        if session_state is not None:
            opening_date = session_state.get("opening_date")
            if opening_date != now.date():
                print("🧭 [DEBUG] Capturing opening straddle")
                q = fyers_api.quotes({"symbols": "BSE:SENSEX-INDEX"})
                if q.get("s") != "ok":
                    print("❌ [DEBUG] Failed to fetch BSE:SENSEX-INDEX open quote")
                    return "HOLD", metrics

                nifty_open = q["d"][0]["v"]["open_price"]
                session_state.day_open = nifty_open

                atm_open = min(merged_df["Strike"], key=lambda x: abs(x - nifty_open))
                atm_row = merged_df[merged_df["Strike"] == atm_open].iloc[0]

                ce_symbol = atm_row.get("CE_symbol")
                pe_symbol = atm_row.get("PE_symbol")

                if not ce_symbol or not pe_symbol:
                    print("❌ [DEBUG] ATM symbols missing at open")
                    return "HOLD", metrics

                q_opt = fyers_api.quotes({"symbols": f"{ce_symbol},{pe_symbol}"})
                if q_opt.get("s") != "ok":
                    print("❌ [DEBUG] Failed to fetch ATM straddle quotes")
                    return "HOLD", metrics

                ce_open = q_opt["d"][0]["v"]["open_price"]
                pe_open = q_opt["d"][1]["v"]["open_price"]
                opening_straddle = ce_open + pe_open

                session_state.opening_straddle = opening_straddle
                session_state.opening_date = now.date()
                print(f"📊 [DEBUG] Opening straddle = {opening_straddle:.2f}")
            else:
                print("🟩 [DEBUG] Opening straddle already captured")

        # Step 3: Underlying score
        print("\n🧭 [STEP 3] Computing underlying score")
        udf = fetch_history("BSE:SENSEX-INDEX", session_state)
        if udf is None:
            print("❌ [DEBUG] Unable to fetch underlying history → HOLD")
            return "HOLD", metrics

        u = compute_score(udf, "UNDERLYING")
        if u is None or u.get("sigma") is None:
            print("❌ [DEBUG] Underlying sigma missing → HOLD")
            return "HOLD", metrics

        underlying_score = u["score"]
        underlying_sigma = u["sigma"]
        metrics["underlying_score"] = underlying_score
        print(f"✅ [DEBUG] Underlying Score: {underlying_score:.4f}, Sigma: {underlying_sigma:.4f}")

        # Step 3.5: Straddle regime gate
        if session_state is not None and session_state.get("opening_straddle"):
            print("📊 [DEBUG] Checking regime gate")
            try:
                quote_resp = fyers_api.quotes(data={"symbols": "BSE:SENSEX-INDEX"})
                if quote_resp.get("s") == "ok" and quote_resp.get("d"):
                    quote_data = quote_resp["d"][0]["v"]
                    day_high = quote_data.get("high_price")
                    day_low = quote_data.get("low_price")
                    if day_high is not None and day_low is not None:
                        realized_range = day_high - day_low
                        threshold = Config.STRADDLE_MULTIPLIER * session_state.opening_straddle
                        print(f"📏 [DEBUG] Regime → Range={realized_range:.2f}, Threshold={threshold:.2f}")
                        if realized_range < threshold:
                            print("🛑 [DEBUG] Regime BLOCK → HOLD")
                            return "HOLD", metrics
                        print("✅ [DEBUG] Regime PASSED")
                    else:
                        print("❌ [DEBUG] Could not get high/low → HOLD")
                        return "HOLD", metrics
                else:
                    print("❌ [DEBUG] Quotes API failed → HOLD")
                    return "HOLD", metrics
            except Exception as e:
                print(f"❌ [DEBUG] Exception fetching quotes: {e} → HOLD")
                return "HOLD", metrics

        # Step 4: ATM ± 1 strike selection
        print("\n🎯 [STEP 4] Selecting ATM ± 1 strikes")
        atm = min(merged_df["Strike"], key=lambda x: abs(x - ltp))
        strike_df = merged_df[merged_df["Strike"].isin([atm, atm + Config.STRIKE_GAP, atm - Config.STRIKE_GAP])].copy()
        if strike_df.empty:
            print("❌ [DEBUG] No strikes available → HOLD")
            return "HOLD", metrics

        # Step 5: CE vs PE dominance (volatility-aware)
        print("\n🏎️ [STEP 5] Evaluating CE & PE dominance")
        dominant_options = []
        evaluated_options = []

        for _, row in strike_df.iterrows():
            strike = row["Strike"]
            ce_symbol = row.get("CE_symbol")
            pe_symbol = row.get("PE_symbol")

            ce_score, ce_sigma = None, None
            pe_score, pe_sigma = None, None

            # Compute CE
            if pd.notna(ce_symbol):
                df_ce = fetch_history(ce_symbol, session_state)
                if df_ce is not None:
                    s_ce = compute_score(df_ce, ce_symbol)
                    if s_ce is not None:
                        ce_score = s_ce.get("score")
                        ce_sigma = s_ce.get("sigma")
                        if ce_sigma is None:
                            print(f"❌ [DEBUG] Sigma missing for {ce_symbol} → HOLD")
                            return "HOLD", metrics
                        evaluated_options.append({"symbol": ce_symbol, "type": "CE", "score": ce_score})

            # Compute PE
            if pd.notna(pe_symbol):
                df_pe = fetch_history(pe_symbol, session_state)
                if df_pe is not None:
                    s_pe = compute_score(df_pe, pe_symbol)
                    if s_pe is not None:
                        pe_score = s_pe.get("score")
                        pe_sigma = s_pe.get("sigma")
                        if pe_sigma is None:
                            print(f"❌ [DEBUG] Sigma missing for {pe_symbol} → HOLD")
                            return "HOLD", metrics
                        evaluated_options.append({"symbol": pe_symbol, "type": "PE", "score": pe_score})

            # Determine dominance using dynamic threshold and magnitude
            if ce_score is not None and pe_score is not None:
                relative_factor = 0.50
                
                print('-' * 50)

                # Calculate thresholds for logging
                # ce_dominance_required = abs(pe_score) * (1 + relative_factor)
                # pe_dominance_required = abs(ce_score) * (1 + relative_factor)

                ce_dominance_required = abs(pe_score) 
                pe_dominance_required = abs(ce_score) 

                # CE dominant (BUY)
                if ce_score > 0 and abs(ce_score) > ce_dominance_required and pe_score < 0 and abs(ce_score) < abs(pe_score) * (1 + relative_factor):
                    dominant_options.append({
                        "symbol": ce_symbol,
                        "type": "CE",
                        "score": ce_score,
                        "required_ratio": 1 + relative_factor
                    })
                    print(
                        f"✅ [DEBUG] {ce_symbol} dominant (BUY) | "
                        f"CE={ce_score:.2f}, PE={pe_score:.2f}, "
                        f"CE requires > {ce_dominance_required:.2f}, "
                        f"Underlying Score={underlying_score:.4f}"
                    )

                # PE dominant (SELL)
                elif pe_score > 0 and abs(pe_score) > pe_dominance_required and ce_score < 0 and abs(pe_score) < abs(ce_score) * (1 + relative_factor):
                    dominant_options.append({
                        "symbol": pe_symbol,
                        "type": "PE",
                        "score": pe_score,
                        "required_ratio": 1 + relative_factor
                    })
                    print(
                        f"✅ [DEBUG] {pe_symbol} dominant (SELL) | "
                        f"PE={pe_score:.2f}, CE={ce_score:.2f}, "
                        f"PE requires > {pe_dominance_required:.2f}, "
                        f"Underlying Score={underlying_score:.4f}"
                    )

                else:
                    print(
                        f"ℹ️ [DEBUG] No clear dominance | "
                        f"CE={ce_score:.2f}, PE={pe_score:.2f}, "
                        f"Underlying Score={underlying_score:.4f}"
                    )


                print('-' * 50)

            # Only CE available
            elif ce_score is not None:
                dominant_options.append({
                    "symbol": ce_symbol,
                    "type": "CE",
                    "score": ce_score,
                    "Threshold CE": None
                })
                print(f"✅ [DEBUG] {ce_symbol} dominant (no PE data found) | CE={ce_score:.2f}  |  "
                      f"Underlying Score={underlying_score:.4f}"
                      )

            # Only PE available
            elif pe_score is not None:
                dominant_options.append({
                    "symbol": pe_symbol,
                    "type": "PE",
                    "score": pe_score,
                    "Threshold PE": None
                })
                print(f"✅ [DEBUG] {pe_symbol} dominant (no CE data found) | PE={pe_score:.2f}  |  "
                      f"Underlying Score={underlying_score:.4f}"
                      )

        dominant_options.sort(key=lambda x: x["score"], reverse=True)
        top_option = dominant_options[0] if dominant_options else None
        metrics['dominant_option'] = top_option["symbol"] if top_option else None
        metrics['option_score'] = top_option["score"] if top_option else 0.0
        print(f"🏆 [DEBUG] Top dominant option: {metrics['dominant_option']}")

        # Step 5.5: ATP-LTP gate
        ce_symbols = [row["CE_symbol"] for _, row in strike_df.iterrows() if pd.notna(row.get("CE_symbol"))]
        pe_symbols = [row["PE_symbol"] for _, row in strike_df.iterrows() if pd.notna(row.get("PE_symbol"))]
        ce_atp_avg, ce_ltp_avg = fetch_quotes_avg_atp_ltp(ce_symbols, fyers_api)
        pe_atp_avg, pe_ltp_avg = fetch_quotes_avg_atp_ltp(pe_symbols, fyers_api)
        allow_buy = ce_atp_avg is not None and ce_ltp_avg is not None and ce_ltp_avg > ce_atp_avg and pe_ltp_avg < pe_atp_avg
        allow_sell = pe_atp_avg is not None and pe_ltp_avg is not None and pe_ltp_avg > pe_atp_avg and ce_ltp_avg < ce_atp_avg
        print(f"📊 [DEBUG] ATP-LTP Gate → BUY={allow_buy}, SELL={allow_sell}")

        # Step 6: Raw signal
        raw_signal = "HOLD"
        total_ce = len([opt for opt in evaluated_options if opt["type"] == "CE"])
        total_pe = len([opt for opt in evaluated_options if opt["type"] == "PE"])
        dominant_types = [opt["type"] for opt in dominant_options]
        ce_count = dominant_types.count("CE")
        pe_count = dominant_types.count("PE")

        if current_position is None:
            if total_ce > 0 and ce_count == total_ce and allow_buy and underlying_score > 0:
                raw_signal = "BUY"
            elif total_pe > 0 and pe_count == total_pe and allow_sell and underlying_score < 0:
                raw_signal = "SELL"
        else:
            if current_position == "CE":
                raw_signal = "HOLD" if ce_count == total_ce else "SIDEWAYS"
            elif current_position == "PE":
                raw_signal = "HOLD" if pe_count == total_pe else "SIDEWAYS"
        print(f"📌 [DEBUG] Raw signal: {raw_signal} | Position={current_position}")

        # Step 7: Majority confirmation
        history = list(session_state.get("signal_history", [])) if session_state else []
        history.append(raw_signal)
        history = history[-Config.MAX_HISTORY:]
        if session_state is not None:
            session_state.signal_history = history

        has_position = current_position is not None
        confirmed_signal = majority_signal(history, is_entry=not has_position)
        if has_position:
            confirmed_signal = "SIDEWAYS" if confirmed_signal == "SIDEWAYS" else "HOLD"
        else:
            confirmed_signal = confirmed_signal if confirmed_signal in ["BUY", "SELL"] else "HOLD"
        metrics["signal"] = confirmed_signal
        metrics["history"] = history
        print(f'total_ce : {total_ce} | total_pe:{total_pe} | Dominant CE Count: {ce_count} | Dominant PE Count :{pe_count} | ')
        print(f'Signal History: {history}')
        print(f'Confirm Signal: {confirmed_signal}')
        # Step 7.5 & 8: Cooldown
        if session_state is not None and session_state.get("last_trade_time"):
            elapsed_mins = (now - session_state.last_trade_time).total_seconds() / 60
            print(f"⏱️ [DEBUG] Cooldown Check → elapsed={elapsed_mins:.2f} min | limit={Config.COOLDOWN_MINUTES}")
            if elapsed_mins < Config.COOLDOWN_MINUTES and confirmed_signal in ("BUY", "SELL"):
                print("🛑 [DEBUG] Cooldown ACTIVE → HOLD")
                print(f"Cooldown Time Left: {elapsed_mins}")
                confirmed_signal = "HOLD"
                metrics["signal"] = "HOLD"

        print("=" * 90 + "\n")
        return confirmed_signal, metrics

    except Exception as e:
        logging.error("Error in compute_signals", exc_info=True)
        print(f"❌ [DEBUG] Exception: {e}")
        return "SIDEWAYS", metrics

# ============================================================================
# STRIKE SELECTION
# ============================================================================

def select_strikes_atm_half_price(chain: List, atm_strike: float) -> Tuple:
    """Select strikes for trading (ATM buy + OTM sell at half price)"""
    print(f"🔍 [DEBUG] Selecting strikes for ATM: {atm_strike}")
    
    try:
        df = pd.DataFrame(chain)
        if df.empty or atm_strike is None:
            print("⚠️ [DEBUG] No data or ATM strike")
            return None, None, None, None
        
        ce = df[df["option_type"] == "CE"].copy()
        pe = df[df["option_type"] == "PE"].copy()
        
        # ATM Buy legs
        atm_pe_row = pe[pe["strike_price"] == atm_strike]
        atm_ce_row = ce[ce["strike_price"] == atm_strike]
        
        buy_pe_row = atm_pe_row.iloc[0].to_dict() if not atm_pe_row.empty else None
        buy_ce_row = atm_ce_row.iloc[0].to_dict() if not atm_ce_row.empty else None
        
        # OTM Sell legs (half price)
        sell_pe_row, sell_ce_row = None, None
        
        if buy_pe_row and "ltp" in buy_pe_row and buy_pe_row["ltp"] > 0:
            target = buy_pe_row["ltp"] / 4
            pe_candidates = pe[pe["strike_price"] < atm_strike].copy()
            pe_candidates["ltp_diff"] = (pe_candidates["ltp"] - target).abs()
            if not pe_candidates.empty:
                sell_pe_row = pe_candidates.nsmallest(1, "ltp_diff").iloc[0].to_dict()
        
        if buy_ce_row and "ltp" in buy_ce_row and buy_ce_row["ltp"] > 0:
            target = buy_ce_row["ltp"] / 4
            ce_candidates = ce[ce["strike_price"] > atm_strike].copy()
            ce_candidates["ltp_diff"] = (ce_candidates["ltp"] - target).abs()
            if not ce_candidates.empty:
                sell_ce_row = ce_candidates.nsmallest(1, "ltp_diff").iloc[0].to_dict()
        
        print("✅ [DEBUG] Strike selection complete")
        if buy_pe_row:
            print(f"   - BUY PE: {buy_pe_row['symbol']} @ {buy_pe_row['ltp']}")
        if buy_ce_row:
            print(f"   - BUY CE: {buy_ce_row['symbol']} @ {buy_ce_row['ltp']}")
        
        return buy_pe_row, sell_pe_row, buy_ce_row, sell_ce_row
        
    except Exception as e:
        logging.error(f"Error in select_strikes: {e}", exc_info=True)
        print(f"❌ [DEBUG] Error in strike selection: {e}")
        return None, None, None, None


# ============================================================================
# BASKET ORDER HANDLING
# ============================================================================

def handle_basket_orders_atomic(session_state: SessionState, signal: str,
                                sell_pe, buy_pe, sell_ce, buy_ce, fyers, data_logger):
    """Handle basket orders atomically"""
    print(f"\n🔍 [DEBUG] Handling basket orders for signal: {signal}")
    
    # Lock to prevent overlapping runs
    if session_state._hb_lock:
        print("⚠️ [DEBUG] Another rebalance running, skipping")
        return []
    
    session_state._hb_lock = True
    placed_ids = []
    
    try:
        lot = Config.LOT_SIZE
        current_signal = session_state.last_signal
        print(f"🔄 [DEBUG] Current: {current_signal}, Incoming: {signal}")
        
        def _wait_until_flat(timeout=Config.FLATTEN_TIMEOUT, interval=Config.FLATTEN_POLL_INTERVAL):
            """Wait until positions are flat"""
            print(f"⏳ [DEBUG] Waiting up to {timeout}s for positions to flatten")
            end = time.time() + timeout
            
            while time.time() < end:
                pos_resp = fyers.positions()
                if pos_resp.get("s") == "ok":
                    still_open = [
                        p for p in pos_resp.get("netPositions", [])
                        if abs(p.get("netQty", 0)) != 0
                    ]
                    
                    if not still_open:
                        print("✅ [DEBUG] All positions flat")
                        return True
                    
                    print(f"⏳ [DEBUG] Still open: {[(p['symbol'], p['netQty']) for p in still_open]}")
                
                time.sleep(interval)
            
            print("❌ [DEBUG] Timeout: positions did not flatten")
            return False
        
        # Get current positions
        pos_resp = fyers.positions()
        net_positions = []
        
        if pos_resp.get("s") == "ok":
            net_positions = [
                p for p in pos_resp.get("netPositions", [])
                if abs(p.get("netQty", 0)) != 0
            ]
        
        print(f"🔍 [DEBUG] Found {len(net_positions)} active positions")
        for p in net_positions:
            print(f"  - {p.get('symbol')}: {p.get('netQty')} units")
        
        # 1) Handle HOLD signal
        if signal == "HOLD":
            print("📊 [DEBUG] HOLD → Maintaining positions")
            return []
        
        # 2) Handle SIDEWAYS signal (exit)
        if signal == "SIDEWAYS" and Config.EXIT_ON_SIDEWAYS:
            print("📊 [DEBUG] SIDEWAYS → Exiting positions")
            
            if not net_positions:
                print("✅ [DEBUG] No positions to exit")
                session_state.last_signal = signal
                return []
            
            try:
                timestamp = datetime.now(pytz.timezone("Asia/Kolkata")).strftime("%Y-%m-%d %H:%M:%S")
                for position in net_positions:
                    symbol = position.get('symbol', '')
                    net_qty = position.get('netQty', 0)
                    avg_price = position.get('avgPrice', 0)
                    print(f"ℹ️ Exiting {symbol} qty={net_qty} avg_price={avg_price} at {timestamp}")
                
                # Exit shorts
                exit_shorts = {"segment": [11], "side": [-1], "productType": ["MARGIN"]}
                resp_short = fyers.exit_positions(data=exit_shorts)
                print(f"📥 [DEBUG] SHORT exit: {resp_short}")
                
                # Exit longs
                exit_longs = {"segment": [11], "side": [1], "productType": ["MARGIN"]}
                resp_long = fyers.exit_positions(data=exit_longs)
                print(f"📥 [DEBUG] LONG exit: {resp_long}")
                
                # Verify flattening
                if not _wait_until_flat():
                    print("❌ [DEBUG] Flattening failed")
                    return placed_ids
                
                print("✅ [DEBUG] All positions exited")
                session_state.last_signal = signal
                session_state.last_trade_time = datetime.now()
                print("🕒 [DEBUG] Cooldown started")
                return []
                
            except Exception as e:
                print(f"❌ [DEBUG] Exception during SIDEWAYS exit: {e}")
                return placed_ids
        
        if signal == "SIDEWAYS" and not Config.EXIT_ON_SIDEWAYS:
            print("📊 [DEBUG] SIDEWAYS → Holding (EXIT_ON_SIDEWAYS=False)")
            return []
        
        # 3) Flatten on signal change
        if current_signal in ["BUY", "SELL"] and current_signal != signal and net_positions:
            print(f"⚠️ [DEBUG] Signal changed ({current_signal} → {signal}), exiting positions")
            
            try:
                timestamp = datetime.now(pytz.timezone("Asia/Kolkata")).strftime("%Y-%m-%d %H:%M:%S")
                for position in net_positions:
                    symbol = position.get('symbol', '')
                    net_qty = position.get('netQty', 0)
                    avg_price = position.get('avgPrice', 0)
                    print(f"ℹ️ Exiting {symbol} qty={net_qty} avg_price={avg_price} at {timestamp}")
                
                # Exit shorts
                exit_shorts = {"segment": [11], "side": [-1], "productType": ["MARGIN"]}
                resp_short = fyers.exit_positions(data=exit_shorts)
                print(f"📥 [DEBUG] SHORT exit: {resp_short}")
                
                # Exit longs
                exit_longs = {"segment": [11], "side": [1], "productType": ["MARGIN"]}
                resp_long = fyers.exit_positions(data=exit_longs)
                print(f"📥 [DEBUG] LONG exit: {resp_long}")
                
                # Verify flattening
                if not _wait_until_flat():
                    print("❌ [DEBUG] Flattening failed")
                    return placed_ids
                
                print("✅ [DEBUG] All positions exited for signal change")
                
            except Exception as e:
                print(f"❌ [DEBUG] Exception during exit: {e}")
                return placed_ids
        
        # 4) Enter new basket
        signal_map = {
            "BUY": {"enter_hedge": buy_ce, "enter_short": None},
            "SELL": {"enter_hedge": buy_pe, "enter_short": None}
        }
        
        # Check if positions are flat
        pos_resp = fyers.positions()
        current_positions = []
        
        if pos_resp.get("s") == "ok":
            current_positions = [
                p for p in pos_resp.get("netPositions", [])
                if abs(p.get("netQty", 0)) != 0
            ]
        
        if current_positions:
            print("⚠️ [DEBUG] Positions still open, skipping entry")
            for p in current_positions:
                print(f"  - OPEN: {p.get('symbol')} {p.get('netQty')}")
            return placed_ids
        
        # Build entry basket
        enter_hedge = signal_map[signal]["enter_hedge"]
        enter_short = signal_map[signal]["enter_short"]
        
        print(f"📥 [DEBUG] Preparing {signal} basket:")
        print(f"  - ATM BUY: {enter_hedge}")
        
        entry_basket = []
        
        if enter_hedge:
            if not isinstance(enter_hedge, dict) or "symbol" not in enter_hedge:
                print("❌ [DEBUG] Invalid ATM buy leg, aborting")
                return placed_ids
            
            entry_basket.append({
                "symbol": enter_hedge["symbol"],
                "qty": lot,
                "type": 2,
                "side": 1,
                "productType": "MARGIN",
                "validity": "DAY",
            })
        
        if enter_short:
            if not isinstance(enter_short, dict) or "symbol" not in enter_short:
                print("❌ [DEBUG] Invalid short leg, skipping")
            else:
                entry_basket.append({
                    "symbol": enter_short["symbol"],
                    "qty": lot,
                    "type": 2,
                    "side": -1,
                    "productType": "MARGIN",
                    "validity": "DAY",
                })
        
        if not entry_basket:
            print("❌ [DEBUG] No valid legs, aborting")
            return placed_ids
        
        print(f"📤 [DEBUG] Sending basket order: {entry_basket}")
        entry_resp = fyers.place_basket_orders(data=entry_basket)
        print(f"📥 [DEBUG] Basket response: {entry_resp}")
        
        if entry_resp and entry_resp.get("s") == "ok":
            for item in entry_resp.get("data", []):
                body = item.get("body", {})
                if body.get("s") == "ok" and body.get("id"):
                    placed_ids.append(body["id"])
            
            timestamp = datetime.now(pytz.timezone("Asia/Kolkata")).strftime("%Y-%m-%d %H:%M:%S")
            if enter_hedge and isinstance(enter_hedge, dict) and "ltp" in enter_hedge:
                print(f"ℹ️ Entry: {signal} {enter_hedge.get('symbol')} @ {enter_hedge.get('ltp')} at {timestamp}")
            
            session_state.last_signal = signal
            print(f"✅ [DEBUG] Successfully entered {signal} basket → IDs: {placed_ids}")
        else:
            msg = entry_resp.get("message", "Unknown") if isinstance(entry_resp, dict) else "Unknown"
            print(f"❌ [DEBUG] Basket order FAILED: {msg}")
        
        return placed_ids
        
    except Exception as e:
        logging.exception("Fatal error in handle_basket_orders_atomic")
        print(f"❌ [DEBUG] Fatal error: {e}")
        return []
    finally:
        session_state._hb_lock = False
        print("🔓 [DEBUG] Lock released\n")


# ============================================================================
# DATA LOGGING
# ============================================================================

class DataLogger:
    """Handle data logging to CSV"""
    
    def __init__(self, filename="trading_data.csv"):
        self.filename = filename
        self._ensure_header()
    
    def _ensure_header(self):
        """Create file with headers if not exists"""
        try:
            with open(self.filename, 'r') as f:
                pass
        except FileNotFoundError:
            with open(self.filename, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'timestamp', 'underlying_ltp', 'signal',
                    'atm_strike', 'expiry_date', 'dominant_option',
                    'option_score', 'underlying_score'
                ])
    
    def log_data(self, timestamp, underlying_ltp, signal, atm_strike,
                 expiry_date, dominant_option='', option_score=0.0, underlying_score=0.0):
        """Log trading data to CSV"""
        try:
            row = [
                str(timestamp),
                float(underlying_ltp) if underlying_ltp is not None else "",
                str(signal) if signal is not None else "",
                int(atm_strike) if (atm_strike is not None and not pd.isna(atm_strike)) else "",
                str(expiry_date) if expiry_date is not None else "",
                str(dominant_option) if dominant_option is not None else "",
                float(option_score) if option_score is not None else "",
                float(underlying_score) if underlying_score is not None else ""
            ]
            
            with open(self.filename, 'a', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(row)
            
            print(f"✅ Data logged: {timestamp} - LTP: {underlying_ltp}, Signal: {signal}")
        except Exception as e:
            logging.exception("Error logging data")
            print(f"❌ Error logging data: {e}")
    
    def read_data(self, limit=None) -> pd.DataFrame:
        """Read logged data from CSV"""
        try:
            df = pd.read_csv(self.filename)
            if limit:
                return df.tail(limit)
            return df
        except Exception as e:
            logging.exception("Error reading data")
            print(f"❌ Error reading data: {e}")
            return pd.DataFrame()


# ============================================================================
# TERMINAL DASHBOARD
# ============================================================================

class TerminalDashboard:
    """Display live trading dashboard in terminal"""
    
    def __init__(self, data_logger: DataLogger, session_state: SessionState = None):
        self.data_logger = data_logger
        self.session_state = session_state
        self.last_update = None
    
    def display_live_dashboard(self):
        """Display live dashboard"""
        try:
            clear_screen()
            
            df = self.data_logger.read_data(limit=20)
            
            print("\n" + "=" * 100)
            print("📊 LIVE TRADING DASHBOARD")
            print("=" * 100)
            print(f"Last Update: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
            print("-" * 100)
            
            # Display order count
            if self.session_state:
                print(f"📈 DAILY ORDER COUNT: {self.session_state.daily_executed_orders}/{Config.MAX_DAILY_ORDERS}")
                print("-" * 100)
            
            if df.empty:
                print("🔄 Waiting for trading data...")
                return
            
            # Convert timestamp
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            df = df.sort_values('timestamp')
            
            # Current status
            latest = df.iloc[-1]
            ltp = latest.get('underlying_ltp', 0) if isinstance(latest, pd.Series) else 0
            
            print(f"\n📈 CURRENT STATUS:")
            try:
                print(f"   BSE:SENSEX-INDEX LTP: {float(ltp):.2f}")
            except Exception:
                print(f"   BSE:SENSEX-INDEX LTP: {ltp}")
            
            print(f"   Signal: {latest.get('signal', '')}")
            print(f"   ATM Strike: {latest.get('atm_strike', '')}")
            print(f"   Expiry Date: {latest.get('expiry_date', '')}")
            
            # Recent signals
            print(f"\n🔄 RECENT SIGNALS (Last 5):")
            recent_signals = df.tail(5)[['timestamp', 'underlying_ltp', 'signal']]
            
            signal_colors = {
                'BUY': '🟢',
                'SELL': '🔴',
                'SIDEWAYS': '🟡',
                'HOLD': '⚪'
            }
            
            for _, row in recent_signals.iterrows():
                color = signal_colors.get(row['signal'], '⚪')
                print(f"   {row['timestamp'].strftime('%H:%M:%S')} - {color} {row['signal']} - LTP: {row['underlying_ltp']:.2f}")
            
            # Signal statistics
            signal_counts = df['signal'].value_counts()
            print(f"\n📊 SIGNAL STATISTICS:")
            for signal, count in signal_counts.items():
                percentage = (count / len(df)) * 100
                print(f"   {signal}: {count} times ({percentage:.1f}%)")
            
            print("\n" + "=" * 100)
            print(f"🔄 Next update in {Config.REFRESH_INTERVAL} seconds (Ctrl+C to stop)")
            print("=" * 100)
            
        except Exception as e:
            logging.exception("Error displaying dashboard")
            print(f"❌ Error displaying dashboard: {e}")


# ============================================================================
# PLOTTING
# ============================================================================

def generate_static_plot() -> Optional[str]:
    """Generate static plot of trading data"""
    try:
        data_logger = DataLogger()
        df = data_logger.read_data()
        
        if df.empty:
            print("❌ No data available for plotting")
            return None
        
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        df = df.sort_values('timestamp')
        
        fig, ax1 = plt.subplots(1, 1, figsize=(15, 6))
        
        # Plot BSE:SENSEX-INDEX LTP
        ax1.plot(df['timestamp'], df['underlying_ltp'], 'b-', label='BSE:SENSEX-INDEX LTP', linewidth=2)
        ax1.set_ylabel('BSE:SENSEX-INDEX LTP', color='blue')
        ax1.tick_params(axis='y', labelcolor='blue')
        ax1.grid(True, alpha=0.3)
        
        # Add signals
        buy_signals = df[df['signal'] == 'BUY']
        sell_signals = df[df['signal'] == 'SELL']
        sideways_signals = df[df['signal'] == 'SIDEWAYS']
        
        if not buy_signals.empty:
            ax1.scatter(buy_signals['timestamp'], buy_signals['underlying_ltp'],
                       color='green', s=100, label='BUY', marker='^', alpha=0.8)
        
        if not sell_signals.empty:
            ax1.scatter(sell_signals['timestamp'], sell_signals['underlying_ltp'],
                       color='red', s=100, label='SELL', marker='v', alpha=0.8)
        
        if not sideways_signals.empty:
            ax1.scatter(sideways_signals['timestamp'], sideways_signals['underlying_ltp'],
                       color='orange', s=80, label='SIDEWAYS', marker='s', alpha=0.6)
        
        ax1.legend()
        ax1.set_title('BSE:SENSEX-INDEX LTP vs Trading Signals')
        
        plt.tight_layout()
        
        plot_filename = f"trading_plot_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
        plt.savefig(plot_filename, dpi=300, bbox_inches='tight')
        plt.close()
        
        print(f"✅ Plot saved as: {plot_filename}")
        return plot_filename
        
    except Exception as e:
        logging.exception("Error generating plot")
        print(f"❌ Error generating plot: {e}")
        return None


# ============================================================================
# DATA FORMATTING
# ============================================================================

def format_and_show(chain: List, title: str, ltp: float, show_signals: bool = False,
                   fyers_api=None, session_state: SessionState = None) -> Tuple:
    """Format and display option chain data"""
    print(f"🔍 [DEBUG] Formatting data for: {title}")
    
    df = pd.DataFrame(chain)
    if df.empty:
        print(f"ℹ️ [DEBUG] No data for {title}")
        return None, None, None
    
    # Process CE and PE data
    ce = df[df["option_type"] == "CE"]
    pe = df[df["option_type"] == "PE"]
    
    cols = ["symbol", "strike_price", "oi", "volume", "ltp", "ask", "bid",
            "ltpch", "ltpchp", "oich", "oichp", "prev_oi"]
    
    ce_df = ce[cols].rename(columns={
        "strike_price": "Strike",
        "oi": "OI",
        "volume": "Vol",
        "ltpch": "LTPCh",
        "ltpchp": "LTPChP",
        "oich": "OICh",
        "oichp": "OIChP",
        "prev_oi": "PrevOI"
    })
    
    pe_df = pe[cols].rename(columns={
        "strike_price": "Strike",
        "oi": "OI",
        "volume": "Vol",
        "ltpch": "LTPCh",
        "ltpchp": "LTPChP",
        "oich": "OICh",
        "oichp": "OIChP",
        "prev_oi": "PrevOI"
    })
    
    merged = pd.merge(
        ce_df.add_prefix("CE_"),
        pe_df.add_prefix("PE_"),
        left_on="CE_Strike",
        right_on="PE_Strike",
        how="outer"
    ).rename(columns={"CE_Strike": "Strike"}).drop("PE_Strike", axis=1)
    
    # Find ATM strike
    atm = None
    if ltp is not None and not merged["Strike"].dropna().empty:
        atm = min(merged["Strike"].dropna(), key=lambda x: abs(x - ltp))
    
    print(f"\n📈 {title}")
    
    if show_signals and atm is not None:
        signal, metrics = compute_signals(merged, atm, ltp, fyers_api=fyers_api, session_state=session_state)
        print(f"✅ Signal: {signal}")
    
    print(f"📊 ATM Strike: {atm} | Underlying LTP: {ltp}")
    
    if show_signals and atm is not None:
        return signal, atm, metrics
    
    return None, atm, None


# ============================================================================
# SETTINGS MENU
# ============================================================================

def settings_menu(session_state: SessionState):
    """Display and handle settings menu"""
    while True:
        clear_screen()
        print("\n" + "=" * 50)
        print("⚙️ SETTINGS")
        print("=" * 50)
        print(f"1. Client ID: {session_state.cid}")
        print(f"2. Access Token: {'*' * len(session_state.token) if session_state.token else 'Not set'}")
        print(f"3. Lot Size: {Config.LOT_SIZE}")
        print(f"4. Max Daily Orders: {Config.MAX_DAILY_ORDERS}")
        print("5. 🔙 Back to Main Menu")
        
        choice = get_user_input("Select option", input_type=int)
        
        if choice == 1:
            session_state.cid = get_user_input("Enter Client ID", session_state.cid)
        elif choice == 2:
            session_state.token = get_user_input("Enter Access Token", session_state.token)
        elif choice == 3:
            Config.LOT_SIZE = get_user_input("Enter Lot Size", Config.LOT_SIZE, int)
        elif choice == 4:
            Config.MAX_DAILY_ORDERS = get_user_input("Enter Max Daily Orders", Config.MAX_DAILY_ORDERS, int)
        elif choice == 5:
            break
        else:
            print("❌ Invalid option")


# ============================================================================
# MAIN APPLICATION
# ============================================================================

def main():
    """Main application entry point"""
    print("🚀 Starting Live Auto Trading Application")
    
    # Initialize
    session_state = SessionState()
    load_credentials(session_state)
    data_logger = DataLogger()
    dashboard = TerminalDashboard(data_logger, session_state)
    
    sym = 'BSE:SENSEX-INDEX'
    
    while True:
        clear_screen()
        print("\n" + "=" * 100)
        print("📈 FYERS ALGO TRADING - LIVE AUTO TRADE")
        print("=" * 50)
        print("1. 📈 Start Live Trading (with Auto Dashboard)")
        print("2. ⚙️ Settings")
        print("3. 📊 Generate Static Plot")
        print("4. 🚪 Exit")
        print("=" * 50)
        
        choice = get_user_input("Select option", input_type=int)
        
        if choice == 1:  # Live Trading
            clear_screen()
            print("\n" + "=" * 100)
            print("📈 LIVE AUTO TRADING")
            print("=" * 100)
            
            # Check credentials
            if not (session_state.cid and session_state.token):
                print("❌ Please set credentials in Settings first")
                input("Press Enter to continue...")
                continue
            
            # Get trading mode
            auto_trade = get_user_input("Enable Auto Trade? (y/n)", "y").lower() == 'y'
            
            if not auto_trade:
                print("ℹ️ Auto trade disabled")
                input("Press Enter to continue...")
                continue
            
            print("🔄 Starting live trading loop...")
            print("📊 Dashboard will update automatically...")
            
            try:
                iteration_count = 0
                
                while True:
                    iteration_count += 1
                    
                    # Display dashboard
                    dashboard.display_live_dashboard()
                    
                    print(f"\n🔄 [DEBUG] Iteration {iteration_count} at {datetime.now().strftime('%H:%M:%S')}")
                    
                    # Update data
                    ltp, chain, curr_date = update_all_data(session_state, session_state.cid, session_state.token, sym)
                    
                    ist = pytz.timezone("Asia/Kolkata")
                    print(f"🕒 Data Updated: {datetime.now(ist).strftime('%Y-%m-%d %H:%M:%S')}")
                    
                    if ltp:
                        print(f"✅ Underlying LTP: {ltp}")
                    
                    if chain:
                        fy = fyersModel.FyersModel(
                            client_id=session_state.cid,
                            token=session_state.token,
                            is_async=False,
                            log_path=""
                        )
                        
                        # Sync order count
                        session_state.sync_order_count_with_fyers(fy)
                        
                        signal, atm, metrics = format_and_show(
                            chain,
                            f"Current Expiry: {curr_date}",
                            ltp,
                            show_signals=True,
                            fyers_api=fy,
                            session_state=session_state
                        )
                        
                        # Log data
                        if signal and ltp:
                            timestamp = datetime.now(ist).strftime("%Y-%m-%d %H:%M:%S")
                            metrics = metrics or {}
                            
                            data_logger.log_data(
                                timestamp=timestamp,
                                underlying_ltp=ltp,
                                atm_strike=atm,
                                expiry_date=curr_date,
                                dominant_option=metrics.get("dominant_option", ""),
                                option_score=metrics.get("option_score", 0.0),
                                underlying_score=metrics.get("underlying_score", 0.0),
                                signal=signal
                            )
                        
                        # Select strikes
                        buy_pe, sell_pe, buy_ce, sell_ce = select_strikes_atm_half_price(chain, atm)
                        
                        # Validate
                        valid_buy = (buy_ce is not None)
                        valid_sell = (buy_pe is not None)
                        
                        # Trading logic
                        if signal == "HOLD":
                            print("📊 HOLD → Maintaining positions")
                        
                        elif signal == "BUY" and not valid_buy:
                            print("⚠️ Missing ATM CE buy data for BUY signal")
                        
                        elif signal == "SELL" and not valid_sell:
                            print("⚠️ Missing ATM PE buy data for SELL signal")
                        
                        elif signal in ("BUY", "SELL"):
                            # Check daily limit
                            if not session_state.can_place_order(fy):
                                print("⛔ [DEBUG] Trade skipped - daily limit reached")
                                print("📊 HOLD → Daily order limit reached")
                            
                            elif session_state.live_last_signal == signal and has_open_orders_for_last_signal(fy, session_state):
                                print(f"ℹ️ ATM BUY for {signal} already open")
                            
                            else:
                                ids = handle_basket_orders_atomic(
                                    session_state, signal, sell_pe, buy_pe,
                                    sell_ce, buy_ce, fy, data_logger
                                )
                                session_state.live_last_signal = signal
                                session_state.live_last_signal_order_ids = ids
                        
                        elif signal == "SIDEWAYS":
                            handle_basket_orders_atomic(
                                session_state, signal, sell_pe, buy_pe,
                                sell_ce, buy_ce, fy, data_logger
                            )
                        
                        else:
                            print("ℹ️ No action")
                    
                    print(f"⏳ Waiting {Config.REFRESH_INTERVAL} seconds...")
                    wait_until_next_interval(Config.REFRESH_INTERVAL)
                    
            except KeyboardInterrupt:
                print("\n⏹️ Live trading stopped by user")
                input("Press Enter to continue...")
            
            except Exception as e:
                logging.exception("Error in live trading loop")
                print(f"❌ Error in live trading: {e}")
                input("Press Enter to continue...")
        
        elif choice == 2:  # Settings
            settings_menu(session_state)
        
        elif choice == 3:  # Generate Plot
            print("📊 Generating static plot...")
            plot_file = generate_static_plot()
            if plot_file:
                print(f"✅ Plot saved as: {plot_file}")
            input("Press Enter to continue...")
        
        elif choice == 4:  # Exit
            print("👋 Exiting... Goodbye!")
            break
        
        else:
            print("❌ Invalid option")
            input("Press Enter to continue...")


if __name__ == "__main__":
    main()
