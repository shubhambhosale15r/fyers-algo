import time
from datetime import datetime
import pytz
from fyers_apiv3 import fyersModel
from fyers_apiv3.FyersWebsocket import data_ws
import logging
import os
import json
import csv
import threading
import traceback
from collections import deque

# ============================================================
# PAPER TRADE FLAG
# ============================================================
PAPER_MODE = True   # Change to False for live trading

# When True, log_console() suppresses stdout prints (they would corrupt the
# dashboard's full-screen refresh). All messages still go to the log file
# and the in-memory event feed.
DASHBOARD_ACTIVE = False

# ============================================================
# CONFIGURATION
# ============================================================
class Config:
    SAMPLE_INTERVAL = 1                 # seconds between strategy evaluations
    OPTION_CHAIN_INTERVAL = 30          # seconds between option-chain REST polls

    SUBSCRIBE_STRIKE_RANGE = 10         # subscribe to ATM +/- this many strikes (CE+PE)
    PAIR_SEARCH_RANGE = 1               # only ATM, ATM+1, ATM-1 are scanned for the initial pair

    LOT_SIZE = 65
    LOTS_PER_LEG = 1                    # quantity multiplier per CE/PE leg, in lots

    TARGET_MULTIPLIER = 1.25            # target = entry_premium * 1.25  (i.e. +25%)

    MAX_DAILY_ENTRIES = 200             # safety cap: total leg BUYS (not pairs) allowed per day
    API_RATE_LIMIT = 200
    API_WINDOW = 60
    MAX_RETRIES = 3
    RETRY_DELAY = 2

    WS_HEARTBEAT_TIMEOUT = 10
    PRICE_STALE_SECONDS = 5             # reject ltp/bid/ask older than this for any decision

    # Auto square-off: after this time, no new pairs/replacements are opened and any
    # still-open legs are closed out (market sell) once, per the day.
    SQUAREOFF_HOUR = 15
    SQUAREOFF_MINUTE = 20

    EVENT_LOG_SIZE = 30                 # how many recent BUY/EXIT/state events the session keeps in memory

    # How long to poll the order book for a fill (LIVE mode only)
    FILL_POLL_ATTEMPTS = 10
    FILL_POLL_DELAY = 0.2

# ============================================================
# LOGGING
# ============================================================
logging.basicConfig(
    filename="trading_app.log",
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)

def log_debug(msg):
    logging.debug(msg)

def log_console(msg):
    # Suppress stdout while the dashboard is redrawing to avoid flicker.
    # Messages always go to the log file regardless.
    if not DASHBOARD_ACTIVE:
        print(msg, flush=True)
    logging.info(msg)

IST = pytz.timezone("Asia/Kolkata")

def now_ist():
    return datetime.now(IST)

def timestamp_ist():
    return now_ist().strftime("%Y-%m-%d %H:%M:%S")

def is_after_squareoff_time():
    now = now_ist()
    return (now.hour, now.minute) >= (Config.SQUAREOFF_HOUR, Config.SQUAREOFF_MINUTE)

def record_event(session, msg):
    """Log to console/log-file AND push into the session's short in-memory
    event history (kept for potential debugging; no longer rendered on the dashboard)."""
    log_console(msg)
    entry = f"{timestamp_ist()} | {msg}"
    with session.lock:
        session.event_log.append(entry)

# ============================================================
# ERROR HANDLER
# ============================================================
def handle_errors(func):
    def wrapper(*args, **kwargs):
        for retry in range(Config.MAX_RETRIES):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                log_debug(f"{func.__name__} attempt {retry+1} failed: {e}\n{traceback.format_exc()}")
                if retry < Config.MAX_RETRIES - 1:
                    time.sleep(Config.RETRY_DELAY)
                else:
                    log_debug(f"{func.__name__} permanently failed")
                    return None, None, None, None, []
    return wrapper

# ============================================================
# DATA LOGGER  (tick-by-tick snapshot, one row every SAMPLE_INTERVAL)
# ============================================================
class DataLogger:
    def __init__(self, filename="trading_data.csv"):
        self.filename = filename
        self._ensure_header()

    def _ensure_header(self):
        if not os.path.exists(self.filename):
            with open(self.filename, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'timestamp', 'strategy_state',
                    # market context
                    'spot_ltp', 'spot_stale', 'atm_strike', 'india_vix',
                    'fut_price', 'expiry_date',
                    # ATM reference quotes
                    'atm_ce_symbol', 'atm_ce_bid', 'atm_ce_ask',
                    'atm_pe_symbol', 'atm_pe_bid', 'atm_pe_ask',
                    # CE leg detail
                    'ce_symbol', 'ce_strike', 'ce_entry', 'ce_entry_time',
                    'ce_current', 'ce_bid', 'ce_ask', 'ce_target', 'ce_status',
                    'ce_unrealized_pnl',
                    # PE leg detail
                    'pe_symbol', 'pe_strike', 'pe_entry', 'pe_entry_time',
                    'pe_current', 'pe_bid', 'pe_ask', 'pe_target', 'pe_status',
                    'pe_unrealized_pnl',
                    # totals
                    'realized_pnl', 'unrealized_pnl', 'total_pnl',
                    'daily_entries', 'decision_reason'
                ])

    @staticmethod
    def _leg_fields(leg):
        if leg is None:
            return ('', 0, 0.0, '', 0.0, 0.0, 0.0, 0.0, 'NONE', 0.0)
        cur = leg.get('current_premium', leg.get('entry_premium', 0.0)) or 0.0
        entry = leg.get('entry_premium', 0.0) or 0.0
        pnl = (cur - entry) * Config.LOT_SIZE * Config.LOTS_PER_LEG
        return (
            leg.get('symbol', ''),
            leg.get('strike', 0) or 0,
            round(entry, 2),
            leg.get('entry_time', ''),
            round(cur, 2),
            round(leg.get('current_bid') or 0.0, 2),
            round(leg.get('current_ask') or 0.0, 2),
            round(leg.get('target_price', 0.0) or 0.0, 2),
            leg.get('status', 'OPEN'),
            round(pnl, 2),
        )

    def log_data(self, timestamp, strategy_state, spot_ltp, spot_stale,
                 atm_strike, india_vix, fut_price, expiry_date,
                 atm_ce_symbol, atm_ce_bid, atm_ce_ask,
                 atm_pe_symbol, atm_pe_bid, atm_pe_ask,
                 ce_leg, pe_leg,
                 realized_pnl, unrealized_pnl, total_pnl,
                 daily_entries, decision_reason):
        ce = self._leg_fields(ce_leg)
        pe = self._leg_fields(pe_leg)
        with open(self.filename, 'a', newline='') as f:
            w = csv.writer(f)
            w.writerow([
                str(timestamp), strategy_state,
                round(spot_ltp, 2) if spot_ltp else 0.0,
                int(bool(spot_stale)),
                atm_strike or 0,
                round(india_vix or 0.0, 2),
                round(fut_price or 0.0, 2),
                expiry_date or '',
                atm_ce_symbol or '', round(atm_ce_bid or 0.0, 2), round(atm_ce_ask or 0.0, 2),
                atm_pe_symbol or '', round(atm_pe_bid or 0.0, 2), round(atm_pe_ask or 0.0, 2),
                *ce,
                *pe,
                round(realized_pnl, 2), round(unrealized_pnl, 2), round(total_pnl, 2),
                daily_entries, decision_reason
            ])

# ============================================================
# TRADE LOGGER (one row per discrete BUY / EXIT event)
# ============================================================
class TradeLogger:
    def __init__(self, filename="trades_log.csv"):
        self.filename = filename
        self._ensure_header()

    def _ensure_header(self):
        if not os.path.exists(self.filename):
            with open(self.filename, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'timestamp', 'mode', 'event', 'option_type', 'symbol', 'strike',
                    'requested_price', 'fill_price', 'target_price',
                    'entry_time', 'hold_seconds',
                    'reason', 'trade_pnl',
                    'order_id', 'order_status',
                    'realized_pnl_after', 'daily_entries_after'
                ])

    def log_trade(self, event, option_type, symbol, strike,
                  requested_price, fill_price, reason, session,
                  target_price=0.0, trade_pnl=0.0,
                  entry_time='', order_id='', order_status=''):
        mode = "PAPER" if PAPER_MODE else "LIVE"
        hold_seconds = ''
        if event == 'EXIT' and entry_time:
            try:
                t0 = datetime.strptime(entry_time, "%Y-%m-%d %H:%M:%S")
                t1 = datetime.strptime(timestamp_ist(), "%Y-%m-%d %H:%M:%S")
                hold_seconds = int((t1 - t0).total_seconds())
            except Exception:
                hold_seconds = ''
        with open(self.filename, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                timestamp_ist(), mode, event, option_type, symbol, strike or 0,
                round(requested_price or 0.0, 2),
                round(fill_price or 0.0, 2),
                round(target_price or 0.0, 2),
                entry_time, hold_seconds,
                reason, round(trade_pnl, 2),
                order_id, order_status,
                round(session.realized_pnl, 2), session.daily_entries
            ])

# ============================================================
# SESSION STATE
# ============================================================
class SessionState:
    def __init__(self):
        self.lock = threading.RLock()
        self.option_chain_api_count = 0
        self.api_window_start = now_ist()
        self.cid = ""
        self.token = ""

        self.daily_entries = 0
        self.realized_pnl = 0.0
        self.eod_squareoff_done = False

        self.decision_reason = ""
        self.strategy_state = "INIT"        # FLAT_SEARCHING / PAIR_OPEN / SINGLE_LEG_OPEN / PAST_SQUAREOFF
        self.event_log = deque(maxlen=Config.EVENT_LOG_SIZE)
        self.running = False
        self._order_lock = False

        # Live tick storage. live_tick_time[symbol] is updated whenever ANY of
        # ltp/bid/ask changes for that symbol, and is used as the single
        # staleness marker for that symbol's whole quote.
        self.live_ltp = {}
        self.live_bid = {}
        self.live_ask = {}
        self.live_tick_time = {}

        self.india_vix = 15.0
        self.last_data_time = None

        # Option chain snapshot (REST poll, refreshed every OPTION_CHAIN_INTERVAL)
        self.option_chain = []
        self.fut_price = None
        self.expiry_date = None
        self.atm_strike = None
        self.option_symbols = []
        self.strike_to_symbols = {}   # strike -> [ce_symbol, pe_symbol]
        self.chain_last_refresh = None

        # The two legs we may be holding. Either can be None (flat on that side).
        self.legs = {"CE": None, "PE": None}

        self.current_ltp = 0.0

    def update_ws(self, symbol, ltp, bid, ask, vwap=None, volume=None):
        with self.lock:
            now = time.time()
            self.last_data_time = now
            changed = False
            if ltp is not None:
                self.live_ltp[symbol] = float(ltp)
                changed = True
            if bid is not None:
                self.live_bid[symbol] = float(bid)
                changed = True
            if ask is not None:
                self.live_ask[symbol] = float(ask)
                changed = True
            if changed:
                self.live_tick_time[symbol] = now

            if symbol == "NSE:INDIAVIX-INDEX":
                if ltp is not None:
                    self.india_vix = float(ltp)

    def get_ltp(self, symbol):
        with self.lock:
            return self.live_ltp.get(symbol)

    def get_ltp_time(self, symbol):
        with self.lock:
            return self.live_tick_time.get(symbol)

    def get_bid_ask_fresh(self, symbol):
        """Returns (bid, ask) only if this symbol ticked within PRICE_STALE_SECONDS, else (None, None)."""
        with self.lock:
            ts = self.live_tick_time.get(symbol)
            if ts is None or (time.time() - ts) > Config.PRICE_STALE_SECONDS:
                return None, None
            return self.live_bid.get(symbol), self.live_ask.get(symbol)

    def is_symbol_fresh(self, symbol):
        with self.lock:
            ts = self.live_tick_time.get(symbol)
            return ts is not None and (time.time() - ts) <= Config.PRICE_STALE_SECONDS

    def get_symbol_data_counts(self, recency_seconds=5):
        with self.lock:
            total = len(self.live_tick_time)
            now = time.time()
            recent = sum(1 for t in self.live_tick_time.values() if now - t <= recency_seconds)
            return total, recent

    def get_stale_symbols(self, recency_seconds=5):
        with self.lock:
            now = time.time()
            return sorted(s for s, t in self.live_tick_time.items() if now - t > recency_seconds)

    def update_chain(self, chain, fut_price, expiry_date, atm_strike, option_symbols):
        with self.lock:
            self.option_chain = chain
            self.fut_price = float(fut_price) if fut_price else 0.0
            self.expiry_date = expiry_date
            self.atm_strike = int(atm_strike) if atm_strike else None
            self.option_symbols = option_symbols
            self.chain_last_refresh = time.time()

            self.strike_to_symbols = {}
            for opt in chain:
                strike = opt.get("strike_price")
                if strike is None:
                    continue
                ot = opt.get("option_type")
                sym = opt.get("symbol")
                if strike not in self.strike_to_symbols:
                    self.strike_to_symbols[strike] = [None, None]
                if ot == "CE":
                    self.strike_to_symbols[strike][0] = sym
                elif ot == "PE":
                    self.strike_to_symbols[strike][1] = sym

    def has_open_legs(self):
        with self.lock:
            return self.legs["CE"] is not None or self.legs["PE"] is not None

    def reset_for_new_day(self):
        with self.lock:
            if self.has_open_legs():
                log_console("⚠️ Position(s) still tracked, not resetting.")
                return
            self.daily_entries = 0
            self.realized_pnl = 0.0
            self.eod_squareoff_done = False
            self.decision_reason = ""
            self.strategy_state = "INIT"
            self.event_log.clear()
            self.legs = {"CE": None, "PE": None}
            self.last_data_time = None
            self.live_ltp.clear()
            self.live_bid.clear()
            self.live_ask.clear()
            self.live_tick_time.clear()
            self.chain_last_refresh = None

# ============================================================
# WEBSOCKET MANAGER
# ============================================================
class MarketWSManager:
    def __init__(self, session_state, access_token):
        self.session = session_state
        self.access_token = access_token
        self.ws = None
        self.subscribed = set()
        self.subscribed_at = {}
        self.running = False
        self.ws_thread = None

    def on_message(self, message):
        symbol = message.get("symbol")
        if symbol:
            ltp = message.get("ltp")
            bid = message.get("bid_price")
            ask = message.get("ask_price")
            self.session.update_ws(symbol, ltp, bid, ask)

    def on_error(self, msg):
        log_console(f"WS error: {msg}")

    def on_close(self, msg):
        log_console(f"WS closed: {msg}. Automatic reconnection is enabled.")

    def on_open(self):
        log_console("✅ WebSocket on_open() triggered")
        if self.subscribed:
            self.ws.subscribe(list(self.subscribed), "SymbolUpdate")
        self.ws.keep_running()

    def _ws_connect(self):
        try:
            self.ws = data_ws.FyersDataSocket(
                access_token=self.access_token,
                log_path="",
                litemode=False,
                write_to_file=False,
                reconnect=True,
                on_connect=self.on_open,
                on_close=self.on_close,
                on_error=self.on_error,
                on_message=self.on_message
            )
            self.ws.connect()
        except Exception as e:
            log_console(f"❌ WebSocket connection thread crashed: {e}")
            log_debug(traceback.format_exc())
        finally:
            log_console("WebSocket thread finished.")

    def start(self):
        if self.running:
            return
        self.running = True
        self.ws_thread = threading.Thread(target=self._ws_connect, daemon=True)
        self.ws_thread.start()

    def subscribe(self, symbols):
        new_symbols = set(symbols) - self.subscribed
        if not new_symbols:
            return
        now = time.time()
        if self.ws:
            try:
                self.ws.subscribe(list(new_symbols), "SymbolUpdate")
            except Exception as e:
                log_console(f"⚠️ Subscribe request failed for {sorted(new_symbols)}: {e}")
                log_debug(traceback.format_exc())
        else:
            log_debug(f"subscribe() called before WS was ready; relying on on_open(): {sorted(new_symbols)}")
        self.subscribed.update(new_symbols)
        for s in new_symbols:
            self.subscribed_at.setdefault(s, now)

    def resubscribe(self, symbols):
        symbols = list(symbols)
        if not self.ws or not symbols:
            return
        try:
            self.ws.subscribe(symbols, "SymbolUpdate")
        except Exception as e:
            log_console(f"⚠️ Resubscribe failed for {symbols}: {e}")
            log_debug(traceback.format_exc())

    def stop(self):
        self.running = False
        if self.ws:
            self.ws.close_connection()
        if self.ws_thread and self.ws_thread.is_alive():
            self.ws_thread.join(timeout=2)

    def is_alive(self):
        return self.ws_thread and self.ws_thread.is_alive()

# ============================================================
# REST API
# ============================================================
def enforce_rate_limit(session):
    now = now_ist()
    window = (now - session.api_window_start).total_seconds()
    if window > Config.API_WINDOW:
        session.api_window_start = now
        session.option_chain_api_count = 0
    elif session.option_chain_api_count >= Config.API_RATE_LIMIT:
        wait = Config.API_WINDOW - window
        if wait > 0:
            time.sleep(wait)
        session.api_window_start = now
        session.option_chain_api_count = 0

@handle_errors
def fetch_option_chain(session, index_symbol, fyers):
    """Fetch ATM +/- SUBSCRIBE_STRIKE_RANGE strikes (CE+PE) for the 2nd-nearest upcoming expiry."""
    enforce_rate_limit(session)
    session.option_chain_api_count += 1
    meta = fyers.optionchain(data={"symbol": index_symbol, "timestamp": ""})
    if meta.get("code") != 200:
        return None, None, None, None, []

    fut_price = None
    for item in meta["data"]["optionsChain"]:
        if item.get("option_type") == "":
            fut_price = item.get("fp")
            break
    if fut_price is None:
        fut_price = meta["data"].get("fp", 0.0)

    exp_list = sorted([(e["date"], e["expiry"]) for e in meta["data"]["expiryData"]],
                      key=lambda x: datetime.strptime(x[0], "%d-%m-%Y"))
    today = now_ist().date()

    # Keep only expiries that haven't lapsed yet (today or later), in
    # ascending order: [nearest, 2nd-nearest, 3rd-nearest, ...].
    upcoming = [(d_str, ts) for (d_str, ts) in exp_list
                if datetime.strptime(d_str, "%d-%m-%Y").date() >= today]

    if not upcoming:
        log_debug("fetch_option_chain: no upcoming expiries returned by API")
        return None, None, None, None, []

    if len(upcoming) >= 2:
        curr_date, expiry_ts = upcoming[1]     # 2nd-nearest expiry (skip current/front expiry)
    else:
        curr_date, expiry_ts = upcoming[0]      # only one upcoming expiry available, fall back to it
        log_debug("fetch_option_chain: only one upcoming expiry available, using it instead of 2nd-nearest")

    payload = {
        "symbol": index_symbol,
        "strikecount": Config.SUBSCRIBE_STRIKE_RANGE,
        "timestamp": expiry_ts,
        "greeks": "1",
    }
    session.option_chain_api_count += 1
    resp = fyers.optionchain(data=payload)
    if resp.get("code") != 200:
        return None, None, None, None, []

    chain = resp["data"]["optionsChain"]
    for opt in chain:
        greeks = opt.get("greeks", {}) or {}
        opt["delta"] = greeks.get("delta", 0.0)
        opt["gamma"] = greeks.get("gamma", 0.0)
        opt["oi"] = opt.get("oi", 0)

    option_symbols = [opt["symbol"] for opt in chain if opt.get("option_type") in ("CE", "PE")]
    return chain, fut_price, curr_date, expiry_ts, option_symbols

# ============================================================
# CHAIN POLLER
# ============================================================
def chain_poller(session, ws_manager, index_symbol, fyers):
    while session.running:
        try:
            chain, fut_price, expiry_date, _, opt_symbols = fetch_option_chain(session, index_symbol, fyers)
            if chain is not None:
                underlying_ltp = session.get_ltp(index_symbol)
                if underlying_ltp is None:
                    underlying_ltp = fut_price
                strikes = sorted(set(opt["strike_price"] for opt in chain if opt.get("option_type") in ("CE", "PE")))
                if strikes and underlying_ltp:
                    atm = min(strikes, key=lambda x: abs(x - underlying_ltp))
                else:
                    atm = None
                session.update_chain(chain, fut_price, expiry_date, atm, opt_symbols)
                all_syms = [index_symbol, "NSE:INDIAVIX-INDEX"] + opt_symbols
                ws_manager.subscribe(all_syms)
            time.sleep(Config.OPTION_CHAIN_INTERVAL)
        except Exception as e:
            log_debug(f"Chain poller error: {e}\n{traceback.format_exc()}")
            time.sleep(Config.OPTION_CHAIN_INTERVAL)

# ============================================================
# STRATEGY HELPERS
# ============================================================
def get_strike_step(session):
    with session.lock:
        strikes = sorted(session.strike_to_symbols.keys())
    if len(strikes) < 2:
        return 50
    diffs = [b - a for a, b in zip(strikes, strikes[1:]) if b > a]
    return min(diffs) if diffs else 50

def get_pairing_candidate_strikes(session):
    """ATM, ATM+step, ATM-step -- i.e. ATM +/- PAIR_SEARCH_RANGE strikes."""
    atm = session.atm_strike
    if atm is None:
        return []
    step = get_strike_step(session)
    with session.lock:
        known_strikes = set(session.strike_to_symbols.keys())
    candidates = [atm]
    for i in range(1, Config.PAIR_SEARCH_RANGE + 1):
        candidates.append(atm + i * step)
        candidates.append(atm - i * step)
    return [s for s in candidates if s in known_strikes]

def get_atm_quotes(session):
    """Return (ce_symbol, ce_bid, ce_ask, pe_symbol, pe_bid, pe_ask) for the current ATM strike."""
    atm = session.atm_strike
    if atm is None:
        return None, None, None, None, None, None
    with session.lock:
        ce_sym, pe_sym = session.strike_to_symbols.get(atm, (None, None))
    ce_bid = ce_ask = pe_bid = pe_ask = None
    if ce_sym:
        ce_bid, ce_ask = session.get_bid_ask_fresh(ce_sym)
    if pe_sym:
        pe_bid, pe_ask = session.get_bid_ask_fresh(pe_sym)
    return ce_sym, ce_bid, ce_ask, pe_sym, pe_bid, pe_ask

def find_atm_pair(session):
    """
    Scan ATM, ATM+1, ATM-1 strikes. Return the first strike where
    int(ce_ask) == int(pe_ask), along with both symbols/asks.
    """
    for strike in get_pairing_candidate_strikes(session):
        with session.lock:
            ce_sym, pe_sym = session.strike_to_symbols.get(strike, (None, None))
        if not ce_sym or not pe_sym:
            continue
        _, ce_ask = session.get_bid_ask_fresh(ce_sym)
        _, pe_ask = session.get_bid_ask_fresh(pe_sym)
        if not ce_ask or not pe_ask or ce_ask <= 0 or pe_ask <= 0:
            continue
        if int(ce_ask) == int(pe_ask):
            return {
                "strike": strike,
                "ce_symbol": ce_sym, "pe_symbol": pe_sym,
                "ce_ask": ce_ask, "pe_ask": pe_ask,
            }
    return None

def find_replacement_leg(session, open_type, open_symbol):
    """
    The leg of type `open_type` is still open (hasn't hit target). Scan the
    WHOLE subscribed option chain (ATM +/- SUBSCRIBE_STRIKE_RANGE) for an
    option of the OPPOSITE type whose current ask, int()'d, matches the open
    leg's current ask, int()'d. Among ties, prefer the strike closest to ATM.
    """
    opp_type = "PE" if open_type == "CE" else "CE"
    _, open_ask = session.get_bid_ask_fresh(open_symbol)
    if not open_ask or open_ask <= 0:
        return None
    target_int = int(open_ask)

    atm = session.atm_strike or 0
    with session.lock:
        chain_snapshot = list(session.option_chain)

    best = None
    best_dist = None
    for opt in chain_snapshot:
        if opt.get("option_type") != opp_type:
            continue
        sym = opt.get("symbol")
        strike = opt.get("strike_price")
        if not sym or strike is None or sym == open_symbol:
            continue
        _, ask = session.get_bid_ask_fresh(sym)
        if not ask or ask <= 0:
            continue
        if int(ask) == target_int:
            dist = abs(strike - atm)
            if best is None or dist < best_dist:
                best = {"strike": strike, "symbol": sym, "ask": ask}
                best_dist = dist
    return best

# ============================================================
# ORDER EXECUTION
# ============================================================
def submit_market_order(fyers, symbol, side):
    order = {
        "symbol": symbol,
        "qty": Config.LOT_SIZE * Config.LOTS_PER_LEG,
        "type": 2,          # market order
        "side": side,        # 1 = buy, -1 = sell
        "productType": "MARGIN",
        "validity": "DAY",
    }
    return fyers.place_order(data=order)

def _get_fill_price(fyers, order_id, fallback_price):
    """Poll the order book until the order is filled, then return the traded price.
    Returns None if the order was rejected/cancelled; returns fallback if we
    can't confirm within the polling window (so we don't lock up)."""
    if not order_id:
        return fallback_price
    for _ in range(Config.FILL_POLL_ATTEMPTS):
        try:
            ob = fyers.orderbook(data={"id": order_id})
            if ob.get("s") == "ok" and ob.get("orderBook"):
                order = ob["orderBook"][0]
                status = str(order.get("status", ""))
                traded = order.get("tradedPrice") or order.get("avgTradedPrice") or 0
                # Fyers: 2 = filled, 5 = rejected, 6 = cancelled, 7 = expired
                if status == "2" and traded:
                    return float(traded)
                if status in ("5", "6", "7"):
                    log_console(f"❌ Order {order_id} terminal status={status}: {order.get('message', '')}")
                    return None
        except Exception as e:
            log_debug(f"_get_fill_price poll error: {e}")
        time.sleep(Config.FILL_POLL_DELAY)
    log_console(f"⚠️ Order {order_id} not confirmed filled within "
                f"{Config.FILL_POLL_ATTEMPTS * Config.FILL_POLL_DELAY:.1f}s; using fallback price")
    return fallback_price

def buy_leg(session, fyers, trade_logger, option_type, symbol, strike, ask_price):
    """Buy one leg (CE or PE) at (approximately) the observed ask price."""
    requested_price = float(ask_price)
    order_id, order_status = "", ""
    if PAPER_MODE:
        entry_premium = requested_price
    else:
        resp = submit_market_order(fyers, symbol, side=1)
        if not resp or resp.get("s") != "ok":
            log_console(f"❌ LIVE BUY failed for {symbol}: {resp}")
            return None
        order_id = resp.get("id", "")
        log_console(f"🟢 LIVE BUY submitted {symbol} | Order ID: {order_id}")
        fill = _get_fill_price(fyers, order_id, requested_price)
        if fill is None:
            log_console(f"❌ LIVE BUY order {order_id} did not fill; aborting leg")
            return None
        entry_premium = fill
        order_status = "FILLED"

    target_price = entry_premium * Config.TARGET_MULTIPLIER
    leg = {
        "option_type": option_type,
        "symbol": symbol,
        "strike": strike,
        "entry_premium": entry_premium,
        "target_price": target_price,
        "current_premium": entry_premium,
        "current_bid": None,
        "current_ask": requested_price,
        "entry_time": timestamp_ist(),
        "status": "OPEN",
        "entry_order_id": order_id,
    }
    session.legs[option_type] = leg
    session.daily_entries += 1

    mode_tag = "PAPER" if PAPER_MODE else "LIVE"
    record_event(
        session,
        f"🟢 {mode_tag} BUY {option_type} {symbol} @ {entry_premium:.2f} "
        f"(req {requested_price:.2f}) | Strike={strike} | "
        f"Target(+{(Config.TARGET_MULTIPLIER - 1) * 100:.0f}%)={target_price:.2f}"
    )
    if trade_logger is not None:
        trade_logger.log_trade(
            event="BUY", option_type=option_type, symbol=symbol, strike=strike,
            requested_price=requested_price, fill_price=entry_premium,
            reason="ENTRY", session=session, target_price=target_price,
            trade_pnl=0.0, order_id=order_id, order_status=order_status,
        )
    return leg

def close_leg(session, fyers, trade_logger, option_type, leg, requested_price, reason):
    """Sell out one leg. Returns True on success."""
    order_id, order_status = "", ""
    if PAPER_MODE:
        exit_premium = requested_price
    else:
        resp = submit_market_order(fyers, leg["symbol"], side=-1)
        if not resp or resp.get("s") != "ok":
            log_console(f"❌ LIVE SELL failed for {leg['symbol']}: {resp}; "
                        f"leg left open, will retry next tick")
            return False
        order_id = resp.get("id", "")
        log_console(f"🔴 LIVE EXIT submitted {option_type} {leg['symbol']} | "
                    f"Reason={reason} | Order ID: {order_id}")
        fill = _get_fill_price(fyers, order_id, requested_price)
        if fill is None:
            log_console(f"❌ LIVE SELL order {order_id} did not fill; leg left open")
            return False
        exit_premium = fill
        order_status = "FILLED"

    pnl = (exit_premium - leg["entry_premium"]) * Config.LOT_SIZE * Config.LOTS_PER_LEG
    session.realized_pnl += pnl

    mode_tag = "PAPER" if PAPER_MODE else "LIVE"
    record_event(
        session,
        f"🔴 {mode_tag} EXIT {option_type} {leg['symbol']} | Reason={reason} | "
        f"Entry={leg['entry_premium']:.2f} Exit={exit_premium:.2f} (req {requested_price:.2f}) "
        f"| P&L={pnl:+.2f}"
    )
    if trade_logger is not None:
        trade_logger.log_trade(
            event="EXIT", option_type=option_type, symbol=leg["symbol"],
            strike=leg.get("strike"),
            requested_price=requested_price, fill_price=exit_premium,
            reason=reason, session=session,
            target_price=leg.get("target_price", 0.0), trade_pnl=pnl,
            entry_time=leg.get("entry_time", ""),
            order_id=order_id, order_status=order_status,
        )
    session.legs[option_type] = None
    return True

def square_off_all(session, fyers, trade_logger, reason="EOD_SQUAREOFF"):
    for option_type in ("CE", "PE"):
        leg = session.legs.get(option_type)
        if leg is None or leg.get("status") != "OPEN":
            continue
        bid, _ = session.get_bid_ask_fresh(leg["symbol"])
        ltp = session.get_ltp(leg["symbol"])
        exit_premium = bid if bid else (ltp if ltp else leg["entry_premium"])
        close_leg(session, fyers, trade_logger, option_type, leg, exit_premium, reason)

# ============================================================
# STATE MACHINE
# ============================================================
def manage_strategy(session, fyers, trade_logger, execute_trades=False):
    """
    Strategy:

      FLAT (no legs open):
        Scan ATM, ATM+1, ATM-1. If a strike's CE ask and PE ask, int()'d,
        are equal -> buy both CE and PE of that strike. Set each leg's
        target = entry_premium * 1.25.

      PAIR OPEN (both legs open):
        Hold. Every tick, check whether either leg's price has reached its
        own target.

      ONE LEG OPEN (the other already hit target and was closed):
        Take the open leg's current ask, int() it, and scan the WHOLE
        subscribed option chain (ATM +/- SUBSCRIBE_STRIKE_RANGE) for an
        option of the OPPOSITE type whose ask, int()'d, matches. Buy it,
        set its own 25% target, and go back to "PAIR OPEN".

      EOD (after SQUAREOFF_HOUR:SQUAREOFF_MINUTE):
        No new pairs/replacements. Any legs still open are squared off once.
    """
    if getattr(session, '_order_lock', False):
        return
    session._order_lock = True
    try:
        with session.lock:
            spot = session.get_ltp("NSE:NIFTY50-INDEX")
            if spot is not None and spot > 0:
                session.current_ltp = spot

            # ---- EOD square-off guard ----
            if is_after_squareoff_time():
                session.strategy_state = "PAST_SQUAREOFF"
                if session.has_open_legs():
                    if execute_trades:
                        if not session.eod_squareoff_done:
                            square_off_all(session, fyers, trade_logger, reason="EOD_SQUAREOFF")
                        if not session.has_open_legs():
                            session.eod_squareoff_done = True
                            session.decision_reason = "EOD square-off complete"
                        else:
                            session.decision_reason = "EOD square-off: one or more legs failed to close, will retry"
                    else:
                        session.decision_reason = "Past square-off time with open legs; auto-trade disabled, close manually"
                else:
                    session.eod_squareoff_done = True
                    session.decision_reason = "Past square-off time; flat, no new entries today"
                return

            if session.atm_strike is None:
                session.decision_reason = "Waiting for option chain / ATM strike"
                return

            # ---- 1. Manage any open legs: check target hits ----
            for option_type in ("CE", "PE"):
                leg = session.legs.get(option_type)
                if leg is None or leg.get("status") != "OPEN":
                    continue

                ltp = session.get_ltp(leg["symbol"])
                bid, ask = session.get_bid_ask_fresh(leg["symbol"])
                if ltp is not None:
                    leg["current_premium"] = ltp
                leg["current_bid"] = bid
                leg["current_ask"] = ask

                check_price = bid if bid is not None else ltp
                if check_price is not None and check_price >= leg["target_price"]:
                    if execute_trades:
                        close_leg(session, fyers, trade_logger, option_type, leg, check_price, "TARGET_HIT")
                    else:
                        session.decision_reason = (
                            f"{option_type} target reached ({check_price:.2f} >= "
                            f"{leg['target_price']:.2f}); auto-trade disabled, not closing"
                        )

            ce_leg = session.legs.get("CE")
            pe_leg = session.legs.get("PE")

            # ---- 2. Flat on both sides: search a fresh ATM+/-1 pair ----
            if ce_leg is None and pe_leg is None:
                session.strategy_state = "FLAT_SEARCHING"
                if session.daily_entries >= Config.MAX_DAILY_ENTRIES:
                    session.decision_reason = "Max daily entries reached; flat, no new pair"
                    return

                found = find_atm_pair(session)
                if found is None:
                    session.decision_reason = (
                        f"FLAT | Scanning ATM strikes for CE/PE ask match (ATM={session.atm_strike})"
                    )
                    return

                if not execute_trades:
                    session.decision_reason = (
                        f"Pair found at strike {found['strike']} (CE ask={found['ce_ask']:.2f}, "
                        f"PE ask={found['pe_ask']:.2f}); auto-trade disabled"
                    )
                    return

                ce_ok = buy_leg(session, fyers, trade_logger, "CE",
                                found["ce_symbol"], found["strike"], found["ce_ask"])
                pe_ok = buy_leg(session, fyers, trade_logger, "PE",
                                found["pe_symbol"], found["strike"], found["pe_ask"])
                if ce_ok and pe_ok:
                    session.strategy_state = "PAIR_OPEN"
                    session.decision_reason = f"Entered new CE+PE pair at strike {found['strike']}"
                elif ce_ok or pe_ok:
                    session.strategy_state = "SINGLE_LEG_OPEN"
                    session.decision_reason = (
                        f"Partial entry at strike {found['strike']} "
                        f"(CE={'ok' if ce_ok else 'fail'}, PE={'ok' if pe_ok else 'fail'})"
                    )
                else:
                    session.decision_reason = f"Both legs failed to open at strike {found['strike']}"
                return

            # ---- 3. Both legs open: just hold and monitor ----
            if ce_leg is not None and pe_leg is not None:
                session.strategy_state = "PAIR_OPEN"
                session.decision_reason = (
                    f"Holding pair | CE {ce_leg['symbol']} "
                    f"E={ce_leg['entry_premium']:.2f}/C={ce_leg['current_premium']:.2f}/T={ce_leg['target_price']:.2f} | "
                    f"PE {pe_leg['symbol']} "
                    f"E={pe_leg['entry_premium']:.2f}/C={pe_leg['current_premium']:.2f}/T={pe_leg['target_price']:.2f}"
                )
                return

            # ---- 4. Exactly one leg open: search a replacement of the opposite type ----
            session.strategy_state = "SINGLE_LEG_OPEN"
            open_type = "CE" if ce_leg is not None else "PE"
            open_leg = ce_leg if ce_leg is not None else pe_leg
            opp_type = "PE" if open_type == "CE" else "CE"

            if session.daily_entries >= Config.MAX_DAILY_ENTRIES:
                session.decision_reason = (
                    f"Holding lone {open_type} {open_leg['symbol']} "
                    f"(C={open_leg['current_premium']:.2f}/T={open_leg['target_price']:.2f}); "
                    f"max daily entries reached, no replacement search"
                )
                return

            replacement = find_replacement_leg(session, open_type, open_leg["symbol"])
            if replacement is None:
                cur_ask = open_leg.get("current_ask") or 0.0
                session.decision_reason = (
                    f"Holding lone {open_type} {open_leg['symbol']} "
                    f"(C={open_leg['current_premium']:.2f}/Ask={cur_ask:.2f}/"
                    f"T={open_leg['target_price']:.2f}); searching {opp_type} with matching ask int()"
                )
                return

            if not execute_trades:
                session.decision_reason = (
                    f"Replacement {opp_type} found (strike {replacement['strike']}, "
                    f"ask={replacement['ask']:.2f}); auto-trade disabled"
                )
                return

            ok = buy_leg(session, fyers, trade_logger, opp_type,
                         replacement["symbol"], replacement["strike"], replacement["ask"])
            if ok:
                session.strategy_state = "PAIR_OPEN"
                session.decision_reason = (
                    f"Replacement {opp_type} bought at strike {replacement['strike']} "
                    f"(ask={replacement['ask']:.2f}), re-paired with open {open_type}"
                )
            else:
                session.decision_reason = f"Replacement {opp_type} buy failed; will retry"
            return

    except Exception as e:
        log_console(f"manage_strategy error: {e}")
        log_debug(traceback.format_exc())
        session.decision_reason = f"Error: {str(e)}"
    finally:
        session._order_lock = False

# ============================================================
# SAMPLER THREAD
# ============================================================
def sampler(session, data_logger, trade_logger, auto_trade, fyers):
    log_debug("Sampler thread started")
    while session.running:
        start = now_ist()
        try:
            manage_strategy(session, fyers, trade_logger, execute_trades=auto_trade)

            spot = session.get_ltp("NSE:NIFTY50-INDEX")
            spot_stale = not session.is_symbol_fresh("NSE:NIFTY50-INDEX")
            atm_ce_sym, atm_ce_bid, atm_ce_ask, atm_pe_sym, atm_pe_bid, atm_pe_ask = get_atm_quotes(session)

            with session.lock:
                ce_leg = dict(session.legs["CE"]) if session.legs["CE"] else None
                pe_leg = dict(session.legs["PE"]) if session.legs["PE"] else None
                atm_strike = session.atm_strike
                realized_pnl = session.realized_pnl
                daily_entries = session.daily_entries
                decision_reason = session.decision_reason
                strategy_state = session.strategy_state
                vix = session.india_vix
                fut_price = session.fut_price
                expiry_date = session.expiry_date

                unrealized_pnl = 0.0
                for leg in (ce_leg, pe_leg):
                    if leg:
                        cur = leg.get("current_premium", leg["entry_premium"])
                        unrealized_pnl += (cur - leg["entry_premium"]) * Config.LOT_SIZE * Config.LOTS_PER_LEG
                total_pnl = realized_pnl + unrealized_pnl

            data_logger.log_data(
                timestamp=timestamp_ist(),
                strategy_state=strategy_state,
                spot_ltp=spot or session.current_ltp,
                spot_stale=spot_stale,
                atm_strike=atm_strike,
                india_vix=vix,
                fut_price=fut_price,
                expiry_date=expiry_date,
                atm_ce_symbol=atm_ce_sym, atm_ce_bid=atm_ce_bid, atm_ce_ask=atm_ce_ask,
                atm_pe_symbol=atm_pe_sym, atm_pe_bid=atm_pe_bid, atm_pe_ask=atm_pe_ask,
                ce_leg=ce_leg, pe_leg=pe_leg,
                realized_pnl=realized_pnl, unrealized_pnl=unrealized_pnl,
                total_pnl=total_pnl, daily_entries=daily_entries,
                decision_reason=decision_reason,
            )

            elapsed = (now_ist() - start).total_seconds()
            if elapsed < Config.SAMPLE_INTERVAL:
                time.sleep(Config.SAMPLE_INTERVAL - elapsed)
        except Exception as e:
            log_debug(f"Sampler error: {e}\n{traceback.format_exc()}")
            time.sleep(1)

# ============================================================
# DASHBOARD (RECENT EVENTS panel removed)
# ============================================================
class TerminalDashboard:
    def __init__(self, data_logger, session_state):
        self.data_logger = data_logger
        self.session_state = session_state

    @staticmethod
    def _leg_line(label, leg):
        if leg is None:
            return f"  {label}: -- (flat)"
        pnl = (leg.get("current_premium", leg["entry_premium"]) - leg["entry_premium"]) \
              * Config.LOT_SIZE * Config.LOTS_PER_LEG
        return (
            f"  {label}: {leg['symbol']} (K={leg['strike']}) | "
            f"E={leg['entry_premium']:.2f} C={leg.get('current_premium', 0.0):.2f} "
            f"B={leg.get('current_bid') or 0.0:.2f} A={leg.get('current_ask') or 0.0:.2f} | "
            f"T={leg['target_price']:.2f} | P&L={pnl:+.2f} | {leg.get('status', 'OPEN')}"
        )

    @staticmethod
    def _flow_banner(state):
        steps = [
            ("FLAT_SEARCHING", "① FLAT (scan ATM±1)"),
            ("PAIR_OPEN", "② PAIR OPEN (hold / watch target)"),
            ("SINGLE_LEG_OPEN", "③ ONE LEG OPEN (scan full chain)"),
            ("PAST_SQUAREOFF", "④ EOD SQUARE-OFF"),
        ]
        parts = []
        for key, label in steps:
            if state == key:
                parts.append(f"[ ➤ {label} ]")
            else:
                parts.append(f"  {label}  ")
        return "  →  ".join(parts)

    def display(self):
        try:
            os.system('cls' if os.name == 'nt' else 'clear')
            mode = "PAPER" if PAPER_MODE else "LIVE"
            print("\n" + "=" * 100)
            print(f"📊 {mode} TRADING DASHBOARD – CE/PE Ask-Matched Pairing Strategy".center(100))
            print("=" * 100)

            with self.session_state.lock:
                daily_entries = self.session_state.daily_entries
                vix = self.session_state.india_vix
                realized = self.session_state.realized_pnl
                decision_reason = self.session_state.decision_reason
                strategy_state = self.session_state.strategy_state
                ltp = self.session_state.current_ltp
                atm_strike = self.session_state.atm_strike
                fut_price = self.session_state.fut_price
                expiry_date = self.session_state.expiry_date
                ce_leg = dict(self.session_state.legs["CE"]) if self.session_state.legs["CE"] else None
                pe_leg = dict(self.session_state.legs["PE"]) if self.session_state.legs["PE"] else None
                last_data = self.session_state.last_data_time
                last_data_str = datetime.fromtimestamp(last_data).strftime("%H:%M:%S") if last_data else "No data yet"
                total_symbols, active_symbols = self.session_state.get_symbol_data_counts(5)
                stale_symbols = self.session_state.get_stale_symbols(5)
                pairing_strikes = get_pairing_candidate_strikes(self.session_state)
                chain_age = (time.time() - self.session_state.chain_last_refresh) \
                             if self.session_state.chain_last_refresh else None

            atm_ce_sym, atm_ce_bid, atm_ce_ask, atm_pe_sym, atm_pe_bid, atm_pe_ask = get_atm_quotes(self.session_state)

            unrealized = 0.0
            for leg in (ce_leg, pe_leg):
                if leg:
                    unrealized += (leg.get("current_premium", leg["entry_premium"]) - leg["entry_premium"]) \
                                  * Config.LOT_SIZE * Config.LOTS_PER_LEG
            total_pnl = realized + unrealized

            # ---- Flow banner ----
            print("\n" + self._flow_banner(strategy_state))

            print("\n" + "-" * 100)
            print("🕒 SESSION")
            print("-" * 100)
            print(f"  Now: {timestamp_ist()}  |  WS Last Data: {last_data_str}  "
                  f"|  Chain refresh: {f'{chain_age:.1f}s ago' if chain_age is not None else 'n/a'}")
            print(f"  📡 Symbol feed: total={total_symbols}, active(≤5s)={active_symbols}")
            if stale_symbols:
                shown = ', '.join(stale_symbols[:5])
                more = f" (+{len(stale_symbols) - 5} more)" if len(stale_symbols) > 5 else ""
                print(f"     ⚠️ Stale >5s: {shown}{more}")
            sq = "PAST" if is_after_squareoff_time() else "not yet"
            print(f"  ⏱️ Square-off {Config.SQUAREOFF_HOUR:02d}:{Config.SQUAREOFF_MINUTE:02d} IST ({sq})  "
                  f"|  📈 Daily Entries: {daily_entries}/{Config.MAX_DAILY_ENTRIES}")

            print("\n" + "-" * 100)
            print("📊 MARKET SNAPSHOT")
            print("-" * 100)
            print(f"  NIFTY LTP: {ltp:.2f}  |  ATM: {atm_strike}  |  Fut: {fut_price or 0:.2f}  "
                  f"|  Expiry: {expiry_date or '--'}  |  VIX: {vix:.2f}")
            print(f"  Pairing candidates (ATM ±{Config.PAIR_SEARCH_RANGE}): {pairing_strikes}")
            print(f"  ATM ref  CE: {atm_ce_sym or '--'}  "
                  f"Bid={atm_ce_bid if atm_ce_bid is not None else 0:.2f}  "
                  f"Ask={atm_ce_ask if atm_ce_ask is not None else 0:.2f}")
            print(f"           PE: {atm_pe_sym or '--'}  "
                  f"Bid={atm_pe_bid if atm_pe_bid is not None else 0:.2f}  "
                  f"Ask={atm_pe_ask if atm_pe_ask is not None else 0:.2f}")
            if atm_ce_ask and atm_pe_ask:
                flag = "✅ MATCH" if int(atm_ce_ask) == int(atm_pe_ask) else "—"
                print(f"           int(CE ask)={int(atm_ce_ask)}  int(PE ask)={int(atm_pe_ask)}  {flag}")

            print("\n" + "-" * 100)
            print("📌 LEGS")
            print("-" * 100)
            print(self._leg_line("CE", ce_leg))
            print(self._leg_line("PE", pe_leg))
            print(f"  💰 Realized: {realized:+.2f}  |  Unrealized: {unrealized:+.2f}  |  Total: {total_pnl:+.2f}")

            print("\n" + "-" * 100)
            print("🧠 CURRENT DECISION")
            print("-" * 100)
            print(f"  {decision_reason}")

            print("\n" + "-" * 100)
            print("⚙️ CONFIGURATION")
            print("-" * 100)
            print(f"  Subscribe range: ATM ±{Config.SUBSCRIBE_STRIKE_RANGE} strikes  |  "
                  f"Pairing scan: ATM ±{Config.PAIR_SEARCH_RANGE} strikes")
            print(f"  Target: entry × {Config.TARGET_MULTIPLIER} (+{(Config.TARGET_MULTIPLIER - 1) * 100:.0f}%)  |  "
                  f"Lots/leg: {Config.LOTS_PER_LEG}  |  Lot size: {Config.LOT_SIZE}")
            print("  CSV: trading_data.csv (tick-by-tick)  |  trades_log.csv (BUY/EXIT events)")

            print("\n" + "=" * 100)
        except Exception as e:
            log_debug(f"Dashboard error: {e}")

# ============================================================
# HEARTBEAT MONITOR
# ============================================================
def heartbeat_monitor(session, ws_manager, index_symbol):
    while session.running:
        time.sleep(Config.WS_HEARTBEAT_TIMEOUT // 2)

        last_ts = session.get_ltp_time(index_symbol)
        if last_ts is not None and (time.time() - last_ts) > Config.WS_HEARTBEAT_TIMEOUT:
            log_console(f"⚠️ NIFTY LTP stale for >{Config.WS_HEARTBEAT_TIMEOUT}s, forcing WS restart...")
            ws_manager.stop()
            time.sleep(2)
            ws_manager.start()
            if ws_manager.subscribed:
                ws_manager.subscribe(list(ws_manager.subscribed))
            continue

        now = time.time()
        stale = set()
        for sym in ws_manager.subscribed:
            if sym == index_symbol:
                continue
            ts = session.get_ltp_time(sym)
            if ts is not None:
                if (now - ts) > Config.WS_HEARTBEAT_TIMEOUT:
                    stale.add(sym)
            else:
                subscribed_at = ws_manager.subscribed_at.get(sym)
                if subscribed_at is not None and (now - subscribed_at) > Config.WS_HEARTBEAT_TIMEOUT:
                    stale.add(sym)

        if stale:
            log_console(f"⚠️ {len(stale)} symbol(s) stale/never-arrived, resubscribing: {sorted(stale)}")
            ws_manager.resubscribe(stale)

# ============================================================
# CREDENTIALS & MAIN
# ============================================================
def load_credentials(session):
    try:
        with open('fyers_credentials.json', 'r') as f:
            creds = json.load(f)
            session.cid = creds.get('client_id', '')
            session.token = creds.get('access_token', '')
        log_console(f"Loaded credentials: {session.cid}")
    except Exception as e:
        log_console(f"Failed to load credentials file: {e} – falling back to env vars")
        session.cid = os.getenv("FYERS_CID", "")
        session.token = os.getenv("FYERS_TOKEN", "")
        log_console(f"Using env vars: {session.cid}")

def main():
    global DASHBOARD_ACTIVE
    log_console("Starting CE/PE Ask-Matched Pairing Strategy...")
    session = SessionState()
    load_credentials(session)
    data_logger = DataLogger()
    trade_logger = TradeLogger()
    dashboard = TerminalDashboard(data_logger, session)
    index_symbol = "NSE:NIFTY50-INDEX"
    vix_symbol = "NSE:INDIAVIX-INDEX"

    poller_thread = None
    sampler_thread = None
    heartbeat_thread = None
    ws_manager = None
    fyers = None

    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        print("=" * 50)
        mode = "PAPER" if PAPER_MODE else "LIVE"
        print(f"📈 FYERS ALGO TRADING ({mode} MODE)")
        print("1. Start Trading")
        print("2. Settings")
        print("3. Exit")
        choice = input("Select option: ").strip()

        if choice == "1":
            if not (session.cid and session.token):
                print("❌ Set credentials first")
                input("Press Enter...")
                continue

            session.reset_for_new_day()

            auto_trade = input("Enable Auto Trade? (y/n): ").lower() == 'y'
            log_console(f"Auto trade: {'ON' if auto_trade else 'OFF'}")

            ws_manager = MarketWSManager(session, session.token)
            ws_manager.start()
            ws_manager.subscribe([index_symbol, vix_symbol])
            session.running = True

            fyers = fyersModel.FyersModel(client_id=session.cid, token=session.token,
                                          is_async=False, log_path="")
            poller_thread = threading.Thread(target=chain_poller,
                                             args=(session, ws_manager, index_symbol, fyers), daemon=True)
            sampler_thread = threading.Thread(target=sampler,
                                              args=(session, data_logger, trade_logger, auto_trade, fyers), daemon=True)
            heartbeat_thread = threading.Thread(target=heartbeat_monitor,
                                                args=(session, ws_manager, index_symbol), daemon=True)

            poller_thread.start()
            sampler_thread.start()
            heartbeat_thread.start()

            print("\n✅ Trading started. Press Ctrl+C to stop.\n")
            time.sleep(1)
            DASHBOARD_ACTIVE = True   # suppress stdout logs from here on
            try:
                while True:
                    dashboard.display()
                    time.sleep(1)
            except KeyboardInterrupt:
                DASHBOARD_ACTIVE = False
                log_console("\n🛑 Stopping trading...")
                session.running = False
                ws_manager.stop()

                if sampler_thread is not None:
                    sampler_thread.join(timeout=5)
                if poller_thread is not None:
                    poller_thread.join(timeout=Config.OPTION_CHAIN_INTERVAL + 5)
                if heartbeat_thread is not None:
                    heartbeat_thread.join(timeout=2)

                if session.has_open_legs():
                    log_console("Attempting to close open leg(s) before exit...")
                    square_off_all(session, fyers, trade_logger, reason="MANUAL_STOP")

                with session.lock:
                    if session.has_open_legs():
                        log_console("⚠️ Some leg(s) could not be closed. Check broker manually.")
                    else:
                        session.eod_squareoff_done = False
                        session.daily_entries = 0
                        session.realized_pnl = 0.0
                        log_console("✅ Trading stopped and state reset. You can start again.")

        elif choice == "2":
            print("\n⚙️ SETTINGS")
            new_cid = input(f"Client ID [{session.cid}]: ").strip()
            if new_cid:
                session.cid = new_cid
            new_token = input("Access token: ").strip()
            if new_token:
                session.token = new_token
            with open('fyers_credentials.json', 'w') as f:
                json.dump({"client_id": session.cid, "access_token": session.token}, f)
            print("✅ Saved")
            input("Press Enter...")

        elif choice == "3":
            if session.running:
                session.running = False
                if ws_manager:
                    ws_manager.stop()
            if session.has_open_legs():
                log_console("⚠️ Exiting with position(s) still tracked.")
            break

if __name__ == "__main__":
    main()