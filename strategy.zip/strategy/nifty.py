"""
Today's ATM CE / PE N-minute return, OI change and Buildup/Unwinding tags.

  python atm_today.py                # backfill today, 5-min bars (default)
  python atm_today.py --tf 15        # backfill today, 15-min bars
  python atm_today.py --live --tf 10 # log the option chain every 10 min to CSV (for future days)

Timeframe (--tf, in minutes) must be one Fyers supports: 1, 2, 3, 5, 10, 15, 20, 30, 60, 120, 240.
Or just change DEFAULT_TF below.

NOTE: optionchain's `timestamp` param is the EXPIRY epoch (from expiryData), NOT a clock time.
      The chain is live-only, so past bars come from history(oi_flag=1).

Set your token before running:
  Windows (cmd):   set FYERS_TOKEN=your_token
  Linux / macOS:   export FYERS_TOKEN=your_token
"""
import math, os, sys, time
import numpy as np
import pandas as pd
from fyers_apiv3 import fyersModel

CLIENT_ID = "J0ENYFX9ME-200"
ACCESS_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOlsiZDoxIiwiZDoyIiwieDowIiwieDoxIiwieDoyIl0sImF0X2hhc2giOiJnQUFBQUFCcXZwLXlUUmdZU2ptakhIbG92NDRtQUZ1QjVJUElhRUtGZlJmM01rTVJ3SkxlRkdVbGhtYVIzRmcwdFZSQUIzTUJsYU5mQTJxVVI5Q2hWLWJBakhLbU5xTGxCVzloNmZpeWVWR3hfSF9oeWxlS1cyND0iLCJkaXNwbGF5X25hbWUiOiIiLCJvbXMiOiJLMSIsImhzbV9rZXkiOiIyZDA2MWI2YmI5NjIxOTQwOGM2MDg5MWIzMjdiNTlkYmY3YTdiN2RlZGZhNWQ5OWNiZWI5YTU3NyIsImlzRGRwaUVuYWJsZWQiOiJOIiwiaXNNdGZFbmFibGVkIjoiTiIsImZ5X2lkIjoiRkFBMzE0OTUiLCJhcHBUeXBlIjoyMDAsImV4cCI6MTc5MDkwMTAwMCwiaWF0IjoxNzkwODc3NjE4LCJpc3MiOiJhcGkuZnllcnMuaW4iLCJuYmYiOjE3OTA4Nzc2MTgsInN1YiI6ImFjY2Vzc190b2tlbiJ9.y9S3nzZopW8z2ncmqvdhaZyyOaPV_f63bxUK002Ehdw"


fyers = fyersModel.FyersModel(client_id=CLIENT_ID, token=ACCESS_TOKEN,
                              is_async=False, log_path="")

UNDERLYING = "NSE:NIFTY50-INDEX"
STEP, TZ = 50, "Asia/Kolkata"

# ------------------------------------------------------------ timeframe
DEFAULT_TF = 15                                    # minutes per bar (change here, or pass --tf N)
VALID_TF = (1, 2, 3, 5, 10, 15, 20, 30, 60, 120, 240)


def get_tf():
    tf = DEFAULT_TF
    for i, a in enumerate(sys.argv):
        if a == "--tf" and i + 1 < len(sys.argv):
            tf = int(sys.argv[i + 1])
        elif a.startswith("--tf="):
            tf = int(a.split("=", 1)[1])
    if tf not in VALID_TF:
        raise SystemExit(f"--tf must be one of {VALID_TF}, got {tf}")
    return tf


TF = get_tf()
OUT = f"atm_today_{TF}m.csv"


# ------------------------------------------------------------- option chain
def nearest_expiry():
    r = fyers.optionchain(data={"symbol": UNDERLYING, "strikecount": 1, "timestamp": ""})
    if r.get("s") != "ok":
        raise RuntimeError(r)
    today = pd.Timestamp.now(tz=TZ).normalize().tz_localize(None)
    for e in r["data"]["expiryData"]:                       # already sorted by date
        if pd.to_datetime(e["date"], format="%d-%m-%Y") >= today:
            return e["expiry"], e["date"]
    raise RuntimeError("no live expiry found")


def chain(expiry_epoch, strikecount=10):
    """Return spot and {strike: {CE:{ltp,oi,symbol}, PE:{...}}} for the given expiry."""
    r = fyers.optionchain(data={"symbol": UNDERLYING, "strikecount": strikecount,
                                "timestamp": str(expiry_epoch)})
    if r.get("s") != "ok":
        raise RuntimeError(r)
    spot, strikes = None, {}
    for row in r["data"]["optionsChain"]:
        if row.get("strike_price") == -1:
            spot = row["ltp"]
        else:
            strikes.setdefault(int(row["strike_price"]), {})[row["option_type"]] = dict(
                ltp=row["ltp"], oi=row["oi"], symbol=row["symbol"])
    return spot, strikes


# ----------------------------------------------------------------- history
def history_5m(symbol, day, oi=False):
    r = fyers.history(data={"symbol": symbol, "resolution": str(TF), "date_format": "1",
                            "range_from": day, "range_to": day, "cont_flag": "1",
                            "oi_flag": "1" if oi else "0"})
    if r.get("s") != "ok" or not r.get("candles"):
        print("history failed:", symbol, day, "->", r)
        return None
    cols = ["ts", "o", "h", "l", "c", "v"] + (["oi"] if oi else [])
    df = pd.DataFrame(r["candles"], columns=cols[:len(r["candles"][0])])
    df = df.drop_duplicates("ts", keep="last").sort_values("ts")   # guard against repeated candles
    df["start"] = pd.to_datetime(df.ts, unit="s", utc=True).dt.tz_convert(TZ)  # bar OPEN time (as on charts)
    df = df.set_index("start")
    return df[~df.index.duplicated(keep="last")]


# --------------------------------------------------------------------- tag
def tag(ret, d_oi):
    """Classify one instrument from its price return and OI change.

    price up   + OI up   -> Long Buildup
    price down + OI up   -> Short Buildup
    price down + OI down -> Long Unwinding
    price up   + OI down -> Short Covering
    """
    if ret == 0 or d_oi == 0:
        return "Neutral"
    if ret > 0:
        return "Long Buildup" if d_oi > 0 else "Short Covering"
    return "Short Buildup" if d_oi > 0 else "Long Unwinding"


def leg(p0, p1, o0, o1, side):
    """Price and OI change of ONE strike/side between two consecutive bars.
    p0/o0 = previous bar (e.g. 10:00), p1/o1 = current bar (e.g. 10:05).
    e.g. price 100 -> 110, OI 1000 -> 1100  =>  px_diff 10, px_pct 10, oi_diff 100, oi_pct 10
    """
    d_p, d_o = p1 - p0, o1 - o0
    return {
        f"{side}_prev_px": p0,
        f"{side}_px": p1,
        f"{side}_px_diff": round(d_p, 2),
        f"{side}_px_pct": round(d_p / p0 * 100, 2) if p0 else np.nan,
        f"{side}_prev_oi": o0,
        f"{side}_oi": o1,
        f"{side}_oi_diff": d_o,
        f"{side}_oi_pct": round(d_o / o0 * 100, 2) if o0 else np.nan,
        f"{side}_tag": tag(d_p, d_o),
    }


def spot_chg(p0, p1):
    """Nifty close-to-close change between two consecutive bars."""
    d = p1 - p0
    return {"spot_prev": p0, "spot_diff": round(d, 2),
            "spot_pct": round(d / p0 * 100, 2) if p0 else np.nan}


def signal(row):
    """BUY  : spot% > 0, CE px% > 0, PE px% < 0, CE px% > PE px%, CE OI% > PE OI%
       SELL : spot% < 0, PE px% > 0, CE px% < 0, PE px% > CE px%, PE OI% > CE OI%
       else : NO DECISION  (also when a % is NaN, e.g. previous OI was 0)"""
    if (row["spot_pct"] > 0 and row["ce_px_pct"] > 0 and row["pe_px_pct"] < 0
            and row["ce_px_pct"] > row["pe_px_pct"] and row["ce_oi_pct"] > row["pe_oi_pct"]):
        return "BUY"
    if (row["spot_pct"] < 0 and row["pe_px_pct"] > 0 and row["ce_px_pct"] < 0
            and row["pe_px_pct"] > row["ce_px_pct"] and row["pe_oi_pct"] > row["ce_oi_pct"]):
        return "SELL"
    return "NO DECISION"


# ---------------------------------------------------------------- backfill
def backfill():
    expiry, exp_date = nearest_expiry()
    print("using expiry", exp_date)
    spot_now, strikes = chain(expiry, strikecount=1)
    k0 = next(iter(strikes))
    sample = strikes[k0]["CE"]["symbol"]                    # e.g. NSE:NIFTY2610622850CE
    prefix = sample[:-(len(str(k0)) + 2)]                   # -> NSE:NIFTY26106
    sym = lambda k, side: f"{prefix}{k}{side}"              # works for ANY strike
    print("symbol template:", sym(k0, "CE"))
    now = pd.Timestamp.now(tz=TZ)

    # use today if it has candles, otherwise walk back to the last trading day
    spot, day = None, None
    for back in range(7):
        d = now - pd.Timedelta(days=back)
        if d.weekday() >= 5:                                # skip Sat/Sun
            continue
        day = d.strftime("%Y-%m-%d")
        spot = history_5m(UNDERLYING, day)
        if spot is not None:
            break
        print(f"no candles for {day} (holiday / market not open yet?), trying previous day")
    if spot is None:
        raise SystemExit("No index candles found in the last 7 days. Check the token / symbol.")
    print("using trading day", day)
    if day == now.strftime("%Y-%m-%d"):
        spot = spot[spot.index + pd.Timedelta(minutes=TF) <= now]   # drop the still-forming candle
    cache, rows = {}, []

    def get(sym):
        if sym not in cache:
            cache[sym] = history_5m(sym, day, oi=True)
            time.sleep(0.3)
        return cache[sym]

    idx = list(spot.index)
    for prev_t, t in zip(idx[:-1], idx[1:]):
        k = int(round(spot.at[prev_t, "c"] / STEP) * STEP)  # ATM fixed at START of window
        ce, pe = get(sym(k, "CE")), get(sym(k, "PE"))       # fetched once per strike, cached
        if ce is None or pe is None or t not in ce.index or prev_t not in ce.index \
                or t not in pe.index or prev_t not in pe.index:
            continue
        row = (dict(time=t.strftime("%H:%M"),
                         spot_o=spot.at[t, "o"], spot_h=spot.at[t, "h"],
                         spot_l=spot.at[t, "l"], spot=spot.at[t, "c"],
                         **spot_chg(spot.at[prev_t, "c"], spot.at[t, "c"]),
                         strike=k,
                         ce_vol=ce.at[t, "v"], pe_vol=pe.at[t, "v"],
                         **leg(ce.at[prev_t, "c"], ce.at[t, "c"],
                               ce.at[prev_t, "oi"], ce.at[t, "oi"], "ce"),
                         **leg(pe.at[prev_t, "c"], pe.at[t, "c"],
                               pe.at[prev_t, "oi"], pe.at[t, "oi"], "pe")))
        row["signal"] = signal(row)
        rows.append(row)
    return pd.DataFrame(rows)


# -------------------------------------------------------------------- live
def live():
    expiry, _ = nearest_expiry()
    tf = pd.Timedelta(minutes=TF)
    out = f"atm_live_{TF}m.csv"
    prev, prev_t = None, None
    header = not os.path.exists(out)
    while True:
        now = pd.Timestamp.now(tz=TZ)
        day0 = now.normalize()
        mkt_open, mkt_close = day0 + pd.Timedelta(hours=9, minutes=15), day0 + pd.Timedelta(hours=15, minutes=30)
        if now > mkt_close:
            print("market closed, stopping")
            break
        n = max(math.ceil((now - mkt_open) / tf), 1)        # next bar boundary, aligned to 9:15
        t = mkt_open + n * tf
        if t > mkt_close:
            break
        time.sleep(max((t - now).total_seconds() + 2, 0))
        spot, strikes = chain(expiry, strikecount=5)
        cur = dict(spot=spot, strikes=strikes)
        if prev and t - prev_t == tf:
            k = int(round(prev["spot"] / STEP) * STEP)
            a, b = prev["strikes"].get(k), cur["strikes"].get(k)
            if a and b:
                row = dict(time=(t - tf).strftime("%H:%M"), spot=spot,
                           **spot_chg(prev["spot"], spot), strike=k,
                           **leg(a["CE"]["ltp"], b["CE"]["ltp"],
                                 a["CE"]["oi"], b["CE"]["oi"], "ce"),
                           **leg(a["PE"]["ltp"], b["PE"]["ltp"],
                                 a["PE"]["oi"], b["PE"]["oi"], "pe"))
                row["signal"] = signal(row)
                pd.DataFrame([row]).to_csv(out, mode="a", header=header, index=False)
                header = False
                print(row)
        prev, prev_t = cur, t


if __name__ == "__main__":
    if "--live" in sys.argv:
        live()
    else:
        df = backfill()
        pd.set_option("display.width", 250, "display.max_columns", 30)
        print(df.to_string(index=False))
        df.to_csv(OUT, index=False)
        print("\nsaved ->", OUT)