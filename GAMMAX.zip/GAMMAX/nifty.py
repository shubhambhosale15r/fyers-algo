import time
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import pytz
from fyers_apiv3 import fyersModel
import logging
import os
import json
import csv
import threading
import traceback

# ============================================================
# CONFIGURATION
# ============================================================
class Config:
    SAMPLE_INTERVAL = 60
    OPTION_CHAIN_INTERVAL = 60
    LOT_SIZE = 195
    MAX_DAILY_ORDERS = 5

    # Trailing stop (percentage drop from peak)
    TRAILING_STOP_PCT = 33.0   # configurable

    # History API (candles) settings
    CANDLE_INTERVAL = 3
    LOOKBACK_CANDLES = 2

    # Rate limits
    API_RATE_LIMIT = 200
    API_WINDOW = 60
    MAX_RETRIES = 3
    RETRY_DELAY = 2

# ============================================================
# LOGGING
# ============================================================
logging.basicConfig(
    filename="trading_app.log",
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)

def log_debug(msg): logging.debug(msg)
def log_console(msg):
    print(msg, flush=True)
    logging.info(msg)

IST = pytz.timezone("Asia/Kolkata")
def now_ist(): return datetime.now(IST)
def timestamp_ist(): return now_ist().strftime("%Y-%m-%d %H:%M:%S")

# ============================================================
# PAPER TRADING ACCOUNT
# ============================================================
class PaperAccount:
    def __init__(self, initial_capital=100000):
        self.capital = initial_capital
        self.position = "FLAT"
        self.held_symbol = None
        self.entry_price = 0.0
        self.entry_time = None
        self.trade_log = []
        self.pnl = 0.0
        self.lock = threading.RLock()

    def reset(self):
        with self.lock:
            self.capital = 100000
            self.position = "FLAT"
            self.held_symbol = None
            self.entry_price = 0.0
            self.entry_time = None
            self.trade_log = []
            self.pnl = 0.0

    def enter(self, side, symbol, price, qty=Config.LOT_SIZE):
        with self.lock:
            if self.position != "FLAT":
                return False, "Position already open"
            if side not in ("LONG", "SHORT"):
                return False, "Invalid side"
            required = qty * price
            if required > self.capital:
                return False, "Insufficient capital"
            self.position = side
            self.held_symbol = symbol
            self.entry_price = price
            self.entry_time = timestamp_ist()
            self.capital -= required
            self.trade_log.append({
                "time": self.entry_time,
                "action": "ENTRY",
                "side": side,
                "symbol": symbol,
                "price": price,
                "qty": qty,
                "capital_after": self.capital
            })
            return True, f"{side} entered at {price:.2f}"

    def exit(self, price, qty=Config.LOT_SIZE):
        with self.lock:
            if self.position == "FLAT":
                return False, "No position to exit"
            if self.position == "LONG":
                pnl = (price - self.entry_price) * qty
            else:  # SHORT
                pnl = (self.entry_price - price) * qty
            self.capital += qty * price
            self.pnl += pnl
            self.trade_log.append({
                "time": timestamp_ist(),
                "action": "EXIT",
                "side": self.position,
                "symbol": self.held_symbol,
                "entry_price": self.entry_price,
                "exit_price": price,
                "qty": qty,
                "pnl": pnl,
                "capital_after": self.capital
            })
            pos = self.position
            self.position = "FLAT"
            self.held_symbol = None
            self.entry_price = 0.0
            self.entry_time = None
            return True, f"Exited {pos} at {price:.2f}, P&L: {pnl:+.2f}"

    def get_status(self):
        with self.lock:
            return {
                "capital": self.capital,
                "position": self.position,
                "symbol": self.held_symbol,
                "entry_price": self.entry_price,
                "entry_time": self.entry_time,
                "total_pnl": self.pnl
            }

# ============================================================
# SESSION STATE
# ============================================================
class SessionState:
    def __init__(self):
        self.lock = threading.RLock()
        self.running = False

        # Live trading state
        self.daily_executed_orders = 0
        self.last_order_sync = None

        # REST-fetched data
        self.live_ltp = {}
        self.live_atp = {}
        self.live_bid = {}
        self.live_ask = {}

        # Option chain
        self.option_chain = []
        self.fut_price = None
        self.expiry_date = None
        self.atm_strike = None

        # VIX
        self.india_vix = 15.0

        # Position tracking (shared by paper & live)
        self.position = "FLAT"
        self.held_option_symbol = None
        self.option_entry_price = 0.0
        self.peak_price = 0.0          # highest price since entry

        # Debug
        self.last_debug_output = "Initialising..."

        # Paper account
        self.paper = PaperAccount()

    def update_quotes(self, quotes_dict):
        with self.lock:
            for symbol, data in quotes_dict.items():
                if symbol == "NSE:INDIAVIX-INDEX":
                    self.india_vix = float(data.get("ltp", 15.0))
                    continue
                self.live_ltp[symbol] = float(data.get("ltp", 0))
                self.live_atp[symbol] = float(data.get("avg_trade_price", 0))
                self.live_bid[symbol] = float(data.get("bid", 0))
                self.live_ask[symbol] = float(data.get("ask", 0))

    def get_ltp(self, symbol):
        with self.lock: return self.live_ltp.get(symbol)
    def get_atp(self, symbol):
        with self.lock: return self.live_atp.get(symbol)
    def get_bid(self, symbol):
        with self.lock: return self.live_bid.get(symbol)
    def get_ask(self, symbol):
        with self.lock: return self.live_ask.get(symbol)

    def update_chain(self, chain, fut_price, expiry_date, atm_strike):
        with self.lock:
            self.option_chain = chain
            self.fut_price = float(fut_price) if fut_price else 0.0
            self.expiry_date = expiry_date
            self.atm_strike = int(atm_strike) if atm_strike else None

    def sync_order_count(self, fyers):
        today = now_ist().date()
        if self.last_order_sync != today:
            self.daily_executed_orders = 0
            self.last_order_sync = today
        try:
            resp = fyers.orderbook()
            if resp.get("s") == "ok":
                self.daily_executed_orders = len([o for o in resp.get("orderBook", []) if o.get("status") == 2])
        except Exception as e:
            log_debug(f"Order sync failed: {e}")

    def can_place_order(self, fyers=None):
        if fyers: self.sync_order_count(fyers)
        return self.daily_executed_orders < Config.MAX_DAILY_ORDERS

    def update_peak(self, current_price):
        if current_price > self.peak_price:
            self.peak_price = current_price

# ============================================================
# REST API HELPERS
# ============================================================
def fetch_quotes(session, symbols, fyers):
    try:
        symbol_str = ",".join(symbols)
        resp = fyers.quotes(data={"symbols": symbol_str})
        if resp.get("s") != "ok":
            log_debug(f"Quotes API error: {resp}")
            return {}
        quotes = {}
        for item in resp.get("d", []):
            symbol = item.get("n", "")
            ltp = item.get("v", {}).get("lp", 0)
            atp = item.get("v", {}).get("atp", 0)
            bid = item.get("v", {}).get("bid", 0)
            ask = item.get("v", {}).get("ask", 0)
            quotes[symbol] = {"ltp": ltp, "atp": atp, "bid": bid, "ask": ask}
        return quotes
    except Exception as e:
        log_debug(f"Quotes API exception: {e}")
        return {}

def fetch_candle_return(session, symbol, fyers):
    try:
        end_date = now_ist()
        start_date = end_date - timedelta(minutes=10)
        from_date = start_date.strftime("%Y-%m-%d")
        to_date = end_date.strftime("%Y-%m-%d")
        data = {
            "symbol": symbol,
            "resolution": str(Config.CANDLE_INTERVAL),
            "date_format": "1",
            "range_from": from_date,
            "range_to": to_date,
            "cont_flag": "1"
        }
        resp = fyers.history(data=data)
        if resp.get("s") != "ok" or not resp.get("candles"):
            return None, None, None
        candles = resp["candles"]
        if len(candles) < 2:
            return None, None, None
        current_candle = candles[-1]
        previous_candle = candles[-2]
        current_close = current_candle[4]
        previous_close = previous_candle[4]
        if previous_close == 0:
            return None, None, None
        return_pct = ((current_close - previous_close) / previous_close) * 100
        return current_close, previous_close, return_pct
    except Exception as e:
        log_debug(f"History API exception: {e}")
        return None, None, None

# def fetch_candle_return(session, symbol, fyers):
#     try:
#         end_date = now_ist()
#         start_date = end_date - timedelta(minutes=10)
#         from_date = start_date.strftime("%Y-%m-%d")
#         to_date = end_date.strftime("%Y-%m-%d")
#         data = {
#             "symbol": symbol,
#             "resolution": str(Config.CANDLE_INTERVAL),
#             "date_format": "1",
#             "range_from": '2026-06-19',
#             "range_to": '2026-06-19',
#             "cont_flag": "1"
#         }
#         resp = fyers.history(data=data)
#         if resp.get("s") != "ok" or not resp.get("candles"):
#             log_debug(f"History API error/empty for {symbol}: {resp}")
#             return None, None, None
#         candles = resp["candles"]
#         if len(candles) < 2:
#             log_debug(f"Not enough candles for {symbol}: only {len(candles)}")
#             return None, None, None
        
#         # --- DEBUG: print last 5 candles ---
#         print(f"Last 5 candles for {symbol}:")
#         for c in candles[-5:]:
#             # c = [timestamp, open, high, low, close, volume]
#             print(f"  {datetime.fromtimestamp(c[0]).strftime('%H:%M:%S')} O:{c[1]:.2f} H:{c[2]:.2f} L:{c[3]:.2f} C:{c[4]:.2f} V:{c[5]}")
        
#         current_candle = candles[-1]
#         previous_candle = candles[-2]
#         current_close = current_candle[4]
#         previous_close = previous_candle[4]
#         if previous_close == 0:
#             print(f"Previous close is zero for {symbol}")
#             return None, None, None
#         return_pct = ((current_close - previous_close) / previous_close) * 100
#         print(f"Return for {symbol}: {return_pct:.2f}% (prev close {previous_close:.2f} -> current {current_close:.2f})")
#         return current_close, previous_close, return_pct
#     except Exception as e:
#         log_debug(f"History API exception: {e}")
#         return None, None, None

def fetch_option_chain(session, index_symbol, fyers):
    meta = fyers.optionchain(data={"symbol": index_symbol, "timestamp": ""})
    if meta.get("code") != 200:
        return None, None, None, None

    fut_price = None
    for item in meta["data"]["optionsChain"]:
        if item.get("option_type") == "":
            fut_price = item.get("fp")
            break
    if fut_price is None:
        fut_price = meta["data"].get("fp", 0.0)

    exp_list = sorted([(e["date"], e["expiry"]) for e in meta["data"]["expiryData"]],
                      key=lambda x: datetime.strptime(x[0], "%d-%m-%Y"))
    today = now_ist().date()
    idx = 0
    for i, (d_str, _) in enumerate(exp_list):
        if datetime.strptime(d_str, "%d-%m-%Y").date() >= today:
            idx = i
            break
    curr_date, expiry_ts = exp_list[idx]

    payload = {"symbol": index_symbol, "strikecount": 5, "timestamp": expiry_ts, "greeks": "1"}
    resp = fyers.optionchain(data=payload)
    if resp.get("code") != 200:
        return None, None, None, None

    chain = resp["data"]["optionsChain"]
    return chain, fut_price, curr_date, expiry_ts

# ============================================================
# SIGNAL COMPUTATION (with trailing stop)
# ============================================================
def compute_signal(session, fyers):
    log_debug(">>> compute_signal called")
    debug_lines = []

    try:
        with session.lock:
            # --- 1. Ensure ATM exists ---
            if session.atm_strike is None:
                debug_lines.append("❌ No ATM strike – waiting for chain")
                session.last_debug_output = "\n".join(debug_lines)
                return "HOLD", {"spot": 0}

            atm = session.atm_strike
            strike_interval = 50
            target_strikes = {atm - strike_interval, atm, atm + strike_interval}

            # Build list of symbols: index + zone options
            index_symbol = "NSE:NIFTY50-INDEX"
            zone_symbols = []
            for opt in session.option_chain:
                if opt["strike_price"] in target_strikes and opt["option_type"] in ("CE", "PE"):
                    zone_symbols.append(opt["symbol"])
            quote_symbols = [index_symbol] + zone_symbols

            # Fetch quotes
            quotes = fetch_quotes(session, quote_symbols, fyers)
            if not quotes:
                debug_lines.append("❌ Quotes API returned empty")
                session.last_debug_output = "\n".join(debug_lines)
                return "HOLD", {"spot": 0}
            session.update_quotes(quotes)

            underlying_ltp = session.get_ltp(index_symbol)
            if underlying_ltp is None:
                debug_lines.append("❌ No NIFTY LTP")
                session.last_debug_output = "\n".join(debug_lines)
                return "HOLD", {"spot": 0}

            # --- 2. Build debug table and compute zone aggregates ---
            debug_lines.append("="*80)
            debug_lines.append(f"🔍 ZONE DEBUG (Strikes: {sorted(target_strikes)})")
            debug_lines.append(f"{'Strike':>8} | {'Type':>4} | {'LTP':>8} | {'ATP(VWAP)':>10} | {'OI':>12} | {'Gamma':>12} | {'OI*Gamma':>12}")
            debug_lines.append("-"*80)

            ce_ltps = []; ce_atps = []; ce_oi_gamma = []
            pe_ltps = []; pe_atps = []; pe_oi_gamma = []
            atm_ce_sym = None ; atm_pe_sym = None

            for opt in session.option_chain:
                strike = opt["strike_price"]
                if strike not in target_strikes:
                    continue
                sym = opt["symbol"]
                oi = opt.get("oi", 0)
                gamma = opt.get("greeks", {}).get("gamma", 0)
                ltp = session.get_ltp(sym) or opt.get("ltp", 0)
                atp = session.get_atp(sym) or 0
                oi_gamma_val = oi * gamma if oi > 0 and gamma > 0 else 0

                debug_lines.append(f"{strike:8} | {opt['option_type']:>4} | {ltp:8.2f} | {atp:10.2f} | {oi:12.0f} | {gamma:12.6f} | {oi_gamma_val:12.2f}")

                if opt["option_type"] == "CE":
                    ce_ltps.append(ltp); ce_atps.append(atp)
                    if oi > 0 and gamma > 0: ce_oi_gamma.append(oi * gamma)
                    if strike == atm: atm_ce_sym = sym
                elif opt["option_type"] == "PE":
                    pe_ltps.append(ltp); pe_atps.append(atp)
                    if oi > 0 and gamma > 0: pe_oi_gamma.append(oi * gamma)
                    if strike == atm: atm_pe_sym = sym

            if not ce_ltps or not pe_ltps or atm_ce_sym is None or atm_pe_sym is None:
                debug_lines.append("❌ Missing data for target strikes -> HOLD")
                session.last_debug_output = "\n".join(debug_lines)
                return "HOLD", {"spot": underlying_ltp}

            ce_avg_ltp = sum(ce_ltps) / len(ce_ltps)
            pe_avg_ltp = sum(pe_ltps) / len(pe_ltps)
            ce_avg_atp = sum(ce_atps) / len(ce_atps) if ce_atps else 0
            pe_avg_atp = sum(pe_atps) / len(pe_atps) if pe_atps else 0
            total_ce_gex = sum(ce_oi_gamma)
            total_pe_gex = sum(pe_oi_gamma)
            zone_gex = total_ce_gex - total_pe_gex

            debug_lines.append("-"*80)
            debug_lines.append(f"📊 ZONE AGGREGATES:")
            debug_lines.append(f"  CE Avg LTP: {ce_avg_ltp:.2f}, CE Avg ATP: {ce_avg_atp:.2f}")
            debug_lines.append(f"  PE Avg LTP: {pe_avg_ltp:.2f}, PE Avg ATP: {pe_avg_atp:.2f}")
            debug_lines.append(f"  total_ce_gex: {total_ce_gex:.2f}")
            debug_lines.append(f"  total_pe_gex: {total_pe_gex:.2f}")
            debug_lines.append(f"  netGEX: {zone_gex:.2f} {'🚀 NEGATIVE' if zone_gex < 0 else '⛔ POSITIVE'}")

            # --- 3. Fetch candle returns (for entry conditions) ---
            debug_lines.append("-"*80)
            debug_lines.append(f"📈 FETCHING CANDLE RETURNS (ATM Symbols):")
            ce_close, ce_prev, ce_ret = fetch_candle_return(session, atm_ce_sym, fyers)
            pe_close, pe_prev, pe_ret = fetch_candle_return(session, atm_pe_sym, fyers)
            if ce_ret is None or pe_ret is None:
                debug_lines.append("⚠️ Candle data incomplete – using 0% returns")
                ce_ret = pe_ret = 0.0
            debug_lines.append(f"  CE: {atm_ce_sym} -> Return: {ce_ret:.2f}%")
            debug_lines.append(f"  PE: {atm_pe_sym} -> Return: {pe_ret:.2f}%")

            # --- 4. TRAILING STOP EXIT (if position open) ---
            if session.position != "FLAT" and session.held_option_symbol:
                held_sym = session.held_option_symbol
                current_price = session.get_ltp(held_sym)
                if current_price is None or current_price <= 0:
                    debug_lines.append(f"⚠️ No LTP for held symbol {held_sym}")
                    session.last_debug_output = "\n".join(debug_lines)
                    return "HOLD", {"spot": underlying_ltp}

                # Update peak
                session.update_peak(current_price)

                if session.peak_price > 0:
                    drawdown_pct = (session.peak_price - current_price) / session.peak_price * 100
                    debug_lines.append(f"📌 Position: {session.position} | Entry: {session.option_entry_price:.2f} | Peak: {session.peak_price:.2f} | Current: {current_price:.2f} | Drawdown: {drawdown_pct:.2f}%")
                    if drawdown_pct >= Config.TRAILING_STOP_PCT:
                        debug_lines.append(f"⏰ EXIT triggered: Drawdown {drawdown_pct:.2f}% >= {Config.TRAILING_STOP_PCT}%")
                        session.last_debug_output = "\n".join(debug_lines)
                        return "EXIT", {"spot": underlying_ltp, "drawdown": drawdown_pct}
                    else:
                        debug_lines.append(f"⏳ Holding: drawdown {drawdown_pct:.2f}% < {Config.TRAILING_STOP_PCT}%")
                else:
                    debug_lines.append("⚠️ Peak price not set")
                session.last_debug_output = "\n".join(debug_lines)
                return "HOLD", {"spot": underlying_ltp}

            # --- 5. GEX BLOCK (only if FLAT) ---
            if zone_gex >= 0:
                debug_lines.append(f"⛔ GEX BLOCK: Zone GEX {zone_gex:.2f} >= 0 -> HOLD")
                session.last_debug_output = "\n".join(debug_lines)
                return "HOLD", {"spot": underlying_ltp, "zone_gex": zone_gex}

            # --- 6. ANTI-CHOP BLOCK (only if FLAT) ---
            both_returns_negative = (ce_ret < 0 and pe_ret < 0)
            both_below_vwap = (ce_avg_ltp < ce_avg_atp and pe_avg_ltp < pe_avg_atp)
            if both_returns_negative or both_below_vwap:
                block_reason = "CHOP" if both_returns_negative else "VWAP_LAG"
                debug_lines.append(f"⛔ ANTI-CHOP BLOCK: {block_reason} -> HOLD")
                session.last_debug_output = "\n".join(debug_lines)
                return "HOLD", {"spot": underlying_ltp, "block_reason": block_reason}

            # --- 7. ENTRY LOGIC (only if FLAT) ---
            signal = "HOLD"
            if ce_ret > 0 and ce_avg_ltp > ce_avg_atp and pe_avg_ltp < pe_avg_atp:
                debug_lines.append(f"🚀 BUY CALL: ce_ret={ce_ret:.2f}% | ce_avg_ltp={ce_avg_ltp:.2f}>{ce_avg_atp:.2f} | pe_avg_ltp={pe_avg_ltp:.2f}<{pe_avg_atp:.2f}")
                signal = "BUY"
            elif pe_ret > 0 and pe_avg_ltp > pe_avg_atp and ce_avg_ltp < ce_avg_atp:
                debug_lines.append(f"🚀 BUY PUT: pe_ret={pe_ret:.2f}% | pe_avg_ltp={pe_avg_ltp:.2f}>{pe_avg_atp:.2f} | ce_avg_ltp={ce_avg_ltp:.2f}<{ce_avg_atp:.2f}")
                signal = "SELL"
            else:
                debug_lines.append("⏸ Entry conditions not met.")

            debug_lines.append(f"✅ FINAL DECISION: Signal={signal}")
            debug_lines.append("="*80)
            session.last_debug_output = "\n".join(debug_lines)
            for line in debug_lines:
                log_debug(line)

            metrics = {
                "spot": underlying_ltp,
                "atm_strike": atm,
                "ce_ret": ce_ret,
                "pe_ret": pe_ret,
                "ce_avg_ltp": ce_avg_ltp,
                "pe_avg_ltp": pe_avg_ltp,
                "ce_avg_atp": ce_avg_atp,
                "pe_avg_atp": pe_avg_atp,
                "zone_gex": zone_gex,
            }
            return signal, metrics

    except Exception as e:
        error_msg = f"CRASH: {e}\n{traceback.format_exc()}"
        log_debug(error_msg)
        session.last_debug_output = f"❌ ERROR: {str(e)}"
        return "HOLD", {}

# ============================================================
# ORDER PLACEMENT (handles both Live and Paper)
# ============================================================
def place_order(session, signal, atm_ce, atm_pe, fyers, mode, entry_metrics=None):
    if mode == "PAPER":
        return place_order_paper(session, signal, atm_ce, atm_pe)
    else:
        return place_order_live(session, signal, atm_ce, atm_pe, fyers)

def place_order_paper(session, signal, atm_ce, atm_pe):
    paper = session.paper
    if signal == "EXIT":
        if paper.position != "FLAT":
            sym = paper.held_symbol
            ltp = session.get_ltp(sym)
            if ltp is None:
                log_console("❌ Cannot exit: no LTP")
                return False
            success, msg = paper.exit(ltp)
            log_console(f"📝 Paper EXIT: {msg}")
            if success:
                session.position = "FLAT"
                session.held_option_symbol = None
                session.option_entry_price = 0.0
                session.peak_price = 0.0
            return success
        return True

    if signal in ("BUY", "SELL"):
        leg = atm_ce if signal == "BUY" else atm_pe
        if not leg:
            return False
        sym = leg["symbol"]
        price = session.get_ltp(sym) or leg.get("ltp", 0)
        if price <= 0:
            return False
        side = "LONG" if signal == "BUY" else "SHORT"
        success, msg = paper.enter(side, sym, price)
        log_console(f"📝 Paper {side} order: {msg}")
        if success:
            session.position = side
            session.held_option_symbol = sym
            session.option_entry_price = price
            session.peak_price = price
        return success
    return False

def place_order_live(session, signal, atm_ce, atm_pe, fyers):
    if getattr(session, '_hb_lock', False):
        return False
    session._hb_lock = True
    try:
        if signal == "EXIT":
            log_console("🟡 EXIT signal – closing live positions")
            fyers.exit_positions(data={"segment": [11], "side": [-1], "productType": ["MARGIN"]})
            fyers.exit_positions(data={"segment": [11], "side": [1], "productType": ["MARGIN"]})
            time.sleep(2)
            session.position = "FLAT"
            session.held_option_symbol = None
            session.option_entry_price = 0.0
            session.peak_price = 0.0
            log_console("✓ Positions closed")
            return True

        if signal in ("BUY", "SELL") and session.can_place_order(fyers):
            leg = atm_ce if signal == "BUY" else atm_pe
            if not leg:
                return False
            order = {
                "symbol": leg["symbol"],
                "qty": Config.LOT_SIZE,
                "type": 1,
                "limit_price": session.get_ltp(leg["symbol"]) or leg.get("ltp", 0),
                "side": 1,
                "productType": "MARGIN",
                "validity": "DAY",
            }
            side = "LONG" if signal == "BUY" else "SHORT"
            log_console(f"🟢 Placing LIVE {side} order for {leg['symbol']}")
            resp = fyers.place_order(data=order)
            if resp.get("s") == "ok":
                session.position = side
                session.held_option_symbol = leg["symbol"]
                session.option_entry_price = session.get_ltp(leg["symbol"]) or leg.get("ltp", 0)
                session.peak_price = session.option_entry_price
                log_console(f"✓ {side} order placed at {session.option_entry_price:.2f}")
                return True
            else:
                log_console(f"❌ Order failed: {resp}")
        return False
    except Exception as e:
        log_console(f"Order error: {e}")
        return False
    finally:
        session._hb_lock = False

# ============================================================
# CHAIN POLLER
# ============================================================
def chain_poller(session, fyers, index_symbol):
    log_debug("Chain poller thread started")
    while session.running:
        try:
            chain, fut_price, expiry_date, _ = fetch_option_chain(session, index_symbol, fyers)
            if chain is None:
                time.sleep(Config.OPTION_CHAIN_INTERVAL)
                continue
            underlying_ltp = session.get_ltp(index_symbol) or fut_price
            strikes = sorted(set(opt["strike_price"] for opt in chain if opt.get("option_type") in ("CE","PE")))
            atm = min(strikes, key=lambda x: abs(x - underlying_ltp)) if strikes and underlying_ltp else None
            session.update_chain(chain, fut_price, expiry_date, atm)
            time.sleep(Config.OPTION_CHAIN_INTERVAL)
        except Exception as e:
            log_debug(f"Chain poller error: {e}\n{traceback.format_exc()}")
            time.sleep(Config.OPTION_CHAIN_INTERVAL)

# ============================================================
# SAMPLER THREAD
# ============================================================
def sampler(session, data_logger, auto_trade, fyers, mode):
    log_debug("Sampler thread started")
    last_signal_logged = None

    while session.running:
        start = now_ist()
        try:
            signal, metrics = compute_signal(session, fyers)

            if metrics:
                data_logger.log_data(
                    timestamp=timestamp_ist(),
                    underlying_ltp=metrics.get("spot", 0),
                    signal=signal,
                    atm_strike=metrics.get("atm_strike", 0),
                    ce_ret=metrics.get("ce_ret", 0),
                    pe_ret=metrics.get("pe_ret", 0),
                    ce_avg_ltp=metrics.get("ce_avg_ltp", 0),
                    pe_avg_ltp=metrics.get("pe_avg_ltp", 0),
                    ce_avg_atp=metrics.get("ce_avg_atp", 0),
                    pe_avg_atp=metrics.get("pe_avg_atp", 0),
                    zone_gex=metrics.get("zone_gex", 0),
                    position=session.position if hasattr(session, 'position') else "FLAT",
                )

                if signal != last_signal_logged and signal != "HOLD":
                    log_console(f"📢 Signal changed to: {signal}")
                    last_signal_logged = signal

            if auto_trade and signal in ("BUY", "SELL", "EXIT"):
                atm_ce = atm_pe = None
                if session.atm_strike:
                    for opt in session.option_chain:
                        if opt["strike_price"] == session.atm_strike:
                            if opt["option_type"] == "CE":
                                atm_ce = {"symbol": opt["symbol"], "ltp": opt.get("ltp", 0)}
                            elif opt["option_type"] == "PE":
                                atm_pe = {"symbol": opt["symbol"], "ltp": opt.get("ltp", 0)}

                if signal == "EXIT":
                    place_order(session, signal, None, None, fyers, mode, None)
                elif signal == "BUY" and atm_ce:
                    place_order(session, signal, atm_ce, None, fyers, mode, metrics)
                elif signal == "SELL" and atm_pe:
                    place_order(session, signal, None, atm_pe, fyers, mode, metrics)

            elapsed = (now_ist() - start).total_seconds()
            if elapsed < Config.SAMPLE_INTERVAL:
                time.sleep(Config.SAMPLE_INTERVAL - elapsed)
        except Exception as e:
            log_debug(f"Sampler error: {e}\n{traceback.format_exc()}")
            time.sleep(1)

# ============================================================
# DATA LOGGER
# ============================================================
class DataLogger:
    def __init__(self, filename="trading_data.csv"):
        self.filename = filename
        self._ensure_header()

    def _ensure_header(self):
        if not os.path.exists(self.filename):
            with open(self.filename, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'timestamp', 'underlying_ltp', 'signal', 'atm_strike',
                    'ce_ret', 'pe_ret', 'ce_avg_ltp', 'pe_avg_ltp',
                    'ce_avg_atp', 'pe_avg_atp', 'zone_gex', 'position'
                ])

    def log_data(self, timestamp, underlying_ltp, signal, atm_strike,
                 ce_ret, pe_ret, ce_avg_ltp, pe_avg_ltp,
                 ce_avg_atp, pe_avg_atp, zone_gex, position):
        with open(self.filename, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                str(timestamp), underlying_ltp, signal, atm_strike,
                round(ce_ret,2), round(pe_ret,2),
                round(ce_avg_ltp,2), round(pe_avg_ltp,2),
                round(ce_avg_atp,2), round(pe_avg_atp,2),
                round(zone_gex,2), position
            ])

# ============================================================
# DASHBOARD
# ============================================================
class TerminalDashboard:
    def __init__(self, session_state, mode):
        self.session = session_state
        self.mode = mode

    def display(self):
        try:
            os.system('cls' if os.name == 'nt' else 'clear')
            print("\n" + "="*120)
            print(f"📊 ZONE-BASED HYBRID STRATEGY  |  Mode: {self.mode}  |  Trailing Stop: {Config.TRAILING_STOP_PCT}%")
            print("="*120)

            under_ltp = self.session.get_ltp("NSE:NIFTY50-INDEX")
            if under_ltp is None:
                print(f"⏱ {timestamp_ist()}  |  Pos: {self.session.position if hasattr(self.session,'position') else 'FLAT'}  |  📈 NIFTY: Waiting...")
            else:
                print(f"⏱ {timestamp_ist()}  |  Pos: {self.session.position if hasattr(self.session,'position') else 'FLAT'}  |  📈 NIFTY: {under_ltp:.2f}  |  ATM: {self.session.atm_strike or '?'}  |  Daily Trades: {self.session.daily_executed_orders}/{Config.MAX_DAILY_ORDERS if self.mode=='LIVE' else 'PAPER'}")

            # Paper account status
            if self.mode == "PAPER":
                status = self.session.paper.get_status()
                entry_display = f"{status['entry_price']:.2f}" if status['entry_price'] else "--"
                print(f"💵 Capital: {status['capital']:.2f}  |  Total P&L: {status['total_pnl']:+.2f}  |  Position: {status['position']}  |  Entry: {entry_display}")

            print("\n" + "-"*80)
            print("📊 ZONE METRICS (Avg of ATM-1, ATM, ATM+1)")
            print("-"*80)

            if self.session.atm_strike is None:
                print("  Waiting for chain...")
            else:
                atm = self.session.atm_strike
                target = [atm-50, atm, atm+50]
                ce_ltps=[]; ce_atps=[]; pe_ltps=[]; pe_atps=[]; ce_gex=[]; pe_gex=[]
                for opt in self.session.option_chain:
                    if opt["strike_price"] not in target: continue
                    sym = opt["symbol"]
                    ltp = self.session.get_ltp(sym) or 0
                    atp = self.session.get_atp(sym) or 0
                    gamma = opt.get("greeks", {}).get("gamma", 0)
                    oi = opt.get("oi", 0)
                    if opt["option_type"] == "CE":
                        ce_ltps.append(ltp); ce_atps.append(atp)
                        if oi and gamma: ce_gex.append(oi*gamma)
                    else:
                        pe_ltps.append(ltp); pe_atps.append(atp)
                        if oi and gamma: pe_gex.append(oi*gamma)
                if ce_ltps and pe_ltps:
                    ce_avg_ltp = sum(ce_ltps)/len(ce_ltps)
                    pe_avg_ltp = sum(pe_ltps)/len(pe_ltps)
                    ce_avg_atp = sum(ce_atps)/len(ce_atps)
                    pe_avg_atp = sum(pe_atps)/len(pe_atps)
                    zone_gex = sum(ce_gex) - sum(pe_gex)
                    print(f"  CE Zone Avg LTP  : {ce_avg_ltp:.2f}  |  CE Zone Avg ATP (VWAP): {ce_avg_atp:.2f}  |  {'🟢 ABOVE' if ce_avg_ltp > ce_avg_atp else '🔴 BELOW'}")
                    print(f"  PE Zone Avg LTP  : {pe_avg_ltp:.2f}  |  PE Zone Avg ATP (VWAP): {pe_avg_atp:.2f}  |  {'🟢 ABOVE' if pe_avg_ltp > pe_avg_atp else '🔴 BELOW'}")
                    print(f"  Zone GEX (OI*Gamma) : {zone_gex:.2f}  {'🚀 NEGATIVE (Amplify)' if zone_gex < 0 else '⛔ POSITIVE (Suppress)'}")
                else:
                    print("  Waiting for data...")

            # Active position with trailing stop info
            if hasattr(self.session, 'held_option_symbol') and self.session.held_option_symbol:
                held_ltp = self.session.get_ltp(self.session.held_option_symbol)
                if held_ltp and hasattr(self.session, 'option_entry_price') and self.session.option_entry_price:
                    pnl = (held_ltp - self.session.option_entry_price) / self.session.option_entry_price * 100
                    peak = self.session.peak_price
                    if peak > 0:
                        drawdown = (peak - held_ltp) / peak * 100
                        print(f"\n  📌 Active {self.session.position} @ {self.session.option_entry_price:.2f}  |  Current: {held_ltp:.2f}  |  P&L: {pnl:+.2f}%  |  Peak: {peak:.2f}  |  Drawdown: {drawdown:.2f}%  |  Stop: {Config.TRAILING_STOP_PCT}%")
                    else:
                        print(f"\n  📌 Active {self.session.position} @ {self.session.option_entry_price:.2f}  |  Current: {held_ltp:.2f}  |  P&L: {pnl:+.2f}%")

            # Debug panel
            print("\n" + "-"*80)
            print("🕵️ LAST COMPUTE CYCLE")
            print("-"*80)
            if hasattr(self.session, 'last_debug_output'):
                print(self.session.last_debug_output)
            else:
                print("  No data yet.")

            print("\n" + "="*120)
        except Exception as e:
            log_debug(f"Dashboard error: {e}")
            print(f"Dashboard error: {e}")

# ============================================================
# CREDENTIALS LOADER
# ============================================================
def load_credentials(session):
    try:
        with open('fyers_credentials.json', 'r') as f:
            creds = json.load(f)
            session.cid = creds.get('client_id', '')
            session.token = creds.get('access_token', '')
        log_console(f"Loaded credentials: {session.cid}")
    except:
        session.cid = os.getenv("FYERS_CID", "")
        session.token = os.getenv("FYERS_TOKEN", "")

# ============================================================
# PRE-FETCH INITIAL DATA
# ============================================================
def prefetch_initial_data(session, fyers, index_symbol):
    log_console("Pre-fetching initial data...")
    chain, fut_price, expiry_date, _ = fetch_option_chain(session, index_symbol, fyers)
    if not chain:
        log_console("❌ Failed to fetch initial chain. Will retry in background.")
        return

    quotes = fetch_quotes(session, [index_symbol], fyers)
    under_ltp = quotes.get(index_symbol, {}).get("ltp", 0)
    if under_ltp == 0:
        log_console("❌ Failed to fetch NIFTY LTP. Using future price.")
        under_ltp = fut_price or 0

    if under_ltp:
        strikes = sorted(set(opt["strike_price"] for opt in chain if opt.get("option_type") in ("CE","PE")))
        atm = min(strikes, key=lambda x: abs(x - under_ltp)) if strikes else None
        session.update_chain(chain, fut_price, expiry_date, atm)
        target = {atm-50, atm, atm+50} if atm else set()
        zone_symbols = [opt["symbol"] for opt in chain if opt["strike_price"] in target]
        all_symbols = [index_symbol] + zone_symbols
        quotes = fetch_quotes(session, all_symbols, fyers)
        session.update_quotes(quotes)
        log_console("✅ Initial data ready.")
    else:
        log_console("❌ Could not determine ATM. Chain will be updated by poller.")

# ============================================================
# MAIN
# ============================================================
def main():
    log_console("Starting REST-only Quant Option System...")
    session = SessionState()
    load_credentials(session)

    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        print("="*50)
        print("📈 ZONE-BASED HYBRID STRATEGY")
        print("1. Start Live Trading")
        print("2. Start Paper Trading")
        print("3. Settings")
        print("4. Exit")
        choice = input("Select option: ").strip()

        if choice == "1":
            mode = "LIVE"
            if not (session.cid and session.token):
                print("❌ Set credentials first (option 3)")
                input("Press Enter...")
                continue
            auto_trade = input("Enable Auto Trade? (y/n): ").lower() == 'y'
            fyers = fyersModel.FyersModel(client_id=session.cid, token=session.token, is_async=False, log_path="")
            session.running = True
            prefetch_initial_data(session, fyers, "NSE:NIFTY50-INDEX")
            threading.Thread(target=chain_poller, args=(session, fyers, "NSE:NIFTY50-INDEX"), daemon=True).start()
            threading.Thread(target=sampler, args=(session, DataLogger(), auto_trade, fyers, mode), daemon=True).start()
            dashboard = TerminalDashboard(session, mode)
            print("\n✅ Live trading started. Press Ctrl+C to stop.\n")
            try:
                while session.running:
                    dashboard.display()
                    time.sleep(Config.SAMPLE_INTERVAL)
            except KeyboardInterrupt:
                session.running = False
                log_console("\n🛑 Stopped")

        elif choice == "2":
            mode = "PAPER"
            session.paper.reset()
            session.position = "FLAT"
            session.held_option_symbol = None
            session.option_entry_price = 0.0
            session.peak_price = 0.0
            if not (session.cid and session.token):
                print("❌ Credentials required for market data (option 3)")
                input("Press Enter...")
                continue
            auto_trade = input("Enable Auto Trade? (y/n): ").lower() == 'y'
            fyers = fyersModel.FyersModel(client_id=session.cid, token=session.token, is_async=False, log_path="")
            session.running = True
            prefetch_initial_data(session, fyers, "NSE:NIFTY50-INDEX")
            threading.Thread(target=chain_poller, args=(session, fyers, "NSE:NIFTY50-INDEX"), daemon=True).start()
            threading.Thread(target=sampler, args=(session, DataLogger(), auto_trade, fyers, mode), daemon=True).start()
            dashboard = TerminalDashboard(session, mode)
            print("\n✅ Paper trading started. Press Ctrl+C to stop.\n")
            try:
                while session.running:
                    dashboard.display()
                    time.sleep(Config.SAMPLE_INTERVAL)
            except KeyboardInterrupt:
                session.running = False
                log_console("\n🛑 Stopped")

        elif choice == "3":
            print("\n⚙️ SETTINGS")
            new_cid = input(f"Client ID [{session.cid if hasattr(session,'cid') else ''}]: ").strip()
            if new_cid: session.cid = new_cid
            new_token = input("Access token: ").strip()
            if new_token: session.token = new_token
            with open('fyers_credentials.json', 'w') as f:
                json.dump({"client_id": session.cid, "access_token": session.token}, f)
            print("✅ Saved")
            input("Press Enter...")

        elif choice == "4":
            break

if __name__ == "__main__":
    main()