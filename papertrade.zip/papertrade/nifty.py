import time
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import pytz
from fyers_apiv3 import fyersModel
from fyers_apiv3.FyersWebsocket import data_ws
import logging
import os
import json
from collections import deque
import csv
import threading
import traceback

# ============================================================
# CONFIGURATION
# ============================================================
class Config:
    SAMPLE_INTERVAL = 1
    OPTION_CHAIN_INTERVAL = 30
    ROLLING_WINDOW_SIZE = 3 * 60          # 3 minutes
    OPTION_TRAIL_MULTIPLIER = 0.5          # SL% = (VIX/100) * multiplier
    TARGET_MULTIPLIER = 2                  # Target = 2 * SL distance
    LOT_SIZE = 195
    MAX_DAILY_ORDERS = 6
    API_RATE_LIMIT = 200
    API_WINDOW = 60
    MAX_RETRIES = 3
    RETRY_DELAY = 2
    BUFFER_SIZE = 1                       # seconds to aggregate before computing delta
    EMA_TRAIL_PCT = 0.10                  # 10% trailing stop on EMA
    PAPER_TRADE = True                    # Set to False for live orders

# ============================================================
# LOGGING
# ============================================================
logging.basicConfig(
    filename="trading_app.log",
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)

def log_debug(msg):
    logging.debug(msg)

def log_console(msg):
    print(msg, flush=True)
    logging.info(msg)

IST = pytz.timezone("Asia/Kolkata")

def now_ist():
    return datetime.now(IST)

def timestamp_ist():
    return now_ist().strftime("%Y-%m-%d %H:%M:%S")

# ============================================================
# ERROR HANDLER
# ============================================================
def handle_errors(func):
    def wrapper(*args, **kwargs):
        for retry in range(Config.MAX_RETRIES):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                log_debug(f"{func.__name__} attempt {retry+1} failed: {e}\n{traceback.format_exc()}")
                if retry < Config.MAX_RETRIES-1:
                    time.sleep(Config.RETRY_DELAY)
                else:
                    log_debug(f"{func.__name__} permanently failed")
                    return None
    return wrapper

# ============================================================
# DATA LOGGER
# ============================================================
class DataLogger:
    def __init__(self, filename="trading_data.csv"):
        self.filename = filename
        self._ensure_header()

    def _ensure_header(self):
        if not os.path.exists(self.filename):
            with open(self.filename, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'timestamp', 'underlying_ltp', 'fut_price', 'signal', 'atm_strike',
                    'expiry_date',
                    'ce_avg', 'pe_avg', 'ema_ce', 'ema_pe',
                    'position',
                    'opt_symbol', 'opt_entry', 'opt_current', 'opt_stop', 'opt_target',
                    'trailing_stop', 'peak_opt_price',
                    'vix', 'sl_pct',
                    'ema_peak_ce', 'ema_peak_pe',
                    'paper_pnl'
                ])

    def log_data(self, timestamp, underlying_ltp, fut_price, signal, atm_strike,
                 expiry_date,
                 ce_avg, pe_avg, ema_ce, ema_pe,
                 position,
                 opt_symbol='', opt_entry=0.0, opt_current=0.0, opt_stop=0.0, opt_target=0.0,
                 trailing_stop=0.0, peak_opt_price=0.0,
                 vix=0.0, sl_pct=0.0,
                 ema_peak_ce=0.0, ema_peak_pe=0.0,
                 paper_pnl=0.0):
        with open(self.filename, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                str(timestamp), underlying_ltp, fut_price, signal, atm_strike,
                expiry_date,
                round(ce_avg,2), round(pe_avg,2),
                round(ema_ce,2), round(ema_pe,2),
                position,
                opt_symbol, round(opt_entry,2), round(opt_current,2),
                round(opt_stop,2), round(opt_target,2),
                round(trailing_stop,2), round(peak_opt_price,2),
                round(vix,2), round(sl_pct*100,2),
                round(ema_peak_ce,2), round(ema_peak_pe,2),
                round(paper_pnl,2)
            ])

    def read_data(self, limit=None):
        try:
            df = pd.read_csv(self.filename)
            return df.tail(limit) if limit else df
        except:
            return pd.DataFrame()

# ============================================================
# SESSION STATE – added raw_data for dashboard
# ============================================================
class SessionState:
    def __init__(self):
        self.lock = threading.RLock()
        self.option_chain_api_count = 0
        self.quote_api_count = 0
        self.api_window_start = now_ist()
        self.cid = ""
        self.token = ""
        self._hb_lock = False
        self.daily_executed_orders = 0
        self.last_order_sync = None
        self.position = "FLAT"
        self.prev_ema_ce = 0.0
        self.prev_ema_pe = 0.0
        self.prev_ce_avg = 0.0
        self.prev_pe_avg = 0.0

        self.ce_window = deque(maxlen=Config.ROLLING_WINDOW_SIZE)
        self.pe_window = deque(maxlen=Config.ROLLING_WINDOW_SIZE)
        self.buffers = {}
        self.window_filled = False
        self.live_ltp = {}
        self.live_volume = {}
        self.option_chain = []
        self.fut_price = None
        self.expiry_date = None
        self.atm_strike = None
        self.option_symbols = []
        self.running = False

        self.held_option_symbol = None
        self.option_entry_price = 0.0
        self.option_stop_price = 0.0
        self.option_target_price = 0.0
        self.current_sl_pct = 0.0
        self.entry_vix = 0.0
        self.peak_opt_price = 0.0
        self.india_vix = 15.0
        self.ema_peak_ce = 0.0
        self.ema_peak_pe = 0.0

        # Paper trading
        self.paper_cash = 100000.0
        self.paper_position = 0
        self.paper_entry_price = 0.0
        self.paper_pnl = 0.0
        self.paper_trades = []

        # RAW DATA FOR DASHBOARD (updated every tick)
        self.raw_option_data = []   # list of dicts

    def update_ws(self, symbol, ltp, volume):
        with self.lock:
            if symbol == "NSE:INDIAVIX-INDEX":
                if ltp is not None:
                    self.india_vix = float(ltp)
                return
            if ltp is not None:
                self.live_ltp[symbol] = float(ltp)
            if volume is not None:
                self.live_volume[symbol] = int(volume)

    def get_ltp(self, symbol):
        with self.lock:
            return self.live_ltp.get(symbol)

    def get_volume(self, symbol):
        with self.lock:
            return self.live_volume.get(symbol)

    def update_chain(self, chain, fut_price, expiry_date, atm_strike, option_symbols):
        with self.lock:
            self.option_chain = chain
            self.fut_price = float(fut_price) if fut_price else 0.0
            self.expiry_date = expiry_date
            self.atm_strike = int(atm_strike) if atm_strike else None
            self.option_symbols = option_symbols
            log_debug(f"Chain updated: ATM={self.atm_strike}, fut={self.fut_price}, {len(option_symbols)} symbols")

    def sync_order_count(self, fyers):
        if Config.PAPER_TRADE:
            return
        today = now_ist().date()
        if self.last_order_sync != today:
            self.daily_executed_orders = 0
            self.last_order_sync = today
        try:
            resp = fyers.orderbook()
            if resp.get("s") == "ok":
                self.daily_executed_orders = len([o for o in resp.get("orderBook", []) if o.get("status") == 2])
        except Exception as e:
            log_debug(f"Order sync failed: {e}")

    def can_place_order(self, fyers=None):
        if Config.PAPER_TRADE:
            return True
        if fyers:
            self.sync_order_count(fyers)
        return self.daily_executed_orders < Config.MAX_DAILY_ORDERS

# ============================================================
# WEBSOCKET MANAGER
# ============================================================
class MarketWSManager:
    def __init__(self, session_state, access_token):
        self.session = session_state
        self.access_token = access_token
        self.ws = None
        self.subscribed = set()
        self.running = False

    def on_message(self, message):
        symbol = message.get("symbol")
        if symbol:
            ltp = message.get("ltp")
            volume = message.get("vol_traded_today")
            self.session.update_ws(symbol, ltp, volume)

    def on_error(self, msg):
        log_console(f"WS error: {msg}")

    def on_close(self, msg):
        log_console(f"WS closed: {msg}")
        self.running = False

    def on_open(self):
        log_console("WebSocket connected")
        if self.subscribed:
            self.ws.subscribe(list(self.subscribed), "SymbolUpdate")
        self.ws.keep_running()

    def start(self):
        if self.running:
            return
        self.running = True
        self.ws = data_ws.FyersDataSocket(
            access_token=self.access_token,
            log_path="",
            litemode=False,
            write_to_file=False,
            reconnect=True,
            on_connect=self.on_open,
            on_close=self.on_close,
            on_error=self.on_error,
            on_message=self.on_message
        )
        self.ws.connect()
        log_debug("WebSocket started")

    def subscribe(self, symbols):
        new_symbols = set(symbols) - self.subscribed
        if new_symbols:
            log_debug(f"Subscribing to new symbols: {new_symbols}")
            if self.ws:
                self.ws.subscribe(list(new_symbols), "SymbolUpdate")
            self.subscribed.update(new_symbols)

    def stop(self):
        self.running = False
        if self.ws:
            self.ws.close_connection()

# ============================================================
# REST API HELPERS
# ============================================================
def enforce_rate_limit(session):
    now = now_ist()
    window = (now - session.api_window_start).total_seconds()
    total = session.option_chain_api_count + session.quote_api_count
    if window > Config.API_WINDOW:
        session.api_window_start = now
        session.option_chain_api_count = 0
        session.quote_api_count = 0
    elif total >= Config.API_RATE_LIMIT:
        wait = Config.API_WINDOW - window
        if wait > 0:
            time.sleep(wait)
        session.api_window_start = now
        session.option_chain_api_count = 0
        session.quote_api_count = 0

@handle_errors
def fetch_option_chain(session, index_symbol):
    log_debug("Enter fetch_option_chain")
    enforce_rate_limit(session)
    session.option_chain_api_count += 1
    fy = fyersModel.FyersModel(client_id=session.cid, token=session.token, is_async=False, log_path="")
    meta = fy.optionchain(data={"symbol": index_symbol, "timestamp": ""})
    if meta.get("code") != 200:
        log_debug(f"Meta chain failed: {meta}")
        return None, None, None, None, []
    fut_price = None
    for item in meta["data"]["optionsChain"]:
        if item.get("option_type") == "":
            fut_price = item.get("fp")
            break
    if fut_price is None:
        fut_price = meta["data"].get("fp", 0.0)
    exp_list = sorted([(e["date"], e["expiry"]) for e in meta["data"]["expiryData"]],
                      key=lambda x: datetime.strptime(x[0], "%d-%m-%Y"))
    today = now_ist().date()
    idx = 0
    for i, (d_str, _) in enumerate(exp_list):
        if datetime.strptime(d_str, "%d-%m-%Y").date() >= today:
            idx = i
            break
    curr_date, expiry_ts = exp_list[idx]
    payload = {"symbol": index_symbol, "strikecount": 5, "timestamp": expiry_ts, "greeks": "0"}
    resp = fy.optionchain(data=payload)
    if resp.get("code") != 200:
        log_debug(f"Detailed chain failed: {resp}")
        return None, None, None, None, []
    chain = resp["data"]["optionsChain"]
    option_symbols = [opt["symbol"] for opt in chain if opt.get("option_type") in ("CE","PE")]
    log_debug(f"Got {len(chain)} options, {len(option_symbols)} symbols")
    return chain, fut_price, curr_date, expiry_ts, option_symbols

# ============================================================
# CHAIN POLLER
# ============================================================
def chain_poller(session, ws_manager, index_symbol):
    log_debug("Chain poller thread started")
    while session.running:
        try:
            chain, fut_price, expiry_date, _, opt_symbols = fetch_option_chain(session, index_symbol)
            if chain is None:
                log_debug("Chain fetch returned None")
            else:
                underlying_ltp = session.get_ltp(index_symbol)
                if underlying_ltp is None:
                    underlying_ltp = fut_price
                strikes = sorted(set(opt["strike_price"] for opt in chain if opt.get("option_type") in ("CE","PE")))
                if strikes and underlying_ltp:
                    atm = min(strikes, key=lambda x: abs(x - underlying_ltp))
                else:
                    atm = None
                session.update_chain(chain, fut_price, expiry_date, atm, opt_symbols)
                all_syms = [index_symbol] + opt_symbols
                ws_manager.subscribe(all_syms)
            time.sleep(Config.OPTION_CHAIN_INTERVAL)
        except Exception as e:
            log_debug(f"Chain poller error: {e}\n{traceback.format_exc()}")
            time.sleep(Config.OPTION_CHAIN_INTERVAL)

# ============================================================
# SIGNAL COMPUTATION – now stores raw data for dashboard
# ============================================================
def compute_signal(session):
    log_debug(">>> compute_signal called")
    try:
        with session.lock:
            if not session.option_chain or session.atm_strike is None:
                return "HOLD", {}

            underlying_ltp = session.get_ltp("NSE:NIFTY50-INDEX")
            if underlying_ltp is None:
                return "HOLD", {}

            strikes = sorted(set(opt["strike_price"] for opt in session.option_chain if opt.get("option_type") in ("CE","PE")))
            if not strikes or session.atm_strike not in strikes:
                return "HOLD", {}

            idx = strikes.index(session.atm_strike)
            selected = [session.atm_strike]
            if idx > 0: selected.append(strikes[idx-1])
            if idx < len(strikes)-1: selected.append(strikes[idx+1])

            # Build raw data list for dashboard
            raw_data = []
            sum_ce = 0.0
            sum_pe = 0.0
            cnt_ce = 0
            cnt_pe = 0

            for strike in selected:
                ce_opt = next((o for o in session.option_chain if o["strike_price"] == strike and o["option_type"] == "CE"), None)
                pe_opt = next((o for o in session.option_chain if o["strike_price"] == strike and o["option_type"] == "PE"), None)
                if not ce_opt or not pe_opt:
                    continue

                strike_raw = {"strike": strike, "CE": {}, "PE": {}}

                for opt, key in [(ce_opt, "CE"), (pe_opt, "PE")]:
                    sym = opt["symbol"]
                    curr_ltp = session.get_ltp(sym)
                    curr_vol = session.get_volume(sym)
                    buffer_len = len(session.buffers.get(sym, []))
                    last_product = None

                    if curr_ltp is not None and curr_vol is not None:
                        if sym not in session.buffers:
                            session.buffers[sym] = []
                        session.buffers[sym].append((curr_ltp, curr_vol))

                        if len(session.buffers[sym]) >= Config.BUFFER_SIZE:
                            first_ltp, first_vol = session.buffers[sym][0]
                            delta_ltp = curr_ltp - first_ltp
                            delta_vol = curr_vol - first_vol
                            last_product = delta_ltp * delta_vol
                            # Accumulate
                            if key == "CE":
                                sum_ce += last_product
                                cnt_ce += 1
                            else:
                                sum_pe += last_product
                                cnt_pe += 1
                            # Clear buffer
                            session.buffers[sym] = []

                    strike_raw[key] = {
                        "symbol": sym,
                        "ltp": curr_ltp if curr_ltp else 0,
                        "vol": curr_vol if curr_vol else 0,
                        "buffer": len(session.buffers.get(sym, [])),
                        "last_product": round(last_product, 2) if last_product else None
                    }

                raw_data.append(strike_raw)

            # Store raw data in session for dashboard
            session.raw_option_data = raw_data

            if cnt_ce == 0 or cnt_pe == 0:
                return "HOLD", {}

            ce_avg = sum_ce / cnt_ce
            pe_avg = sum_pe / cnt_pe
            session.ce_window.append(ce_avg)
            session.pe_window.append(pe_avg)

            if len(session.ce_window) < Config.ROLLING_WINDOW_SIZE:
                metrics = {"spot": underlying_ltp, "atm_strike": session.atm_strike,
                           "ce_avg": ce_avg, "pe_avg": pe_avg, "ema_ce": 0.0, "ema_pe": 0.0}
                return "HOLD", metrics
            else:
                if not session.window_filled:
                    session.window_filled = True
                    log_console("✓ 5‑minute window filled – strategy active")

            alpha = 2 / (Config.ROLLING_WINDOW_SIZE + 1)
            ce_list = list(session.ce_window)
            ema_ce = ce_list[0]
            for v in ce_list[1:]:
                ema_ce = alpha * v + (1 - alpha) * ema_ce
            pe_list = list(session.pe_window)
            ema_pe = pe_list[0]
            for v in pe_list[1:]:
                ema_pe = alpha * v + (1 - alpha) * ema_pe

            if session.position == "LONG":
                if ema_ce > session.ema_peak_ce:
                    session.ema_peak_ce = ema_ce
            elif session.position == "SHORT":
                if ema_pe > session.ema_peak_pe:
                    session.ema_peak_pe = ema_pe

            signal = "HOLD"
            intended = session.position
            if session.held_option_symbol is not None:
                opt_ltp = session.get_ltp(session.held_option_symbol)
                if opt_ltp is not None:
                    exit_reason = None
                    if opt_ltp > session.peak_opt_price:
                        session.peak_opt_price = opt_ltp
                    trailing_stop_opt = session.peak_opt_price * (1 - session.current_sl_pct)
                    fixed_stop = session.option_stop_price
                    target = session.option_target_price
                    if opt_ltp <= fixed_stop:
                        exit_reason = f"Fixed SL hit: {opt_ltp:.2f} <= {fixed_stop:.2f}"
                    elif opt_ltp <= trailing_stop_opt:
                        exit_reason = f"Trailing SL hit: {opt_ltp:.2f} <= {trailing_stop_opt:.2f}"
                    elif opt_ltp >= target:
                        exit_reason = f"Target hit: {opt_ltp:.2f} >= {target:.2f}"
                    if not exit_reason:
                        if session.position == "LONG" and session.ema_peak_ce > 0:
                            if ema_ce < session.ema_peak_ce * (1 - Config.EMA_TRAIL_PCT):
                                exit_reason = f"EMA_CE dropped from peak {session.ema_peak_ce:.2f} to {ema_ce:.2f}"
                        elif session.position == "SHORT" and session.ema_peak_pe > 0:
                            if ema_pe < session.ema_peak_pe * (1 - Config.EMA_TRAIL_PCT):
                                exit_reason = f"EMA_PE dropped from peak {session.ema_peak_pe:.2f} to {ema_pe:.2f}"
                    if exit_reason:
                        log_console(f"🟡 EXIT triggered: {exit_reason}")
                        signal = "EXIT"
                        intended = "FLAT"

            if session.position == "FLAT" and signal != "EXIT":
                buy_signal = (ema_ce > 0 and ema_ce > ema_pe)
                prev_buy = (session.prev_ema_ce > 0 and session.prev_ema_ce > session.prev_ema_pe)
                if buy_signal and not prev_buy:
                    signal = "BUY"
                    intended = "LONG"
                sell_signal = (ema_pe > 0 and ema_pe > ema_ce)
                prev_sell = (session.prev_ema_pe > 0 and session.prev_ema_pe > session.prev_ema_ce)
                if sell_signal and not prev_sell:
                    signal = "SELL"
                    intended = "SHORT"

            session.prev_ema_ce = ema_ce
            session.prev_ema_pe = ema_pe
            metrics = {"spot": underlying_ltp, "atm_strike": session.atm_strike,
                       "ce_avg": ce_avg, "pe_avg": pe_avg, "ema_ce": ema_ce, "ema_pe": ema_pe,
                       "ema_peak_ce": session.ema_peak_ce, "ema_peak_pe": session.ema_peak_pe}
            return signal, metrics
    except Exception as e:
        log_debug(f"CRASH in compute_signal: {e}\n{traceback.format_exc()}")
        return "HOLD", {}

# ============================================================
# ORDER PLACEMENT (unchanged, already fixed)
# ============================================================
def place_order(session, signal, atm_ce, atm_pe, fyers, entry_metrics=None):
    if getattr(session, '_hb_lock', False):
        return False
    session._hb_lock = True
    try:
        if signal == "EXIT":
            log_console("🟡 EXIT signal – closing positions")
            if Config.PAPER_TRADE:
                if session.paper_position != 0:
                    opt_sym = session.held_option_symbol
                    opt_ltp = session.get_ltp(opt_sym) if opt_sym else 0
                    if opt_ltp:
                        if session.paper_position == 1:
                            pnl = (opt_ltp - session.paper_entry_price) * Config.LOT_SIZE
                        else:
                            pnl = (session.paper_entry_price - opt_ltp) * Config.LOT_SIZE
                        session.paper_cash += pnl
                        session.paper_pnl = pnl
                        log_console(f"📄 Paper trade closed: P&L = {pnl:.2f}")
                        session.paper_trades.append({
                            'time': timestamp_ist(), 'action': 'EXIT', 'symbol': opt_sym,
                            'price': opt_ltp, 'pnl': pnl, 'cash': session.paper_cash
                        })
                    session.paper_position = 0
                    session.paper_entry_price = 0.0
                session.held_option_symbol = None
                session.option_stop_price = 0.0
                session.option_target_price = 0.0
                session.peak_opt_price = 0.0
                session.ema_peak_ce = 0.0
                session.ema_peak_pe = 0.0
                session.position = "FLAT"
                log_console("✓ Positions closed (paper or live)")
                return True
            else:
                if session.position in ("LONG", "SHORT") and session.held_option_symbol:
                    exit_side = -1 if session.position == "LONG" else 1
                    order = {
                        "symbol": session.held_option_symbol,
                        "qty": Config.LOT_SIZE,
                        "type": 2,
                        "side": exit_side,
                        "productType": "MARGIN",
                        "validity": "DAY",
                    }
                    resp = fyers.place_order(data=order)
                    if resp.get("s") == "ok":
                        log_console("✓ Exit order placed")
                    else:
                        log_console(f"❌ Exit order failed: {resp}")
                session.position = "FLAT"
                session.held_option_symbol = None
                session.option_stop_price = 0.0
                session.option_target_price = 0.0
                session.peak_opt_price = 0.0
                session.ema_peak_ce = 0.0
                session.ema_peak_pe = 0.0
                log_console("✓ Position closed (live)")
                return True

        if signal in ("BUY","SELL") and session.can_place_order(fyers):
            leg = atm_ce if signal == "BUY" else atm_pe
            if not leg:
                return False
            side_str = "LONG" if signal == "BUY" else "SHORT"
            log_console(f"🟢 {signal} signal – placing {side_str} order (buy {leg['symbol']})")

            if Config.PAPER_TRADE:
                opt_ltp = session.get_ltp(leg["symbol"])
                if opt_ltp is None:
                    log_console("❌ No LTP for paper trade, aborting")
                    return False
                if signal == "BUY":
                    session.paper_position = 1
                    session.paper_cash -= opt_ltp * Config.LOT_SIZE
                else:
                    session.paper_position = -1
                    session.paper_cash += opt_ltp * Config.LOT_SIZE
                session.paper_entry_price = opt_ltp
                session.paper_pnl = 0.0
                session.paper_trades.append({
                    'time': timestamp_ist(), 'action': 'ENTRY', 'side': side_str,
                    'symbol': leg['symbol'], 'price': opt_ltp, 'cash': session.paper_cash
                })
                session.held_option_symbol = leg["symbol"]
                session.option_entry_price = opt_ltp
                session.entry_vix = session.india_vix
                sl_pct = (session.india_vix / 100.0) * Config.OPTION_TRAIL_MULTIPLIER
                sl_pct = max(0.01, sl_pct)
                session.current_sl_pct = sl_pct
                session.option_stop_price = opt_ltp * (1 - sl_pct)
                session.option_target_price = opt_ltp * (1 + Config.TARGET_MULTIPLIER * sl_pct)
                session.peak_opt_price = opt_ltp
                session.ema_peak_ce = 0.0
                session.ema_peak_pe = 0.0
                session.position = side_str
                log_console(f"   Paper position: {side_str}, Entry: {opt_ltp:.2f}, SL: {session.option_stop_price:.2f}, Target: {session.option_target_price:.2f}")
                return True
            else:
                current_opt_ltp = session.get_ltp(leg["symbol"])
                if current_opt_ltp is None:
                    log_console("❌ No LTP available for order, aborting")
                    return False
                side = 1 if signal == "BUY" else -1
                order = {
                    "symbol": leg["symbol"],
                    "qty": Config.LOT_SIZE,
                    "type": 2,
                    "side": side,
                    "productType": "MARGIN",
                    "validity": "DAY",
                }
                resp = fyers.place_order(data=order)
                if resp.get("s") == "ok":
                    session.position = side_str
                    session.held_option_symbol = leg["symbol"]
                    session.option_entry_price = current_opt_ltp
                    session.entry_vix = session.india_vix
                    sl_pct = (session.india_vix / 100.0) * Config.OPTION_TRAIL_MULTIPLIER
                    sl_pct = max(0.01, sl_pct)
                    session.current_sl_pct = sl_pct
                    session.option_stop_price = current_opt_ltp * (1 - sl_pct)
                    session.option_target_price = current_opt_ltp * (1 + Config.TARGET_MULTIPLIER * sl_pct)
                    session.peak_opt_price = current_opt_ltp
                    session.ema_peak_ce = 0.0
                    session.ema_peak_pe = 0.0
                    log_console(f"✓ {side_str} order placed successfully")
                    return True
                else:
                    log_console(f"❌ Order failed: {resp}")
                    return False
        return False
    except Exception as e:
        log_console(f"Order error: {e}")
        return False
    finally:
        session._hb_lock = False

# ============================================================
# DASHBOARD – NOW SHOWING RAW STRIKE DATA
# ============================================================
class TerminalDashboard:
    def __init__(self, data_logger, session_state):
        self.data_logger = data_logger
        self.session_state = session_state

    def display(self):
        try:
            os.system('cls' if os.name == 'nt' else 'clear')
            df = self.data_logger.read_data(limit=1)

            print("\n" + "="*120)
            print("📊 LIVE TRADING DASHBOARD")
            print("="*120)
            print(f"Last Update: {timestamp_ist()}")
            print(f"📈 DAILY ORDER COUNT: {self.session_state.daily_executed_orders}/{Config.MAX_DAILY_ORDERS}")
            print(f"📊 India VIX: {self.session_state.india_vix:.2f}")
            window_size = len(self.session_state.ce_window)
            if not self.session_state.window_filled:
                print(f"⏳ WARMING UP: {window_size}/{Config.ROLLING_WINDOW_SIZE} samples")
            else:
                print(f"✅ WINDOW FULL: {window_size} samples")

            # --- RAW OPTION DATA ---
            print("\n" + "-"*120)
            print("📋 STRIKE-WISE OPTION DATA (Real-time)")
            print("-"*120)
            print(f"Underlying LTP: {self.session_state.get_ltp('NSE:NIFTY50-INDEX')}")
            print(f"ATM Strike: {self.session_state.atm_strike}")
            if self.session_state.raw_option_data:
                print(f"{'Strike':<10} {'Type':<4} {'Symbol':<25} {'LTP':>8} {'Volume':>10} {'Buffer':>6} {'Last Product':>14}")
                print("-"*120)
                for strike_data in self.session_state.raw_option_data:
                    strike = strike_data["strike"]
                    for otype in ["CE", "PE"]:
                        d = strike_data[otype]
                        prod_str = f"{d['last_product']:.2f}" if d['last_product'] is not None else "N/A"
                        print(f"{strike:<10} {otype:<4} {d['symbol']:<25} {d['ltp']:>8.2f} {d['vol']:>10} {d['buffer']:>6} {prod_str:>14}")
            else:
                print("   No data yet...")

            # --- SIGNAL VALUES ---
            print("\n" + "-"*80)
            print("📈 CURRENT SIGNAL VALUES")
            print("-"*80)
            if not df.empty:
                latest = df.iloc[-1]
                print(f"   Signal: {latest['signal']}")
                print(f"   Position: {self.session_state.position}")
                print(f"   CE avg: {latest['ce_avg']:.2f}")
                print(f"   PE avg: {latest['pe_avg']:.2f}")
                print(f"   EMA_CE: {latest['ema_ce']:.2f}")
                print(f"   EMA_PE: {latest['ema_pe']:.2f}")
                if self.session_state.position == "LONG":
                    print(f"   EMA_CE peak: {self.session_state.ema_peak_ce:.2f}")
                elif self.session_state.position == "SHORT":
                    print(f"   EMA_PE peak: {self.session_state.ema_peak_pe:.2f}")
            else:
                print("   Waiting for first data point...")

            # --- POSITION & PAPER ---
            pos = self.session_state.position
            if pos in ("LONG", "SHORT"):
                if self.session_state.held_option_symbol:
                    opt_ltp = self.session_state.get_ltp(self.session_state.held_option_symbol)
                    if opt_ltp:
                        trailing_stop_opt = self.session_state.peak_opt_price * (1 - self.session_state.current_sl_pct)
                        print(f"\n{'📈 LONG (Call)' if pos == 'LONG' else '📉 SHORT (Put)'} POSITION ACTIVE")
                        print(f"   Held option: {self.session_state.held_option_symbol}")
                        print(f"   Entry: {self.session_state.option_entry_price:.2f}")
                        print(f"   Current: {opt_ltp:.2f}")
                        print(f"   Peak: {self.session_state.peak_opt_price:.2f}")
                        print(f"   SL%: {self.session_state.current_sl_pct*100:.2f}%")
                        print(f"   Fixed stop: {self.session_state.option_stop_price:.2f}")
                        print(f"   Trailing stop: {trailing_stop_opt:.2f}")
                        print(f"   Target: {self.session_state.option_target_price:.2f}")
                    else:
                        print(f"\n{'📈 LONG' if pos == 'LONG' else '📉 SHORT'} POSITION ACTIVE (waiting for option price)")
            else:
                print(f"\n💤 FLAT - Ready for entry" if self.session_state.window_filled else f"\n💤 FLAT - Warming up")

            if Config.PAPER_TRADE:
                print("\n" + "-"*80)
                print("📄 PAPER TRADING STATUS")
                print("-"*80)
                print(f"   Cash: {self.session_state.paper_cash:.2f}")
                if self.session_state.paper_position != 0:
                    opt_sym = self.session_state.held_option_symbol
                    opt_ltp = self.session_state.get_ltp(opt_sym) if opt_sym else 0
                    if opt_ltp and self.session_state.paper_entry_price:
                        if self.session_state.paper_position == 1:
                            pnl = (opt_ltp - self.session_state.paper_entry_price) * Config.LOT_SIZE
                        else:
                            pnl = (self.session_state.paper_entry_price - opt_ltp) * Config.LOT_SIZE
                        print(f"   Position: {'LONG' if self.session_state.paper_position == 1 else 'SHORT'}")
                        print(f"   Entry: {self.session_state.paper_entry_price:.2f}")
                        print(f"   Current: {opt_ltp:.2f}")
                        print(f"   Unrealised P&L: {pnl:.2f}")
                        print(f"   Total Equity: {self.session_state.paper_cash + pnl:.2f}")
                    else:
                        print(f"   Position: {'LONG' if self.session_state.paper_position == 1 else 'SHORT'} (price unknown)")
                else:
                    print(f"   Position: FLAT")
                    print(f"   Total Equity: {self.session_state.paper_cash:.2f}")
                print(f"   Trade Count: {len(self.session_state.paper_trades)}")

            print("\n" + "="*120)
        except Exception as e:
            log_debug(f"Dashboard error: {e}")

# ============================================================
# SAMPLER, CREDENTIALS, MAIN (unchanged except passing new data)
# ============================================================
last_signal_logged = None

def sampler(session, data_logger, auto_trade, fyers):
    global last_signal_logged
    log_debug("Sampler thread started")
    while session.running:
        start = now_ist()
        try:
            signal, metrics = compute_signal(session)
            if metrics:
                opt_symbol = session.held_option_symbol if session.held_option_symbol else ''
                opt_entry = session.option_entry_price if session.held_option_symbol else 0.0
                opt_current = session.get_ltp(opt_symbol) if opt_symbol else 0.0
                opt_stop = session.option_stop_price if session.held_option_symbol else 0.0
                opt_target = session.option_target_price if session.held_option_symbol else 0.0
                peak_opt = session.peak_opt_price if session.held_option_symbol else 0.0
                trailing_stop_opt = peak_opt * (1 - session.current_sl_pct) if session.held_option_symbol else 0.0
                vix = session.india_vix
                sl_pct = session.current_sl_pct if session.held_option_symbol else 0.0
                ema_peak_ce = session.ema_peak_ce
                ema_peak_pe = session.ema_peak_pe
                paper_pnl = 0.0
                if Config.PAPER_TRADE and session.paper_position != 0:
                    opt_sym = session.held_option_symbol
                    opt_ltp = session.get_ltp(opt_sym) if opt_sym else 0
                    if opt_ltp and session.paper_entry_price:
                        if session.paper_position == 1:
                            paper_pnl = (opt_ltp - session.paper_entry_price) * Config.LOT_SIZE
                        else:
                            paper_pnl = (session.paper_entry_price - opt_ltp) * Config.LOT_SIZE

                data_logger.log_data(
                    timestamp=timestamp_ist(),
                    underlying_ltp=metrics.get("spot", 0),
                    fut_price=session.fut_price or 0,
                    signal=signal,
                    atm_strike=metrics.get("atm_strike", 0),
                    expiry_date=session.expiry_date or "",
                    ce_avg=metrics.get("ce_avg", 0.0),
                    pe_avg=metrics.get("pe_avg", 0.0),
                    ema_ce=metrics.get("ema_ce", 0.0),
                    ema_pe=metrics.get("ema_pe", 0.0),
                    position=session.position,
                    opt_symbol=opt_symbol,
                    opt_entry=opt_entry,
                    opt_current=opt_current,
                    opt_stop=opt_stop,
                    opt_target=opt_target,
                    trailing_stop=trailing_stop_opt,
                    peak_opt_price=peak_opt,
                    vix=vix,
                    sl_pct=sl_pct,
                    ema_peak_ce=ema_peak_ce,
                    ema_peak_pe=ema_peak_pe,
                    paper_pnl=paper_pnl
                )
                if signal != last_signal_logged and signal != "HOLD":
                    log_console(f"📢 Signal changed to: {signal}")
                    last_signal_logged = signal

            if auto_trade and signal in ("BUY","SELL","EXIT"):
                atm_ce = atm_pe = None
                if session.atm_strike:
                    for opt in session.option_chain:
                        if opt["strike_price"] == session.atm_strike:
                            if opt["option_type"] == "CE":
                                atm_ce = {"symbol": opt["symbol"]}
                            elif opt["option_type"] == "PE":
                                atm_pe = {"symbol": opt["symbol"]}
                if signal == "EXIT":
                    place_order(session, signal, None, None, fyers, None)
                elif signal == "BUY" and atm_ce:
                    place_order(session, signal, atm_ce, None, fyers, metrics)
                elif signal == "SELL" and atm_pe:
                    place_order(session, signal, None, atm_pe, fyers, metrics)
            elapsed = (now_ist() - start).total_seconds()
            if elapsed < Config.SAMPLE_INTERVAL:
                time.sleep(Config.SAMPLE_INTERVAL - elapsed)
        except Exception as e:
            log_debug(f"Sampler error: {e}\n{traceback.format_exc()}")
            time.sleep(1)

def load_credentials(session):
    try:
        with open('fyers_credentials.json', 'r') as f:
            creds = json.load(f)
            session.cid = creds.get('client_id', '')
            session.token = creds.get('access_token', '')
        log_console(f"Loaded credentials: {session.cid}")
    except Exception as e:
        session.cid = os.getenv("FYERS_CID", "")
        session.token = os.getenv("FYERS_TOKEN", "")
        log_console(f"Using env vars: {session.cid}")

def main():
    log_console("Starting Algo Trading System...")
    session = SessionState()
    load_credentials(session)
    data_logger = DataLogger()
    dashboard = TerminalDashboard(data_logger, session)
    index_symbol = "NSE:NIFTY50-INDEX"
    vix_symbol = "NSE:INDIAVIX-INDEX"

    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        print("="*50)
        print("📈 FYERS ALGO TRADING (Separate EMA CE/PE)")
        print("1. Start Live Trading")
        print("2. Settings")
        print("3. Exit")
        choice = input("Select option: ").strip()
        if choice == "1":
            if not (session.cid and session.token) and not Config.PAPER_TRADE:
                print("❌ Set credentials first (or enable paper trade)")
                input("Press Enter...")
                continue
            auto_trade = input("Enable Auto Trade? (y/n): ").lower() == 'y'
            log_console(f"Auto trade: {'ON' if auto_trade else 'OFF'}")
            log_console(f"Paper trade mode: {'ON' if Config.PAPER_TRADE else 'OFF'}")
            ws_manager = MarketWSManager(session, session.token)
            ws_manager.start()
            ws_manager.subscribe([index_symbol, vix_symbol])
            session.running = True
            threading.Thread(target=chain_poller, args=(session, ws_manager, index_symbol), daemon=True).start()
            fyers = fyersModel.FyersModel(client_id=session.cid, token=session.token, is_async=False, log_path="")
            threading.Thread(target=sampler, args=(session, data_logger, auto_trade, fyers), daemon=True).start()
            print("\n✅ Live trading started. Press Ctrl+C to stop.\n")
            try:
                while True:
                    dashboard.display()
                    time.sleep(2)
            except KeyboardInterrupt:
                session.running = False
                ws_manager.stop()
                log_console("\n🛑 Trading stopped by user")
        elif choice == "2":
            print("\n⚙️ SETTINGS")
            new_cid = input(f"Client ID [{session.cid}]: ").strip()
            if new_cid:
                session.cid = new_cid
            new_token = input("Access token: ").strip()
            if new_token:
                session.token = new_token
            paper = input("Enable paper trade? (y/n) [current: {}]: ".format("ON" if Config.PAPER_TRADE else "OFF"))
            if paper.lower() == 'y':
                Config.PAPER_TRADE = True
            elif paper.lower() == 'n':
                Config.PAPER_TRADE = False
            with open('fyers_credentials.json', 'w') as f:
                json.dump({"client_id": session.cid, "access_token": session.token}, f)
            print("✅ Saved")
            input("Press Enter...")
        elif choice == "3":
            break

if __name__ == "__main__":
    main()