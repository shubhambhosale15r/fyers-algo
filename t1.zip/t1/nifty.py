import time
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import pytz
from fyers_apiv3 import fyersModel
from fyers_apiv3.FyersWebsocket import data_ws
import logging
import os
import json
from collections import deque
import csv
import threading
import traceback

# ============================================================
# CONFIGURATION
# ============================================================
class Config:
    SAMPLE_INTERVAL = 1
    OPTION_CHAIN_INTERVAL = 30
    ROLLING_WINDOW_SIZE = 15 * 60          # 5 minutes
    OPTION_TRAIL_MULTIPLIER = 0.5          # SL% = (VIX/100) * multiplier
    TARGET_MULTIPLIER = 2                  # Target = 2 * SL distance
    LOT_SIZE = 195
    MAX_DAILY_ORDERS = 6
    API_RATE_LIMIT = 200
    API_WINDOW = 60
    MAX_RETRIES = 3
    RETRY_DELAY = 2

# ============================================================
# LOGGING
# ============================================================
logging.basicConfig(
    filename="trading_app.log",
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)

def log_debug(msg):
    logging.debug(msg)

def log_console(msg):
    print(msg, flush=True)
    logging.info(msg)

IST = pytz.timezone("Asia/Kolkata")

def now_ist():
    return datetime.now(IST)

def timestamp_ist():
    return now_ist().strftime("%Y-%m-%d %H:%M:%S")

# ============================================================
# ERROR HANDLER
# ============================================================
def handle_errors(func):
    def wrapper(*args, **kwargs):
        for retry in range(Config.MAX_RETRIES):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                log_debug(f"{func.__name__} attempt {retry+1} failed: {e}\n{traceback.format_exc()}")
                if retry < Config.MAX_RETRIES-1:
                    time.sleep(Config.RETRY_DELAY)
                else:
                    log_debug(f"{func.__name__} permanently failed")
                    return None
    return wrapper

# ============================================================
# DATA LOGGER (CSV) – includes trailing_stop and peak_opt_price
# ============================================================
class DataLogger:
    def __init__(self, filename="trading_data.csv"):
        self.filename = filename
        self._ensure_header()

    def _ensure_header(self):
        if not os.path.exists(self.filename):
            with open(self.filename, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'timestamp', 'underlying_ltp', 'fut_price', 'signal', 'atm_strike',
                    'expiry_date', 'idwp', 'inof', 'cumul_idwp', 'cumul_inof',
                    'vwap_composite', 'cumul_vwap_composite', 'position',
                    'opt_symbol', 'opt_entry', 'opt_current', 'opt_stop', 'opt_target',
                    'trailing_stop', 'peak_opt_price',   # NEW
                    'vix', 'sl_pct'
                ])

    def log_data(self, timestamp, underlying_ltp, fut_price, signal, atm_strike,
                 expiry_date, idwp, inof, cumul_idwp, cumul_inof,
                 vwap_composite, cumul_vwap_composite, position,
                 opt_symbol='', opt_entry=0.0, opt_current=0.0, opt_stop=0.0, opt_target=0.0,
                 trailing_stop=0.0, peak_opt_price=0.0,   # NEW
                 vix=0.0, sl_pct=0.0):
        with open(self.filename, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                str(timestamp), underlying_ltp, fut_price, signal, atm_strike,
                expiry_date, round(idwp,2), round(inof,2), round(cumul_idwp,2),
                round(cumul_inof,2), round(vwap_composite,2), round(cumul_vwap_composite,2),
                position,
                opt_symbol, round(opt_entry,2), round(opt_current,2), round(opt_stop,2), round(opt_target,2),
                round(trailing_stop,2), round(peak_opt_price,2),   # NEW
                round(vix,2), round(sl_pct*100,2)
            ])

    def read_data(self, limit=None):
        try:
            df = pd.read_csv(self.filename)
            return df.tail(limit) if limit else df
        except:
            return pd.DataFrame()

# ============================================================
# STRIKE DETAILS (unchanged)
# ============================================================
def get_strike_details(session):
    details = []
    with session.lock:
        if not session.option_chain or session.atm_strike is None:
            return details
        fut = session.fut_price
        atm = session.atm_strike
        all_strikes = sorted(set(opt["strike_price"] for opt in session.option_chain if opt.get("option_type") in ("CE","PE")))
        if not all_strikes or atm not in all_strikes:
            return details
        idx = all_strikes.index(atm)
        selected = [atm]
        if idx > 0:
            selected.append(all_strikes[idx-1])
        if idx < len(all_strikes)-1:
            selected.append(all_strikes[idx+1])
        for strike in selected:
            ce = next((o for o in session.option_chain if o["strike_price"] == strike and o["option_type"] == "CE"), None)
            pe = next((o for o in session.option_chain if o["strike_price"] == strike and o["option_type"] == "PE"), None)
            if not ce or not pe:
                continue
            ce_ltp = session.get_ltp(ce["symbol"]) or ce.get("ltp", 0)
            pe_ltp = session.get_ltp(pe["symbol"]) or pe.get("ltp", 0)
            ce_vwap = session.get_vwap(ce["symbol"]) or ce_ltp
            pe_vwap = session.get_vwap(pe["symbol"]) or pe_ltp
            ce_current_vol = session.get_volume(ce["symbol"]) or ce.get("volume", 0)
            pe_current_vol = session.get_volume(pe["symbol"]) or pe.get("volume", 0)
            ce_delta = ce.get("greeks", {}).get("delta", 0)
            pe_delta = abs(pe.get("greeks", {}).get("delta", 0))
            parity = (ce_ltp - pe_ltp) / (ce_ltp + pe_ltp) if (ce_ltp + pe_ltp) != 0 else 0
            diff_ce = max(0, ce_current_vol - session.prev_ce_volume.get(ce["symbol"], ce_current_vol))
            diff_pe = max(0, pe_current_vol - session.prev_pe_volume.get(pe["symbol"], pe_current_vol))
            inof = (diff_ce * ce_delta) - (diff_pe * pe_delta)
            ce_mom = ce_ltp - ce_vwap
            pe_mom = pe_ltp - pe_vwap
            details.append({
                "strike": strike,
                "ce_ltp": ce_ltp,
                "ce_vwap": ce_vwap,
                "pe_ltp": pe_ltp,
                "pe_vwap": pe_vwap,
                "parity": parity,
                "inof": inof,
                "ce_mom": ce_mom,
                "pe_mom": pe_mom
            })
    return details

# ============================================================
# DASHBOARD – shows entry, current, fixed SL, target, trailing SL, peak
# ============================================================
class TerminalDashboard:
    def __init__(self, data_logger, session_state):
        self.data_logger = data_logger
        self.session_state = session_state

    def display(self):
        try:
            os.system('cls' if os.name == 'nt' else 'clear')
            df = self.data_logger.read_data(limit=1)
            print("\n" + "="*120)
            print("📊 LIVE TRADING DASHBOARD (Fixed + Trailing SL)")
            print("="*120)
            print(f"Last Update: {timestamp_ist()}")
            print(f"📈 DAILY ORDER COUNT: {self.session_state.daily_executed_orders}/{Config.MAX_DAILY_ORDERS}")
            print(f"📊 India VIX: {self.session_state.india_vix:.2f}")
            window_size = len(self.session_state.inof_window)
            if not self.session_state.window_filled:
                print(f"⏳ WARMING UP: {window_size}/{Config.ROLLING_WINDOW_SIZE} samples")
            else:
                print(f"✅ WINDOW FULL: {window_size} samples")
            print("\n" + "-"*80)
            print("📈 CURRENT SIGNAL VALUES")
            print("-"*80)
            if not df.empty:
                latest = df.iloc[-1]
                print(f"   Nifty LTP: {latest['underlying_ltp']}")
                print(f"   Signal: {latest['signal']}")
                print(f"   Position: {self.session_state.position}")
                print(f"   ATM Strike: {latest['atm_strike']}")
                print(f"   Raw inof: {latest['inof']:.2f}")
                print(f"   Raw VWAP Composite: {latest['vwap_composite']:.2f}")
                print(f"   Cumulative inof (EMA): {latest['cumul_inof']:.2f}")
                print(f"   Cumulative VWAP Composite (EMA): {latest['cumul_vwap_composite']:.2f}")
            else:
                print("   Waiting for first data point...")
            strike_details = get_strike_details(self.session_state)
            if strike_details:
                print("\n" + "-"*80)
                print("🔍 PER‑STRIKE DETAILS (Live from WebSocket)")
                print("-"*80)
                print(f"{'Strike':>8} | {'CE LTP':>8} | {'CE VWAP':>8} | {'PE LTP':>8} | {'PE VWAP':>8} | {'Parity':>10} | {'Inof':>15} | {'CE Mom':>8} | {'PE Mom':>8}")
                print("-"*80)
                for d in strike_details:
                    print(f"{d['strike']:8} | {d['ce_ltp']:8.2f} | {d['ce_vwap']:8.2f} | {d['pe_ltp']:8.2f} | {d['pe_vwap']:8.2f} | {d['parity']:10.2f} | {d['inof']:15.0f} | {d['ce_mom']:8.2f} | {d['pe_mom']:8.2f}")
            pos = self.session_state.position
            if pos in ("LONG", "SHORT"):
                if self.session_state.held_option_symbol:
                    opt_ltp = self.session_state.get_ltp(self.session_state.held_option_symbol)
                    if opt_ltp:
                        # compute trailing stop from peak
                        trailing_stop = self.session_state.peak_opt_price * (1 - self.session_state.current_sl_pct)
                        print(f"\n{'📈 LONG (Call)' if pos == 'LONG' else '📉 SHORT (Put)'} POSITION ACTIVE (Fixed + Trailing SL)")
                        print(f"   Held option: {self.session_state.held_option_symbol}")
                        print(f"   Entry price: {self.session_state.option_entry_price:.2f}")
                        print(f"   Current price: {opt_ltp:.2f}")
                        print(f"   Peak price (since entry): {self.session_state.peak_opt_price:.2f}")
                        print(f"   India VIX at entry: {self.session_state.entry_vix:.2f}")
                        print(f"   SL % (fixed & trailing): {self.session_state.current_sl_pct*100:.2f}%")
                        print(f"   Fixed stop loss: {self.session_state.option_stop_price:.2f}")
                        print(f"   Trailing stop loss: {trailing_stop:.2f}")
                        print(f"   Target price (2x risk): {self.session_state.option_target_price:.2f}")
                        # Highlight which stop is tighter
                        if trailing_stop > self.session_state.option_stop_price:
                            print(f"   🔹 Currently trailing stop is higher (more protective)")
                        else:
                            print(f"   🔹 Fixed stop is tighter (more conservative)")
                    else:
                        print(f"\n{'📈 LONG' if pos == 'LONG' else '📉 SHORT'} POSITION ACTIVE (waiting for option price)")
                else:
                    print(f"\n{'📈 LONG' if pos == 'LONG' else '📉 SHORT'} POSITION ACTIVE (no option symbol stored)")
            elif self.session_state.window_filled:
                print(f"\n💤 FLAT - Ready for entry")
            else:
                print(f"\n💤 FLAT - Warming up")
            print("\n" + "="*120)
        except Exception as e:
            log_debug(f"Dashboard error: {e}")

# ============================================================
# SESSION STATE – added peak for trailing (used for both sides)
# ============================================================
class SessionState:
    def __init__(self):
        self.lock = threading.RLock()
        self.option_chain_api_count = 0
        self.quote_api_count = 0
        self.api_window_start = now_ist()
        self.cid = ""
        self.token = ""
        self._hb_lock = False
        self.daily_executed_orders = 0
        self.last_order_sync = None
        self.position = "FLAT"
        self.peak_cumul_inof = 0.0
        self.trough_cumul_inof = 0.0
        self.prev_cumul_composite = 0.0
        self.prev_cumul_inof = 0.0
        self.idwp_window = deque(maxlen=Config.ROLLING_WINDOW_SIZE)
        self.inof_window = deque(maxlen=Config.ROLLING_WINDOW_SIZE)
        self.composite_window = deque(maxlen=Config.ROLLING_WINDOW_SIZE)
        self.cumul_inof_window = deque(maxlen=Config.ROLLING_WINDOW_SIZE)
        self.cumul_composite_window = deque(maxlen=Config.ROLLING_WINDOW_SIZE)
        self.window_filled = False
        self.live_ltp = {}
        self.live_vwap = {}
        self.live_volume = {}
        self.option_chain = []
        self.fut_price = None
        self.expiry_date = None
        self.atm_strike = None
        self.option_symbols = []
        self.running = False
        self.std_cumul_inof = 0.0
        self.std_cumul_composite = 0.0
        # Option tracking for fixed SL/Target and trailing
        self.held_option_symbol = None
        self.option_entry_price = 0.0
        self.option_stop_price = 0.0
        self.option_target_price = 0.0
        self.current_sl_pct = 0.0      # dynamic % from VIX at entry
        self.entry_vix = 0.0
        # Trailing SL: we track the peak price since entry (because we are long the option)
        self.peak_opt_price = 0.0
        # India VIX
        self.india_vix = 15.0   # default fallback
        # Incremental volume tracking for INOF
        self.prev_ce_volume = {}   # ce_symbol -> last seen cumulative volume
        self.prev_pe_volume = {}   # pe_symbol -> last seen cumulative volume

    def update_ws(self, symbol, ltp, vwap, volume):
        with self.lock:
            if symbol == "NSE:INDIAVIX-INDEX":
                if ltp is not None:
                    self.india_vix = float(ltp)
                    log_debug(f"India VIX updated: {self.india_vix:.2f}")
                return
            if ltp is not None:
                self.live_ltp[symbol] = float(ltp)
            if vwap is not None:
                self.live_vwap[symbol] = float(vwap)
            if volume is not None:
                self.live_volume[symbol] = int(volume)
            log_debug(f"Updated {symbol}: LTP={ltp}, VWAP={vwap}, VOL={volume}")

    def get_ltp(self, symbol):
        with self.lock:
            return self.live_ltp.get(symbol)

    def get_vwap(self, symbol):
        with self.lock:
            return self.live_vwap.get(symbol)

    def get_volume(self, symbol):
        with self.lock:
            return self.live_volume.get(symbol)

    def update_chain(self, chain, fut_price, expiry_date, atm_strike, option_symbols):
        with self.lock:
            self.option_chain = chain
            self.fut_price = float(fut_price) if fut_price else 0.0
            self.expiry_date = expiry_date
            self.atm_strike = int(atm_strike) if atm_strike else None
            self.option_symbols = option_symbols
            log_debug(f"Chain updated: ATM={self.atm_strike}, fut={self.fut_price}, {len(option_symbols)} symbols")

    def sync_order_count(self, fyers):
        today = now_ist().date()
        if self.last_order_sync != today:
            self.daily_executed_orders = 0
            self.last_order_sync = today
        try:
            resp = fyers.orderbook()
            if resp.get("s") == "ok":
                self.daily_executed_orders = len([o for o in resp.get("orderBook", []) if o.get("status") == 2])
        except Exception as e:
            log_debug(f"Order sync failed: {e}")

    def can_place_order(self, fyers=None):
        if fyers:
            self.sync_order_count(fyers)
        return self.daily_executed_orders < Config.MAX_DAILY_ORDERS

# ============================================================
# MARKET WEBSOCKET MANAGER (unchanged)
# ============================================================
class MarketWSManager:
    def __init__(self, session_state, access_token):
        self.session = session_state
        self.access_token = access_token
        self.ws = None
        self.subscribed = set()
        self.running = False

    def on_message(self, message):
        symbol = message.get("symbol")
        if symbol:
            ltp = message.get("ltp")
            vwap = message.get("avg_trade_price")
            volume = message.get("vol_traded_today")
            self.session.update_ws(symbol, ltp, vwap, volume)

    def on_error(self, msg):
        log_console(f"WS error: {msg}")

    def on_close(self, msg):
        log_console(f"WS closed: {msg}")
        self.running = False

    def on_open(self):
        log_console("WebSocket connected")
        if self.subscribed:
            log_debug(f"Subscribing to {len(self.subscribed)} symbols")
            self.ws.subscribe(list(self.subscribed), "SymbolUpdate")
        self.ws.keep_running()

    def start(self):
        if self.running:
            return
        self.running = True
        self.ws = data_ws.FyersDataSocket(
            access_token=self.access_token,
            log_path="",
            litemode=False,
            write_to_file=False,
            reconnect=True,
            on_connect=self.on_open,
            on_close=self.on_close,
            on_error=self.on_error,
            on_message=self.on_message
        )
        self.ws.connect()
        log_debug("WebSocket started")

    def subscribe(self, symbols):
        new_symbols = set(symbols) - self.subscribed
        if new_symbols:
            log_debug(f"Subscribing to new symbols: {new_symbols}")
            if self.ws:
                self.ws.subscribe(list(new_symbols), "SymbolUpdate")
            self.subscribed.update(new_symbols)

    def stop(self):
        self.running = False
        if self.ws:
            self.ws.close_connection()

# ============================================================
# REST API HELPERS (unchanged)
# ============================================================
def enforce_rate_limit(session):
    now = now_ist()
    window = (now - session.api_window_start).total_seconds()
    total = session.option_chain_api_count + session.quote_api_count
    if window > Config.API_WINDOW:
        session.api_window_start = now
        session.option_chain_api_count = 0
        session.quote_api_count = 0
    elif total >= Config.API_RATE_LIMIT:
        wait = Config.API_WINDOW - window
        if wait > 0:
            time.sleep(wait)
        session.api_window_start = now
        session.option_chain_api_count = 0
        session.quote_api_count = 0

@handle_errors
def fetch_option_chain(session, index_symbol):
    log_debug("Enter fetch_option_chain")
    enforce_rate_limit(session)
    session.option_chain_api_count += 1
    fy = fyersModel.FyersModel(client_id=session.cid, token=session.token, is_async=False, log_path="")
    meta = fy.optionchain(data={"symbol": index_symbol, "timestamp": ""})
    if meta.get("code") != 200:
        log_debug(f"Meta chain failed: {meta}")
        return None, None, None, None, []
    fut_price = None
    for item in meta["data"]["optionsChain"]:
        if item.get("option_type") == "":
            fut_price = item.get("fp")
            break
    if fut_price is None:
        fut_price = meta["data"].get("fp", 0.0)
    exp_list = sorted([(e["date"], e["expiry"]) for e in meta["data"]["expiryData"]],
                      key=lambda x: datetime.strptime(x[0], "%d-%m-%Y"))
    today = now_ist().date()
    idx = 0
    for i, (d_str, _) in enumerate(exp_list):
        if datetime.strptime(d_str, "%d-%m-%Y").date() >= today:
            idx = i
            break
    curr_date, expiry_ts = exp_list[idx]
    payload = {"symbol": index_symbol, "strikecount": 5, "timestamp": expiry_ts, "greeks": "1"}
    resp = fy.optionchain(data=payload)
    if resp.get("code") != 200:
        log_debug(f"Detailed chain failed: {resp}")
        return None, None, None, None, []
    chain = resp["data"]["optionsChain"]
    option_symbols = [opt["symbol"] for opt in chain if opt.get("option_type") in ("CE","PE")]
    log_debug(f"Got {len(chain)} options, {len(option_symbols)} symbols")
    return chain, fut_price, curr_date, expiry_ts, option_symbols

# ============================================================
# CHAIN POLLER THREAD (unchanged)
# ============================================================
def chain_poller(session, ws_manager, index_symbol):
    log_debug("Chain poller thread started")
    while session.running:
        try:
            log_debug("Polling option chain...")
            chain, fut_price, expiry_date, _, opt_symbols = fetch_option_chain(session, index_symbol)
            if chain is None:
                log_debug("Chain fetch returned None")
            else:
                underlying_ltp = session.get_ltp(index_symbol)
                if underlying_ltp is None:
                    underlying_ltp = fut_price
                strikes = sorted(set(opt["strike_price"] for opt in chain if opt.get("option_type") in ("CE","PE")))
                if strikes and underlying_ltp:
                    atm = min(strikes, key=lambda x: abs(x - underlying_ltp))
                else:
                    atm = None
                session.update_chain(chain, fut_price, expiry_date, atm, opt_symbols)
                all_syms = [index_symbol] + opt_symbols
                ws_manager.subscribe(all_syms)
            time.sleep(Config.OPTION_CHAIN_INTERVAL)
        except Exception as e:
            log_debug(f"Chain poller error: {e}\n{traceback.format_exc()}")
            time.sleep(Config.OPTION_CHAIN_INTERVAL)

# ============================================================
# SIGNAL COMPUTATION – now with correct trailing (peak-based)
# ============================================================
def compute_signal(session):
    log_debug(">>> compute_signal called")
    try:
        with session.lock:
            log_debug(">>> Lock acquired")
            if not session.option_chain or session.atm_strike is None:
                log_debug(">>> No option chain or ATM strike -> HOLD")
                return "HOLD", {}
            underlying_ltp = session.get_ltp("NSE:NIFTY50-INDEX")
            if underlying_ltp is None:
                log_debug(">>> No underlying LTP -> HOLD")
                return "HOLD", {}
            log_debug(f">>> Underlying LTP: {underlying_ltp}, ATM: {session.atm_strike}")

            strikes = sorted(set(opt["strike_price"] for opt in session.option_chain if opt.get("option_type") in ("CE","PE")))
            if not strikes or session.atm_strike not in strikes:
                log_debug(">>> No valid strikes -> HOLD")
                return "HOLD", {}
            idx = strikes.index(session.atm_strike)
            selected = [session.atm_strike]
            if idx > 0: selected.append(strikes[idx-1])
            if idx < len(strikes)-1: selected.append(strikes[idx+1])
            log_debug(f">>> Selected strikes: {selected}")

            idwps, inofs, ce_moms, pe_moms = [], [], [], []
            for strike in selected:
                ce = next((o for o in session.option_chain if o["strike_price"] == strike and o["option_type"] == "CE"), None)
                pe = next((o for o in session.option_chain if o["strike_price"] == strike and o["option_type"] == "PE"), None)
                if not ce or not pe:
                    log_debug(f">>> Strike {strike} missing CE/PE")
                    continue
                ce_ltp = session.get_ltp(ce["symbol"]) or ce.get("ltp", 0)
                pe_ltp = session.get_ltp(pe["symbol"]) or pe.get("ltp", 0)
                ce_vwap = session.get_vwap(ce["symbol"]) or ce_ltp
                pe_vwap = session.get_vwap(pe["symbol"]) or pe_ltp
                ce_current_vol = session.get_volume(ce["symbol"]) or ce.get("volume", 0)
                pe_current_vol = session.get_volume(pe["symbol"]) or pe.get("volume", 0)
                ce_delta = ce.get("greeks", {}).get("delta", 0)
                pe_delta = abs(pe.get("greeks", {}).get("delta", 0))
                parity = (ce_ltp - pe_ltp) / (ce_ltp + pe_ltp) if (ce_ltp + pe_ltp) != 0 else 0
                # Incremental volume: diff between current and previous tick
                ce_prev_vol = session.prev_ce_volume.get(ce["symbol"], ce_current_vol)
                pe_prev_vol = session.prev_pe_volume.get(pe["symbol"], pe_current_vol)
                diff_ce = max(0, ce_current_vol - ce_prev_vol)
                diff_pe = max(0, pe_current_vol - pe_prev_vol)
                session.prev_ce_volume[ce["symbol"]] = ce_current_vol
                session.prev_pe_volume[pe["symbol"]] = pe_current_vol
                inof = (diff_ce * ce_delta) - (diff_pe * pe_delta)
                ce_mom = ce_ltp - ce_vwap
                pe_mom = pe_ltp - pe_vwap
                idwps.append(parity)
                inofs.append(inof)
                ce_moms.append(ce_mom)
                pe_moms.append(pe_mom)
                log_debug(f">>> Strike {strike}: ce_ltp={ce_ltp}, pe_ltp={pe_ltp}, parity={parity:.4f}, inof={inof:.2f}")

            if not idwps:
                log_debug(">>> No valid idwps -> HOLD")
                return "HOLD", {}

            idwp = sum(idwps)/len(idwps)
            inof = sum(inofs)/len(inofs)
            avg_ce_mom = sum(ce_moms)/len(ce_moms) if ce_moms else 0.0
            avg_pe_mom = sum(pe_moms)/len(pe_moms) if pe_moms else 0.0
            composite = (sum(ce_moms)/len(ce_moms)) - (sum(pe_moms)/len(pe_moms))
            log_debug(f">>> Raw values: idwp={idwp:.4f}, inof={inof:.2f}, composite={composite:.4f}, ce_mom_avg={avg_ce_mom:.2f}, pe_mom_avg={avg_pe_mom:.2f}")

            session.idwp_window.append(idwp)
            session.inof_window.append(inof)
            session.composite_window.append(composite)

            if not session.window_filled:
                if len(session.inof_window) < Config.ROLLING_WINDOW_SIZE:
                    log_debug(f">>> Warmup: {len(session.inof_window)}/{Config.ROLLING_WINDOW_SIZE} -> HOLD")
                    metrics = {
                        "spot": underlying_ltp, "atm_strike": session.atm_strike,
                        "idwp": idwp, "inof": inof,
                        "cumul_idwp": 0.0, "cumul_inof": 0.0,
                        "vwap_composite": composite, "cumul_vwap": 0.0,
                    }
                    return "HOLD", metrics
                else:
                    session.window_filled = True
                    log_console("✓ 15-minute window filled – strategy active")

            # --- EMAs ---
            alpha = 2 / (Config.ROLLING_WINDOW_SIZE + 1)
            comp_list = list(session.composite_window)
            ema_comp = comp_list[0]
            for v in comp_list[1:]:
                ema_comp = alpha * v + (1-alpha) * ema_comp
            cumul_composite = ema_comp

            idwp_list = list(session.idwp_window)
            ema_idwp = idwp_list[0]
            for v in idwp_list[1:]:
                ema_idwp = alpha * v + (1-alpha) * ema_idwp
            cumul_idwp = ema_idwp

            inof_list = list(session.inof_window)
            ema_inof = inof_list[0]
            for v in inof_list[1:]:
                ema_inof = alpha * v + (1-alpha) * ema_inof
            cumul_inof = ema_inof
            log_debug(f">>> Cumulative (EMA): cumul_idwp={cumul_idwp:.2f}, cumul_inof={cumul_inof:.2f}, cumul_composite={cumul_composite:.2f}")

            session.cumul_inof_window.append(cumul_inof)
            session.cumul_composite_window.append(cumul_composite)

            # Update peak/trough for entry logic (unchanged)
            if session.position == "LONG":
                if cumul_inof > session.peak_cumul_inof:
                    session.peak_cumul_inof = cumul_inof
                    log_debug(f">>> New LONG peak: {session.peak_cumul_inof:.2f}")
            elif session.position == "SHORT":
                if cumul_inof < session.trough_cumul_inof:
                    session.trough_cumul_inof = cumul_inof
                    log_debug(f">>> New SHORT trough: {session.trough_cumul_inof:.2f}")

            # --- Exit logic: fixed SL, trailing SL (peak-based), or target ---
            signal = "HOLD"
            intended = session.position

            if session.held_option_symbol is not None:
                opt_ltp = session.get_ltp(session.held_option_symbol)
                if opt_ltp is not None:
                    exit_reason = None

                    # Update peak price (since we are always long the option)
                    if opt_ltp > session.peak_opt_price:
                        session.peak_opt_price = opt_ltp
                        log_debug(f"New peak: {session.peak_opt_price:.2f}")

                    # Compute trailing stop from peak
                    trailing_stop = session.peak_opt_price * (1 - session.current_sl_pct)

                    fixed_stop = session.option_stop_price   # entry * (1 - SL%)
                    target = session.option_target_price    # entry * (1 + 2*SL%)

                    # Check conditions (all long option logic)
                    if opt_ltp <= fixed_stop:
                        exit_reason = f"Fixed SL hit: {opt_ltp:.2f} <= {fixed_stop:.2f}"
                    elif opt_ltp <= trailing_stop:
                        exit_reason = f"Trailing SL hit: {opt_ltp:.2f} <= {trailing_stop:.2f} (peak: {session.peak_opt_price:.2f})"
                    elif opt_ltp >= target:
                        exit_reason = f"Target hit: {opt_ltp:.2f} >= {target:.2f}"

                    if exit_reason:
                        log_console(exit_reason)
                        signal = "EXIT"
                        intended = "FLAT"

            # --- Entry logic (unchanged) ---
            if session.position == "FLAT" and signal != "EXIT" and (avg_pe_mom * avg_ce_mom < 0):
                prev_both_pos = (session.prev_cumul_composite > 0 and session.prev_cumul_inof > 0)
                prev_both_neg = (session.prev_cumul_composite < 0 and session.prev_cumul_inof < 0)
                curr_both_pos = (cumul_composite > 0 and cumul_inof > 0)
                curr_both_neg = (cumul_composite < 0 and cumul_inof < 0)
                if curr_both_pos and not prev_both_pos and inof > 0 and composite > 0 :
                    log_debug(f">>> BUY entry triggered (curr_both_pos={curr_both_pos}, prev_both_pos={prev_both_pos})")
                    signal = "BUY"
                    intended = "LONG"
                elif curr_both_neg and not prev_both_neg and inof < 0 and composite < 0 :
                    log_debug(f">>> SELL entry triggered (curr_both_neg={curr_both_neg}, prev_both_neg={prev_both_neg})")
                    signal = "SELL"
                    intended = "SHORT"

            session.prev_cumul_composite = cumul_composite
            session.prev_cumul_inof = cumul_inof

            metrics = {
                "spot": underlying_ltp, "atm_strike": session.atm_strike,
                "idwp": idwp, "inof": inof,
                "cumul_idwp": cumul_idwp, "cumul_inof": cumul_inof,
                "vwap_composite": composite, "cumul_vwap": cumul_composite,
            }
            log_debug(f">>> Returning signal={signal}, intended={intended}")
            return signal, metrics
    except Exception as e:
        log_debug(f"CRASH in compute_signal: {e}\n{traceback.format_exc()}")
        return "HOLD", {}

# ============================================================
# ORDER PLACEMENT – correct for long options (both sides)
# ============================================================
def place_order(session, signal, atm_ce, atm_pe, fyers, entry_metrics=None):
    if getattr(session, '_hb_lock', False):
        return False
    session._hb_lock = True
    try:
        if signal == "EXIT":
            log_console("🟡 EXIT signal – closing positions")
            fyers.exit_positions(data={"segment": [11], "side": [-1], "productType": ["MARGIN"]})
            fyers.exit_positions(data={"segment": [11], "side": [1], "productType": ["MARGIN"]})
            time.sleep(2)
            session.position = "FLAT"
            session.peak_cumul_inof = 0.0
            session.trough_cumul_inof = 0.0
            # Reset option tracking
            session.held_option_symbol = None
            session.option_stop_price = 0.0
            session.option_target_price = 0.0
            session.peak_opt_price = 0.0
            log_console("✓ Positions closed")
            return True
        if signal in ("BUY","SELL") and session.can_place_order(fyers):
            leg = atm_ce if signal == "BUY" else atm_pe
            if not leg:
                return False
            order = {
                "symbol": leg["symbol"],
                "qty": Config.LOT_SIZE,
                "type": 2,
                "side": 1,
                "productType": "MARGIN",
                "validity": "DAY",
            }
            side = "LONG" if signal == "BUY" else "SHORT"
            log_console(f"🟢 {signal} signal – placing {side} order (buy {leg['symbol']})")
            resp = fyers.place_order(data=order)
            if resp.get("s") == "ok":
                if signal == "BUY":
                    session.position = "LONG"
                    if entry_metrics:
                        session.peak_cumul_inof = entry_metrics.get("cumul_inof", 0.0)
                else:
                    session.position = "SHORT"
                    if entry_metrics:
                        session.trough_cumul_inof = entry_metrics.get("cumul_inof", 0.0)
                # Store option symbol and compute fixed SL/Target based on current VIX
                session.held_option_symbol = leg["symbol"]
                current_opt_ltp = session.get_ltp(leg["symbol"]) or leg.get("ltp", 0)
                session.option_entry_price = current_opt_ltp
                session.entry_vix = session.india_vix
                # Compute dynamic SL% from VIX
                sl_pct = (session.india_vix / 100.0) * Config.OPTION_TRAIL_MULTIPLIER
                sl_pct = max(0.01, sl_pct)   # safety floor 1%
                session.current_sl_pct = sl_pct

                # ----- CORRECTED: both BUY and SELL are long options -----
                # Fixed stop is always below entry, target above entry.
                session.option_stop_price = current_opt_ltp * (1 - sl_pct)
                session.option_target_price = current_opt_ltp * (1 + Config.TARGET_MULTIPLIER * sl_pct)

                # Initialise peak for trailing (same for both)
                session.peak_opt_price = current_opt_ltp

                log_console(f"{side} entry: {leg['symbol']} at {current_opt_ltp:.2f}")
                log_console(f"   VIX: {session.india_vix:.2f} -> SL% = {sl_pct*100:.2f}%")
                log_console(f"   Fixed stop: {session.option_stop_price:.2f}, Target: {session.option_target_price:.2f}")
                log_console(f"   Trailing stop will trail from peak using same SL%")
                log_console(f"✓ {side} order placed successfully")
                return True
        return False
    except Exception as e:
        log_console(f"Order error: {e}")
        return False
    finally:
        session._hb_lock = False

# ============================================================
# SAMPLER THREAD – logs trailing_stop and peak
# ============================================================
last_signal_logged = None

def sampler(session, data_logger, auto_trade, fyers):
    global last_signal_logged
    log_debug("Sampler thread started")
    while session.running:
        start = now_ist()
        try:
            signal, metrics = compute_signal(session)
            if metrics:
                # Collect all option data
                opt_symbol = session.held_option_symbol if session.held_option_symbol else ''
                opt_entry = session.option_entry_price if session.held_option_symbol else 0.0
                opt_current = session.get_ltp(opt_symbol) if opt_symbol else 0.0
                opt_stop = session.option_stop_price if session.held_option_symbol else 0.0
                opt_target = session.option_target_price if session.held_option_symbol else 0.0
                peak = session.peak_opt_price if session.held_option_symbol else 0.0
                # compute trailing stop
                trailing_stop = peak * (1 - session.current_sl_pct) if session.held_option_symbol else 0.0
                vix = session.india_vix
                sl_pct = session.current_sl_pct if session.held_option_symbol else 0.0

                data_logger.log_data(
                    timestamp=timestamp_ist(),
                    underlying_ltp=metrics.get("spot", 0),
                    fut_price=session.fut_price or 0,
                    signal=signal,
                    atm_strike=metrics.get("atm_strike", 0),
                    expiry_date=session.expiry_date or "",
                    idwp=metrics.get("idwp", 0),
                    inof=metrics.get("inof", 0),
                    cumul_idwp=metrics.get("cumul_idwp", 0),
                    cumul_inof=metrics.get("cumul_inof", 0),
                    vwap_composite=metrics.get("vwap_composite", 0),
                    cumul_vwap_composite=metrics.get("cumul_vwap", 0),
                    position=session.position,
                    opt_symbol=opt_symbol,
                    opt_entry=opt_entry,
                    opt_current=opt_current,
                    opt_stop=opt_stop,
                    opt_target=opt_target,
                    trailing_stop=trailing_stop,
                    peak_opt_price=peak,
                    vix=vix,
                    sl_pct=sl_pct
                )
                if signal != last_signal_logged and signal != "HOLD":
                    log_console(f"📢 Signal changed to: {signal}")
                    last_signal_logged = signal

            if auto_trade and signal in ("BUY","SELL","EXIT"):
                atm_ce = atm_pe = None
                if session.atm_strike:
                    for opt in session.option_chain:
                        if opt["strike_price"] == session.atm_strike:
                            if opt["option_type"] == "CE":
                                atm_ce = {"symbol": opt["symbol"]}
                            elif opt["option_type"] == "PE":
                                atm_pe = {"symbol": opt["symbol"]}
                if signal == "EXIT":
                    place_order(session, signal, None, None, fyers, None)
                elif signal == "BUY" and atm_ce:
                    place_order(session, signal, atm_ce, None, fyers, metrics)
                elif signal == "SELL" and atm_pe:
                    place_order(session, signal, None, atm_pe, fyers, metrics)
            elapsed = (now_ist() - start).total_seconds()
            if elapsed < Config.SAMPLE_INTERVAL:
                time.sleep(Config.SAMPLE_INTERVAL - elapsed)
        except Exception as e:
            log_debug(f"Sampler error: {e}\n{traceback.format_exc()}")
            time.sleep(1)

# ============================================================
# CREDENTIALS
# ============================================================
def load_credentials(session):
    try:
        with open('fyers_credentials.json', 'r') as f:
            creds = json.load(f)
            session.cid = creds.get('client_id', '')
            session.token = creds.get('access_token', '')
        log_console(f"Loaded credentials: {session.cid}")
    except Exception as e:
        session.cid = os.getenv("FYERS_CID", "")
        session.token = os.getenv("FYERS_TOKEN", "")
        log_console(f"Using env vars: {session.cid}")

# ============================================================
# MAIN
# ============================================================
def main():
    log_console("Starting Algo Trading System...")
    session = SessionState()
    load_credentials(session)
    data_logger = DataLogger()
    dashboard = TerminalDashboard(data_logger, session)
    index_symbol = "NSE:NIFTY50-INDEX"
    vix_symbol = "NSE:INDIAVIX-INDEX"

    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        print("="*50)
        print("📈 FYERS ALGO TRADING (Fixed + Trailing SL)")
        print("1. Start Live Trading")
        print("2. Settings")
        print("3. Exit")
        choice = input("Select option: ").strip()
        if choice == "1":
            if not (session.cid and session.token):
                print("❌ Set credentials first")
                input("Press Enter...")
                continue
            auto_trade = input("Enable Auto Trade? (y/n): ").lower() == 'y'
            log_console(f"Auto trade: {'ON' if auto_trade else 'OFF'}")
            ws_manager = MarketWSManager(session, session.token)
            ws_manager.start()
            ws_manager.subscribe([index_symbol, vix_symbol])
            session.running = True
            threading.Thread(target=chain_poller, args=(session, ws_manager, index_symbol), daemon=True).start()
            fyers = fyersModel.FyersModel(client_id=session.cid, token=session.token, is_async=False, log_path="")
            threading.Thread(target=sampler, args=(session, data_logger, auto_trade, fyers), daemon=True).start()
            print("\n✅ Live trading started. Press Ctrl+C to stop.\n")
            try:
                while True:
                    dashboard.display()
                    time.sleep(2)
            except KeyboardInterrupt:
                session.running = False
                ws_manager.stop()
                log_console("\n🛑 Trading stopped by user")
        elif choice == "2":
            print("\n⚙️ SETTINGS")
            new_cid = input(f"Client ID [{session.cid}]: ").strip()
            if new_cid:
                session.cid = new_cid
            new_token = input("Access token: ").strip()
            if new_token:
                session.token = new_token
            with open('fyers_credentials.json', 'w') as f:
                json.dump({"client_id": session.cid, "access_token": session.token}, f)
            print("✅ Saved")
            input("Press Enter...")
        elif choice == "3":
            break

if __name__ == "__main__":
    main()