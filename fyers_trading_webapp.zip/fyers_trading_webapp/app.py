import os
import time
import uuid
import json
import logging
from functools import lru_cache, wraps
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List, Tuple
import threading

import pandas as pd
import pytz
from fastapi import FastAPI, HTTPException, Body
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

import math
import numpy as np
from datetime import date

# --- External trading SDK ---
# pip install fyers-apiv3
from fyers_apiv3 import fyersModel


# =============================
# Config & Logging
# =============================
class Config:
    REFRESH_INTERVAL = 10  # seconds
    API_RATE_LIMIT = 200
    API_WINDOW = 60  # seconds
    LOT_SIZE = 75
    MAX_RETRIES = 3
    RETRY_DELAY = 2  # seconds
    TZ = "Asia/Kolkata"


logging.basicConfig(
    filename="trading_app.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("fyers-fastapi")


# =============================
# App State (replacement for st.session_state)
# =============================
class PaperPnL(BaseModel):
    realized: float = 0.0
    unrealized: float = 0.0


class AppState:
    def __init__(self):
        self.lock = threading.Lock()
        self.state: Dict[str, Any] = {
            "option_chain_api_count": 0,
            "quote_api_count": 0,
            "api_window_start": datetime.now(),
            "last_signal": None,
            "last_signal_order_ids": [],
            "paper_trades": [],
            "paper_positions": {},  # symbol -> position dict
            "paper_pnl": PaperPnL().dict(),
            "trade_history": [],
            "paper_trade_active": False,
            "pnl_update_time": datetime.now(),
            "paper_last_signal": None,
            "paper_last_signal_order_ids": [],
            "live_last_signal": None,
            "live_last_signal_order_ids": [],
            "signal_history": [],
            "cid": os.getenv("FYERS_CID", ""),
            "token": os.getenv("FYERS_TOKEN", ""),
            "sym": "NSE:NIFTY50-INDEX",
            "auto_trade": False,
            "paper_trade": False,
            "current_expiry_date": None,
            "last_ltp": None,
            "last_chain": None,
        }

    def get(self, key, default=None):
        with self.lock:
            return self.state.get(key, default)

    def set(self, key, value):
        with self.lock:
            self.state[key] = value

    def multi_set(self, **kwargs):
        with self.lock:
            self.state.update(kwargs)

    def snapshot(self) -> Dict[str, Any]:
        with self.lock:
            # deep-ish copy for safety
            return json.loads(json.dumps(self.state, default=str))


STATE = AppState()


# =============================
# Utilities
# =============================
def ist_now_str() -> str:
    tz = pytz.timezone(Config.TZ)
    return datetime.now(tz).strftime("%Y-%m-%d %H:%M:%S")


def handle_errors(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        retries = 0
        while retries < Config.MAX_RETRIES:
            try:
                return func(*args, **kwargs)
            except Exception as e:
                retries += 1
                logger.error(
                    f"Error in {func.__name__} (attempt {retries}): {e}",
                    exc_info=True,
                )
                if retries < Config.MAX_RETRIES:
                    time.sleep(Config.RETRY_DELAY)
                else:
                    return None
    return wrapper


def enforce_rate_limit():
    now = datetime.now()
    window = now - STATE.get("api_window_start")
    oc = STATE.get("option_chain_api_count", 0)
    qc = STATE.get("quote_api_count", 0)
    total_calls = oc + qc
    if window > timedelta(seconds=Config.API_WINDOW):
        STATE.multi_set(
            api_window_start=now, option_chain_api_count=0, quote_api_count=0
        )
    elif total_calls >= Config.API_RATE_LIMIT:
        wait = Config.API_WINDOW - window.seconds
        logger.warning(f"Approaching rate limit, waiting {wait}s...")
        time.sleep(max(1, wait))
        STATE.multi_set(
            api_window_start=datetime.now(),
            option_chain_api_count=0,
            quote_api_count=0,
        )


# =============================
# Fyers API Calls
# =============================
@handle_errors
@lru_cache(maxsize=32)
def get_option_chain_data(cid: str, token: str, sym: str, expiry_ts: str = ""):
    enforce_rate_limit()
    STATE.set("option_chain_api_count", STATE.get("option_chain_api_count", 0) + 1)
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    resp = fy.optionchain(data={"symbol": sym, "timestamp": expiry_ts})
    if not resp or resp.get("code") != 200:
        logger.error(f"Option chain error ({expiry_ts or 'nearest'}): {resp}")
        return None
    return resp["data"]["optionsChain"]


@handle_errors
def get_underlying_ltp(cid: str, token: str, sym: str) -> Optional[float]:
    enforce_rate_limit()
    STATE.set("quote_api_count", STATE.get("quote_api_count", 0) + 1)
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    resp = fy.quotes(data={"symbols": sym})
    if not resp or resp.get("code") != 200 or not resp.get("d"):
        logger.error(f"Quotes API error ({resp.get('code')}): {resp}")
        return None
    return resp["d"][0]["v"]["lp"]


@handle_errors
def get_symbol_ltp(cid: str, token: str, symbol: str) -> Optional[float]:
    enforce_rate_limit()
    STATE.set("quote_api_count", STATE.get("quote_api_count", 0) + 1)
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    resp = fy.quotes(data={"symbols": symbol})
    if not resp or resp.get("code") != 200 or not resp.get("d"):
        logger.error(f"Quotes API error for {symbol}: {resp}")
        return None
    return resp["d"][0]["v"]["lp"]


# =============================
# Signal & Helpers
# =============================
def compute_signals(merged_df: pd.DataFrame, atm_strike: int, ltp: float, tolerance_pct: float = 1):
    try:
        def safe_val(series, default=0):
            if series.empty:
                return default
            val = series.iloc[0]
            return default if pd.isna(val) else val

        strikes = sorted(merged_df["Strike"].dropna().unique().tolist())
        if not strikes:
            logger.error("No valid strikes in data")
            return "SIDEWAYS", 0, 0

        if atm_strike not in strikes:
            atm_strike = min(strikes, key=lambda s: abs(s - atm_strike))
        idx_atm = strikes.index(atm_strike)

        merged_df = merged_df.fillna(0)

        # Money flow
        merged_df["CE_moneyflow"] = merged_df["CE_ltp"] * merged_df["CE_Vol"]
        merged_df["PE_moneyflow"] = merged_df["PE_ltp"] * merged_df["PE_Vol"]

        atm_row = merged_df[merged_df["Strike"] == atm_strike]
        atm_ce_price = safe_val(atm_row["CE_ltp"])
        atm_pe_price = safe_val(atm_row["PE_ltp"])

        ce_itm_strikes = strikes[max(0, idx_atm - 5):idx_atm]
        pe_itm_strikes = strikes[idx_atm + 1:min(len(strikes), idx_atm + 6)]
        ce_itm_df = merged_df[merged_df["Strike"].isin(ce_itm_strikes)]
        pe_itm_df = merged_df[merged_df["Strike"].isin(pe_itm_strikes)]

        itm_ce_moneyflow = ce_itm_df["CE_moneyflow"].sum()
        itm_pe_moneyflow = pe_itm_df["PE_moneyflow"].sum()
        itm_ce_vol = ce_itm_df["CE_Vol"].sum()
        itm_pe_vol = pe_itm_df["PE_Vol"].sum()

        ratio = 0
        denom = abs(itm_ce_moneyflow) + abs(itm_pe_moneyflow)
        if denom != 0:
            ratio = (itm_ce_moneyflow - itm_pe_moneyflow) / denom

        volume_ratio = 0
        vden = (itm_ce_vol + itm_pe_vol)
        if vden != 0:
            volume_ratio = (itm_ce_vol - itm_pe_vol) / vden

        # Fairness
        max_price = max(atm_ce_price, atm_pe_price)
        min_price = min(atm_ce_price, atm_pe_price)
        if max_price == 0:
            diff_pct = 0
            fair_bool = True
        else:
            diff_pct = ((max_price - min_price) / max_price) * 100
            fair_bool = diff_pct <= tolerance_pct

        signal = "SIDEWAYS"
        if ratio > 0.33 and volume_ratio > 0.33 and fair_bool:
            signal = "BUY"
        elif ratio < -0.33 and volume_ratio < -0.33 and fair_bool:
            signal = "SELL"

        logger.info(
            f"Signal Computation: ratio={ratio:.2f}, volume_ratio={volume_ratio:.2f}, "
            f"signal={signal}, fair={fair_bool}"
        )

        return signal, ratio, volume_ratio
    except Exception as e:
        logger.error(f"Error in compute_signals: {e}", exc_info=True)
        return "SIDEWAYS", 0, 0


def select_strikes_atm_half_price(chain: List[dict], atm_strike: int):
    try:
        df = pd.DataFrame(chain)
        if df.empty or atm_strike is None:
            return None, None, None, None

        ce = df[df["option_type"] == "CE"].copy()
        pe = df[df["option_type"] == "PE"].copy()

        atm_pe_row = pe[pe["strike_price"] == atm_strike]
        atm_ce_row = ce[ce["strike_price"] == atm_strike]

        sell_pe_row = atm_pe_row.iloc[0].to_dict() if not atm_pe_row.empty else None
        sell_ce_row = atm_ce_row.iloc[0].to_dict() if not atm_ce_row.empty else None

        buy_pe_row = None
        if sell_pe_row and "ltp" in sell_pe_row and sell_pe_row["ltp"] > 0:
            target = sell_pe_row["ltp"] / 2
            pe_candidates = pe[pe["strike_price"] != atm_strike].copy()
            pe_candidates["ltp_diff"] = (pe_candidates["ltp"] - target).abs()
            if not pe_candidates.empty:
                buy_pe_row = pe_candidates.nsmallest(1, "ltp_diff").iloc[0].to_dict()

        buy_ce_row = None
        if sell_ce_row and "ltp" in sell_ce_row and sell_ce_row["ltp"] > 0:
            target = sell_ce_row["ltp"] / 2
            ce_candidates = ce[ce["strike_price"] != atm_strike].copy()
            ce_candidates["ltp_diff"] = (ce_candidates["ltp"] - target).abs()
            if not ce_candidates.empty:
                buy_ce_row = ce_candidates.nsmallest(1, "ltp_diff").iloc[0].to_dict()

        return sell_pe_row, buy_pe_row, sell_ce_row, buy_ce_row
    except Exception as e:
        logger.error(f"Error in select_strikes_atm_half_price: {e}", exc_info=True)
        return None, None, None, None


# =============================
# Order helpers (live & paper)
# =============================
@handle_errors
def cancel_order(fyers, order_id):
    try:
        resp = fyers.cancel_order(data={"id": order_id})
        logger.info(f"Cancelled order {order_id}: {resp}")
        return resp
    except Exception as e:
        logger.error(f"Exception while cancelling order {order_id}: {e}", exc_info=True)
        raise


@handle_errors
def get_order_status_by_id(fyers, order_id):
    try:
        orderbook = fyers.orderbook()
        for o in orderbook.get("orderBook", []):
            if o.get("id") == order_id:
                return o.get("status")
        return None
    except Exception as e:
        logger.warning(f"Could not fetch order status for {order_id}: {e}")
        return None


@handle_errors
def place_order_and_check(fyers, order):
    try:
        resp = fyers.place_order(data=order)
        logger.info(f"Order placed for {order['symbol']}: {resp}")
        if resp and resp.get("s") == "ok":
            oid = resp.get("id")
            time.sleep(2)
            status = get_order_status_by_id(fyers, oid)
            if status in [1, 5]:  # Rejected or canceled
                logger.error(f"Order {oid} rejected/canceled. Status: {status}")
                return None, status
            return oid, status
        logger.error(f"Order failed: {resp}")
        return None, None
    except Exception as e:
        logger.exception(f"Place order error: {e}")
        raise


def has_open_orders_for_last_signal(fyers):
    ids = STATE.get("live_last_signal_order_ids", [])
    if not ids:
        return False
    try:
        ob = fyers.orderbook().get("orderBook", [])
        return any(o.get("id") in ids and o.get("status") == 2 for o in ob)
    except Exception as e:
        logger.warning(f"Could not check open orders: {e}")
        return False


def update_paper_positions(trade: Dict[str, Any]):
    try:
        positions = STATE.get("paper_positions", {})
        paper_pnl = STATE.get("paper_pnl", {"realized": 0.0, "unrealized": 0.0})

        symbol = trade["symbol"]
        if trade["type"] == "OPEN":
            positions[symbol] = {
                "symbol": trade["symbol"],
                "id": trade["id"],
                "entry_time": trade["timestamp"],
                "qty": trade["qty"],
                "action": trade["action"],
                "side": 1 if trade["action"] == "BUY" else -1,
                "entry_price": trade["price"],
                "current_price": trade["price"],
                "signal": trade["signal"],
            }
        else:
            if symbol in positions:
                position = positions[symbol]
                if position["action"] == "BUY":
                    pnl = (trade["price"] - position["entry_price"]) * position["qty"]
                else:
                    pnl = (position["entry_price"] - trade["price"]) * position["qty"]
                paper_pnl["realized"] += pnl
                trade["pnl"] = pnl
                del positions[symbol]
                if not positions:
                    STATE.set("last_signal", None)

        STATE.multi_set(paper_positions=positions, paper_pnl=paper_pnl)
    except Exception as e:
        logger.error(f"Error in update_paper_positions: {e}", exc_info=True)


@handle_errors
def update_unrealized_pnl(cid: str, token: str):
    positions = STATE.get("paper_positions", {})
    if not positions:
        STATE.set("paper_pnl", {"realized": STATE.get("paper_pnl")["realized"], "unrealized": 0.0})
        return

    total_unrealized = 0.0
    for symbol, position in positions.items():
        ltp = get_symbol_ltp(cid, token, symbol)
        if ltp is None:
            ltp = position.get("current_price", position["entry_price"])
        position["current_price"] = ltp
        if position["action"] == "BUY":
            pnl = (ltp - position["entry_price"]) * position["qty"]
        else:
            pnl = (position["entry_price"] - ltp) * position["qty"]
        total_unrealized += pnl

    paper_pnl = STATE.get("paper_pnl")
    paper_pnl["unrealized"] = total_unrealized
    STATE.multi_set(paper_positions=positions, paper_pnl=paper_pnl, pnl_update_time=datetime.now())


@handle_errors
def update_position_prices(cid: str, token: str):
    positions = STATE.get("paper_positions", {})
    if not positions:
        return
    for symbol, position in positions.items():
        ltp = get_symbol_ltp(cid, token, symbol)
        if ltp is not None:
            position["current_price"] = ltp
    STATE.set("paper_positions", positions)


def handle_paper_trade(signal, sell_pe, buy_pe, sell_ce, buy_ce) -> List[str]:
    try:
        orders = []
        lot = Config.LOT_SIZE
        timestamp = ist_now_str()
        current_signal = STATE.get("paper_last_signal")

        if current_signal == signal and STATE.get("paper_positions"):
            logger.info(f"[PAPER] Signal {signal} already active. No new trades.")
            return []

        # Exit then enter opposite
        if current_signal == "BUY" and signal == "SELL":
            for symbol, position in list(STATE.get("paper_positions", {}).items()):
                close_action = "SELL" if position["action"] == "BUY" else "BUY"
                orders.append({
                    "symbol": symbol, "qty": position["qty"], "action": close_action,
                    "price": position["current_price"], "type": "CLOSE"
                })
            if buy_ce and sell_ce:
                orders += [
                    {"symbol": buy_ce["symbol"], "qty": lot, "action": "BUY", "price": buy_ce["ltp"]},
                    {"symbol": sell_ce["symbol"], "qty": lot, "action": "SELL", "price": sell_ce["ltp"]},
                ]

        elif current_signal == "SELL" and signal == "BUY":
            for symbol, position in list(STATE.get("paper_positions", {}).items()):
                close_action = "SELL" if position["action"] == "BUY" else "BUY"
                orders.append({
                    "symbol": symbol, "qty": position["qty"], "action": close_action,
                    "price": position["current_price"], "type": "CLOSE"
                })
            if buy_pe and sell_pe:
                orders += [
                    {"symbol": buy_pe["symbol"], "qty": lot, "action": "BUY", "price": buy_pe["ltp"]},
                    {"symbol": sell_pe["symbol"], "qty": lot, "action": "SELL", "price": sell_pe["ltp"]},
                ]

        elif current_signal is None and signal in ["BUY", "SELL"]:
            if signal == "BUY" and buy_pe and sell_pe:
                orders += [
                    {"symbol": buy_pe["symbol"], "qty": lot, "action": "BUY", "price": buy_pe["ltp"]},
                    {"symbol": sell_pe["symbol"], "qty": lot, "action": "SELL", "price": sell_pe["ltp"]},
                ]
            elif signal == "SELL" and buy_ce and sell_ce:
                orders += [
                    {"symbol": buy_ce["symbol"], "qty": lot, "action": "BUY", "price": buy_ce["ltp"]},
                    {"symbol": sell_ce["symbol"], "qty": lot, "action": "SELL", "price": sell_ce["ltp"]},
                ]
        elif signal == "SIDEWAYS":
            logger.info("[PAPER] SIDEWAYS: holding")
            return []

        placed_ids = []
        for order in orders:
            trade_id = str(uuid.uuid4())[:8]
            trade = {
                "id": trade_id,
                "timestamp": timestamp,
                "symbol": order["symbol"],
                "qty": order["qty"],
                "action": order["action"],
                "price": order["price"],
                "signal": signal,
                "type": order.get("type", "OPEN"),
            }
            update_paper_positions(trade)
            hist = STATE.get("trade_history", [])
            hist.append(trade)
            STATE.set("trade_history", hist)
            placed_ids.append(trade_id)
            logger.info(f"[PAPER] {order['action']} {order['qty']} of {order['symbol']} at {order['price']}")

        if placed_ids and signal in ["BUY", "SELL"]:
            STATE.set("paper_last_signal", signal)

        return placed_ids
    except Exception as e:
        logger.error(f"Error in handle_paper_trade: {e}", exc_info=True)
        return []


def handle_basket_orders_atomic(signal, sell_pe, buy_pe, sell_ce, buy_ce, fyers):
    try:
        orders = []
        lot = Config.LOT_SIZE
        current_signal = STATE.get("last_signal")

        if current_signal == signal:
            logger.info(f"Signal {signal} already active. No new live trades.")
            return []

        def exit_nfo_positions():
            out = []
            positions = fyers.positions().get("netPositions", [])
            for p in positions:
                if p.get("segment") == "NFO" and p.get("qty") != 0:
                    side = -1 if p["qty"] > 0 else 1
                    out.append({
                        "symbol": p["symbol"], "qty": abs(int(p["qty"])),
                        "type": 2, "side": side, "productType": "MARGIN", "validity": "DAY"
                    })
            return out

        if current_signal == "BUY" and signal == "SELL":
            orders += exit_nfo_positions()
            if buy_ce and sell_ce:
                orders += [
                    {"symbol": buy_ce["symbol"], "qty": lot, "type": 2, "side": 1, "productType": "MARGIN", "validity": "DAY"},
                    {"symbol": sell_ce["symbol"], "qty": lot, "type": 2, "side": -1, "productType": "MARGIN", "validity": "DAY"},
                ]
        elif current_signal == "SELL" and signal == "BUY":
            orders += exit_nfo_positions()
            if buy_pe and sell_pe:
                orders += [
                    {"symbol": buy_pe["symbol"], "qty": lot, "type": 2, "side": 1, "productType": "MARGIN", "validity": "DAY"},
                    {"symbol": sell_pe["symbol"], "qty": lot, "type": 2, "side": -1, "productType": "MARGIN", "validity": "DAY"},
                ]
        elif current_signal is None and signal in ["BUY", "SELL"]:
            if signal == "BUY" and buy_pe and sell_pe:
                orders += [
                    {"symbol": buy_pe["symbol"], "qty": lot, "type": 2, "side": 1, "productType": "MARGIN", "validity": "DAY"},
                    {"symbol": sell_pe["symbol"], "qty": lot, "type": 2, "side": -1, "productType": "MARGIN", "validity": "DAY"},
                ]
            elif signal == "SELL" and buy_ce and sell_ce:
                orders += [
                    {"symbol": buy_ce["symbol"], "qty": lot, "type": 2, "side": 1, "productType": "MARGIN", "validity": "DAY"},
                    {"symbol": sell_ce["symbol"], "qty": lot, "type": 2, "side": -1, "productType": "MARGIN", "validity": "DAY"},
                ]
        elif signal == "SIDEWAYS":
            logger.info("[LIVE] SIDEWAYS: holding")
            return []

        placed_ids = []
        for order in orders:
            oid, status = place_order_and_check(fyers, order)
            if oid is None or status in [1, 5]:
                logger.error(f"Order failed for {order['symbol']}. Rolling back.")
                for pid in placed_ids:
                    cancel_order(fyers, pid)
                return []
            placed_ids.append(oid)

        if placed_ids:
            STATE.set("last_signal", signal)
            logger.info(f"[LIVE] {signal} basket executed")
        return placed_ids
    except Exception as e:
        logger.error(f"Error in handle_basket_orders_atomic: {e}", exc_info=True)
        return []


# =============================
# Data shaping for frontend
# =============================
def build_merged_chain_for_signal(chain: List[dict]) -> Optional[pd.DataFrame]:
    if not chain:
        return None
    df = pd.DataFrame(chain)
    ce = df[df["option_type"] == "CE"]
    pe = df[df["option_type"] == "PE"]
    cols = ["symbol", "strike_price", "oi", "volume", "ltp", "ask", "bid", "ltpch", "ltpchp", "oich", "oichp", "prev_oi"]
    ce_df = ce[cols].rename(columns={"strike_price": "Strike", "oi": "OI", "volume": "Vol", "ltpch": "LTPCh", "ltpchp": "LTPChP", "oich": "OICh", "oichp": "OIChP", "prev_oi": "PrevOI"})
    pe_df = pe[cols].rename(columns={"strike_price": "Strike", "oi": "OI", "volume": "Vol", "ltpch": "LTPCh", "ltpchp": "LTPChP", "oich": "OICh", "oichp": "OIChP", "prev_oi": "PrevOI"})
    merged = pd.merge(
        ce_df.add_prefix("CE_"),
        pe_df.add_prefix("PE_"),
        left_on="CE_Strike", right_on="PE_Strike", how="outer"
    ).rename(columns={"CE_Strike": "Strike"}).drop(columns=["PE_Strike"])
    return merged


# =============================
# FastAPI app & models
# =============================
app = FastAPI(title="Fyers Algo (FastAPI)")

app.mount("/static", StaticFiles(directory="static"), name="static")


class Credentials(BaseModel):
    cid: str = Field("", description="Fyers client ID")
    token: str = Field("", description="Fyers access token")


class Settings(BaseModel):
    sym: str = Field("NSE:NIFTY50-INDEX")
    auto_trade: bool = False
    paper_trade: bool = False


@app.get("/")
def index():
    # Serve the frontend
    return FileResponse("static/index.html")


@app.post("/set_credentials")
def set_credentials(creds: Credentials):
    STATE.multi_set(cid=creds.cid, token=creds.token)
    return {"ok": True, "message": "Credentials updated"}


@app.post("/set_settings")
def set_settings(cfg: Settings):
    STATE.multi_set(sym=cfg.sym, auto_trade=cfg.auto_trade, paper_trade=cfg.paper_trade)
    return {"ok": True, "message": "Settings updated", "refresh_interval": Config.REFRESH_INTERVAL}


@app.get("/state_snapshot")
def state_snapshot():
    snap = STATE.snapshot()
    # Don't leak token back
    if "token" in snap:
        snap["token"] = "***"
    return snap


@app.get("/signal_history")
def signal_history():
    return {"ok": True, "history": STATE.get("signal_history", [])}


@app.get("/paper_dashboard")
def paper_dashboard():
    return {
        "ok": True,
        "pnl": STATE.get("paper_pnl", {}),
        "positions": list(STATE.get("paper_positions", {}).values()),
        "trade_history": STATE.get("trade_history", []),
        "updated": ist_now_str(),
    }


@app.post("/reset_paper")
def reset_paper():
    STATE.multi_set(
        paper_trades=[],
        paper_positions={},
        paper_pnl={"realized": 0.0, "unrealized": 0.0},
        trade_history=[],
        last_signal=None,
        paper_last_signal=None,
    )
    return {"ok": True, "message": "Paper trading data reset"}
def sanitize_for_json(obj):
    """
    Recursively convert numpy/pandas scalars, NaN, inf, timestamps, etc. into
    JSON-serializable native Python types. NaN/inf -> None.
    """
    # None
    if obj is None:
        return None

    # numpy floats / python floats
    if isinstance(obj, (np.floating, float)):
        if np.isnan(obj) or np.isinf(obj):
            return None
        return float(obj)

    # numpy ints / python ints
    if isinstance(obj, (np.integer, int)):
        return int(obj)

    # pandas Timestamp or datetime
    if isinstance(obj, (pd.Timestamp, datetime)):
        try:
            return obj.strftime("%Y-%m-%d %H:%M:%S")
        except Exception:
            return str(obj)

    # date
    if isinstance(obj, date):
        return obj.isoformat()

    # dict -> recurse
    if isinstance(obj, dict):
        return {str(k): sanitize_for_json(v) for k, v in obj.items()}

    # list/tuple/set -> recurse to list
    if isinstance(obj, (list, tuple, set)):
        return [sanitize_for_json(v) for v in obj]

    # try pandas isna
    try:
        if pd.isna(obj):
            return None
    except Exception:
        pass

    # fallback: primitive (str, bool, etc.)
    return obj


@app.get("/update_data")
def update_all_data():
    cid = STATE.get("cid", "")
    token = STATE.get("token", "")
    sym = STATE.get("sym", "")

    if not (cid and token and sym):
        raise HTTPException(status_code=400, detail="Missing credentials or symbol")

    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    enforce_rate_limit()
    # increment option chain API usage (we fetched meta)
    STATE.set("option_chain_api_count", STATE.get("option_chain_api_count", 0) + 1)

    meta = fy.optionchain(data={"symbol": sym, "timestamp": ""})
    if not meta or meta.get("code") != 200:
        raise HTTPException(status_code=500, detail="Failed to fetch expiry data")

    # pick current/nearest expiry
    exp = sorted(
        [(e["date"], e.get("expiry")) for e in meta["data"]["expiryData"]],
        key=lambda x: datetime.strptime(x[0], "%d-%m-%Y")
    )
    today = datetime.today().date()
    dates = [datetime.strptime(d, "%d-%m-%Y").date() for d, _ in exp]
    idx = next((i for i, d in enumerate(dates) if d >= today), 0)
    curr_date, curr_ts = exp[idx]

    # underlying LTP & option chain (for that expiry)
    ltp = get_underlying_ltp(cid, token, sym)
    chain = get_option_chain_data(cid, token, sym, expiry_ts=curr_ts)

    # update paper positions prices/pnl if enabled
    if STATE.get("paper_trade") and STATE.get("paper_positions"):
        update_position_prices(cid, token)
        update_unrealized_pnl(cid, token)

    STATE.multi_set(last_ltp=ltp, last_chain=chain, current_expiry_date=curr_date)

    # Prepare signal/atm/ratios/defaults
    atm = None
    signal = None
    ratio = None
    volume_ratio = None
    sell_pe = buy_pe = sell_ce = buy_ce = None

    if chain and ltp is not None:
        merged = build_merged_chain_for_signal(chain)
        if merged is not None and not merged["Strike"].dropna().empty:
            # ATM strike
            try:
                atm = min(merged["Strike"].dropna(), key=lambda x: abs(x - ltp))
            except Exception:
                atm = None

            # compute signal using your existing logic
            try:
                signal, ratio, volume_ratio = compute_signals(merged, atm, ltp)
            except Exception as e:
                logger.error(f"compute_signals failed: {e}", exc_info=True)
                signal, ratio, volume_ratio = "SIDEWAYS", 0.0, 0.0

            # Persist signal history (convert numeric fields to native floats)
            try:
                if signal:
                    hist = STATE.get("signal_history", [])
                    hist.append({
                        "timestamp": ist_now_str(),
                        "ratio": float(ratio) if ratio is not None else None,
                        "volume_ratio": float(volume_ratio) if volume_ratio is not None else None,
                        "signal": signal,
                        "underlying_ltp": float(ltp) if ltp is not None else None,
                        "expiry_date": curr_date,
                    })
                    STATE.set("signal_history", hist)
            except Exception as e:
                logger.warning(f"Could not append signal history: {e}")

        # determine suggested strikes for trade actions
        try:
            sell_pe, buy_pe, sell_ce, buy_ce = select_strikes_atm_half_price(chain, atm if atm is not None else 0)
        except Exception as e:
            logger.warning(f"select_strikes_atm_half_price failed: {e}", exc_info=True)
            sell_pe = buy_pe = sell_ce = buy_ce = None

    # build result dict (leave raw 'chain' because it's already list-of-dict from API)
    result = {
        "ok": True,
        "updated": ist_now_str(),
        "ltp": ltp,
        "expiry_date": curr_date,
        "signal": signal,
        "ratio": ratio,
        "volume_ratio": volume_ratio,
        "atm_strike": atm,
        "api_usage": {
            "option_chain_api_count": STATE.get("option_chain_api_count", 0),
            "quote_api_count": STATE.get("quote_api_count", 0),
            "limit_per_minute": Config.API_RATE_LIMIT,
        },
        "chain": chain or [],
        "suggested": {
            "sell_pe": sell_pe,
            "buy_pe": buy_pe,
            "sell_ce": sell_ce,
            "buy_ce": buy_ce,
        },
    }

    # sanitize and return
    safe = sanitize_for_json(result)
    return safe



class TradeRequest(BaseModel):
    mode: str = Field(..., description="'paper' or 'live'")
    signal: str = Field(..., description="'BUY', 'SELL', or 'SIDEWAYS'")
    suggested: Dict[str, Any] = Field(default_factory=dict)


@app.post("/trade")
def trade(req: TradeRequest):
    if req.mode not in ("paper", "live"):
        raise HTTPException(status_code=400, detail="mode must be 'paper' or 'live'")
    if req.signal not in ("BUY", "SELL", "SIDEWAYS"):
        raise HTTPException(status_code=400, detail="invalid signal")

    sell_pe = req.suggested.get("sell_pe")
    buy_pe = req.suggested.get("buy_pe")
    sell_ce = req.suggested.get("sell_ce")
    buy_ce = req.suggested.get("buy_ce")

    if req.mode == "paper":
        ids = handle_paper_trade(req.signal, sell_pe, buy_pe, sell_ce, buy_ce)
        STATE.set("paper_last_signal_order_ids", ids)
        return {"ok": True, "ids": ids, "message": "Paper trade processed"}

    # live
    cid = STATE.get("cid", "")
    token = STATE.get("token", "")
    if not (cid and token):
        raise HTTPException(status_code=400, detail="Missing live trading credentials")

    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    if STATE.get("live_last_signal") == req.signal and has_open_orders_for_last_signal(fy):
        return {"ok": True, "ids": [], "message": f"Basket for {req.signal} already open"}

    ids = handle_basket_orders_atomic(req.signal, sell_pe, buy_pe, sell_ce, buy_ce, fy)
    STATE.multi_set(live_last_signal=req.signal, live_last_signal_order_ids=ids)
    return {"ok": True, "ids": ids, "message": "Live trade attempted"}


# For local run: uvicorn server:app --reload
if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", "8000"))
    uvicorn.run("app:app", host="localhost", port=port, reload=True)
