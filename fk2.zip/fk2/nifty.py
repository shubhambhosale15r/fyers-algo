import time
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import pytz
from fyers_apiv3 import fyersModel
import logging
import os
import json
from collections import deque
import csv
import matplotlib.pyplot as plt

# ============================================================
# CONFIGURATION
# ============================================================
class Config:
    REFRESH_INTERVAL = 60          # seconds
    API_RATE_LIMIT = 200
    API_WINDOW = 60
    LOT_SIZE = 65
    MAX_RETRIES = 3
    RETRY_DELAY = 2
    EXIT_ON_SIDEWAYS = True
    MAX_DAILY_ORDERS = 8
    STRIKE_GAP = 50

# ============================================================
# LOGGING
# ============================================================
logging.basicConfig(
    filename="trading_app.log",
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)

# ============================================================
# IST TIMEZONE
# ============================================================
IST = pytz.timezone("Asia/Kolkata")

def now_ist():
    return datetime.now(IST)

def timestamp_ist():
    return now_ist().strftime("%Y-%m-%d %H:%M:%S")

def is_market_open():
    # For debugging, always return True
    return True
    # Uncomment for live:
    # now = now_ist()
    # if now.weekday() >= 5: return False
    # if now.hour < 9 or (now.hour == 9 and now.minute < 15): return False
    # if now.hour > 15 or (now.hour == 15 and now.minute > 30): return False
    # return True

# ============================================================
# ERROR HANDLER
# ============================================================
def handle_errors(func):
    def wrapper(*args, **kwargs):
        retries = 0
        while retries < Config.MAX_RETRIES:
            try:
                return func(*args, **kwargs)
            except Exception as e:
                retries += 1
                print(f"[ERROR] {func.__name__} failed: {e}")
                logging.error(f"{func.__name__} failed: {e}")
                if retries < Config.MAX_RETRIES:
                    time.sleep(Config.RETRY_DELAY)
                else:
                    return None
        return None
    return wrapper

# ============================================================
# HELPER FUNCTIONS
# ============================================================
def get_next_aligned_time(interval_seconds):
    now = now_ist()
    current_seconds = (now - now.replace(hour=0, minute=0, second=0, microsecond=0)).total_seconds()
    intervals_passed = current_seconds // interval_seconds
    next_aligned_seconds = (intervals_passed + 1) * interval_seconds
    next_time = now.replace(hour=0, minute=0, second=0, microsecond=0) + timedelta(seconds=next_aligned_seconds)
    return next_time

def wait_until_next_interval(interval_seconds):
    next_time = get_next_aligned_time(interval_seconds)
    wait_seconds = (next_time - now_ist()).total_seconds()
    if wait_seconds > 0:
        print(f"⏳ Next update at {next_time.strftime('%H:%M:%S')} (waiting {wait_seconds:.1f}s)")
        time.sleep(wait_seconds)

# ============================================================
# DATA LOGGER
# ============================================================
class DataLogger:
    def __init__(self, filename="trading_data.csv"):
        self.filename = filename
        self._ensure_header()
        print(f"[DEBUG] DataLogger initialized, file: {filename}")

    def _ensure_header(self):
        try:
            with open(self.filename, 'r'):
                pass
        except FileNotFoundError:
            with open(self.filename, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'timestamp', 'underlying_ltp', 'signal', 'atm_strike',
                    'expiry_date', 'idwp', 'inof', 'inof_z', 'idwp_z', 'position'
                ])

    def log_data(self, timestamp, underlying_ltp, signal, atm_strike,
                 expiry_date, idwp, inof, inof_z, idwp_z, position):
        try:
            with open(self.filename, 'a', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    str(timestamp),
                    float(underlying_ltp) if underlying_ltp is not None else 0.0,
                    str(signal),
                    int(atm_strike) if atm_strike is not None else 0,
                    str(expiry_date),
                    round(float(idwp), 2),
                    round(float(inof), 2),
                    round(float(inof_z), 2),
                    round(float(idwp_z), 2),
                    str(position)
                ])
        except Exception as e:
            logging.exception("Logging error")

    def read_data(self, limit=None):
        try:
            df = pd.read_csv(self.filename)
            if limit:
                return df.tail(limit)
            return df
        except:
            return pd.DataFrame()

# ============================================================
# DASHBOARD
# ============================================================
class TerminalDashboard:
    def __init__(self, data_logger, session_state=None):
        self.data_logger = data_logger
        self.session_state = session_state

    def display_live_dashboard(self):
        try:
            os.system('cls' if os.name == 'nt' else 'clear')
            df = self.data_logger.read_data(limit=20)
            print("\n" + "=" * 100)
            print("📊 LIVE TRADING DASHBOARD")
            print("=" * 100)
            print(f"Last Update: {timestamp_ist()}")
            if self.session_state:
                print(f"📈 DAILY ORDER COUNT: {self.session_state.daily_executed_orders}/{Config.MAX_DAILY_ORDERS}")
            if df.empty:
                print("🔄 Waiting for trading data...")
                return
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            df = df.sort_values('timestamp')
            latest = df.iloc[-1]
            print(f"\n📈 CURRENT STATUS:")
            print(f"   Nifty LTP: {latest.get('underlying_ltp', 0)}")
            print(f"   Signal: {latest.get('signal', '')}")
            print(f"   ATM Strike: {latest.get('atm_strike', '')}")
            print(f"   idwp: {latest.get('idwp', '')} | inof: {latest.get('inof', '')}")
            print(f"   inof_z: {latest.get('inof_z', '')} | idwp_z: {latest.get('idwp_z', '')}")
            print(f"   Position: {latest.get('position', '')}")
            print(f"\n🔄 RECENT SIGNALS (Last 5):")
            for _, row in df.tail(5).iterrows():
                color = {'BUY': '🟢', 'SELL': '🔴', 'EXIT': '🟡', 'HOLD': '⚪'}.get(row['signal'], '⚪')
                print(f"   {row['timestamp'].strftime('%H:%M:%S')} - {color} {row['signal']} - LTP: {row['underlying_ltp']}")
            print("\n" + "=" * 100)
        except Exception as e:
            print(f"[ERROR] Dashboard error: {e}")

# ============================================================
# SESSION STATE
# ============================================================
class SessionState:
    def __init__(self):
        self.option_chain_api_count = 0
        self.quote_api_count = 0
        self.api_window_start = now_ist()
        self.last_signal = None
        self.last_signal_order_ids = []
        self.live_last_signal = None
        self.live_last_signal_order_ids = []
        self.signal_history = []
        self.cid = ""
        self.token = ""
        self._hb_lock = False
        self.last_trade_time = None
        self.opening_straddle = None
        self.opening_date = None
        self.cooldown_warned = False
        self.daily_executed_orders = 0
        self.last_order_sync = None
        # Rolling buffers – maxlen = 15 entries (15 minutes)
        self.inof_window = deque(maxlen=15)
        self.idwp_window = deque(maxlen=15)
        self.position = "FLAT"
        self.window_filled = False
        # For trailing stop on idwp
        self.peak_idwp = 0.0
        self.entry_idwp = 0.0

    def get(self, key, default=None):
        return getattr(self, key, default)

    def sync_order_count_with_fyers(self, fyers):
        today = now_ist().date()
        if self.last_order_sync != today:
            self.daily_executed_orders = 0
            self.last_order_sync = today
        try:
            resp = fyers.orderbook()
            if resp.get("s") == "ok":
                self.daily_executed_orders = len([o for o in resp.get("orderBook", []) if o.get("status") == 2])
        except:
            pass
        print(f"[DEBUG] Synced orders: {self.daily_executed_orders}")

    def can_place_order(self, fyers=None):
        if fyers:
            self.sync_order_count_with_fyers(fyers)
        return self.daily_executed_orders < Config.MAX_DAILY_ORDERS

# ============================================================
# CREDENTIALS
# ============================================================
def load_credentials(session_state):
    try:
        with open('fyers_credentials.json', 'r') as f:
            creds = json.load(f)
            session_state.cid = creds.get('client_id', '')
            session_state.token = creds.get('access_token', '')
        print(f"[DEBUG] Credentials loaded from JSON")
    except:
        session_state.cid = os.getenv("FYERS_CID", session_state.cid)
        session_state.token = os.getenv("FYERS_TOKEN", session_state.token)
        print("[DEBUG] Credentials from environment")

# ============================================================
# API FUNCTIONS
# ============================================================
def enforce_rate_limit(session_state):
    now = now_ist()
    window = now - session_state.api_window_start
    total_calls = session_state.option_chain_api_count + session_state.quote_api_count
    if window.total_seconds() > Config.API_WINDOW:
        session_state.api_window_start = now
        session_state.option_chain_api_count = 0
        session_state.quote_api_count = 0
    elif total_calls >= Config.API_RATE_LIMIT:
        wait = Config.API_WINDOW - int(window.total_seconds())
        if wait > 0:
            print(f"[DEBUG] Rate limit wait {wait}s")
            time.sleep(wait)
        session_state.api_window_start = now
        session_state.option_chain_api_count = 0
        session_state.quote_api_count = 0

@handle_errors
def get_option_chain_data(session_state, cid, token, sym, expiry_ts=""):
    print(f"[DEBUG] Fetching option chain for {sym}, expiry={expiry_ts or 'nearest'}")
    enforce_rate_limit(session_state)
    session_state.option_chain_api_count += 1
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    payload = {
        "symbol": sym,
        "strikecount": 5,
        "timestamp": expiry_ts,
        "greeks": "1"
    }
    resp = fy.optionchain(data=payload)
    if not resp or resp.get("code") != 200:
        print(f"[ERROR] Option chain failed: {resp}")
        return None
    print(f"[DEBUG] Option chain OK, {len(resp['data']['optionsChain'])} items")
    return resp["data"]["optionsChain"]

@handle_errors
def get_underlying_ltp(session_state, cid, token, sym):
    print(f"[DEBUG] Fetching LTP for {sym}")
    enforce_rate_limit(session_state)
    session_state.quote_api_count += 1
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    resp = fy.quotes(data={"symbols": sym})
    if not resp or resp.get("code") != 200 or not resp.get("d"):
        print(f"[ERROR] Quote failed: {resp}")
        return None
    ltp = resp["d"][0]["v"]["lp"]
    print(f"[DEBUG] Underlying LTP = {ltp}")
    return ltp

@handle_errors
def update_all_data(session_state, cid, token, sym):
    print("[DEBUG] update_all_data started")
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    enforce_rate_limit(session_state)
    session_state.option_chain_api_count += 1
    meta = fy.optionchain(data={"symbol": sym, "timestamp": ""})
    if meta.get("code") != 200:
        print(f"[ERROR] Meta option chain failed: {meta}")
        return None, None, None
    exp = sorted([(e["date"], e.get("expiry")) for e in meta["data"]["expiryData"]],
                 key=lambda x: datetime.strptime(x[0], "%d-%m-%Y"))
    today = now_ist().date()
    dates = [datetime.strptime(d, "%d-%m-%Y").date() for d,_ in exp]
    idx = next((i for i,d in enumerate(dates) if d >= today), 0)
    curr_date, curr_ts = exp[idx]
    print(f"[DEBUG] Using expiry {curr_date}")
    ltp = get_underlying_ltp(session_state, cid, token, sym)
    chain = get_option_chain_data(session_state, cid, token, sym, expiry_ts=curr_ts)
    return ltp, chain, curr_date

# ============================================================
# COMPUTE SIGNALS (no span check, only deque length)
# ============================================================
def compute_signals(merged_df, atm_strike, ltp, fyers_api=None, session_state=None):
    print("\n[DEBUG] ========== compute_signals START ==========")
    if merged_df is None or merged_df.empty:
        return "HOLD", {}

    if session_state is None:
        session_state = SessionState()

    # Ensure buffers
    if not hasattr(session_state, "inof_window"):
        session_state.inof_window = deque(maxlen=15)
    if not hasattr(session_state, "idwp_window"):
        session_state.idwp_window = deque(maxlen=15)
    if not hasattr(session_state, "window_filled"):
        session_state.window_filled = False
    if not hasattr(session_state, "position"):
        session_state.position = "FLAT"
    if not hasattr(session_state, "peak_idwp"):
        session_state.peak_idwp = 0.0
    if not hasattr(session_state, "entry_idwp"):
        session_state.entry_idwp = 0.0

    # 1. Select strikes and compute idwp / inof for this minute
    available_strikes = sorted(merged_df["strike"].unique())
    if atm_strike not in available_strikes:
        return "HOLD", {}
    atm_idx = available_strikes.index(atm_strike)
    selected = [atm_strike]
    if atm_idx > 0:
        selected.append(available_strikes[atm_idx-1])
    if atm_idx < len(available_strikes)-1:
        selected.append(available_strikes[atm_idx+1])

    idwps, inofs = [], []
    for strike in selected:
        rows = merged_df[merged_df["strike"] == strike]
        ce = rows[rows["option_type"] == "CE"]
        pe = rows[rows["option_type"] == "PE"]
        if ce.empty or pe.empty:
            continue
        ce = ce.iloc[0]; pe = pe.iloc[0]
        ce_ltp = float(ce.get("ltp",0))
        pe_ltp = float(pe.get("ltp",0))
        ce_delta = float(ce.get("delta",0))
        pe_delta = abs(float(pe.get("delta",0)))
        ce_vol = float(ce.get("volume",0))
        pe_vol = float(pe.get("volume",0))
        idwps.append((ce_ltp * ce_delta) - (pe_ltp * pe_delta))
        inofs.append((ce_vol * ce_delta) - (pe_vol * pe_delta))
    if not idwps or not inofs:
        return "HOLD", {}
    idwp = sum(idwps)/len(idwps)
    inof = sum(inofs)/len(inofs)

    # 2. Append to rolling windows (deques with maxlen=15)
    session_state.idwp_window.append(idwp)
    session_state.inof_window.append(inof)

    # 3. Warm‑up: wait until we have 15 entries (15 minutes)
    if not session_state.window_filled:
        if len(session_state.inof_window) < 15:
            print(f"[DEBUG] Warming up: {len(session_state.inof_window)}/15 entries – HOLD")
            metrics = {
                "atm_strike": atm_strike, "spot": ltp,
                "idwp": round(idwp,2), "inof": round(inof,2),
                "inof_z": 0.0, "idwp_z": 0.0,
                "position": session_state.position, "signal": "HOLD"
            }
            return "HOLD", metrics
        else:
            session_state.window_filled = True
            print("[DEBUG] Rolling window FULL (15 entries) – signals enabled")

    # If we are here, window is full (15 values)
    # Compute Z‑scores on the raw idwp and inof over the window
    inof_vals = np.array(session_state.inof_window)
    mean_inof = np.mean(inof_vals)
    std_inof = np.std(inof_vals)
    inof_z = (inof - mean_inof) / std_inof if std_inof > 0 else 0.0

    idwp_vals = np.array(session_state.idwp_window)
    mean_idwp = np.mean(idwp_vals)
    std_idwp = np.std(idwp_vals)
    idwp_z = (idwp - mean_idwp) / std_idwp if std_idwp > 0 else 0.0

    print(f"[DEBUG] inof_z={inof_z:.2f}, idwp_z={idwp_z:.2f}")

    ENTRY_Z = 1.5
    TRAIL_STOP_PCT = 0.33   # 33% drop from peak for exit
    signal = "HOLD"

    # --- Exit for LONG (trailing stop on idwp peak) ---
    if session_state.position == "LONG":
        if idwp > session_state.peak_idwp:
            session_state.peak_idwp = idwp
            print(f"[DEBUG] LONG: new peak idwp = {session_state.peak_idwp:.2f}")
        exit_threshold = session_state.peak_idwp * (1 - TRAIL_STOP_PCT)
        if idwp < exit_threshold:
            print(f"[DEBUG] Exit LONG: idwp={idwp:.2f} < peak*0.75 = {exit_threshold:.2f}")
            signal = "EXIT"
            session_state.position = "FLAT"
            session_state.peak_idwp = 0.0
            session_state.entry_idwp = 0.0

    # --- Exit for SHORT (trailing stop on idwp trough) ---
    elif session_state.position == "SHORT":
        if idwp < session_state.peak_idwp:  # track trough (more negative)
            session_state.peak_idwp = idwp
            print(f"[DEBUG] SHORT: new trough idwp = {session_state.peak_idwp:.2f}")
        exit_threshold = session_state.peak_idwp * (1 - TRAIL_STOP_PCT)
        if idwp > exit_threshold:
            print(f"[DEBUG] Exit SHORT: idwp={idwp:.2f} > trough*0.75 = {exit_threshold:.2f}")
            signal = "EXIT"
            session_state.position = "FLAT"
            session_state.peak_idwp = 0.0
            session_state.entry_idwp = 0.0

    # --- Entry logic (only if FLAT) ---
    if session_state.position == "FLAT":
        if inof_z > ENTRY_Z and idwp_z > ENTRY_Z:
            print(f"[DEBUG] ENTRY BUY (inof_z={inof_z:.2f}, idwp_z={idwp_z:.2f})")
            signal = "BUY"
            session_state.position = "LONG"
            session_state.peak_idwp = idwp
            session_state.entry_idwp = idwp
        elif inof_z < -ENTRY_Z and idwp_z < -ENTRY_Z:
            print(f"[DEBUG] ENTRY SELL (inof_z={inof_z:.2f}, idwp_z={idwp_z:.2f})")
            signal = "SELL"
            session_state.position = "SHORT"
            session_state.peak_idwp = idwp
            session_state.entry_idwp = idwp

    print(f"[DEBUG] Final signal: {signal}")
    metrics = {
        "atm_strike": atm_strike,
        "spot": ltp,
        "idwp": round(idwp,2),
        "inof": round(inof,2),
        "inof_z": round(inof_z,2),
        "idwp_z": round(idwp_z,2),
        "position": session_state.position,
        "signal": signal
    }
    return signal, metrics

# ============================================================
# STRIKE SELECTION (for orders)
# ============================================================
def select_strikes_atm_half_price(chain, atm_strike):
    try:
        df = pd.DataFrame(chain)
        if df.empty:
            return None, None, None, None
        ce = df[df["option_type"] == "CE"].copy()
        pe = df[df["option_type"] == "PE"].copy()
        buy_ce = ce[ce["strike_price"] == atm_strike].iloc[0].to_dict() if not ce[ce["strike_price"] == atm_strike].empty else None
        buy_pe = pe[pe["strike_price"] == atm_strike].iloc[0].to_dict() if not pe[pe["strike_price"] == atm_strike].empty else None
        return buy_pe, None, buy_ce, None
    except Exception as e:
        print(f"[ERROR] select_strikes error: {e}")
        return None, None, None, None

# ============================================================
# ORDER MANAGEMENT
# ============================================================
def handle_basket_orders_atomic(session_state, signal, sell_pe, buy_pe, sell_ce, buy_ce, fyers, data_logger):
    print(f"[DEBUG] handle_basket_orders_atomic called with signal={signal}")
    if getattr(session_state, '_hb_lock', False):
        return []
    session_state._hb_lock = True
    placed_ids = []
    try:
        lot = Config.LOT_SIZE
        if signal in ("SIDEWAYS", "EXIT") or (session_state.last_signal in ("BUY","SELL") and session_state.last_signal != signal):
            print("[DEBUG] Exiting all positions")
            fyers.exit_positions(data={"segment":[11],"side":[-1],"productType":["MARGIN"]})
            fyers.exit_positions(data={"segment":[11],"side":[1],"productType":["MARGIN"]})
            time.sleep(2)
            session_state.last_signal = signal
            session_state.last_trade_time = now_ist()
            return []
        if signal in ("BUY","SELL") and session_state.can_place_order(fyers):
            buy_leg = buy_ce if signal=="BUY" else buy_pe
            if not buy_leg:
                return []
            order = {
                "symbol": buy_leg["symbol"],
                "qty": lot,
                "type": 2,
                "side": 1,
                "productType": "MARGIN",
                "validity": "DAY",
            }
            print(f"[DEBUG] Placing order: {order}")
            resp = fyers.place_order(data=order)
            if resp.get("s") == "ok":
                placed_ids.append(resp["id"])
                session_state.last_signal = signal
        return placed_ids
    except Exception as e:
        print(f"[ERROR] Order exception: {e}")
        return []
    finally:
        session_state._hb_lock = False

# ============================================================
# PLOTTING
# ============================================================
def generate_static_plot():
    try:
        data_logger = DataLogger()
        df = data_logger.read_data()
        if df.empty:
            print("No data to plot")
            return None
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        df = df.sort_values('timestamp')
        fig, ax = plt.subplots(figsize=(15,6))
        ax.plot(df['timestamp'], df['underlying_ltp'], 'b-', label='Nifty LTP')
        buy = df[df['signal'] == 'BUY']
        sell = df[df['signal'] == 'SELL']
        exit_sig = df[df['signal'] == 'EXIT']
        if not buy.empty:
            ax.scatter(buy['timestamp'], buy['underlying_ltp'], color='green', s=100, marker='^', label='BUY')
        if not sell.empty:
            ax.scatter(sell['timestamp'], sell['underlying_ltp'], color='red', s=100, marker='v', label='SELL')
        if not exit_sig.empty:
            ax.scatter(exit_sig['timestamp'], exit_sig['underlying_ltp'], color='orange', s=80, marker='s', label='EXIT')
        ax.legend()
        plt.title('Nifty LTP vs Signals')
        plot_file = f"trading_plot_{now_ist().strftime('%Y%m%d_%H%M%S')}.png"
        plt.savefig(plot_file, dpi=300)
        plt.close()
        print(f"✅ Plot saved as {plot_file}")
        return plot_file
    except Exception as e:
        print(f"[ERROR] Plot error: {e}")
        return None

# ============================================================
# MAIN APPLICATION
# ============================================================
def main():
    session_state = SessionState()
    load_credentials(session_state)
    data_logger = DataLogger()
    dashboard = TerminalDashboard(data_logger, session_state)
    sym = 'NSE:NIFTY50-INDEX'

    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        print("="*50)
        print("📈 FYERS ALGO TRADING")
        print("1. Start Live Trading")
        print("2. Settings")
        print("3. Generate Static Plot")
        print("4. Exit")
        choice = input("Select option: ").strip()
        if choice == "1":
            if not (session_state.cid and session_state.token):
                print("❌ Set credentials first")
                input("Press Enter...")
                continue
            auto_trade = input("Enable Auto Trade? (y/n): ").lower() == 'y'
            if not auto_trade:
                continue
            print("Starting live trading loop...")
            try:
                while True:
                    dashboard.display_live_dashboard()
                    ltp, chain, curr_date = update_all_data(session_state, session_state.cid, session_state.token, sym)
                    if ltp is None or chain is None:
                        wait_until_next_interval(Config.REFRESH_INTERVAL)
                        continue
                    fy = fyersModel.FyersModel(client_id=session_state.cid, token=session_state.token, is_async=False, log_path="")
                    session_state.sync_order_count_with_fyers(fy)

                    records = []
                    for opt in chain:
                        if opt.get("option_type") in ("CE","PE"):
                            greeks = opt.get("greeks", {})
                            records.append({
                                "strike": opt["strike_price"],
                                "option_type": opt["option_type"],
                                "ltp": opt.get("ltp", 0),
                                "delta": greeks.get("delta", 0),
                                "volume": opt.get("volume", 0)
                            })
                    merged_df = pd.DataFrame(records)
                    if merged_df.empty:
                        wait_until_next_interval(Config.REFRESH_INTERVAL)
                        continue
                    atm_strike = min(merged_df["strike"].unique(), key=lambda x: abs(x - ltp))
                    signal, metrics = compute_signals(merged_df, atm_strike, ltp, fyers_api=fy, session_state=session_state)

                    data_logger.log_data(
                        timestamp=timestamp_ist(),
                        underlying_ltp=ltp,
                        signal=signal,
                        atm_strike=atm_strike,
                        expiry_date=curr_date,
                        idwp=metrics.get("idwp", 0),
                        inof=metrics.get("inof", 0),
                        inof_z=metrics.get("inof_z", 0),
                        idwp_z=metrics.get("idwp_z", 0),
                        position=metrics.get("position", "FLAT")
                    )

                    buy_pe, _, buy_ce, _ = select_strikes_atm_half_price(chain, atm_strike)
                    if signal in ("BUY","SELL","SIDEWAYS","EXIT"):
                        handle_basket_orders_atomic(session_state, signal, None, buy_pe, None, buy_ce, fy, data_logger)
                    wait_until_next_interval(Config.REFRESH_INTERVAL)
            except KeyboardInterrupt:
                print("\nStopped by user")
        elif choice == "2":
            print("\n⚙️ SETTINGS")
            new_cid = input(f"Client ID [{session_state.cid}]: ").strip()
            if new_cid: session_state.cid = new_cid
            new_token = input(f"Access token: ").strip()
            if new_token: session_state.token = new_token
            with open('fyers_credentials.json', 'w') as f:
                json.dump({"client_id": session_state.cid, "access_token": session_state.token}, f)
            print("✅ Settings saved")
            input("Press Enter...")
        elif choice == "3":
            generate_static_plot()
            input("Press Enter...")
        elif choice == "4":
            break

if __name__ == "__main__":
    main()