import pandas as pd
import numpy as np
import time
import os
from datetime import datetime
from fyers_apiv3 import fyersModel

# =========================
# CONFIG
# =========================
CLIENT_ID = "0F5WWD1SBL-100"
ACCESS_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."

UNDERLYING_SYMBOL = "NSE:NIFTY50-INDEX"
STRIKE_NEIGHBOR = 1
TOP_K = 1
POLL_INTERVAL = 60
LOT_SIZE = 75
ROLLING_WINDOW = 30

TRADES_CSV   = "paper_trades.csv"
TICKS_CSV    = "paper_ticks.csv"
TOPK_CSV     = "topk_options.csv"
UNIVERSE_CSV = "universe_options.csv"

# =========================
# DEBUG
# =========================
def dbg(msg):
    print(f"[DEBUG] {datetime.now().strftime('%H:%M:%S')} | {msg}")

# =========================
# FYERS INIT
# =========================
def init_fyers():
    dbg("Initializing Fyers API")
    return fyersModel.FyersModel(
        client_id=CLIENT_ID,
        token=ACCESS_TOKEN,
        is_async=False,
        log_path=""
    )

# =========================
# HELPERS
# =========================
def get_ltp(fyers, symbol):
    try:
        return float(fyers.quotes({"symbols": symbol})["d"][0]["v"]["lp"])
    except:
        dbg(f"LTP unavailable for {symbol}")
        return None

# =========================
# FETCH HISTORY
# =========================
def fetch_history(fyers, symbol):
    today = datetime.now().strftime("%Y-%m-%d")
    resp = fyers.history({
        "symbol": symbol,
        "resolution": "1",
        "date_format": 1,
        "range_from": today,
        "range_to": today,
        "cont_flag": 1
    })
    if resp.get("s") != "ok" or not resp.get("candles"):
        dbg(f"HISTORY FAIL {symbol}")
        return None

    return pd.DataFrame(
        resp["candles"],
        columns=["epoch", "open", "high", "low", "close", "volume"]
    )

# =========================
# SCORE COMPUTATION
# =========================
def compute_score(df, label=None):
    closes = df["close"]
    if len(closes) < 32:
        return None

    R3  = closes.iloc[-2] / closes.iloc[-5]  - 1
    R10 = closes.iloc[-2] / closes.iloc[-12] - 1
    R30 = closes.iloc[-2] / closes.iloc[-32] - 1

    M = (R3 + R10 + R30) / 3
    sigma = closes.pct_change().rolling(ROLLING_WINDOW).std().iloc[-1]
    score = M / sigma if sigma and sigma > 0 else 0.0

    if label:
        dbg(f"{label} | score={score:.4f} M={M:.4f} σ={sigma:.4f}")

    return {
        "R3": R3,
        "R10": R10,
        "R30": R30,
        "M": M,
        "score": score
    }

# =========================
# DOMINANCE CHECK
# =========================
def is_option_dominant(opt_score, und_score, opt_M):
    return (
        opt_score > und_score and
        abs(opt_score) > abs(und_score) and
        opt_M > 0
    )

# =========================
# TOP-K OPTIONS
# =========================
def compute_topk_options(fyers, option_chain, underlying_price):

    udf = fetch_history(fyers, UNDERLYING_SYMBOL)
    if udf is None:
        return []

    u = compute_score(udf, "UNDERLYING")
    if u is None:
        return []

    underlying_score = u["score"]
    dbg(f"Underlying score locked = {underlying_score:.4f}")

    strikes = sorted({o["strike_price"] for o in option_chain if o["strike_price"] > 0})
    atm = min(strikes, key=lambda s: abs(s - underlying_price))
    idx = strikes.index(atm)
    selected = strikes[max(0, idx-1): idx+2]

    dbg(f"ATM={atm} | strikes={selected}")

    universe = [o for o in option_chain if o["strike_price"] in selected]
    winners, universe_log = [], []

    for opt in universe:
        df = fetch_history(fyers, opt["symbol"])
        if df is None:
            continue

        s = compute_score(df, opt["symbol"])
        if s is None:
            continue

        dominant = is_option_dominant(s["score"], underlying_score, s["M"])

        dbg(
            f"CHECK {opt['symbol']} | "
            f"opt={s['score']:.2f} und={underlying_score:.2f} "
            f"dominant={dominant}"
        )

        universe_log.append({
            "timestamp": datetime.now(),
            "symbol": opt["symbol"],
            "type": opt["option_type"],
            "strike": opt["strike_price"],
            "option_score": s["score"],
            "underlying_score": underlying_score,
            "dominant": dominant,
            **s
        })

        if dominant:
            winners.append({
                "symbol": opt["symbol"],
                "type": opt["option_type"],
                "option_score": s["score"],
                "underlying_score": underlying_score,
                **s
            })

    if universe_log:
        pd.DataFrame(universe_log).to_csv(
            UNIVERSE_CSV,
            mode="a",
            header=not os.path.exists(UNIVERSE_CSV),
            index=False
        )

    winners = sorted(winners, key=lambda x: x["option_score"], reverse=True)
    topk = winners[:TOP_K]

    if topk:
        pd.DataFrame(topk).assign(timestamp=datetime.now()).to_csv(
            TOPK_CSV,
            mode="a",
            header=not os.path.exists(TOPK_CSV),
            index=False
        )

    dbg(f"TOPK = {[o['symbol'] for o in topk]}")
    return topk

# =========================
# PAPER TRADING
# =========================
def paper_trade(fyers, session, topk):

    now = datetime.now()

    # ----- EXIT -----
    if session.position:
        pos_type = session.position["type"]

        exit_reason = None

        if not topk:
            exit_reason = "NO_DOMINANCE"
            dbg("EXIT SIGNAL | No dominant option")

        else:
            top_type = topk[0]["type"]
            if pos_type != top_type:
                exit_reason = "REGIME_FLIP"
                dbg(f"EXIT SIGNAL | Regime flip {pos_type} → {top_type}")

        if exit_reason:
            exit_price = get_ltp(fyers, session.position["symbol"])
            if exit_price:
                pnl = (exit_price - session.position["entry_price"]) * LOT_SIZE
                session.equity += pnl

                dbg(f"EXIT {session.position['symbol']} | {exit_reason} | pnl={pnl:.2f}")

                pd.DataFrame([{
                    "symbol": session.position["symbol"],
                    "entry_price": session.position["entry_price"],
                    "exit_price": exit_price,
                    "pnl": pnl,
                    "entry_time": session.position["time"],
                    "exit_time": now
                }]).to_csv(
                    TRADES_CSV,
                    mode="a",
                    header=not os.path.exists(TRADES_CSV),
                    index=False
                )

            session.position = None

    # ----- ENTRY -----
    if not session.position and topk:
        o = topk[0]
        entry_price = get_ltp(fyers, o["symbol"])
        if entry_price:
            session.position = {
                "symbol": o["symbol"],
                "type": o["type"],
                "entry_price": entry_price,
                "time": now
            }
            dbg(f"ENTER {o['symbol']} ({o['type']}) @ {entry_price:.2f}")

    # ----- TICK LOG -----
    unrealized = 0.0
    if session.position:
        ltp = get_ltp(fyers, session.position["symbol"])
        if ltp:
            unrealized = (ltp - session.position["entry_price"]) * LOT_SIZE

    pd.DataFrame([{
        "timestamp": now,
        "symbol": session.position["symbol"] if session.position else None,
        "equity": session.equity,
        "unrealized_pnl": unrealized,
        "net_pnl": session.equity + unrealized
    }]).to_csv(
        TICKS_CSV,
        mode="a",
        header=not os.path.exists(TICKS_CSV),
        index=False
    )

# =========================
# MAIN LOOP
# =========================
def main():
    fyers = init_fyers()

    session = type("Session", (), {})()
    session.position = None
    session.equity = 0.0

    dbg("🚀 Strategy started")

    while True:
        try:
            lp = get_ltp(fyers, UNDERLYING_SYMBOL)
            if lp is None:
                time.sleep(5)
                continue

            chain = fyers.optionchain({
                "symbol": UNDERLYING_SYMBOL,
                "strikecount": STRIKE_NEIGHBOR
            })["data"]["optionsChain"]

            topk = compute_topk_options(fyers, chain, lp)
            paper_trade(fyers, session, topk)

            time.sleep(POLL_INTERVAL)

        except Exception as e:
            dbg(f"LOOP ERROR {e}")
            time.sleep(5)

if __name__ == "__main__":
    main()
