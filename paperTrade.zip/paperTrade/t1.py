import pandas as pd
import numpy as np
import time
import os
from datetime import datetime
from fyers_apiv3 import fyersModel

# =========================
# CONFIG
# =========================
CLIENT_ID = "0F5WWD1SBL-100"
ACCESS_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOlsiZDoxIiwiZDoyIiwieDowIiwieDoxIiwieDoyIl0sImF0X2hhc2giOiJnQUFBQUFCcFQ0Wi0tZ2F6bHltTHBKMExiSjRYblRMVDV6Nk01RjFxaExNZFhGbWVBSno2anU4UHVVSTA0cFVxQy1PNmFhd0dTbEkxb1VFTDFNLVFVN3dxdW1na2pvVkxxdzVsQUR0c0VnVG9VTmpoNEVubXBIVT0iLCJkaXNwbGF5X25hbWUiOiIiLCJvbXMiOiJLMSIsImhzbV9rZXkiOiI3MjcwYzY1YTdkY2ExYzAxZDNjOTg3NjRmZmViNjAyOWRiY2Y5ODUyMmMzNGViMzRjYTUxYTAwZSIsImlzRGRwaUVuYWJsZWQiOiJOIiwiaXNNdGZFbmFibGVkIjoiTiIsImZ5X2lkIjoiRkFBMzE0OTUiLCJhcHBUeXBlIjoxMDAsImV4cCI6MTc2Njg4MTgwMCwiaWF0IjoxNzY2ODE5NDU0LCJpc3MiOiJhcGkuZnllcnMuaW4iLCJuYmYiOjE3NjY4MTk0NTQsInN1YiI6ImFjY2Vzc190b2tlbiJ9.ABEQCtZv0_N_FPYWIA22WFq3EFukUG7zf1kwcok4808"  # replace with actual
UNDERLYING_SYMBOL = "NSE:NIFTY50-INDEX"
STRIKE_COUNT = 1
POLL_INTERVAL = 60
LOT_SIZE = 75
ROLLING_WINDOW = 3

TRADES_CSV = "paper_trades.csv"
TICKS_CSV = "paper_ticks.csv"

# =========================
# FYERS INIT
# =========================
def init_fyers():
    print("🔌 Initializing Fyers API...")
    fyers = fyersModel.FyersModel(
        client_id=CLIENT_ID,
        token=ACCESS_TOKEN,
        is_async=False,
        log_path=""
    )
    print("✅ Fyers initialized")
    return fyers

# =========================
# CSV APPEND
# =========================
def append_csv(path, row):
    df = pd.DataFrame([row])
    header = not os.path.exists(path)
    df.to_csv(path, mode="a", header=header, index=False)
    print(f"📝 Appended row to {path}")

# =========================
# FETCH OPTION CHAIN
# =========================
def fetch_option_chain(fyers):
    print("📡 Fetching option chain...")
    resp = fyers.optionchain({
        "symbol": UNDERLYING_SYMBOL,
        "strikecount": STRIKE_COUNT,
        "timestamp": ""
    })
    print(f"📄 Option chain response: {resp}")
    if resp.get("code") != 200:
        raise RuntimeError(resp)
    return resp["data"]["optionsChain"]

# =========================
# FETCH UNDERLYING LTP
# =========================
def fetch_underlying_ltp(fyers):
    print("📡 Fetching underlying LTP...")
    resp = fyers.quotes({"symbols": UNDERLYING_SYMBOL})
    print(f"📄 LTP response: {resp}")
    if resp.get("code") != 200:
        raise RuntimeError(resp)
    for item in resp.get("d", []):
        if item.get("s") == "ok":
            print(f"💹 Underlying LTP: {item['v']['lp']}")
            return float(item["v"]["lp"])
    raise RuntimeError("Underlying LTP missing")

# =========================
# BUILD MERGED DF
# =========================
def build_merged_df(chain):
    print("🧩 Building merged dataframe from option chain...")
    rows = {}
    for opt in chain:
        if opt["option_type"] not in ("CE", "PE"):
            continue
        strike = opt["strike_price"]
        rows.setdefault(strike, {
            "Strike": strike,
            "CE_symbol": None,
            "PE_symbol": None,
            "CE_ltp": 0.0,
            "PE_ltp": 0.0,
            "CE_OI_Change": 0.0,
            "PE_OI_Change": 0.0,
            "CE_OI": 0.0,
            "PE_OI": 0.0
        })
        if opt["option_type"] == "CE":
            rows[strike].update({
                "CE_symbol": opt["symbol"],
                "CE_ltp": opt["ltp"],
                "CE_OI": opt.get("oi", 0),
                "CE_OI_Change": opt.get("oich", 0)
            })
        else:
            rows[strike].update({
                "PE_symbol": opt["symbol"],
                "PE_ltp": opt["ltp"],
                "PE_OI": opt.get("oi", 0),
                "PE_OI_Change": opt.get("oich", 0)
            })
    df = pd.DataFrame(rows.values()).sort_values("Strike").reset_index(drop=True)
    print(f"📊 merged_df snapshot:\n{df.head()}")
    return df

# =========================
# FIND ATM
# =========================
def find_atm_strike(df):
    df["diff"] = abs(df["CE_ltp"] - df["PE_ltp"])
    atm = df.loc[df["diff"].idxmin(), "Strike"]
    print(f"🎯 ATM Strike identified: {atm}")
    return atm

# =========================
# SIGNAL ENGINE
# =========================
def compute_signals(df, atm_strike, session):
    print("🧠 Computing TrendForce...")
    strikes = df["Strike"].tolist()
    i = strikes.index(atm_strike)
    selected = strikes[max(i-1,0):i+2]
    d = df[df["Strike"].isin(selected)].copy()
    print(f"📌 Selected strikes for TF calculation: {selected}")

    d["CE_pressure"] = d["CE_ltp"] * d["CE_OI_Change"]
    d["PE_pressure"] = d["PE_ltp"] * d["PE_OI_Change"]
    ce_p = d["CE_pressure"].sum()
    pe_p = d["PE_pressure"].sum()
    tf_raw = (ce_p - pe_p) / (abs(ce_p) + abs(pe_p)) if (abs(ce_p)+abs(pe_p)) else 0.0

    total_ce_oi = d["CE_OI"].sum()
    total_pe_oi = d["PE_OI"].sum()
    pcr = total_pe_oi / total_ce_oi if total_ce_oi else 0.0

    if not hasattr(session, "tf_buffer"):
        session.tf_buffer = []
    session.tf_buffer.append(tf_raw)
    session.tf_buffer = session.tf_buffer[-3:]
    tf_smoothed = float(np.mean(session.tf_buffer))

    print(f"📊 TF Raw: {tf_raw:.4f}, Smoothed: {tf_smoothed:.4f}, CE Pressure Sum: {ce_p}, PE Pressure Sum: {pe_p}, PCR: {pcr:.4f}")

    if tf_smoothed < -0.25 and pcr > 1.2:
        signal = "BUY"
    elif tf_smoothed > 0.25 and pcr < 0.8:
        signal = "SELL"
    else:
        signal = "SIDEWAYS"

    print(f"🔥 Computed Signal: {signal}")
    return signal, tf_smoothed, tf_raw, ce_p, pe_p, total_ce_oi, total_pe_oi, pcr

# =========================
# PAPER TRADE ENGINE
# =========================
def paper_trade(signal, underlying_price, merged_df, atm_strike, session):
    print(f"💹 Processing paper trade | Signal={signal}, Underlying={underlying_price}")
    if not hasattr(session, "price_buffer"):
        session.price_buffer = []
    session.price_buffer.append(underlying_price)
    session.price_buffer = session.price_buffer[-ROLLING_WINDOW:]
    print(f"📈 Price buffer ({len(session.price_buffer)}): {session.price_buffer}")

    high = max(session.price_buffer[:-1]) if len(session.price_buffer) > 1 else underlying_price
    low = min(session.price_buffer[:-1]) if len(session.price_buffer) > 1 else underlying_price
    atm = merged_df[merged_df["Strike"] == atm_strike].iloc[0]
    now = datetime.now()
    unrealised_pnl = 0.0

    # EXIT
    if session.position:
        pos = session.position
        exit_trade = False
        if pos["side"] == "BUY" and (underlying_price < low or signal != "BUY"):
            exit_price = atm["CE_ltp"]
            pnl = (exit_price - pos["entry_price"]) * LOT_SIZE
            exit_trade = True
        elif pos["side"] == "SELL" and (underlying_price > high or signal != "SELL"):
            exit_price = atm["PE_ltp"]
            pnl = (exit_price - pos["entry_price"]) * LOT_SIZE
            exit_trade = True

        if exit_trade:
            session.equity += pnl
            print(f"🚪 EXIT {pos['side']} | Entry={pos['entry_price']}, Exit={exit_price}, PnL={pnl}, Equity={session.equity}")
            session.position = None
        else:
            if pos["side"] == "BUY":
                unrealised_pnl = (atm["CE_ltp"] - pos["entry_price"]) * LOT_SIZE
            else:
                unrealised_pnl = (atm["PE_ltp"] - pos["entry_price"]) * LOT_SIZE
            print(f"💰 Unrealised PnL: {unrealised_pnl}")

    # ENTRY
    if not session.position:
        if signal == "BUY" and underlying_price > high:
            session.position = {"side": "BUY", "entry_price": atm["CE_ltp"], "time": now}
            print(f"🟩 ENTER BUY | Price={atm['CE_ltp']}")
        elif signal == "SELL" and underlying_price < low:
            session.position = {"side": "SELL", "entry_price": atm["PE_ltp"], "time": now}
            print(f"🟥 ENTER SELL | Price={atm['PE_ltp']}")

    return high, low, unrealised_pnl

# =========================
# MAIN LOOP
# =========================
def main():
    fyers = init_fyers()
    session = type("Session", (), {})()
    session.position = None
    session.equity = 0.0
    session.price_buffer = []
    session.tf_buffer = []

    print("🚀 Paper trading started")

    while True:
        try:
            print("\n⏱ New loop iteration")
            chain = fetch_option_chain(fyers)
            underlying = fetch_underlying_ltp(fyers)
            df = build_merged_df(chain)
            atm = find_atm_strike(df)

            signal, tf_smoothed, tf_raw, ce_p, pe_p, total_ce_oi, total_pe_oi, pcr = compute_signals(df, atm, session)
            high, low, unrealised_pnl = paper_trade(signal, underlying, df, atm, session)

            append_csv(TICKS_CSV, {
                "timestamp": datetime.now(),
                "underlying_ltp": underlying,
                "atm_strike": atm,
                "signal": signal,
                "ce_pressure_sum": ce_p,
                "pe_pressure_sum": pe_p,
                "tf_raw": tf_raw,
                "tf_smoothed": tf_smoothed,
                "total_ce_oi": total_ce_oi,
                "total_pe_oi": total_pe_oi,
                "pcr": pcr,
                "rolling_high": high,
                "rolling_low": low,
                "price_buffer_len": len(session.price_buffer),
                "breakout_valid": (signal=="BUY" and underlying>high) or (signal=="SELL" and underlying<low),
                "position_side": session.position["side"] if session.position else None,
                "entry_price": session.position["entry_price"] if session.position else None,
                "current_option_ltp": df[df["Strike"]==atm]["CE_ltp"].values[0] if session.position and session.position["side"]=="BUY" else df[df["Strike"]==atm]["PE_ltp"].values[0] if session.position else None,
                "unrealised_pnl": unrealised_pnl,
                "realised_pnl": session.equity,
                "net_pnl": session.equity + unrealised_pnl
            })

            print(f"💾 Tick appended | Net PnL: {session.equity + unrealised_pnl}")
            time.sleep(POLL_INTERVAL)

        except Exception as e:
            print("❌ LOOP ERROR:", repr(e))
            time.sleep(5)

if __name__ == "__main__":
    main()
