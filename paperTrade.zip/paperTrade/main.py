import pandas as pd
import numpy as np
import time
import os
from datetime import datetime
from fyers_apiv3 import fyersModel

# ======================================================
# CONFIG
# ======================================================
CLIENT_ID = "0F5WWD1SBL-100"
ACCESS_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOlsiZDoxIiwiZDoyIiwieDowIiwieDoxIiwieDoyIl0sImF0X2hhc2giOiJnQUFBQUFCcFROQzhHMHMzaUFpVFdEZ2gzT25SeGswY0VacUJaTVhOQ0QtNmNvNzZ2R0Y3VE4tRUdqM2dJNkRsbS15SjJsMkRfY0NNNGRUcjlEZUZJejFFV2hJSFRrT2NXOWZwUTJUbm54b2JybGlHVFlyNW5LQT0iLCJkaXNwbGF5X25hbWUiOiIiLCJvbXMiOiJLMSIsImhzbV9rZXkiOiI3MjcwYzY1YTdkY2ExYzAxZDNjOTg3NjRmZmViNjAyOWRiY2Y5ODUyMmMzNGViMzRjYTUxYTAwZSIsImlzRGRwaUVuYWJsZWQiOiJOIiwiaXNNdGZFbmFibGVkIjoiTiIsImZ5X2lkIjoiRkFBMzE0OTUiLCJhcHBUeXBlIjoxMDAsImV4cCI6MTc2NjcwOTAwMCwiaWF0IjoxNzY2NjQxODUyLCJpc3MiOiJhcGkuZnllcnMuaW4iLCJuYmYiOjE3NjY2NDE4NTIsInN1YiI6ImFjY2Vzc190b2tlbiJ9.oeTJmr1Tz4R3OUnsNqyMjvxGl0-FLjTP8vq9-W-DnlU"

UNDERLYING_SYMBOL = "NSE:NIFTY50-INDEX"
STRIKE_COUNT = 1
POLL_INTERVAL = 30
LOT_SIZE = 75

TRADES_CSV = "paper_trades.csv"
METRICS_CSV = "paper_metrics.csv"
TICKS_CSV = "paper_ticks.csv"

# ======================================================
# FYERS INIT
# ======================================================
def init_fyers():
    print("🔌 Initializing Fyers...")
    fyers = fyersModel.FyersModel(
        client_id=CLIENT_ID,
        token=ACCESS_TOKEN,
        is_async=False,
        log_path=""
    )
    print("✅ Fyers initialized")
    return fyers

# ======================================================
# CSV APPEND
# ======================================================
def append_csv(path, row):
    try:
        df = pd.DataFrame([row])
        header = not os.path.exists(path)
        df.to_csv(path, mode="a", header=header, index=False)
        print(f"📝 CSV append success → {path}")
    except Exception as e:
        print(f"❌ CSV write failed {path}: {e}")

# ======================================================
# FETCH OPTION CHAIN
# ======================================================
def fetch_option_chain(fyers):
    print("📡 Fetching option chain...")
    data = {"symbol": UNDERLYING_SYMBOL, "strikecount": STRIKE_COUNT, "timestamp": ""}
    resp = fyers.optionchain(data=data)
    if resp.get("code") != 200:
        print("❌ Option chain API error:", resp)
        raise RuntimeError("Option chain fetch failed")
    chain = resp["data"]["optionsChain"]
    print(f"✅ Option chain received | records: {len(chain)}")
    return chain

# ======================================================
# BUILD MERGED DF
# ======================================================
def build_merged_df(option_chain):
    print("🧩 Building merged_df...")
    rows = {}
    for opt in option_chain:
        if opt.get("option_type") not in ("CE", "PE"):
            continue
        strike = opt["strike_price"]
        if strike not in rows:
            rows[strike] = {
                "Strike": strike,
                "CE_symbol": None,
                "PE_symbol": None,
                "CE_ltp": None,
                "PE_ltp": None,
                "CE_OI_Change": 0.0,
                "PE_OI_Change": 0.0
            }
        if opt["option_type"] == "CE":
            rows[strike].update({
                "CE_symbol": opt["symbol"],
                "CE_ltp": opt["ltp"],
                "CE_OI_Change": opt.get("oich", 0)
            })
        elif opt["option_type"] == "PE":
            rows[strike].update({
                "PE_symbol": opt["symbol"],
                "PE_ltp": opt["ltp"],
                "PE_OI_Change": opt.get("oich", 0)
            })
    df = pd.DataFrame(rows.values()).sort_values("Strike").reset_index(drop=True)
    print("📊 merged_df snapshot:")
    print(df)
    return df

# ======================================================
# FIND ATM STRIKE
# ======================================================
def find_atm_strike(df):
    print("🎯 Finding ATM strike...")
    df["diff"] = abs(df["CE_ltp"] - df["PE_ltp"])
    atm = df.loc[df["diff"].idxmin(), "Strike"]
    print(f"✅ ATM strike identified: {atm}")
    return atm

# ======================================================
# SIGNAL ENGINE
# ======================================================
def compute_signals(merged_df, atm_strike, session):
    print("🧠 Computing TrendForce...")
    strikes = merged_df["Strike"].tolist()
    idx = strikes.index(atm_strike)
    selected = strikes[max(0, idx - 1): idx + 2]
    print(f"📌 Selected strikes: {selected}")
    df = merged_df[merged_df["Strike"].isin(selected)].copy()
    df["CE_pressure"] = df["CE_ltp"] * df["CE_OI_Change"]
    df["PE_pressure"] = df["PE_ltp"] * df["PE_OI_Change"]
    ce_p = df["CE_pressure"].sum()
    pe_p = df["PE_pressure"].sum()
    denom = abs(ce_p) + abs(pe_p)
    trend_force = (ce_p - pe_p) / denom if denom else 0.0
    if not hasattr(session, "tf_buffer"):
        session.tf_buffer = []
    session.tf_buffer.append(trend_force)
    session.tf_buffer = session.tf_buffer[-3:]
    trend_force = float(np.mean(session.tf_buffer))
    if trend_force > 0.75:
        signal = "BUY"
    elif trend_force < -0.75:
        signal = "SELL"
    else:
        signal = "SIDEWAYS"
    print(f"🔥 TrendForce={trend_force:.4f} | Signal={signal}")
    return signal, trend_force, ce_p, pe_p

# ======================================================
# PAPER TRADE ENGINE
# ======================================================
def paper_trade(signal, merged_df, atm_strike, trend_force, session):
    now = datetime.now()
    if not hasattr(session, "position"):
        session.position = None
        session.trades = []
        session.equity = 0.0
    atm_row = merged_df[merged_df["Strike"] == atm_strike].iloc[0]

    # 1️⃣ EXIT LOGIC
    if session.position:
        pos = session.position
        symbol = pos["symbol"]
        exit_trade = False
        exit_price = 0.0
        # CE SL
        if symbol.endswith("CE") and trend_force < 0.5:
            exit_price = atm_row["CE_ltp"]
            exit_trade = True
        # PE SL
        elif symbol.endswith("PE") and trend_force > -0.5:
            exit_price = atm_row["PE_ltp"]
            exit_trade = True
        if exit_trade:
            pnl = (exit_price - pos["entry_price"]) * LOT_SIZE
            session.equity += pnl
            print(f"🚪 EXIT {symbol} | Exit Price={exit_price} | PnL={pnl:.2f} | Equity={session.equity:.2f}")
            trade = {
                "entry_time": pos["entry_time"],
                "exit_time": now,
                "symbol": symbol,
                "entry_price": pos["entry_price"],
                "exit_price": exit_price,
                "pnl": pnl,
                "trend_force_entry": pos["tf_entry"],
                "trend_force_exit": trend_force,
                "equity_after_trade": session.equity
            }
            session.trades.append(trade)
            append_csv(TRADES_CSV, trade)
            session.position = None
            return

    # 2️⃣ ENTRY LOGIC (NO DUPLICATE)
    if session.position is None:
        if trend_force > 0.75:
            session.position = {
                "symbol": atm_row["CE_symbol"],
                "entry_price": atm_row["CE_ltp"],
                "entry_time": now,
                "tf_entry": trend_force
            }
            print(f"🟢 ENTRY BUY → {atm_row['CE_symbol']} @ {atm_row['CE_ltp']}")
        elif trend_force < -0.75:
            session.position = {
                "symbol": atm_row["PE_symbol"],
                "entry_price": atm_row["PE_ltp"],
                "entry_time": now,
                "tf_entry": trend_force
            }
            print(f"🔴 ENTRY SELL → {atm_row['PE_symbol']} @ {atm_row['PE_ltp']}")
        else:
            print("⏸ No entry — TrendForce not strong enough")

# ======================================================
# METRICS
# ======================================================
def compute_metrics(session):
    if not session.trades:
        print("📉 No trades yet — metrics skipped")
        return
    df = pd.DataFrame(session.trades)
    wins = df[df.pnl > 0]
    losses = df[df.pnl < 0]
    metrics = {
        "timestamp": datetime.now(),
        "total_trades": len(df),
        "win_rate": len(wins) / len(df),
        "avg_win": wins.pnl.mean() if not wins.empty else 0,
        "avg_loss": losses.pnl.mean() if not losses.empty else 0,
        "net_pnl": df.pnl.sum(),
        "equity": session.equity
    }
    print("📊 Metrics snapshot:", metrics)
    append_csv(METRICS_CSV, metrics)

# ======================================================
# MAIN LOOP
# ======================================================
def main():
    fyers = init_fyers()
    session = type("Session", (), {})()
    print("🚀 Paper trading started")
    while True:
        try:
            option_chain = fetch_option_chain(fyers)
            merged_df = build_merged_df(option_chain)
            atm_strike = find_atm_strike(merged_df)
            signal, tf, ce_p, pe_p = compute_signals(merged_df, atm_strike, session)
            paper_trade(signal, merged_df, atm_strike, tf, session)
            append_csv(TICKS_CSV, {
                "timestamp": datetime.now(),
                "atm_strike": atm_strike,
                "signal": signal,
                "trend_force": tf,
                "ce_pressure": ce_p,
                "pe_pressure": pe_p,
                "equity": getattr(session, "equity", 0)
            })
            compute_metrics(session)
            time.sleep(POLL_INTERVAL)
        except Exception as e:
            print(f"❌ LOOP ERROR: {e}")
            time.sleep(5)

# ======================================================
# ENTRY POINT
# ======================================================
if __name__ == "__main__":
    main()
