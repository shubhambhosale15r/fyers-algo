import pandas as pd
import numpy as np
import time
import os
from datetime import datetime
from fyers_apiv3 import fyersModel

# =========================
# CONFIG
# =========================
CLIENT_ID = "0F5WWD1SBL-100"
ACCESS_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOlsiZDoxIiwiZDoyIiwieDowIiwieDoxIiwieDoyIl0sImF0X2hhc2giOiJnQUFBQUFCcFVmN2JrOERKQ3pabzBhMGZSOU5mcE1uSFMyMmtQYnNpREVwbHZWZ3BqYUR0TG9lV2RWVlJIWEVETlBiZ1ZoaUx2djVHUTZfa09NeUM3WGtWazhwcjB1dGRfcjZjWkl2b05yQWVQdUVwV1BWcGcwRT0iLCJkaXNwbGF5X25hbWUiOiIiLCJvbXMiOiJLMSIsImhzbV9rZXkiOiI3MjcwYzY1YTdkY2ExYzAxZDNjOTg3NjRmZmViNjAyOWRiY2Y5ODUyMmMzNGViMzRjYTUxYTAwZSIsImlzRGRwaUVuYWJsZWQiOiJOIiwiaXNNdGZFbmFibGVkIjoiTiIsImZ5X2lkIjoiRkFBMzE0OTUiLCJhcHBUeXBlIjoxMDAsImV4cCI6MTc2NzA1NDYwMCwiaWF0IjoxNzY2OTgxMzM5LCJpc3MiOiJhcGkuZnllcnMuaW4iLCJuYmYiOjE3NjY5ODEzMzksInN1YiI6ImFjY2Vzc190b2tlbiJ9.EWZQhMxyPwjg_9ltnTvQ-sH9Pn8KQ_YQsP6EeuWmGS0"

UNDERLYING_SYMBOL = "NSE:NIFTY50-INDEX"
STRIKE_NEIGHBOR = 1
TOP_K = 1
POLL_INTERVAL = 60
LOT_SIZE = 75
ROLLING_WINDOW = 30

TRADES_CSV = "paper_trades.csv"
TICKS_CSV = "paper_ticks.csv"
TOPK_CSV = "topk_options.csv"
UNIVERSE_CSV = "universe_options.csv"

# =========================
# DEBUG
# =========================
def dbg(msg):
    print(f"[DEBUG] {datetime.now().strftime('%H:%M:%S')} | {msg}")

# =========================
# FYERS INIT
# =========================
def init_fyers():
    dbg("Initializing Fyers API...")
    fyers = fyersModel.FyersModel(
        client_id=CLIENT_ID,
        token=ACCESS_TOKEN,
        is_async=False,
        log_path=""
    )
    dbg("Fyers initialized")
    return fyers

# =========================
# HELPERS
# =========================
def get_ltp(fyers, symbol):
    try:
        return float(fyers.quotes({"symbols": symbol})["d"][0]["v"]["lp"])
    except:
        return None

# =========================
# FETCH HISTORY
# =========================
def fetch_history(fyers, symbol):
    today = datetime.now().strftime("%Y-%m-%d")
    data = {
        "symbol": symbol,
        "resolution": "1",
        "date_format": 1,
        "range_from": today,
        "range_to": today,
        "cont_flag": 1
    }
    resp = fyers.history(data=data)
    if resp.get("s") != "ok" or not resp.get("candles"):
        dbg(f"History FAILED for {symbol}")
        return None

    return pd.DataFrame(
        resp["candles"],
        columns=["epoch", "open", "high", "low", "close", "volume"]
    )

# =========================
# COMPUTE SCORE
# =========================
def compute_score(df, label):
    closes = df["close"]

    if len(closes) < 32:
        dbg(f"{label} skipped (insufficient data)")
        return None

    # LAST CLOSED candle only
    R3  = closes.iloc[-2] / closes.iloc[-5]  - 1
    R10 = closes.iloc[-2] / closes.iloc[-12] - 1
    R30 = closes.iloc[-2] / closes.iloc[-32] - 1

    M = (R3 + R10 + R30) / 3
    sigma = closes.pct_change().rolling(ROLLING_WINDOW).std().iloc[-1]
    score = M / sigma if sigma and sigma > 0 else 0.0

    dbg(
        f"{label} | R3={R3:.5f} R10={R10:.5f} R30={R30:.5f} "
        f"M={M:.5f} σ={sigma:.5f} score={score:.5f}"
    )

    return {
        "R3": R3,
        "R10": R10,
        "R30": R30,
        "M": M,
        "score": score
    }

# =========================
# COMPUTE TOP-K
# =========================
def compute_topk_options(fyers, option_chain, underlying_price):

    # ----- UNDERLYING -----
    udf = fetch_history(fyers, UNDERLYING_SYMBOL)
    if udf is None:
        return [], None, 0.0

    u = compute_score(udf, "UNDERLYING")
    if u is None:
        return [], None, 0.0

    underlying_score = u["score"]
    dbg(f"Underlying score locked = {underlying_score:.5f}")

    # ----- STRIKES -----
    strikes = sorted({o["strike_price"] for o in option_chain if o["strike_price"] > 0})
    atm = min(strikes, key=lambda s: abs(s - underlying_price))
    idx = strikes.index(atm)
    selected = strikes[max(0, idx-1): idx+2]

    dbg(f"ATM={atm} | strikes={selected}")

    universe = [o for o in option_chain if o["strike_price"] in selected]
    dbg(f"Universe size={len(universe)}")

    winners = []
    universe_log = []

    for opt in universe:
        sym = opt["symbol"]
        df = fetch_history(fyers, sym)
        if df is None:
            continue

        s = compute_score(df, sym)
        if s is None:
            continue

        universe_log.append({
            "timestamp": datetime.now(),
            "symbol": sym,
            "strike": opt["strike_price"],
            "type": opt["option_type"],
            **s
        })

        dbg(
            f"COMPARE {sym} | option={s['score']:.2f} "
            f"vs underlying={underlying_score:.2f}"
        )

        if s["score"] > underlying_score and s["M"] > 0:
            winners.append({"symbol": sym, **s})
        else:
            dbg(f"REJECT {sym}")

    pd.DataFrame(universe_log).to_csv(
        UNIVERSE_CSV,
        mode="a",
        header=not os.path.exists(UNIVERSE_CSV),
        index=False
    )

    winners = sorted(winners, key=lambda x: x["score"], reverse=True)
    topk = winners[:TOP_K]

    if topk:
        pd.DataFrame(topk).assign(timestamp=datetime.now()).to_csv(
            TOPK_CSV,
            mode="a",
            header=not os.path.exists(TOPK_CSV),
            index=False
        )

    dbg(f"Outperformers={len(winners)} | TopK={[o['symbol'] for o in topk]}")
    return topk, atm, underlying_score

# =========================
# PAPER TRADE (DOMINANCE ONLY)
# =========================
def paper_trade(fyers, session, topk, underlying_score):

    now = datetime.now()

    # ---------- EXIT ----------
    if session.position:
        sym = session.position["symbol"]

        still_dominant = any(o["symbol"] == sym for o in topk)

        if not still_dominant:
            exit_price = get_ltp(fyers, sym)
            if exit_price is not None:
                pnl = (exit_price - session.position["entry_price"]) * LOT_SIZE
                session.equity += pnl

                dbg(f"EXIT {sym} | exit={exit_price:.2f} pnl={pnl:.2f}")

                pd.DataFrame([{
                    "symbol": sym,
                    "entry_price": session.position["entry_price"],
                    "exit_price": exit_price,
                    "pnl": pnl,
                    "entry_time": session.position["time"],
                    "exit_time": now
                }]).to_csv(
                    TRADES_CSV,
                    mode="a",
                    header=not os.path.exists(TRADES_CSV),
                    index=False
                )

            session.position = None

    # ---------- ENTRY ----------
    if not session.position and topk:
        o = topk[0]
        entry_price = get_ltp(fyers, o["symbol"])

        if entry_price is not None:
            session.position = {
                "symbol": o["symbol"],
                "entry_price": entry_price,
                "time": now
            }
            dbg(f"ENTER {o['symbol']} @ {entry_price:.2f}")

    # ---------- TICK LOG ----------
    unrealized = 0.0
    if session.position:
        ltp = get_ltp(fyers, session.position["symbol"])
        if ltp:
            unrealized = (ltp - session.position["entry_price"]) * LOT_SIZE

    pd.DataFrame([{
        "timestamp": now,
        "symbol": session.position["symbol"] if session.position else None,
        "equity": session.equity,
        "unrealized_pnl": unrealized,
        "net_pnl": session.equity + unrealized
    }]).to_csv(
        TICKS_CSV,
        mode="a",
        header=not os.path.exists(TICKS_CSV),
        index=False
    )

# =========================
# MAIN LOOP
# =========================
def main():
    fyers = init_fyers()

    session = type("Session", (), {})()
    session.position = None
    session.equity = 0.0

    dbg("🚀 Strategy started")

    while True:
        try:
            lp = get_ltp(fyers, UNDERLYING_SYMBOL)

            chain = fyers.optionchain({
                "symbol": UNDERLYING_SYMBOL,
                "strikecount": STRIKE_NEIGHBOR
            })["data"]["optionsChain"]

            topk, atm, uscore = compute_topk_options(fyers, chain, lp)
            paper_trade(fyers, session, topk, uscore)

            time.sleep(POLL_INTERVAL)

        except Exception as e:
            dbg(f"LOOP ERROR {repr(e)}")
            time.sleep(5)

if __name__ == "__main__":
    main()
