import time
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import pytz
from fyers_apiv3 import fyersModel
import logging
import os
import json
from collections import deque
import csv

# ============================================================
# CONFIGURATION
# ============================================================
class Config:
    REFRESH_INTERVAL = 60
    API_RATE_LIMIT = 200
    API_WINDOW = 60
    LOT_SIZE = 65
    MAX_RETRIES = 3
    RETRY_DELAY = 2
    MAX_DAILY_ORDERS = 8
    ROLLING_WINDOW_SIZE = 15
    TRAIL_STOP_PCT = 0.5          # trailing stop on cumulative idwp

# ============================================================
# LOGGING
# ============================================================
logging.basicConfig(
    filename="trading_app.log",
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)

# Helper to print + log debug messages
def debug_msg(msg):
    print(f"[DEBUG] {msg}")
    logging.debug(msg)

IST = pytz.timezone("Asia/Kolkata")

def now_ist():
    return datetime.now(IST)

def timestamp_ist():
    return now_ist().strftime("%Y-%m-%d %H:%M:%S")

def is_market_open():
    return True   # override for live

# ============================================================
# ERROR HANDLER
# ============================================================
def handle_errors(func):
    def wrapper(*args, **kwargs):
        retries = 0
        while retries < Config.MAX_RETRIES:
            try:
                return func(*args, **kwargs)
            except Exception as e:
                retries += 1
                debug_msg(f"{func.__name__} attempt {retries} failed: {e}")
                if retries < Config.MAX_RETRIES:
                    time.sleep(Config.RETRY_DELAY)
                else:
                    debug_msg(f"{func.__name__} permanently failed after {retries} retries")
                    return None
        return None
    return wrapper

# ============================================================
# HELPER FUNCTIONS
# ============================================================
def get_next_aligned_time(interval_seconds):
    now = now_ist()
    current_seconds = (now - now.replace(hour=0, minute=0, second=0, microsecond=0)).total_seconds()
    intervals_passed = current_seconds // interval_seconds
    next_aligned_seconds = (intervals_passed + 1) * interval_seconds
    next_time = now.replace(hour=0, minute=0, second=0, microsecond=0) + timedelta(seconds=next_aligned_seconds)
    return next_time

def wait_until_next_interval(interval_seconds):
    next_time = get_next_aligned_time(interval_seconds)
    wait_seconds = (next_time - now_ist()).total_seconds()
    if wait_seconds > 0:
        debug_msg(f"Next update at {next_time.strftime('%H:%M:%S')} (waiting {wait_seconds:.1f}s)")
        time.sleep(wait_seconds)
    else:
        debug_msg("No wait needed – immediate update")

# ============================================================
# DATA LOGGER (full cumulative columns)
# ============================================================
class DataLogger:
    def __init__(self, filename="trading_data.csv"):
        self.filename = filename
        self._ensure_header()

    def _ensure_header(self):
        try:
            with open(self.filename, 'r'):
                pass
        except FileNotFoundError:
            with open(self.filename, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'timestamp', 'underlying_ltp', 'fut_price', 'signal', 'atm_strike',
                    'expiry_date', 'idwp', 'inof', 'cumul_idwp', 'cumul_inof', 'position'
                ])
            debug_msg(f"Created new data log file: {self.filename}")

    def log_data(self, timestamp, underlying_ltp,fut_price, signal, atm_strike,
                 expiry_date, idwp, inof, cumul_idwp, cumul_inof, position):
        with open(self.filename, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                str(timestamp),
                float(underlying_ltp) if underlying_ltp is not None else 0.0,
                float(fut_price) if fut_price is not None else 0.0,
                str(signal),
                int(atm_strike) if atm_strike is not None else 0,
                str(expiry_date),
                round(float(idwp), 2),
                round(float(inof), 2),
                round(float(cumul_idwp), 2),
                round(float(cumul_inof), 2),
                str(position)
            ])
        debug_msg(f"Logged row: signal={signal}, ltp={underlying_ltp}, cumul_idwp={cumul_idwp}, pos={position}")

    def read_data(self, limit=None):
        try:
            df = pd.read_csv(self.filename)
            if limit:
                return df.tail(limit)
            return df
        except:
            return pd.DataFrame()

# ============================================================
# DASHBOARD (simplified)
# ============================================================
class TerminalDashboard:
    def __init__(self, data_logger, session_state=None):
        self.data_logger = data_logger
        self.session_state = session_state

    def display_live_dashboard(self):
        try:
            os.system('cls' if os.name == 'nt' else 'clear')
            df = self.data_logger.read_data(limit=20)
            print("\n" + "=" * 100)
            print("📊 LIVE TRADING DASHBOARD")
            print("=" * 100)
            print(f"Last Update: {timestamp_ist()}")
            if self.session_state:
                print(f"📈 DAILY ORDER COUNT: {self.session_state.daily_executed_orders}/{Config.MAX_DAILY_ORDERS}")
            if df.empty:
                print("🔄 Waiting for trading data...")
                return
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            df = df.sort_values('timestamp')
            latest = df.iloc[-1]
            print(f"\n📈 CURRENT STATUS:")
            print(f"   Nifty LTP: {latest.get('underlying_ltp', 0)}")
            print(f"   Signal: {latest.get('signal', '')}")
            print(f"   ATM Strike: {latest.get('atm_strike', '')}")
            print(f"   idwp: {latest.get('idwp', '')} | inof: {latest.get('inof', '')}")
            print(f"   Cumul idwp: {latest.get('cumul_idwp', '')} | Cumul inof: {latest.get('cumul_inof', '')}")
            print(f"   Position: {latest.get('position', '')}")

            if self.session_state:
                pos = self.session_state.position
                if pos == "LONG":
                    peak = self.session_state.peak_cumul_idwp
                    thresh = peak * (1 - Config.TRAIL_STOP_PCT)
                    print(f"   📈 LONG: peak cumul={peak:.2f}, exit below {thresh:.2f}")
                elif pos == "SHORT":
                    trough = self.session_state.trough_cumul_idwp
                    thresh = trough * (1 - Config.TRAIL_STOP_PCT)
                    print(f"   📉 SHORT: trough cumul={trough:.2f}, exit above {thresh:.2f}")
                else:
                    print(f"   💤 No active position")

            print(f"\n🔄 RECENT SIGNALS (Last 5):")
            for _, row in df.tail(5).iterrows():
                color = {'BUY': '🟢', 'SELL': '🔴', 'EXIT': '🟡', 'HOLD': '⚪'}.get(row['signal'], '⚪')
                print(f"   {row['timestamp'].strftime('%H:%M:%S')} - {color} {row['signal']} - LTP: {row['underlying_ltp']}")
            print("\n" + "=" * 100)
        except Exception as e:
            print(f"[ERROR] Dashboard error: {e}")
            debug_msg(f"Dashboard exception: {e}")

# ============================================================
# SESSION STATE
# ============================================================
class SessionState:
    def __init__(self):
        self.option_chain_api_count = 0
        self.quote_api_count = 0
        self.api_window_start = now_ist()
        self.last_signal = None
        self.cid = ""
        self.token = ""
        self._hb_lock = False
        self.daily_executed_orders = 0
        self.last_order_sync = None

        # Rolling buffers
        self.idwp_window = deque(maxlen=Config.ROLLING_WINDOW_SIZE)
        self.inof_window = deque(maxlen=Config.ROLLING_WINDOW_SIZE)
        self.window_filled = False

        # Position and trailing stop on cumulative idwp
        self.position = "FLAT"
        self.peak_cumul_idwp = 0.0
        self.trough_cumul_idwp = 0.0

        # For storing prev cumulative values for entry trigger
        self.prev_cumul_idwp = 0.0
        self.prev_cumul_inof = 0.0

    def sync_order_count_with_fyers(self, fyers):
        today = now_ist().date()
        if self.last_order_sync != today:
            self.daily_executed_orders = 0
            self.last_order_sync = today
            debug_msg("New trading day, reset daily order count")
        try:
            resp = fyers.orderbook()
            if resp.get("s") == "ok":
                self.daily_executed_orders = len([o for o in resp.get("orderBook", []) if o.get("status") == 2])
            debug_msg(f"Synced daily executed orders: {self.daily_executed_orders}")
        except Exception as e:
            debug_msg(f"Order sync failed: {e}")

    def can_place_order(self, fyers=None):
        if fyers:
            self.sync_order_count_with_fyers(fyers)
        allowed = self.daily_executed_orders < Config.MAX_DAILY_ORDERS
        debug_msg(f"Order placement allowed: {allowed} ({self.daily_executed_orders}/{Config.MAX_DAILY_ORDERS})")
        return allowed

# ============================================================
# CREDENTIALS
# ============================================================
def load_credentials(session_state):
    try:
        with open('fyers_credentials.json', 'r') as f:
            creds = json.load(f)
            session_state.cid = creds.get('client_id', '')
            session_state.token = creds.get('access_token', '')
        debug_msg("Loaded credentials from file")
    except:
        session_state.cid = os.getenv("FYERS_CID", session_state.cid)
        session_state.token = os.getenv("FYERS_TOKEN", session_state.token)
        debug_msg("File load failed, using environment variables")

# ============================================================
# API FUNCTIONS
# ============================================================
def enforce_rate_limit(session_state):
    now = now_ist()
    window = now - session_state.api_window_start
    total_calls = session_state.option_chain_api_count + session_state.quote_api_count
    if window.total_seconds() > Config.API_WINDOW:
        debug_msg("Rate-limit window expired, resetting counters")
        session_state.api_window_start = now
        session_state.option_chain_api_count = 0
        session_state.quote_api_count = 0
    elif total_calls >= Config.API_RATE_LIMIT:
        wait = Config.API_WINDOW - int(window.total_seconds())
        if wait > 0:
            debug_msg(f"Rate-limit reached, waiting {wait}s")
            time.sleep(wait)
        session_state.api_window_start = now
        session_state.option_chain_api_count = 0
        session_state.quote_api_count = 0
    else:
        debug_msg(f"Rate-limit OK: {total_calls}/{Config.API_RATE_LIMIT} calls in window")

@handle_errors
def get_underlying_ltp(session_state, cid, token, sym):
    enforce_rate_limit(session_state)
    session_state.quote_api_count += 1
    debug_msg(f"Fetching LTP for {sym}")
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    resp = fy.quotes(data={"symbols": sym})
    if not resp or resp.get("code") != 200 or not resp.get("d"):
        debug_msg(f"LTP response invalid: {resp}")   # full response logged
        return None
    ltp = resp["d"][0]["v"]["lp"]
    debug_msg(f"Underlying LTP = {ltp}")
    return ltp

@handle_errors
def get_option_chain_data(session_state, cid, token, sym, expiry_ts=""):
    enforce_rate_limit(session_state)
    session_state.option_chain_api_count += 1
    debug_msg(f"Fetching option chain for {sym} expiry_ts='{expiry_ts}'")
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    payload = {
        "symbol": sym,
        "strikecount": 5,
        "timestamp": expiry_ts,
        "greeks": "1"
    }
    resp = fy.optionchain(data=payload)
    if not resp or resp.get("code") != 200:
        debug_msg(f"Option chain response invalid: {resp}")   # full response logged
        return None
    chain_len = len(resp["data"]["optionsChain"])
    debug_msg(f"Option chain received: {chain_len} entries")
    return resp["data"]["optionsChain"]

@handle_errors
def update_all_data(session_state, cid, token, sym):
    debug_msg("update_all_data: starting combined fetch")
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    enforce_rate_limit(session_state)
    session_state.option_chain_api_count += 1
    meta = fy.optionchain(data={"symbol": sym, "timestamp": ""})
    if meta.get("code") != 200:
        debug_msg(f"Meta option chain fetch failed, response: {meta}")
        return None, None, None, None   # extra None for futures price

    # --- Extract futures price (fp) from the optionsChain ---
    fut_price = None
    options_chain = meta.get("data", {}).get("optionsChain", [])
    debug_msg(f"Searching optionsChain for underlying entry (option_type='') to get fp")
    for item in options_chain:
        if item.get("option_type") == "":   # this is the underlying contract
            fut_price = item.get("fp")
            if fut_price is not None:
                debug_msg(f"Found fp = {fut_price} in underlying contract entry")
                break
    if fut_price is None:
        # fallback (rare, but keep)
        fut_price = meta.get("data", {}).get("fp", None)
        if fut_price is not None:
            debug_msg(f"Using top-level fp: {fut_price}")
    if fut_price is None:
        debug_msg("Warning: fp (futures price) not found, setting to 0.0")
        fut_price = 0.0

    # Expiry logic (unchanged)
    exp = sorted([(e["date"], e.get("expiry")) for e in meta["data"]["expiryData"]],
                 key=lambda x: datetime.strptime(x[0], "%d-%m-%Y"))
    today = now_ist().date()
    dates = [datetime.strptime(d, "%d-%m-%Y").date() for d,_ in exp]
    idx = next((i for i,d in enumerate(dates) if d >= today), 0)
    curr_date, curr_ts = exp[idx]
    debug_msg(f"Current expiry: {curr_date} (ts={curr_ts})")

    ltp = get_underlying_ltp(session_state, cid, token, sym)
    chain = get_option_chain_data(session_state, cid, token, sym, expiry_ts=curr_ts)
    debug_msg(f"update_all_data: LTP={ltp}, Futures={fut_price}, chain size={len(chain) if chain else 'None'}")
    return ltp, chain, curr_date, fut_price

# ============================================================
# SIGNAL COMPUTATION (simple directional based on cumulative)
# ============================================================
def compute_signals(merged_df, atm_strike, ltp, fut_price, session_state):
    debug_msg(f"Computing signals: atm_strike={atm_strike}, ltp={ltp}, position={session_state.position}")
    if merged_df is None or merged_df.empty:
        debug_msg("merged_df is empty, returning HOLD")
        return "HOLD", {}, "FLAT"

    available_strikes = sorted(merged_df["strike"].unique())
    debug_msg(f"Available strikes: {available_strikes}")
    if atm_strike not in available_strikes:
        debug_msg("ATM strike not in chain, returning HOLD")
        return "HOLD", {}, "FLAT"
    atm_idx = available_strikes.index(atm_strike)
    selected = [atm_strike]
    if atm_idx > 0:
        selected.append(available_strikes[atm_idx-1])
    if atm_idx < len(available_strikes)-1:
        selected.append(available_strikes[atm_idx+1])
    debug_msg(f"Selected strikes for signal: {selected}")

    idwps, inofs = [], []
    for strike in selected:
        rows = merged_df[merged_df["strike"] == strike]
        ce = rows[rows["option_type"] == "CE"]
        pe = rows[rows["option_type"] == "PE"]
        if ce.empty or pe.empty:
            debug_msg(f"Strike {strike} missing CE/PE data, skipping")
            continue
        ce = ce.iloc[0]
        pe = pe.iloc[0]
        ce_ltp = float(ce.get("ltp", 0))
        pe_ltp = float(pe.get("ltp", 0))
        # ------ NEW: put-call parity based trend value ------
        parity = (ce_ltp - pe_ltp) - (ltp - strike)
        idwps.append(parity)   # <--- idwp now holds parity
        # inof calculation remains unchanged (needs delta and volume)
        ce_delta = float(ce.get("delta", 0))
        pe_delta = abs(float(pe.get("delta", 0)))
        ce_vol = float(ce.get("volume", 0))
        pe_vol = float(pe.get("volume", 0))
        inofs.append((ce_vol * ce_delta) - (pe_vol * pe_delta))
        debug_msg(f"Strike {strike}: CE ltp={ce_ltp}, PE ltp={pe_ltp}, Spot={ltp}, Futures={fut_price} -> parity={parity:.2f}, "
                  f"inof={inofs[-1]:.2f}")

    if not idwps or not inofs:
        debug_msg("No valid parity/inof computed, returning HOLD")
        return "HOLD", {}, session_state.position

    idwp = sum(idwps) / len(idwps)
    inof = sum(inofs) / len(inofs)
    debug_msg(f"Averaged parity = {idwp:.2f}, inof = {inof:.2f}")

    # Update rolling windows
    session_state.idwp_window.append(idwp)
    session_state.inof_window.append(inof)
    debug_msg(f"Window sizes: idwp={len(session_state.idwp_window)}, inof={len(session_state.inof_window)}")

    # Warm-up
    if not session_state.window_filled:
        if len(session_state.inof_window) < Config.ROLLING_WINDOW_SIZE:
            debug_msg(f"Warm-up: {len(session_state.inof_window)}/{Config.ROLLING_WINDOW_SIZE}")
            metrics = {"idwp": idwp, "inof": inof, "cumul_idwp": 0.0, "cumul_inof": 0.0}
            return "HOLD", metrics, session_state.position
        else:
            session_state.window_filled = True
            debug_msg("Warm-up complete, window now filled")

    # Compute EMA from the same window (for signals)
    # EMA is calculated from scratch using the full window (15 values)
    alpha = 2 / (Config.ROLLING_WINDOW_SIZE + 1)   # e.g., 2/16 = 0.125
    # EMA for idwp
    idwp_list = list(session_state.idwp_window)
    ema_idwp = idwp_list[0]
    for val in idwp_list[1:]:
        ema_idwp = alpha * val + (1 - alpha) * ema_idwp
    # EMA for inof
    inof_list = list(session_state.inof_window)
    ema_inof = inof_list[0]
    for val in inof_list[1:]:
        ema_inof = alpha * val + (1 - alpha) * ema_inof

    # Compute cumulative sums
    cumul_idwp = ema_idwp
    cumul_inof = ema_inof
    avg_raw_idwp = sum(session_state.idwp_window) / len(session_state.idwp_window)
    debug_msg(f"Cumulative values: cumul_idwp={cumul_idwp:.2f}, cumul_inof={cumul_inof:.2f}, avg_raw_idwp={avg_raw_idwp:.2f}")

    signal = "HOLD"

    # --- EXIT based on cumulative idwp (now cumulative parity) ---
    if session_state.position == "LONG":
        old_peak = session_state.peak_cumul_idwp
        if cumul_idwp > session_state.peak_cumul_idwp:
            session_state.peak_cumul_idwp = cumul_idwp
            debug_msg(f"LONG: new peak {session_state.peak_cumul_idwp}")
        exit_threshold = session_state.peak_cumul_idwp * (1 - Config.TRAIL_STOP_PCT)
        debug_msg(f"LONG exit check: cumul={cumul_idwp:.2f}, peak={session_state.peak_cumul_idwp}, "
                  f"threshold={exit_threshold:.2f}")
        if cumul_idwp < exit_threshold:
            signal = "EXIT"
            session_state.position = "FLAT"
            session_state.peak_cumul_idwp = 0.0
            debug_msg("LONG EXIT triggered")
    elif session_state.position == "SHORT":
        old_trough = session_state.trough_cumul_idwp
        if cumul_idwp < session_state.trough_cumul_idwp:
            session_state.trough_cumul_idwp = cumul_idwp
            debug_msg(f"SHORT: new trough {session_state.trough_cumul_idwp}")
        exit_threshold = session_state.trough_cumul_idwp * (1 - Config.TRAIL_STOP_PCT)
        debug_msg(f"SHORT exit check: cumul={cumul_idwp:.2f}, trough={session_state.trough_cumul_idwp}, "
                  f"threshold={exit_threshold:.2f}")
        if cumul_idwp > exit_threshold:
            signal = "EXIT"
            session_state.position = "FLAT"
            session_state.trough_cumul_idwp = 0.0
            debug_msg("SHORT EXIT triggered")

    # --- ENTRY (only if FLAT) ---
    if session_state.position == "FLAT" and signal != "EXIT":
        
        # Determine previous alignment
        prev_both_pos = (session_state.prev_cumul_idwp > 0 and session_state.prev_cumul_inof > 0)
        prev_both_neg = (session_state.prev_cumul_idwp < 0 and session_state.prev_cumul_inof < 0)

        # Current alignment
        curr_both_pos = (cumul_idwp > 0 and cumul_inof > 0)
        curr_both_neg = (cumul_idwp < 0 and cumul_inof < 0)

        # Compute rolling standard deviation of raw idwp and inof (over the current window)
        if len(session_state.idwp_window) >= 15:
            std_raw_idwp = np.std(list(session_state.idwp_window))
            min_strength_idwp = 1.5 * std_raw_idwp   # adaptive threshold
        else:
            std_raw_idwp = 0.0
            min_strength_idwp = 0.0

        if len(session_state.inof_window) >= 15:
            std_raw_inof = np.std(list(session_state.inof_window))
            min_strength_inof = 1.5 * std_raw_inof
        else:
            std_raw_inof = 0.0
            min_strength_inof = 0.0
        
        debug_msg(f"FLAT entry check: cumul_idwp={cumul_idwp:.2f}, cumul_inof={cumul_inof:.2f}, min_strength_idwp={min_strength_idwp:.2f}, min_strength_inof={min_strength_inof:.2f}")

        # Entry only on transition
        if (curr_both_pos and not prev_both_pos
            and cumul_inof > 0 
            and cumul_idwp > 0
            and abs(cumul_idwp) > min_strength_idwp 
            and abs(cumul_inof) > min_strength_inof
            ):
            signal = "BUY"
            session_state.position = "LONG"
            session_state.peak_cumul_idwp = cumul_idwp
            debug_msg("LONG entry triggered (transition from non-aligned to both positive)")
        elif (curr_both_neg and not prev_both_neg 
            and cumul_inof < 0 
            and cumul_idwp < 0
            and abs(cumul_idwp) > min_strength_idwp 
            and abs(cumul_inof) > min_strength_inof
              ):
            signal = "SELL"
            session_state.position = "SHORT"
            session_state.trough_cumul_idwp = cumul_idwp
            debug_msg("SHORT entry triggered (transition from non-aligned to both negative)")

    metrics = {
        "atm_strike": atm_strike,
        "spot": ltp,
        "idwp": idwp,
        "inof": inof,
        "cumul_idwp": cumul_idwp,
        "cumul_inof": cumul_inof
    }

    # Update previous values
    session_state.prev_cumul_idwp = cumul_idwp
    session_state.prev_cumul_inof = cumul_inof
    debug_msg(f"Final signal: {signal}, position: {session_state.position}, metrics: {metrics}")
    return signal, metrics, session_state.position

# ============================================================
# STRIKE SELECTION (only ATM for directional)
# ============================================================
def select_atm_option(chain, atm_strike, option_type):
    """Return the option dict for given strike and type ('CE' or 'PE')"""
    try:
        df = pd.DataFrame(chain)
        if df.empty:
            debug_msg(f"select_atm_option: empty chain for {option_type}")
            return None
        opt = df[(df["strike_price"] == atm_strike) & (df["option_type"] == option_type)]
        if opt.empty:
            debug_msg(f"select_atm_option: no {option_type} at strike {atm_strike}")
            return None
        chosen = opt.iloc[0].to_dict()
        debug_msg(f"Selected {option_type} option: symbol={chosen.get('symbol')}, ltp={chosen.get('ltp')}")
        return chosen
    except Exception as e:
        debug_msg(f"select_atm_option error: {e}")
        return None

# ============================================================
# ORDER MANAGEMENT (simple directional)
# ============================================================
def place_order(session_state, signal, atm_ce, atm_pe, fyers):
    if getattr(session_state, '_hb_lock', False):
        debug_msg("Order locked (heartbeat), skipping")
        return False
    session_state._hb_lock = True
    try:
        lot = Config.LOT_SIZE
        debug_msg(f"place_order called with signal={signal}, CE exists={atm_ce is not None}, PE exists={atm_pe is not None}")
        if signal == "EXIT":
            debug_msg("Exiting all positions")
            fyers.exit_positions(data={"segment": [11], "side": [-1], "productType": ["MARGIN"]})
            fyers.exit_positions(data={"segment": [11], "side": [1], "productType": ["MARGIN"]})
            time.sleep(2)
            session_state.last_signal = signal
            debug_msg("Exit positions placed")
            return True
        if signal in ("BUY", "SELL") and session_state.can_place_order(fyers):
            leg = atm_ce if signal == "BUY" else atm_pe
            if not leg:
                debug_msg(f"No leg found for signal {signal}")
                return False
            order = {
                "symbol": leg["symbol"],
                "qty": lot,
                "type": 2,
                "side": 1,
                "productType": "MARGIN",
                "validity": "DAY",
            }
            debug_msg(f"Placing order: {order}")
            resp = fyers.place_order(data=order)
            debug_msg(f"Order response: {resp}")
            if resp.get("s") == "ok":
                session_state.last_signal = signal
                debug_msg("Order placed successfully")
                return True
            else:
                debug_msg(f"Order failed: {resp.get('message')}")
        return False
    except Exception as e:
        debug_msg(f"Order error: {e}")
        return False
    finally:
        session_state._hb_lock = False

# ============================================================
# MAIN
# ============================================================
def main():
    session_state = SessionState()
    load_credentials(session_state)
    data_logger = DataLogger()
    dashboard = TerminalDashboard(data_logger, session_state)
    sym = 'NSE:NIFTY50-INDEX'

    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        print("="*50)
        print("📈 FYERS ALGO TRADING")
        print("1. Start Live Trading")
        print("2. Settings")
        print("3. Exit")
        choice = input("Select option: ").strip()
        if choice == "1":
            if not (session_state.cid and session_state.token):
                print("❌ Set credentials first")
                input("Press Enter...")
                continue
            auto_trade = input("Enable Auto Trade? (y/n): ").lower() == 'y'
            debug_msg(f"Auto trade enabled: {auto_trade}")
            if not auto_trade:
                continue
            print("Starting live trading loop...")
            try:
                while True:
                    debug_msg("=== NEW ITERATION ===")
                    dashboard.display_live_dashboard()
                    ltp, chain, curr_date, fut_price  = update_all_data(session_state, session_state.cid, session_state.token, sym)
                    if ltp is None or chain is None:
                        missing = []
                        if ltp is None: missing.append("LTP")
                        if chain is None: missing.append("Option chain")
                        debug_msg(f"Data fetch incomplete – missing: {', '.join(missing)}")
                        wait_until_next_interval(Config.REFRESH_INTERVAL)
                        continue

                    fy = fyersModel.FyersModel(client_id=session_state.cid, token=session_state.token, is_async=False, log_path="")
                    session_state.sync_order_count_with_fyers(fy)

                    records = []
                    for opt in chain:
                        if opt.get("option_type") in ("CE","PE"):
                            greeks = opt.get("greeks", {})
                            records.append({
                                "strike": opt["strike_price"],
                                "option_type": opt["option_type"],
                                "ltp": opt.get("ltp", 0),
                                "delta": greeks.get("delta", 0),
                                "volume": opt.get("volume", 0)
                            })
                    merged_df = pd.DataFrame(records)
                    debug_msg(f"Merged chain: {len(merged_df)} rows")
                    if merged_df.empty:
                        debug_msg("Merged DF empty, skipping")
                        wait_until_next_interval(Config.REFRESH_INTERVAL)
                        continue

                    atm_strike = min(merged_df["strike"].unique(), key=lambda x: abs(x - ltp))
                    debug_msg(f"ATM strike selected: {atm_strike}")
                    signal, metrics, position = compute_signals(merged_df, atm_strike, ltp, fut_price, session_state)
                    # Log to CSV
                    data_logger.log_data(
                        timestamp=timestamp_ist(),
                        underlying_ltp=ltp,
                        fut_price=fut_price, 
                        signal=signal,
                        atm_strike=atm_strike,
                        expiry_date=curr_date,
                        idwp=metrics.get("idwp", 0),
                        inof=metrics.get("inof", 0),
                        cumul_idwp=metrics.get("cumul_idwp", 0),
                        cumul_inof=metrics.get("cumul_inof", 0),
                        position=position
                    )

                    if auto_trade:
                        atm_ce = select_atm_option(chain, atm_strike, "CE")
                        atm_pe = select_atm_option(chain, atm_strike, "PE")
                        debug_msg(f"Auto-trade: signal={signal}, CE={'found' if atm_ce else 'missing'}, "
                                  f"PE={'found' if atm_pe else 'missing'}")
                        place_order(session_state, signal, atm_ce, atm_pe, fy)

                    wait_until_next_interval(Config.REFRESH_INTERVAL)
            except KeyboardInterrupt:
                debug_msg("User stopped live trading")
                print("\nStopped by user")
        elif choice == "2":
            print("\n⚙️ SETTINGS")
            new_cid = input(f"Client ID [{session_state.cid}]: ").strip()
            if new_cid:
                session_state.cid = new_cid
            new_token = input(f"Access token: ").strip()
            if new_token:
                session_state.token = new_token
            with open('fyers_credentials.json', 'w') as f:
                json.dump({"client_id": session_state.cid, "access_token": session_state.token}, f)
            debug_msg("Credentials updated and saved")
            print("✅ Settings saved")
            input("Press Enter...")
        elif choice == "3":
            debug_msg("Exiting application")
            break

if __name__ == "__main__":
    main()