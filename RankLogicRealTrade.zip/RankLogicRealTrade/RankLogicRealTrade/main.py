import time
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import pytz
from fyers_apiv3 import fyersModel
import logging
import uuid
from functools import lru_cache
import os
import subprocess
import sys
import json
from typing import Dict, List, Any, Optional, Tuple
from collections import Counter
import matplotlib.pyplot as plt
import csv
import re  # Added for strike extraction
 
 
# Constants
class Config:
    REFRESH_INTERVAL = 60  # seconds
    API_RATE_LIMIT = 200
    API_WINDOW = 60  # seconds
    LOT_SIZE = 75  # nifty lot size
    MAX_RETRIES = 3
    RETRY_DELAY = 2  # seconds
    EXIT_ON_SIDEWAYS = True
    UNDERLYING_SYMBOL = "NSE:NIFTY50-INDEX"
    ROLLING_WINDOW = 30
    TOP_K = 1
    STRIKE_NEIGHBOR = 1
    TOPK_CSV = "topk_options.csv"
    UNIVERSE_CSV = "universe_options.csv"
 
 
# Initialize logging 
logging.basicConfig( 
    filename="trading_app.log", 
    level=logging.INFO, 
    format="%(asctime)s - %(levelname)s - %(message)s", 
    datefmt="%Y-%m-%d %H:%M:%S" 
) 
 
 
def dbg(msg):
    print(f"[DEBUG] {datetime.now().strftime('%H:%M:%S')} | {msg}")

def get_next_aligned_time(interval_seconds): 
    """Get next time aligned to the interval""" 
    now = datetime.now() 
    current_seconds = (now - now.replace(hour=0, minute=0, second=0, microsecond=0)).total_seconds() 
    intervals_passed = current_seconds // interval_seconds 
    next_aligned_seconds = (intervals_passed + 1) * interval_seconds 
     
    next_time = now.replace(hour=0, minute=0, second=0, microsecond=0) + timedelta(seconds=next_aligned_seconds) 
    return next_time 
 
def wait_until_next_interval(interval_seconds): 
    """Wait until next aligned interval""" 
    next_time = get_next_aligned_time(interval_seconds) 
    wait_seconds = (next_time - datetime.now()).total_seconds() 
     
    if wait_seconds > 0: 
        print(f"⏳ Next update at {next_time.strftime('%H:%M:%S')} (waiting {wait_seconds:.1f}s)") 
        time.sleep(wait_seconds) 
 
# Data Logging Class with PNL Tracking
class DataLogger:
    def __init__(self, filename="trading_data.csv"):
        self.filename = filename
        self.pnl_file = "pnl_data.csv"
        self._ensure_header()
        self._ensure_pnl_header()

    def _ensure_header(self):
        """Create file with headers if it doesn't exist"""
        try:
            with open(self.filename, 'r') as f:
                pass
        except FileNotFoundError:
            with open(self.filename, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'timestamp', 'underlying_ltp', 'dominant_option', 
                    'option_score', 'underlying_score'
                ])

    def _ensure_pnl_header(self):
        """Create PNL file with headers if it doesn't exist"""
        try:
            with open(self.pnl_file, 'r') as f:
                pass
        except FileNotFoundError:
            with open(self.pnl_file, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'timestamp', 'signal', 'entry_price', 'exit_price',
                    'quantity', 'pnl', 'cumulative_pnl', 'trade_type'
                ])

    def log_data(self, timestamp, underlying_ltp, dominant_option, option_score, underlying_score):
        """Log trading data to CSV file with score-based metrics"""
        try:
            with open(self.filename, 'a', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    timestamp, underlying_ltp, dominant_option, 
                    option_score, underlying_score
                ])
            print(f"✅ Data logged: {timestamp} - LTP: {underlying_ltp}, Dominant Option: {dominant_option}")
        except Exception as e:
            print(f"❌ Error logging data: {e}")
 
    def log_pnl(self, timestamp, signal, entry_price, exit_price, quantity, pnl, trade_type): 
        """Log PNL data""" 
        try: 
            # Read existing PNL data to calculate cumulative PNL 
            cumulative_pnl = 0 
            try: 
                pnl_df = pd.read_csv(self.pnl_file) 
                if not pnl_df.empty: 
                    cumulative_pnl = pnl_df['pnl'].sum() + pnl 
            except: 
                cumulative_pnl = pnl 
 
            with open(self.pnl_file, 'a', newline='') as f: 
                writer = csv.writer(f) 
                writer.writerow([ 
                    timestamp, signal, entry_price, exit_price, 
                    quantity, pnl, cumulative_pnl, trade_type 
                ]) 
            print(f"💰 PNL logged: {timestamp} - PNL: {pnl}, Cumulative: {cumulative_pnl}") 
        except Exception as e: 
            print(f"❌ Error logging PNL: {e}") 
 
    def read_data(self, limit=None): 
        """Read logged data from CSV file""" 
        try: 
            df = pd.read_csv(self.filename) 
            if limit: 
                return df.tail(limit) 
            return df 
        except Exception as e: 
            print(f"❌ Error reading data: {e}") 
            return pd.DataFrame() 
 
    def read_pnl_data(self): 
        """Read PNL data""" 
        try: 
            return pd.read_csv(self.pnl_file) 
        except Exception as e: 
            print(f"❌ Error reading PNL data: {e}") 
            return pd.DataFrame() 
 
 
# Terminal-based Live Dashboard
class TerminalDashboard:
    def __init__(self, data_logger):
        self.data_logger = data_logger
        self.last_update = None
        self.underlying_score = None
        self.topk = []

    def update_scores(self, underlying_score, topk):
        self.underlying_score = underlying_score
        self.topk = topk

    def display_live_dashboard(self):
        """Display live dashboard in terminal"""
        try:
            # DON'T clear screen here - let main loop handle it
            
            # Read latest data
            df = self.data_logger.read_data(limit=1) # Only need the last LTP
            pnl_df = self.data_logger.read_pnl_data()

            print("\n" + "=" * 100)
            print("📊 LIVE TRADING DASHBOARD (Score-Based Logic)")
            print("=" * 100)
            print(f"Last Update: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
            print("-" * 100)
            
            # --- CURRENT STATUS ---
            print(f"\n📈 CURRENT STATUS:")
            if not df.empty:
                 print(f"   Nifty LTP: {df.iloc[-1]['underlying_ltp']:.2f}")
            else:
                print("   Nifty LTP: Waiting for data...")
            
            # --- SCORE ANALYSIS ---
            print(f"\n📊 SCORE ANALYSIS:")
            if self.underlying_score is not None:
                print(f"   Underlying Score: {self.underlying_score:.4f}")
            else:
                print(f"   Underlying Score: N/A")
            
            if self.topk:
                top_option = self.topk[0]
                print(f"   Dominant Option: {top_option['symbol']}")
                print(f"     -> Score: {top_option['option_score']:.4f} (Type: {top_option['type']})")
            else:
                print(f"   Dominant Option: None")

            # --- P&L SUMMARY ---
            if not pnl_df.empty:
                pnl_df['timestamp'] = pd.to_datetime(pnl_df['timestamp'])
                pnl_df = pnl_df.sort_values('timestamp')

                total_pnl = pnl_df['pnl'].sum()
                total_trades = len(pnl_df[pnl_df['trade_type'] == 'EXIT'])
                profitable_trades = len(pnl_df[pnl_df['pnl'] > 0])
                win_rate = (profitable_trades / total_trades) * 100 if total_trades > 0 else 0
                current_cumulative = pnl_df['cumulative_pnl'].iloc[-1] if not pnl_df.empty else 0

                print(f"\n💰 P&L SUMMARY:")
                print(f"   Total Trades: {total_trades}")
                print(f"   Profitable: {profitable_trades}")
                print(f"   Win Rate: {win_rate:.1f}%")
                print(f"   Cumulative P&L: {current_cumulative:.2f}")

                # Show recent trades
                recent_trades = pnl_df.tail(3)
                print(f"\n📋 RECENT TRADES:")
                for _, trade in recent_trades.iterrows():
                    pnl_color = "🟢" if trade['pnl'] > 0 else "🔴" if trade['pnl'] < 0 else "⚪"
                    print(f"   {pd.to_datetime(trade['timestamp']).strftime('%H:%M:%S')} - {pnl_color} {trade['signal']} - P&L: {trade['pnl']:.2f}")
            else:
                print(f"\n💰 P&L SUMMARY: No trades yet")

            print("\n" + "=" * 100)
            print("🔄 Next update in 30 seconds... (Press Ctrl+C to stop)")
            print("=" * 100)

        except Exception as e:
            print(f"❌ Error displaying dashboard: {e}")
 
 
# Plotting Functions (for manual use) 
def generate_static_plot(): 
    """Generate a static plot that can be viewed manually""" 
    try: 
        data_logger = DataLogger() 
        df = data_logger.read_data() 
        pnl_df = data_logger.read_pnl_data() 
 
        if df.empty: 
            print("❌ No data available for plotting") 
            return 
 
        # Create the plot 
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(15, 10)) 
 
        # Convert timestamp 
        df['timestamp'] = pd.to_datetime(df['timestamp']) 
        df = df.sort_values('timestamp') 
 
        # Plot 1: Nifty LTP and Scores
        ax1.plot(df['timestamp'], df['underlying_ltp'], 'b-', label='Nifty LTP', linewidth=2)
        ax1.set_ylabel('Nifty LTP', color='blue')
        ax1.tick_params(axis='y', labelcolor='blue')
        ax1.grid(True, alpha=0.3)
        ax1.legend(loc='upper left')

        ax1_twin = ax1.twinx()
        ax1_twin.plot(df['timestamp'], df['underlying_score'], 'r-', label='Underlying Score', linewidth=1, alpha=0.7)
        ax1_twin.plot(df['timestamp'], df['option_score'], 'g-', label='Option Score', linewidth=1, alpha=0.7)
        ax1_twin.set_ylabel('Scores', color='r')
        ax1_twin.tick_params(axis='y', labelcolor='r')
        ax1_twin.legend(loc='upper right')

        ax1.set_title('Nifty LTP and Scores')
 
        # Plot 2: PNL Data 
        if not pnl_df.empty: 
            pnl_df['timestamp'] = pd.to_datetime(pnl_df['timestamp']) 
            pnl_df = pnl_df.sort_values('timestamp') 
 
            ax2.plot(pnl_df['timestamp'], pnl_df['cumulative_pnl'], 'purple', 
                     label='Cumulative P&L', linewidth=2) 
            ax2.set_ylabel('Cumulative P&L') 
            ax2.grid(True, alpha=0.3) 
 
            # Mark individual trades 
            profitable = pnl_df[pnl_df['pnl'] > 0] 
            losses = pnl_df[pnl_df['pnl'] < 0] 
 
            if not profitable.empty: 
                ax2.scatter(profitable['timestamp'], profitable['cumulative_pnl'], 
                            color='green', s=60, label='Profit', alpha=0.7) 
            if not losses.empty: 
                ax2.scatter(losses['timestamp'], losses['cumulative_pnl'], 
                            color='red', s=60, label='Loss', alpha=0.7) 
 
            ax2.legend() 
            ax2.set_title('Cumulative Profit & Loss') 
        else: 
            ax2.text(0.5, 0.5, 'No P&L Data Available', ha='center', va='center', 
                     transform=ax2.transAxes) 
            ax2.set_title('Cumulative Profit & Loss') 
 
        plt.tight_layout() 
 
        # Save plot 
        plot_filename = f"trading_plot_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png" 
        plt.savefig(plot_filename, dpi=300, bbox_inches='tight') 
        plt.close() 
 
        print(f"✅ Plot saved as: {plot_filename}") 
        return plot_filename 
 
    except Exception as e: 
        print(f"❌ Error generating plot: {e}") 
        return None 
 
 
# Error handling decorator 
def handle_errors(func): 
    def wrapper(*args, **kwargs): 
        retries = 0 
        while retries < Config.MAX_RETRIES: 
            try: 
                return func(*args, **kwargs) 
            except Exception as e: 
                retries += 1 
                logging.error(f"Error in {func.__name__} (attempt {retries}): {str(e)}", exc_info=True) 
                if retries < Config.MAX_RETRIES: 
                    time.sleep(Config.RETRY_DELAY) 
                else: 
                    print(f"❌ Operation failed after {Config.MAX_RETRIES} attempts: {str(e)}") 
                    return None 
 
    return wrapper 
 
 
# Initialize all session state in one place
class SessionState:
    def __init__(self):
        self.option_chain_api_count = 0
        self.quote_api_count = 0
        self.api_window_start = datetime.now()
        self.cid = ""
        self.token = ""
        
        #  Persistent position state
        self.position_state = {
            "has_ce_long": False,
            "has_pe_long": False,
            "current_position": None,
            "current_type": None,
            "is_exiting": False,
            "exit_start_time": None
        }

    def get(self, key, default=None):
        """Dictionary-like get method for session state attributes"""
        return getattr(self, key, default)
    
    def update_position_state(self, has_ce_long, has_pe_long, current_position, current_type):
        """Update position state with fresh data"""
        self.position_state["has_ce_long"] = has_ce_long
        self.position_state["has_pe_long"] = has_pe_long
        self.position_state["current_position"] = current_position
        self.position_state["current_type"] = current_type
    
    def set_exiting(self, is_exiting=True):
        """Set exit state"""
        self.position_state["is_exiting"] = is_exiting
        if is_exiting:
            self.position_state["exit_start_time"] = datetime.now()
 
 
# Load credentials from environment variables 
def load_credentials(session_state): 
    """Load credentials from JSON file or environment variables""" 
    try: 
        # Try to load from JSON file first 
        with open('fyers_credentials.json', 'r') as f: 
            creds = json.load(f) 
            session_state.cid = creds.get('client_id', '') 
            session_state.token = creds.get('access_token', '') 
            print("✅ Credentials loaded from JSON file") 
    except FileNotFoundError: 
        # Fall back to environment variables if file doesn't exist 
        print("⚠️ JSON file not found, checking environment variables") 
        session_state.cid = os.getenv("FYERS_CID", session_state.cid) 
        session_state.token = os.getenv("FYERS_TOKEN", session_state.token) 
    except Exception as e: 
        print(f"❌ Error loading credentials: {str(e)}") 
        # Fall back to environment variables 
        session_state.cid = os.getenv("FYERS CID", session_state.cid) 
        session_state.token = os.getenv("FYERS_TOKEN", session_state.token) 
 
 
# Rate limiting with improved logic 
def enforce_rate_limit(session_state): 
    now = datetime.now() 
    window = now - session_state.api_window_start 
    total_calls = session_state.option_chain_api_count + session_state.quote_api_count 
 
    if window > timedelta(seconds=Config.API_WINDOW): 
        session_state.api_window_start = now 
        session_state.option_chain_api_count = 0 
        session_state.quote_api_count = 0 
    elif total_calls >= Config.API_RATE_LIMIT: 
        wait = Config.API_WINDOW - window.seconds 
        logging.warning(f"Approaching rate limit, waiting {wait}s...") 
        print(f"⚠️ Approaching rate limit, waiting {wait}s...") 
        time.sleep(wait) 
        session_state.api_window_start = datetime.now() 
        session_state.option_chain_api_count = 0 
        session_state.quote_api_count = 0 
 
 
# API calls with retry logic 
@handle_errors 
@lru_cache(maxsize=32) 
def get_option_chain_data(session_state, cid, token, sym, expiry_ts=""): 
    print(f"🔍 [DEBUG] Fetching option chain data for {sym}, expiry: {expiry_ts or 'nearest'}") 
    enforce_rate_limit(session_state) 
    session_state.option_chain_api_count += 1 
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="") 
    resp = fy.optionchain(data={"symbol": sym, "timestamp": expiry_ts}) 
    if not resp or resp.get("code") != 200: 
        error_msg = f"Option chain error ({expiry_ts or 'nearest'}): {resp.get('message', 'Unknown')}" 
        logging.error(error_msg) 
        print(f"❌ {error_msg}") 
        return None 
    print(f"✅ [DEBUG] Option chain data fetched successfully") 
    return resp["data"]["optionsChain"] 
 
 
@handle_errors 
def get_underlying_ltp(session_state, cid, token, sym): 
    print(f"🔍 [DEBUG] Fetching underlying LTP for {sym}") 
    enforce_rate_limit(session_state) 
    session_state.quote_api_count += 1 
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="") 
    resp = fy.quotes(data={"symbols": sym}) 
    if not resp or resp.get("code") != 200 or not resp.get("d"): 
        error_msg = f"Quotes API error ({resp.get('code')}): {resp.get('message', 'Unknown')}" 
        logging.error(error_msg) 
        print(f"❌ {error_msg}") 
        return None 
    ltp = resp["d"][0]["v"]["lp"] 
    print(f"✅ [DEBUG] Underlying LTP: {ltp}") 
    return ltp 
 
 
@handle_errors 
def get_symbol_ltp(session_state, cid, token, symbol): 
    print(f"🔍 [DEBUG] Fetching LTP for {symbol}") 
    enforce_rate_limit(session_state) 
    session_state.quote_api_count += 1 
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="") 
    resp = fy.quotes(data={"symbols": symbol}) 
    if not resp or resp.get("code") != 200 or not resp.get("d"): 
        error_msg = f"Quotes API error for {symbol}: {resp.get('message', 'Unknown')}" 
        logging.error(error_msg) 
        print(f"❌ [error_msg]") 
        return None 
    ltp = resp["d"][0]["v"]["lp"] 
    print(f"✅ [DEBUG] Symbol LTP: {ltp}") 
    return ltp 
 
 
MAX_HISTORY = 1  # last N signals for majority check 
MAJORITY_THRESHOLD = 1  # number of same signals to confirm majority 
 
 
# FETCH HISTORY
# =========================
def fetch_history(fyers, symbol):
    today = datetime.now().strftime("%Y-%m-%d")
    resp = fyers.history({
        "symbol": symbol,
        "resolution": "1",
        "date_format": 1,
        "range_from": today,
        "range_to": today,
        "cont_flag": 1
    })
    if resp.get("s") != "ok" or not resp.get("candles"):
        dbg(f"HISTORY FAIL {symbol}")
        return None

    return pd.DataFrame(
        resp["candles"],
        columns=["epoch", "open", "high", "low", "close", "volume"]
    )

# =========================
# SCORE COMPUTATION
# =========================
def compute_score(df, label=None):
    closes = df["close"]
    if len(closes) < 32:
        return None

    R3  = closes.iloc[-2] / closes.iloc[-5]  - 1
    R10 = closes.iloc[-2] / closes.iloc[-12] - 1
    R30 = closes.iloc[-2] / closes.iloc[-32] - 1

    M = (R3 + R10 + R30) / 3
    sigma = closes.pct_change().rolling(Config.ROLLING_WINDOW).std().iloc[-1]
    score = M / sigma if sigma and sigma > 0 else 0.0

    if label:
        dbg(f"{label} | score={score:.4f} M={M:.4f} σ={sigma:.4f}")

    return {
        "R3": R3,
        "R10": R10,
        "R30": R30,
        "M": M,
        "score": score
    }

# =========================
# DOMINANCE CHECK
# =========================
def is_option_dominant(opt_score, und_score, opt_M):
    return (
        opt_score > und_score and
        abs(opt_score) > abs(und_score) and
        opt_M > 0
    )

# =========================
# TOP-K OPTIONS
# =========================
def compute_topk_options(fyers, option_chain, underlying_price):
    """Compute top-k options with improved ATM strike selection"""
    udf = fetch_history(fyers, Config.UNDERLYING_SYMBOL)
    if udf is None:
        return [], None

    u = compute_score(udf, "UNDERLYING")
    if u is None:
        return [], None

    underlying_score = u["score"]
    dbg(f"Underlying score locked = {underlying_score:.4f}")

    # Robust ATM strike selection
    # Get all unique strikes and sort them
    all_strikes = sorted({o["strike_price"] for o in option_chain if o["strike_price"] > 0})
    
    # Find strike closest to underlying price
    atm = min(all_strikes, key=lambda s: abs(s - underlying_price))
    
    # Find index of ATM strike
    atm_idx = all_strikes.index(atm)
    
    # Select neighbors: ATM ± 1 strike
    start_idx = max(0, atm_idx - Config.STRIKE_NEIGHBOR)
    end_idx = min(len(all_strikes), atm_idx + Config.STRIKE_NEIGHBOR + 1)
    selected_strikes = all_strikes[start_idx:end_idx]
    
    dbg(f"Underlying Price: {underlying_price}")
    dbg(f"All Strikes: {all_strikes[:10]}... (total: {len(all_strikes)})")
    dbg(f"ATM Strike: {atm} (index: {atm_idx})")
    dbg(f"Selected Strikes: {selected_strikes}")

    # Filter universe to selected strikes
    universe = [o for o in option_chain if o["strike_price"] in selected_strikes]
    dbg(f"Universe size: {len(universe)} options ({len(selected_strikes)} strikes × 2 types)")
    
    winners, universe_log = [], []

    for opt in universe:
        df = fetch_history(fyers, opt["symbol"])
        if df is None:
            continue

        s = compute_score(df, opt["symbol"])
        if s is None:
            continue

        dominant = is_option_dominant(s["score"], underlying_score, s["M"])

        dbg(
            f"CHECK {opt['symbol']} | "
            f"opt={s['score']:.4f} und={underlying_score:.4f} "
            f"dominant={dominant}"
        )

        universe_log.append({
            "timestamp": datetime.now(),
            "symbol": opt["symbol"],
            "type": opt["option_type"],
            "strike": opt["strike_price"],
            "option_score": s["score"],
            "underlying_score": underlying_score,
            "dominant": dominant,
            **s
        })

        if dominant:
            winners.append({
                "symbol": opt["symbol"],
                "type": opt["option_type"],
                "strike": opt["strike_price"],
                "option_score": s["score"],
                "underlying_score": underlying_score,
                **s
            })

    if universe_log:
        pd.DataFrame(universe_log).to_csv(
            Config.UNIVERSE_CSV,
            mode="a",
            header=not os.path.exists(Config.UNIVERSE_CSV),
            index=False
        )

    # Sort winners by score (highest first)
    winners = sorted(winners, key=lambda x: x["option_score"], reverse=True)
    topk = winners[:Config.TOP_K]

    if topk:
        pd.DataFrame(topk).assign(timestamp=datetime.now()).to_csv(
            Config.TOPK_CSV,
            mode="a",
            header=not os.path.exists(Config.TOPK_CSV),
            index=False
        )

    if topk:
        dbg(f"TOPK = {[o['symbol'] for o in topk]}")
        for opt in topk:
            dbg(f"  - {opt['symbol']}: score={opt['option_score']:.4f}, type={opt['type']}")
    else:
        dbg("TOPK = [] (no dominant options)")

    return topk, underlying_score

# Order management with improved error handling 
@handle_errors 
def cancel_order(fyers, order_id): 
    print(f"🔍 [DEBUG] Cancelling order: {order_id}") 
    try: 
        resp = fyers.cancel_order(data={"id": order_id}) 
        logging.info(f"Cancelled order {order_id}: {resp}") 
        print(f"✅ [DEBUG] Order {order_id} cancelled: {resp}") 
        return resp 
    except Exception as e: 
        logging.error(f"Exception while cancelling order {order_id}: {e}", exc_info=True) 
        print(f"❌ [DEBUG] Error cancelling order {order_id}: {e}") 
        raise 
 
 
@handle_errors 
def get_order_status_by_id(fyers, order_id): 
    print(f"🔍 [DEBUG] Getting status for order: {order_id}") 
    try: 
        orderbook = fyers.orderbook() 
        for o in orderbook.get("orderBook", []): 
            if o.get("id") == order_id: 
                status = o.get("status") 
                print(f"✅ [DEBUG] Order {order_id} status: {status}") 
                return status 
        print(f"⚠️ [DEBUG] Order {order_id} not found in orderbook") 
        return None 
    except Exception as e: 
        logging.warning(f"Could not fetch order status for {order_id}: {e}") 
        print(f"❌ [DEBUG] Error getting order status for {order_id}: {e}") 
        return None 
 
 
@handle_errors 
def place_order_and_check(fyers, order): 
    print(f"🔍 [DEBUG] Placing order: {order}") 
    try: 
        resp = fyers.place_order(data=order) 
        logging.info(f"Order placed for {order['symbol']}: {resp}") 
        print(f"✅ [DEBUG] Order placed: {resp}") 
 
        if resp.get("s") == "ok": 
            oid = resp.get("id") 
            time.sleep(2)  # Wait for order to process 
            status = get_order_status_by_id(fyers, oid) 
            if status in [1, 5]:  # Rejected or canceled 
                logging.error(f"Order {oid} was rejected or canceled. Status: {status}") 
                print(f"❌ [DEBUG] Order {oid} was rejected or canceled. Status: {status}") 
                return None, status 
            logging.info(f"Order {oid} status: {status}") 
            print(f"✅ [DEBUG] Order {oid} status: {status}") 
            return oid, status 
        else: 
            logging.error(f"Order failed: {resp}") 
            print(f"❌ [DEBUG] Order failed: {resp}") 
            return None, None 
    except Exception as e: 
        logging.exception(f"Place order error: {e}") 
        print(f"❌ [DEBUG] Place order error: {e}") 
        raise 
        
def _wait_until_flat(fyers, timeout=28, interval=2):
    """Poll positions until no netQty remains, or timeout."""
    dbg(f"Waiting up to {timeout}s for positions to flatten...")
    end = time.time() + timeout
    while time.time() < end:
        try:
            pos_resp = fyers.positions()
            if pos_resp.get("s") == "ok":
                still_open = [
                    p for p in pos_resp.get("netPositions", [])
                    if abs(p.get("netQty", 0)) != 0
                ]
                if not still_open:
                    dbg("All positions are flat.")
                    return True
                else:
                    dbg(f"Waiting... open positions: {[(p['symbol'], p['netQty']) for p in still_open]}")
            else:
                dbg(f"Positions API error while waiting: {pos_resp}")
        except Exception as e:
            dbg(f"Exception while waiting for flat positions: {e}")
        time.sleep(interval)
    dbg("Timeout reached. Positions did not flatten.")
    return False

# =========================
# NEW POSITION TRACKING FUNCTIONS (FIXED)
# =========================

def extract_strike_from_symbol(symbol):
    """Extract strike price from option symbol"""
    try:
        # Example: "NFO:NIFTY2912225900CE" → 25900
        match = re.search(r'(\d+)(CE|PE)$', symbol)
        if match:
            return int(match.group(1))
        return None
    except:
        return None

def get_current_positions(fyers):
    """
    Get current positions from API
    Returns: (has_ce_long, has_pe_long, current_position, current_type, has_multiple)
    """
    positions = []  # Track ALL positions
    has_pe_long = False
    has_ce_long = False
    current_position = None
    current_type = None
    
    try:
        if fyers:
            pos_resp = fyers.positions()
            if pos_resp.get("s") == "ok":
                for p in pos_resp.get("netPositions", []):
                    qty = p.get("netQty", 0)
                    sym = (p.get("symbol") or "").upper()
                    
                    if abs(qty) > 0:  # Any position (long or short)
                        positions.append(p)
                    
                    if qty > 0:  # Long positions only
                        if "PE" in sym:
                            has_pe_long = True
                            if not current_position:  # Only set if first position
                                current_position = {
                                    "symbol": p.get("symbol"),
                                    "netQty": p.get("netQty", 0),
                                    "avgPrice": p.get("avgPrice", 0),
                                    "type": "PE",
                                    "strike": extract_strike_from_symbol(p.get("symbol", ""))
                                }
                                current_type = "PE"
                        
                        if "CE" in sym:
                            has_ce_long = True
                            if not current_position:  # Only set if first position
                                current_position = {
                                    "symbol": p.get("symbol"),
                                    "netQty": p.get("netQty", 0),
                                    "avgPrice": p.get("avgPrice", 0),
                                    "type": "CE",
                                    "strike": extract_strike_from_symbol(p.get("symbol", ""))
                                }
                                current_type = "CE"
    
    except Exception as e:
        dbg(f"Position check failed: {e}")
    
    # Check if we have multiple positions (EMERGENCY!)
    has_multiple = len([p for p in positions if p.get("netQty", 0) > 0]) > 1
    
    if has_multiple:
        dbg(f"🚨 MULTIPLE POSITIONS DETECTED: {[(p.get('symbol'), p.get('netQty')) for p in positions]}")
    
    return has_ce_long, has_pe_long, current_position, current_type, has_multiple

def live_trade_single_leg(fyers, session_state, topk, data_logger):
    """
    Manages a single-leg option position with CANONICAL EXIT RULES.
    FIXED: Proper position state management using session_state
    YOUR ORIGINAL EXIT LOGIC ONLY: Exit on directional flip OR no dominant option
    """
    dbg("Executing single-leg live trading logic.")
    
    now = datetime.now(pytz.timezone("Asia/Kolkata"))
    
    # Check if we're still exiting from previous iteration
    if session_state.position_state.get("is_exiting", False):
        dbg("🔄 Still waiting for exit to complete...")
        
        # Check if exit timeout (30 seconds max)
        exit_start = session_state.position_state.get("exit_start_time")
        if exit_start and (now - exit_start).total_seconds() > 30:
            dbg("⚠️ Exit timeout. Forcing state reset.")
            session_state.set_exiting(False)
        else:
            # Try to wait for flat
            if _wait_until_flat(fyers):
                dbg("✅ Exit completed successfully.")
                session_state.set_exiting(False)
                # Update position state to reflect flat position
                session_state.update_position_state(False, False, None, None)
            else:
                dbg("⏳ Still waiting for positions to flatten...")
                return  # Skip this iteration
    
    # --- Step 1: Get fresh positions from API ---
    # has_ce_long, has_pe_long, current_position, current_type = get_current_positions(fyers)
    has_ce_long, has_pe_long, current_position, current_type, has_multiple = get_current_positions(fyers)
    
    # Update session state with fresh data
    session_state.update_position_state(has_ce_long, has_pe_long, current_position, current_type)
    
    has_position = has_ce_long or has_pe_long
    has_multiple = has_ce_long and has_pe_long
    
    dbg(f"📊 [DEBUG STEP 1] Open positions: CE_long={has_ce_long}, PE_long={has_pe_long}")
    
    # Safety check: Exit if we have multiple positions
    if has_multiple:
        dbg("⚠️ SAFETY: Multiple positions detected. Exiting all.")
        try:
            fyers.exit_positions()
            if _wait_until_flat(fyers, timeout=15):
                session_state.update_position_state(False, False, None, None)
                session_state.set_exiting(False)
            else:
                session_state.set_exiting(True)
                return
        except Exception as e:
            dbg(f"Error handling multiple positions: {e}")
            return
    
    # --- Step 2: Determine target position ---
    target_symbol = topk[0]["symbol"] if topk else None
    target_type = topk[0]["type"] if topk else None
    
    dbg(f"📊 [DEBUG STEP 2] Target: {target_symbol} ({target_type})" if target_symbol else "📊 [DEBUG STEP 2] Target: None")
    
    # Check for duplicate position
    already_have_target = False
    if target_symbol and current_position and current_position["symbol"] == target_symbol:
        already_have_target = True
        dbg(f"📊 [DEBUG STEP 3] Already have target position")
    
    # --- Step 3: Apply YOUR ORIGINAL EXIT RULES ---
    exit_reason = None
    need_to_exit = False
    
    if has_position and current_position and not already_have_target:
        # YOUR ORIGINAL RULE 1: Directional flip
        if target_type and current_type != target_type:
            exit_reason = f"Direction flip {current_type}→{target_type}"
            need_to_exit = True
        
        # YOUR ORIGINAL RULE 2: No dominant option
        elif not target_symbol:
            exit_reason = "No dominant option"
            need_to_exit = True
    
    # Execute exit
    if need_to_exit:
        dbg(f"🚨 EXIT SIGNAL: {exit_reason}")
        try:
            exit_resp = fyers.exit_positions()
            dbg(f"Exit response: {exit_resp}")
            
            # Set exiting state
            session_state.set_exiting(True)
            
            # Log P&L
            if current_position:
                exit_price = get_symbol_ltp(session_state, session_state.cid, session_state.token, current_position['symbol'])
                if exit_price:
                    entry_price = current_position['avgPrice']
                    qty = abs(current_position['netQty'])
                    pnl = (exit_price - entry_price) * qty
                    
                    data_logger.log_pnl(
                        timestamp=now.strftime("%Y-%m-%d %H:%M:%S"),
                        signal="EXIT",
                        entry_price=entry_price,
                        exit_price=exit_price,
                        quantity=qty,
                        pnl=pnl,
                        trade_type="EXIT"
                    )
            
            # Don't wait here - let next iteration handle it
            return
                
        except Exception as e:
            dbg(f"Exit error: {e}")
            return
    
    # --- Step 4: ENTRY LOGIC ---
    if target_symbol and not already_have_target and not has_position and not session_state.position_state["is_exiting"]:
        dbg(f"✅ ENTRY SIGNAL: {target_symbol}")
        try:
            order = {
                "symbol": target_symbol,
                "qty": Config.LOT_SIZE,
                "type": 2,
                "side": 1,
                "productType": "MARGIN",
                "validity": "DAY",
            }
            oid, status = place_order_and_check(fyers, order)
            
            entry_price = get_symbol_ltp(session_state, session_state.cid, session_state.token, target_symbol)
            if oid and status:
                dbg(f"Order placed: {oid} with status: {status}")
                
                # Update position state (assuming order will fill)
                session_state.update_position_state(
                    has_ce_long=(target_type == "CE"),
                    has_pe_long=(target_type == "PE"),
                    current_position={
                        "symbol": target_symbol,
                        "type": target_type,
                        "netQty": Config.LOT_SIZE,
                        "avgPrice": entry_price # Will be updated on next position check
                    },
                    current_type=target_type
                )
                
                # Log entry
                # entry_price = get_symbol_ltp(session_state, session_state.cid, session_state.token, target_symbol)
                if entry_price:
                    data_logger.log_pnl(
                        timestamp=now.strftime("%Y-%m-%d %H:%M:%S"),
                        signal="ENTRY",
                        entry_price=entry_price,
                        exit_price=0,
                        quantity=Config.LOT_SIZE,
                        pnl=0,
                        trade_type="ENTRY"
                    )
            elif oid is None:
                dbg("❌ Order placement failed!")
                
        except Exception as e:
            dbg(f"Entry error: {e}")
    
    # --- Step 5: HOLD CASES ---
    elif already_have_target:
        dbg(f"⏸️ DUPLICATE PREVENTION: Already in {target_symbol}")
    
    elif has_position and target_type and current_type == target_type:
        current_strike = current_position.get("strike", "?") if current_position else "?"
        target_strike = extract_strike_from_symbol(target_symbol) if target_symbol else "?"
        dbg(f"⏸️ HOLD: Staying in {current_type} (same type, strike {current_strike}→{target_strike})")
    
    elif not has_position and not target_symbol:
        dbg("⏸️ HOLD: Flat, no dominant option")
    
    elif session_state.position_state["is_exiting"]:
        dbg("⏸️ HOLD: Waiting for exit to complete")
    
    else:
        dbg(f"⏸️ HOLD: has_position={has_position}, target={target_symbol}")

# Data display functions with improved formatting 
 
 
@handle_errors 
def update_all_data(session_state, cid, token, sym): 
    print(f"🔍 [DEBUG] Updating all data for {sym}") 
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="") 
    enforce_rate_limit(session_state) 
    session_state.option_chain_api_count += 1 
 
    meta = fy.optionchain(data={"symbol": sym, "timestamp": ""}) 
    if meta.get("code") != 200: 
        print(f"❌ [DEBUG] Option chain API error: {meta}") 
        logging.error("Failed to fetch expiry data") 
        print("❌ [DEBUG] Failed to fetch expiry data") 
        return None, None, None 
 
    exp = sorted( 
        [(e["date"], e.get("expiry")) for e in meta["data"]["expiryData"]], 
        key=lambda x: datetime.strptime(x[0], "%d-%m-%Y") 
    ) 
    today = datetime.today().date() 
    dates = [datetime.strptime(d, "%d-%m-%Y").date() for d, _ in exp] 
    idx = next((i for i, d in enumerate(dates) if d >= today), 0) 
    curr_date, curr_ts = exp[idx] 
 
    ltp = get_underlying_ltp(session_state, cid, token, sym) 
    chain = get_option_chain_data(session_state, cid, token, sym, expiry_ts=curr_ts) 
 
    print(f"✅ [DEBUG] Data update complete") 
    return ltp, chain, curr_date 
 
 
def clear_screen(): 
    """Clear the terminal screen""" 
    os.system('cls' if os.name == 'nt' else 'clear') 
 
 
def get_user_input(prompt, default=None, input_type=str): 
    """Get user input with optional default value""" 
    try: 
        if default is not None: 
            user_input = input(f"{prompt} [{default}]: ").strip() 
            if user_input == "": 
                return default 
            return input_type(user_input) 
        else: 
            return input_type(input(f"{prompt}: ").strip()) 
    except ValueError: 
        print("❌ Invalid input. Please try again.") 
        return get_user_input(prompt, default, input_type) 
 
 
def settings_menu(session_state): 
    """Display and handle settings menu""" 
    while True: 
        clear_screen() 
        print("\n" + "=" * 50) 
        print("⚙️ SETTINGS") 
        print("=" * 50) 
        print(f"1. Client ID: {session_state.cid}") 
        print(f"2. Access Token: {'*' * len(session_state.token) if session_state.token else 'Not set'}") 
        print(f"3. Lot Size: {Config.LOT_SIZE}") 
        print("4. 🔙 Back to Main Menu") 
 
        choice = get_user_input("Select option", input_type=int) 
 
        if choice == 1: 
            session_state.cid = get_user_input("Enter Client ID", session_state.cid) 
        elif choice == 2: 
            session_state.token = get_user_input("Enter Access Token", session_state.token) 
        elif choice == 3: 
            Config.LOT_SIZE = get_user_input("Enter Lot Size", Config.LOT_SIZE, int) 
        elif choice == 4: 
            break 
        else: 
            print("❌ Invalid option. Please try again.") 
 
 
# Main application 
def main(): 
    print("🚀 Starting Live Auto Trading Application") 
    # Initialize session state 
    session_state = SessionState() 
    load_credentials(session_state) 
 
    # Initialize data logger and dashboard 
    data_logger = DataLogger() 
    dashboard = TerminalDashboard(data_logger) 
 
    # Default symbol 
    sym = 'NSE:NIFTY50-INDEX' 
 
    while True: 
        clear_screen() 
        print("\n" + "=" * 100) 
        print("📈 FYERS ALGO TRADING - LIVE AUTO TRADE") 
        print("=" * 50) 
        print("1. 📈 Start Live Trading (with Auto Dashboard)") 
        print("2. ⚙️ Settings") 
        print("3. 📊 Generate Static Plot") 
        print("4. 🚪 Exit") 
        print("=" * 50) 
 
        choice = get_user_input("Select option", input_type=int) 
 
        if choice == 1:  # Live Trading 
            clear_screen() 
            print("\n" + "=" * 100) 
            print("📈 LIVE AUTO TRADING") 
            print("=" * 100) 
 
            # Check credentials 
            if not (session_state.cid and session_state.token): 
                print("❌ Please set Client ID and Access Token in Settings first.") 
                input("Press Enter to continue...") 
                continue 
 
            # Get trading mode 
            auto_trade = get_user_input("Enable Auto Trade? (y/n)", "y").lower() == 'y' 
 
            if not auto_trade: 
                print("ℹ️ Auto trade disabled. Returning to main menu.") 
                input("Press Enter to continue...") 
                continue 
 
            print("🔄 Starting live trading loop...") 
            print("📊 Live dashboard will update automatically every cycle...") 
 
            try: 
                iteration_count = 0 
                while True: 
                    iteration_count += 1 

                    # Clear screen at the start of each iteration
                    clear_screen()
                    
                    print(f"\n🔄 [DEBUG] Starting iteration {iteration_count} at {datetime.now().strftime('%H:%M:%S')}") 
 
                    # Update data 
                    ltp, chain, curr_date = update_all_data(session_state, session_state.cid, session_state.token, sym) 
 
                    ist = pytz.timezone("Asia/Kolkata") 
                    print(f"🕒 Data Updated: {datetime.now(ist).strftime('%Y-%m-%d %H:%M:%S')}") 
 
                    if ltp: 
                        print(f"✅ Underlying LTP: {ltp}") 
 
                    if chain: 
                        fy = fyersModel.FyersModel(client_id=session_state.cid, token=session_state.token, 
                                                   is_async=False, 
                                                   log_path="") 
                        topk, underlying_score = compute_topk_options(fy, chain, ltp)
                        
                        # Log data
                        timestamp = datetime.now(ist).strftime("%Y-%m-%d %H:%M:%S")
                        dominant_option = topk[0]['symbol'] if topk else 'None'
                        option_score = topk[0]['option_score'] if topk else 0
                        
                        data_logger.log_data(
                            timestamp=timestamp,
                            underlying_ltp=ltp,
                            dominant_option=dominant_option,
                            option_score=option_score,
                            underlying_score=underlying_score
                        )

                        # Update dashboard with new info
                        dashboard.update_scores(underlying_score, topk)

                        # Display dashboard every iteration 
                        dashboard.display_live_dashboard() 

                        live_trade_single_leg(fy, session_state, topk, data_logger)
 
                    print(f"⏳ Waiting {Config.REFRESH_INTERVAL} seconds before next update...") 
                    # time.sleep(Config.REFRESH_INTERVAL) 
                    wait_until_next_interval(Config.REFRESH_INTERVAL) 
 
            except KeyboardInterrupt: 
                print("\n⏹️ Live trading stopped by user") 
                input("Press Enter to continue...") 
 
            except Exception as e: 
                print(f"❌ Error in live trading: {str(e)}") 
                logging.exception("Live trading error")
                input("Press Enter to continue...") 
 
        elif choice == 2:  # Settings 
            settings_menu(session_state) 
 
        elif choice == 3:  # Generate Static Plot 
            print("📊 Generating static plot...") 
            plot_file = generate_static_plot() 
            if plot_file: 
                print(f"✅ Plot saved as: {plot_file}") 
            input("Press Enter to continue...") 
 
        elif choice == 4:  # Exit 
            print("👋 Exiting... Goodbye!") 
            break 
 
        else: 
            print("❌ Invalid option. Please try again.") 
            input("Press Enter to continue...") 
 
 
if __name__ == "__main__": 
    main()