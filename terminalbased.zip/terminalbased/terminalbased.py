import time
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import pytz
from fyers_apiv3 import fyersModel
import logging
import uuid
from functools import lru_cache
import os
import subprocess
import sys
import json
from typing import Dict, List, Any, Optional, Tuple


# Constants
class Config:
    REFRESH_INTERVAL = 30  # seconds
    API_RATE_LIMIT = 200
    API_WINDOW = 60  # seconds
    LOT_SIZE = 75
    MAX_RETRIES = 3
    RETRY_DELAY = 2  # seconds


# Initialize logging
logging.basicConfig(
    filename="trading_app.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)


# Error handling decorator
def handle_errors(func):
    def wrapper(*args, **kwargs):
        retries = 0
        while retries < Config.MAX_RETRIES:
            try:
                return func(*args, **kwargs)
            except Exception as e:
                retries += 1
                logging.error(f"Error in {func.__name__} (attempt {retries}): {str(e)}", exc_info=True)
                if retries < Config.MAX_RETRIES:
                    time.sleep(Config.RETRY_DELAY)
                else:
                    print(f"❌ Operation failed after {Config.MAX_RETRIES} attempts: {str(e)}")
                    return None

    return wrapper


# Initialize all session state in one place
class SessionState:
    def __init__(self):
        self.option_chain_api_count = 0
        self.quote_api_count = 0
        self.api_window_start = datetime.now()
        self.last_signal = None
        self.last_signal_order_ids = []
        self.live_last_signal = None
        self.live_last_signal_order_ids = []
        self.signal_history = []
        self.cid = ""
        self.token = ""
        self._hb_lock = False
    
    def get(self, key, default=None):
        """Dictionary-like get method for session state attributes"""
        return getattr(self, key, default)


# Load credentials from environment variables
# def load_credentials(session_state):
#     session_state.cid = os.getenv("FYERS_CID", session_state.cid)
#     session_state.token = os.getenv("FYERS_TOKEN", session_state.token)
def load_credentials(session_state):
    """Load credentials from JSON file or environment variables"""
    try:
        # Try to load from JSON file first
        with open('fyers_credentials.json', 'r') as f:
            creds = json.load(f)
            session_state.cid = creds.get('client_id', '')
            session_state.token = creds.get('access_token', '')
            print("✅ Credentials loaded from JSON file")
    except FileNotFoundError:
        # Fall back to environment variables if file doesn't exist
        print("⚠️ JSON file not found, checking environment variables")
        session_state.cid = os.getenv("FYERS_CID", session_state.cid)
        session_state.token = os.getenv("FYERS_TOKEN", session_state.token)
    except Exception as e:
        print(f"❌ Error loading credentials: {str(e)}")
        # Fall back to environment variables
        session_state.cid = os.getenv("FYERS_CID", session_state.cid)
        session_state.token = os.getenv("FYERS_TOKEN", session_state.token)


# Rate limiting with improved logic
def enforce_rate_limit(session_state):
    now = datetime.now()
    window = now - session_state.api_window_start
    total_calls = session_state.option_chain_api_count + session_state.quote_api_count

    if window > timedelta(seconds=Config.API_WINDOW):
        session_state.api_window_start = now
        session_state.option_chain_api_count = 0
        session_state.quote_api_count = 0
    elif total_calls >= Config.API_RATE_LIMIT:
        wait = Config.API_WINDOW - window.seconds
        logging.warning(f"Approaching rate limit, waiting {wait}s...")
        print(f"⚠️ Approaching rate limit, waiting {wait}s...")
        time.sleep(wait)
        session_state.api_window_start = datetime.now()
        session_state.option_chain_api_count = 0
        session_state.quote_api_count = 0


# API calls with retry logic
@handle_errors
@lru_cache(maxsize=32)
def get_option_chain_data(session_state, cid, token, sym, expiry_ts=""):
    print(f"🔍 [DEBUG] Fetching option chain data for {sym}, expiry: {expiry_ts or 'nearest'}")
    enforce_rate_limit(session_state)
    session_state.option_chain_api_count += 1
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    resp = fy.optionchain(data={"symbol": sym, "timestamp": expiry_ts})
    if not resp or resp.get("code") != 200:
        error_msg = f"Option chain error ({expiry_ts or 'nearest'}): {resp.get('message', 'Unknown')}"
        logging.error(error_msg)
        print(f"❌ {error_msg}")
        return None
    print(f"✅ [DEBUG] Option chain data fetched successfully")
    return resp["data"]["optionsChain"]


@handle_errors
def get_underlying_ltp(session_state, cid, token, sym):
    print(f"🔍 [DEBUG] Fetching underlying LTP for {sym}")
    enforce_rate_limit(session_state)
    session_state.quote_api_count += 1
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    resp = fy.quotes(data={"symbols": sym})
    if not resp or resp.get("code") != 200 or not resp.get("d"):
        error_msg = f"Quotes API error ({resp.get('code')}): {resp.get('message', 'Unknown')}"
        logging.error(error_msg)
        print(f"❌ {error_msg}")
        return None
    ltp = resp["d"][0]["v"]["lp"]
    print(f"✅ [DEBUG] Underlying LTP: {ltp}")
    return ltp


@handle_errors
def get_symbol_ltp(session_state, cid, token, symbol):
    print(f"🔍 [DEBUG] Fetching LTP for {symbol}")
    enforce_rate_limit(session_state)
    session_state.quote_api_count += 1
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    resp = fy.quotes(data={"symbols": symbol})
    if not resp or resp.get("code") != 200 or not resp.get("d"):
        error_msg = f"Quotes API error for {symbol}: {resp.get('message', 'Unknown')}"
        logging.error(error_msg)
        print(f"❌ {error_msg}")
        return None
    ltp = resp["d"][0]["v"]["lp"]
    print(f"✅ [DEBUG] Symbol LTP: {ltp}")
    return ltp


# Signal computation with improved error handling
def compute_signals(merged_df, atm_strike, ltp, min_range_pct=1, tolerance_pct=1, fyers_api=None):
    """
    Compute intraday trading signals using ITM options only.
    Now using ATP (Average Traded Price) instead of VWAP for comparison.
    Returns: (signal, net_flow, direction_ratio)
    """
    print(f"🔍 [DEBUG] Computing signals for ATM strike: {atm_strike}, LTP: {ltp}")
    try:
        def safe_val(series, default=0):
            """Safe extraction from series."""
            return series.iloc[0] if not series.empty and not pd.isna(series.iloc[0]) else default

        # 1. Determine price range around ATM
        atm_row = merged_df[merged_df["Strike"] == atm_strike]
        atm_ce_price = safe_val(atm_row["CE_ltp"])
        atm_pe_price = safe_val(atm_row["PE_ltp"])
        atm_ce_volume = safe_val(atm_row["CE_Vol"])
        atm_pe_volume = safe_val(atm_row["PE_Vol"])
        atm_ce_moneyflow = atm_ce_price * atm_ce_volume
        atm_pe_moneyflow = atm_pe_price * atm_pe_volume
        price_range = atm_ce_price + atm_pe_price

        min_range_abs = ltp * (min_range_pct / 100)

        if price_range >= min_range_abs:
            lower_bound = atm_strike - price_range
            upper_bound = atm_strike + price_range
            range_type = f"ATM+CE Range (±{price_range:.2f} points)"
        else:
            lower_bound = ltp * (1 - min_range_pct / 100)
            upper_bound = ltp * (1 + min_range_pct / 100)
            range_type = f"{min_range_pct}% Underlying Range"

        def round_to_nearest_strike(value, strikes):
            """Round to the nearest available strike price"""
            if not strikes:
                return value
            return min(strikes, key=lambda x: abs(x - value))

        strikes = sorted(merged_df["Strike"].dropna().unique())
        lower_bound = round_to_nearest_strike(lower_bound, strikes)
        upper_bound = round_to_nearest_strike(upper_bound, strikes)
        range_strikes = [s for s in strikes if lower_bound <= s <= upper_bound]

        if not range_strikes:
            logging.warning(f"No strikes in range {lower_bound:.2f}-{upper_bound:.2f}")
            print(f"⚠️ [DEBUG] No strikes in range {lower_bound:.2f}-{upper_bound:.2f}")
            return "SIDEWAYS"

        # 2. Fill missing values
        merged_df = merged_df.fillna(0)
        merged_df["CE_moneyflow"] = merged_df["CE_ltp"] * merged_df["CE_OICh"]
        merged_df["PE_moneyflow"] = merged_df["PE_ltp"] * merged_df["PE_OICh"]

        range_df = merged_df[merged_df["Strike"].isin(range_strikes)].copy()

        # 3. Fyers API quotes for ITM strikes - comparing LTP vs ATP
        if fyers_api and 'CE_symbol' in range_df.columns and 'PE_symbol' in range_df.columns:
            try:
                symbols = list(set(range_df['CE_symbol'].tolist() + range_df['PE_symbol'].tolist()))
                symbols = [s for s in symbols if s != 0 and isinstance(s, str)]
                quotes = {}
                for i in range(0, len(symbols), 50):
                    batch = symbols[i:i + 50]
                    response = fyers_api.quotes({"symbols": ",".join(batch)})
                    if response.get('code') == 200:
                        quotes.update({item['n']: item['v'] for item in response['d'] if item['s'] == 'ok'})

                # Initialize default values
                range_df['CE_vs_atp'] = 'BELOW'  # Default to BELOW if no data
                range_df['PE_vs_atp'] = 'BELOW'
                range_df['ce_strength'] = "LOW"
                range_df['pe_strength'] = "LOW"

                for idx, row in range_df.iterrows():
                    if row['CE_symbol'] in quotes:
                        ce_data = quotes[row['CE_symbol']]
                        ltp = ce_data.get('lp', 0)
                        atp = ce_data.get('atp', 0)
                        high_price = ce_data.get('high_price', 0)
                        if atp > 0:
                            range_df.at[idx, 'CE_vs_atp'] = 'ABOVE' if ltp > atp else 'BELOW'
                        if high_price > 0 and ltp > 0:
                            range_df.at[idx, 'CE_high'] = high_price
                            range_df.at[idx, 'CE_high_diff'] = high_price - ltp
                        range_df.at[idx, 'CE_ltp'] = ltp

                    if row['PE_symbol'] in quotes:
                        pe_data = quotes[row['PE_symbol']]
                        ltp = pe_data.get('lp', 0)
                        atp = pe_data.get('atp', 0)
                        high_price = pe_data.get('high_price', 0)
                        if atp > 0:
                            range_df.at[idx, 'PE_vs_atp'] = 'ABOVE' if ltp > atp else 'BELOW'
                        if high_price > 0 and ltp > 0:
                            range_df.at[idx, 'PE_high'] = high_price
                            range_df.at[idx, 'PE_high_diff'] = high_price - ltp
                        range_df.at[idx, 'PE_ltp'] = ltp

            except Exception as e:
                logging.warning(f"Fyers quotes error: {str(e)}")
                print(f"⚠️ [DEBUG] Fyers quotes error: {str(e)}")

        # 4. Select ITM strikes
        atm_idx = range_strikes.index(atm_strike) if atm_strike in range_strikes else len(range_strikes) // 2
        num_strikes = min(len(range_strikes[:atm_idx]), len(range_strikes[atm_idx + 1:]))
        itm_ce_strikes = range_strikes[atm_idx - num_strikes:atm_idx]
        itm_pe_strikes = range_strikes[atm_idx + 1:atm_idx + 1 + num_strikes]

        # 5. Calculate money flow and direction ratio (using ATP comparison)
        ce_net = range_df[range_df["Strike"].isin(itm_ce_strikes)]["CE_moneyflow"].sum()
        pe_net = range_df[range_df["Strike"].isin(itm_pe_strikes)]["PE_moneyflow"].sum()

        if ce_net > 0 and pe_net > 0:
            net_flow = (ce_net - pe_net) / (ce_net + pe_net) if (ce_net + pe_net) != 0 else 0
        elif ce_net < 0 and pe_net > 0:
            moneyflow = 'Bullish'
        elif ce_net > 0 and pe_net < 0:
            moneyflow = 'Bearish'
        else:
            moneyflow = 'Neutral'

        ce_above_atp = range_df[range_df["Strike"].isin(itm_ce_strikes) & (range_df["CE_vs_atp"] == 'ABOVE')].shape[0]
        pe_above_atp = range_df[range_df["Strike"].isin(itm_pe_strikes) & (range_df["PE_vs_atp"] == 'ABOVE')].shape[0]

        direction_ratio = (ce_above_atp - pe_above_atp) / max(len(itm_ce_strikes) + len(itm_pe_strikes), 1)

        # 6. Convert absolute high diff → % diff from high
        range_df["CE_high_pct"] = np.where(
            range_df["CE_high"] > 0,
            range_df["CE_high_diff"] / range_df["CE_high"],
            0
        )
        range_df["PE_high_pct"] = np.where(
            range_df["PE_high"] > 0,
            range_df["PE_high_diff"] / range_df["PE_high"],
            0
        )

        ce_high_pct_avg = range_df[range_df["Strike"].isin(itm_ce_strikes)]["CE_high_pct"].mean()
        pe_high_pct_avg = range_df[range_df["Strike"].isin(itm_pe_strikes)]["PE_high_pct"].mean()

        # Strength metric: -1 (PE stronger) → +1 (CE stronger)
        strength = (ce_high_pct_avg - pe_high_pct_avg) / max(ce_high_pct_avg + pe_high_pct_avg, 1e-6)

        # 7. Generate signal
        signal = "SIDEWAYS"
        if direction_ratio >= 0.5 and strength < 0:
            print("📈 [DEBUG] Market is in BUY entry found entering the trade")
            signal = "BUY"
        elif direction_ratio <= -0.5 and strength > 0:
            print("📉 [DEBUG] Market is in SELL entry found entering the trade")
            signal = "SELL"

        # Print signal details
        print(f"\n📊 [DEBUG] {range_type}")
        print(f"📊 [DEBUG] Range: {lower_bound:.2f} to {upper_bound:.2f}")
        print(f"📊 [DEBUG] ITM CE Strikes: {list(itm_ce_strikes)}")
        print(f"📊 [DEBUG] ITM PE Strikes: {list(itm_pe_strikes)}")
        print(f"📊 [DEBUG] CE Money Flow: {ce_net:.2f}")
        print(f"📊 [DEBUG] PE Money Flow: {pe_net:.2f}")
        print(f"📊 [DEBUG] Net Money Flow: {net_flow:.2f}")
        print(
            f"📊 [DEBUG] Direction Ratio: {direction_ratio:.2f} | CE Above ATP: {ce_above_atp} | PE Above ATP: {pe_above_atp} | Total Strikes: {len(itm_ce_strikes) + len(itm_pe_strikes)}")
        print(
            f"📊 [DEBUG] Avg CE % below High: {ce_high_pct_avg:.2%} | Avg PE % below High: {pe_high_pct_avg:.2%} | Strength: {strength:.2f}")

        return signal

    except Exception as e:
        logging.error(f"Error in compute_signals: {str(e)}", exc_info=True)
        print(f"❌ [DEBUG] Error in compute_signals: {str(e)}")
        return "SIDEWAYS"


# Optimized strike selection
def select_strikes_atm_half_price(chain, atm_strike):
    print(f"🔍 [DEBUG] Selecting strikes for ATM: {atm_strike}")
    try:
        df = pd.DataFrame(chain)
        if df.empty or atm_strike is None:
            print("⚠️ [DEBUG] No data or ATM strike for selection")
            return None, None, None, None

        ce = df[df["option_type"] == "CE"].copy()
        pe = df[df["option_type"] == "PE"].copy()

        # Find ATM PE and CE rows
        atm_pe_row = pe[pe["strike_price"] == atm_strike]
        atm_ce_row = ce[ce["strike_price"] == atm_strike]

        sell_pe_row = atm_pe_row.iloc[0].to_dict() if not atm_pe_row.empty else None
        sell_ce_row = atm_ce_row.iloc[0].to_dict() if not atm_ce_row.empty else None

        # Find half-price strikes with vectorized operations
        buy_pe_row = None
        if sell_pe_row and "ltp" in sell_pe_row and sell_pe_row["ltp"] > 0:
            target = sell_pe_row["ltp"] / 2
            pe_candidates = pe[pe["strike_price"] != atm_strike].copy()
            pe_candidates["ltp_diff"] = (pe_candidates["ltp"] - target).abs()
            if not pe_candidates.empty:
                buy_pe_row = pe_candidates.nsmallest(1, "ltp_diff").iloc[0].to_dict()

        buy_ce_row = None
        if sell_ce_row and "ltp" in sell_ce_row and sell_ce_row["ltp"] > 0:
            target = sell_ce_row["ltp"] / 2
            ce_candidates = ce[ce["strike_price"] != atm_strike].copy()
            ce_candidates["ltp_diff"] = (ce_candidates["ltp"] - target).abs()
            if not ce_candidates.empty:
                buy_ce_row = ce_candidates.nsmallest(1, "ltp_diff").iloc[0].to_dict()

        print(f"✅ [DEBUG] Strike selection complete:")
        print(f"   - SELL PE: {sell_pe_row['symbol'] if sell_pe_row else 'None'}")
        print(f"   - BUY PE: {buy_pe_row['symbol'] if buy_pe_row else 'None'}")
        print(f"   - SELL CE: {sell_ce_row['symbol'] if sell_ce_row else 'None'}")
        print(f"   - BUY CE: {buy_ce_row['symbol'] if buy_ce_row else 'None'}")

        return sell_pe_row, buy_pe_row, sell_ce_row, buy_ce_row

    except Exception as e:
        logging.error(f"Error in select_strikes_atm_half_price: {str(e)}", exc_info=True)
        print(f"❌ [DEBUG] Error in select_strikes_atm_half_price: {str(e)}")
        return None, None, None, None


# Order management with improved error handling
@handle_errors
def cancel_order(fyers, order_id):
    print(f"🔍 [DEBUG] Cancelling order: {order_id}")
    try:
        resp = fyers.cancel_order(data={"id": order_id})
        logging.info(f"Cancelled order {order_id}: {resp}")
        print(f"✅ [DEBUG] Order {order_id} cancelled: {resp}")
        return resp
    except Exception as e:
        logging.error(f"Exception while cancelling order {order_id}: {e}", exc_info=True)
        print(f"❌ [DEBUG] Error cancelling order {order_id}: {e}")
        raise


@handle_errors
def get_order_status_by_id(fyers, order_id):
    print(f"🔍 [DEBUG] Getting status for order: {order_id}")
    try:
        orderbook = fyers.orderbook()
        for o in orderbook.get("orderBook", []):
            if o.get("id") == order_id:
                status = o.get("status")
                print(f"✅ [DEBUG] Order {order_id} status: {status}")
                return status
        print(f"⚠️ [DEBUG] Order {order_id} not found in orderbook")
        return None
    except Exception as e:
        logging.warning(f"Could not fetch order status for {order_id}: {e}")
        print(f"❌ [DEBUG] Error getting order status for {order_id}: {e}")
        return None


@handle_errors
def place_order_and_check(fyers, order):
    print(f"🔍 [DEBUG] Placing order: {order}")
    try:
        resp = fyers.place_order(data=order)
        logging.info(f"Order placed for {order['symbol']}: {resp}")
        print(f"✅ [DEBUG] Order placed: {resp}")

        if resp.get("s") == "ok":
            oid = resp.get("id")
            time.sleep(2)  # Wait for order to process
            status = get_order_status_by_id(fyers, oid)
            if status in [1, 5]:  # Rejected or canceled
                logging.error(f"Order {oid} was rejected or canceled. Status: {status}")
                print(f"❌ [DEBUG] Order {oid} was rejected or canceled. Status: {status}")
                return None, status
            logging.info(f"Order {oid} status: {status}")
            print(f"✅ [DEBUG] Order {oid} status: {status}")
            return oid, status
        else:
            logging.error(f"Order failed: {resp}")
            print(f"❌ [DEBUG] Order failed: {resp}")
            return None, None
    except Exception as e:
        logging.exception(f"Place order error: {e}")
        print(f"❌ [DEBUG] Place order error: {e}")
        raise


# Trading logic with improved state management
def has_open_orders_for_last_signal(fyers, session_state):
    print(f"🔍 [DEBUG] Checking open orders for last signal")
    ids = session_state.live_last_signal_order_ids
    if not ids:
        print("✅ [DEBUG] No order IDs for last signal")
        return False
    try:
        ob = fyers.orderbook().get("orderBook", [])
        has_open = any(o.get("id") in ids and o.get("status") == 2 for o in ob)
        print(f"✅ [DEBUG] Open orders for last signal: {has_open}")
        return has_open
    except Exception as e:
        logging.warning(f"Could not check open orders: {e}")
        print(f"❌ [DEBUG] Error checking open orders: {e}")
        return False


# Live trading with improved order handling
def handle_basket_orders_atomic(session_state, signal, sell_pe, buy_pe, sell_ce, buy_ce, fyers):
    """
    Atomic-ish rebalancing:
    - If SIDEWAYS: do nothing.
    - If signal changed vs last_signal:
        1) exit ALL current positions via EXIT BASKET
        2) wait for fill (orderbook) + verify flat (positions)
        3) enter new basket for `signal`
    - If same signal: avoid duplicate entries (re-check positions)
    Notes:
      - Uses orderbook polling (report_type/ord_status) to confirm fills.
      - Exits use *actual* netQty to flatten fully (not LOT_SIZE).
      - Adds a simple re-entrancy lock in session_state to avoid overlapping runs.
    """
    print(f"🔍 [DEBUG] Handling basket orders for signal: {signal}")
    
    # ------- simple lock to avoid overlapping runs -------
    if session_state._hb_lock:
        print("⚠️ [DEBUG] Another rebalance is in progress; skipping this run.")
        return []
    session_state._hb_lock = True

    placed_ids = []
    try:
        lot = Config.LOT_SIZE
        current_signal = session_state.last_signal
        print(f"🔄 [DEBUG] Current signal: {current_signal}, New signal: {signal}")

        if signal not in ["BUY", "SELL"]:
            print("📊 [DEBUG] SIDEWAYS signal → No action needed")
            return []

        # Map entry legs for the new signal
        signal_map = {
            "BUY": {
                "enter_hedge": buy_pe,  # buy PE (hedge)
                "enter_short": sell_pe,  # sell PE (short premium)
            },
            "SELL": {
                "enter_hedge": buy_ce,  # buy CE (hedge)
                "enter_short": sell_ce,  # sell CE (short premium)
            }
        }

        # ---------- helper: poll orderbook for fills (inline) ----------
        def _exit_orders_filled(order_ids, timeout=45, interval=2):
            """Return True when ALL given order_ids are filled; False on timeout/failure."""
            print(f"🔍 [DEBUG] Waiting for exit orders to fill: {order_ids}")
            end = time.time() + timeout
            filled = set()
            while time.time() < end:
                ob = fyers.orderbook()
                if ob.get("s") == "ok" and "orderBook" in ob:
                    for o in ob["orderBook"]:
                        oid = o.get("id")
                        if oid in order_ids:
                            rep = str(o.get("report_type", "")).upper()
                            status = o.get("ord_status")
                            # Consider these as FILLED; broaden slightly for broker variations
                            if rep in {"TRADED", "FILLED", "EXECUTED", "COMPLETE", "COMPLETED"} or status in {2}:
                                filled.add(oid)
                                print(f"✅ [DEBUG] Order {oid} filled")
                            # Early-fail on reject/cancel
                            if rep in {"REJECTED", "CANCELLED", "CANCELED"} or status in {-1}:
                                print(f"❌ [DEBUG] Exit order {oid} failed ({rep or status})")
                                return False
                    if filled == set(order_ids):
                        print(f"✅ [DEBUG] All exit orders filled")
                        return True
                time.sleep(interval)
            print(f"❌ [DEBUG] Timeout waiting for exit orders to fill")
            return False

        # ---------- current positions ----------
        pos_resp = fyers.positions()
        net_positions = []
        if pos_resp.get("s") == "ok":
            net_positions = [p for p in pos_resp.get("netPositions", []) if abs(p.get("netQty", 0)) != 0]

        print(f"🔍 [DEBUG] Found {len(net_positions)} active positions")
        for p in net_positions:
            print(f"  - {p.get('symbol')}: {p.get('netQty')} units")

        # ============================================================
        #               1) FLATTEN EVERYTHING on SIGNAL CHANGE
        # ============================================================
        if current_signal in ["BUY", "SELL"] and current_signal != signal and net_positions:
            print(f"⚠️ [DEBUG] Signal changed ({current_signal} → {signal}). Exiting ALL open positions first…")

            # Build an EXIT basket from *all* open positions using their actual qty and opposite side
            exit_basket = []
            for p in net_positions:
                symbol = p.get("symbol")
                net_qty = int(p.get("netQty", 0))
                if net_qty == 0:
                    continue
                # If long (+qty) → sell to close (-1); If short (-qty) → buy to close (+1)
                side = -1 if net_qty > 0 else 1
                qty_to_close = abs(net_qty)  # close fully, not just 1 lot
                product_type = p.get("productType", "MARGIN")

                exit_basket.append({
                    "symbol": symbol,
                    "qty": qty_to_close,
                    "type": 2,  # market
                    "side": side,
                    "productType": product_type,
                    "validity": "DAY"
                })

            if not exit_basket:
                print("📊 [DEBUG] No non-zero positions to exit.")
            else:
                print(f"🧺 [DEBUG] Placing EXIT basket for {len(exit_basket)} legs…")
                exit_resp = fyers.place_basket_orders(data=exit_basket)
                print(f"✅ [DEBUG] Exit basket response: {exit_resp}")

                if not exit_resp or exit_resp.get("s") != "ok":
                    print(
                        f"❌ [DEBUG] Exit basket placement failed: {exit_resp.get('message', 'Unknown error') if isinstance(exit_resp, dict) else 'Unknown error'}")
                    return placed_ids

                # Collect exit order IDs from basket response
                exit_order_ids = []
                for item in exit_resp.get("data", []):
                    body = item.get("body", {})
                    if body.get("s") == "ok" and body.get("id"):
                        exit_order_ids.append(body["id"])
                        placed_ids.append(body["id"])
                    else:
                        # If any leg fails to place, abort re-entry
                        print(f"❌ [DEBUG] Exit leg failed to place: {body.get('message', 'Unknown error')}")
                        return placed_ids

                # Wait for fills via ORDERBOOK
                print("⏳ [DEBUG] Waiting for all exit orders to FILL…")
                if not _exit_orders_filled(exit_order_ids, timeout=60, interval=2):
                    print("❌ [DEBUG] Timeout or failure while exiting positions. Aborting new entry.")
                    return placed_ids

                # Extra safety: verify FLAT via positions
                verify_deadline = time.time() + 10
                while time.time() < verify_deadline:
                    chk = fyers.positions()
                    if chk.get("s") == "ok":
                        still_open = [p for p in chk.get("netPositions", []) if abs(p.get("netQty", 0)) != 0]
                        if not still_open:
                            print("✅ [DEBUG] All positions closed")
                            break
                    time.sleep(1)
                else:
                    print("❌ [DEBUG] Positions not flat after exit fills (broker lag). Aborting new entry.")
                    return placed_ids

        # ============================================================
        #      2) ENTER NEW BASKET (only if nothing is open)
        # ============================================================
        # Refresh positions right before entry
        pos_resp = fyers.positions()
        current_positions = []
        if pos_resp.get("s") == "ok":
            current_positions = [p for p in pos_resp.get("netPositions", []) if abs(p.get("netQty", 0)) != 0]

        if current_positions:
            # If anything still open, do NOT enter new positions
            print("⚠️ [DEBUG] Positions still open; skipping new entry to prevent overlap.")
            for p in current_positions:
                print(f"  - Open: {p.get('symbol')} {p.get('netQty')}")
            return placed_ids

        # Now enter the fresh signal (hedge buy + short sell)
        enter_hedge = signal_map[signal]["enter_hedge"]
        enter_short = signal_map[signal]["enter_short"]

        print(f"📥 [DEBUG] Entering new {signal} positions as a basket…")
        entry_basket = [
            {
                "symbol": enter_hedge["symbol"],
                "qty": lot,
                "type": 2,
                "side": 1,  # Buy hedge
                "productType": "MARGIN",
                "validity": "DAY",
            },
            {
                "symbol": enter_short["symbol"],
                "qty": lot,
                "type": 2,
                "side": -1,  # Sell short leg
                "productType": "MARGIN",
                "validity": "DAY",
            }
        ]

        entry_resp = fyers.place_basket_orders(data=entry_basket)
        print(f"✅ [DEBUG] Entry basket response: {entry_resp}")

        if entry_resp and entry_resp.get("s") == "ok":
            for item in entry_resp.get("data", []):
                body = item.get("body", {})
                if body.get("s") == "ok" and body.get("id"):
                    placed_ids.append(body["id"])
            session_state.last_signal = signal
            print(f"✅ [DEBUG] {signal} positions entered successfully")
        else:
            print(
                f"❌ [DEBUG] Basket order failed: {entry_resp.get('message', 'Unknown error') if isinstance(entry_resp, dict) else 'Unknown error'}")

        return placed_ids

    except Exception as e:
        print(f"❌ [DEBUG] Error: {str(e)}")
        return []
    finally:
        session_state._hb_lock = False
        print("🔓 [DEBUG] Lock released")


# Data display functions with improved formatting
def format_and_show(chain, title, ltp, show_signals=False, fyers_api=None):
    print(f"🔍 [DEBUG] Formatting and displaying data for: {title}")
    df = pd.DataFrame(chain)
    if df.empty:
        print(f"ℹ️ [DEBUG] No data for {title}")
        return None, None

    # Process CE and PE data
    ce = df[df["option_type"] == "CE"]
    pe = df[df["option_type"] == "PE"]

    # Define columns and rename them
    cols = ["symbol", "strike_price", "oi", "volume", "ltp", "ask", "bid",
            "ltpch", "ltpchp", "oich", "oichp", "prev_oi"]

    ce_df = ce[cols].rename(columns={
        "strike_price": "Strike",
        "oi": "OI",
        "volume": "Vol",
        "ltpch": "LTPCh",
        "ltpchp": "LTPChP",
        "oich": "OICh",
        "oichp": "OIChP",
        "prev_oi": "PrevOI"
    })

    pe_df = pe[cols].rename(columns={
        "strike_price": "Strike",
        "oi": "OI",
        "volume": "Vol",
        "ltpch": "LTPCh",
        "ltpchp": "LTPChP",
        "oich": "OICh",
        "oichp": "OIChP",
        "prev_oi": "PrevOI"
    })

    # Merge CE and PE data
    merged = pd.merge(
        ce_df.add_prefix("CE_"),
        pe_df.add_prefix("PE_"),
        left_on="CE_Strike",
        right_on="PE_Strike",
        how="outer"
    ).rename(columns={"CE_Strike": "Strike"}).drop("PE_Strike", axis=1)

    # Find ATM strike
    atm = None
    if ltp is not None and not merged["Strike"].dropna().empty:
        atm = min(merged["Strike"].dropna(), key=lambda x: abs(x - ltp))

    print(f"\n📈 {title}")

    if show_signals and atm is not None:
        # Calculate all required metrics
        strikes = sorted(merged["Strike"].dropna().unique().tolist())
        idx = strikes.index(atm)
        signal = compute_signals(merged, atm, ltp, fyers_api=fyers_api)
        # Display results with improved formatting
        print(f"✅ Signal: {signal}")

    # Display the dataframe
    print(f"📊 ATM Strike: {atm} | Underlying LTP: {ltp}")
    print(merged.to_string(index=False))

    if show_signals and atm is not None:
        return signal, atm
    return None, atm


@handle_errors
def update_all_data(session_state, cid, token, sym):
    print(f"🔍 [DEBUG] Updating all data for {sym}")
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    enforce_rate_limit(session_state)
    session_state.option_chain_api_count += 1

    meta = fy.optionchain(data={"symbol": sym, "timestamp": ""})
    if meta.get("code") != 200:
        logging.error("Failed to fetch expiry data")
        print("❌ [DEBUG] Failed to fetch expiry data")
        return None, None, None

    exp = sorted(
        [(e["date"], e.get("expiry")) for e in meta["data"]["expiryData"]],
        key=lambda x: datetime.strptime(x[0], "%d-%m-%Y")
    )
    today = datetime.today().date()
    dates = [datetime.strptime(d, "%d-%m-%Y").date() for d, _ in exp]
    idx = next((i for i, d in enumerate(dates) if d >= today), 0)
    curr_date, curr_ts = exp[idx]

    ltp = get_underlying_ltp(session_state, cid, token, sym)
    chain = get_option_chain_data(session_state, cid, token, sym, expiry_ts=curr_ts)

    print(f"✅ [DEBUG] Data update complete")
    return ltp, chain, curr_date


def clear_screen():
    """Clear the terminal screen"""
    os.system('cls' if os.name == 'nt' else 'clear')


def get_user_input(prompt, default=None, input_type=str):
    """Get user input with optional default value"""
    try:
        if default is not None:
            user_input = input(f"{prompt} [{default}]: ").strip()
            if user_input == "":
                return default
            return input_type(user_input)
        else:
            return input_type(input(f"{prompt}: ").strip())
    except ValueError:
        print("❌ Invalid input. Please try again.")
        return get_user_input(prompt, default, input_type)


def settings_menu(session_state):
    """Display and handle settings menu"""
    while True:
        clear_screen()
        print("\n" + "=" * 50)
        print("⚙️ SETTINGS")
        print("=" * 50)
        print(f"1. Client ID: {session_state.cid}")
        print(f"2. Access Token: {'*' * len(session_state.token) if session_state.token else 'Not set'}")
        print(f"3. Lot Size: {Config.LOT_SIZE}")
        print("4. 🔙 Back to Main Menu")

        choice = get_user_input("Select option", input_type=int)

        if choice == 1:
            session_state.cid = get_user_input("Enter Client ID", session_state.cid)
        elif choice == 2:
            session_state.token = get_user_input("Enter Access Token", session_state.token)
        elif choice == 3:
            Config.LOT_SIZE = get_user_input("Enter Lot Size", Config.LOT_SIZE, int)
        elif choice == 4:
            break
        else:
            print("❌ Invalid option. Please try again.")


# Main application
def main():
    print("🚀 Starting Live Auto Trading Application")
    # Initialize session state
    session_state = SessionState()
    load_credentials(session_state)

    # Default symbol
    sym = 'NSE:NIFTY50-INDEX'

    while True:
        clear_screen()
        print("\n" + "=" * 50)
        print("📈 FYERS ALGO TRADING - LIVE AUTO TRADE")
        print("=" * 50)
        print("1. 📈 Start Live Trading")
        print("2. ⚙️ Settings")
        print("3. 🚪 Exit")
        print("=" * 50)

        choice = get_user_input("Select option", input_type=int)

        if choice == 1:  # Live Trading
            clear_screen()
            print("\n" + "=" * 50)
            print("📈 LIVE AUTO TRADING")
            print("=" * 50)

            # Check credentials
            if not (session_state.cid and session_state.token):
                print("❌ Please set Client ID and Access Token in Settings first.")
                input("Press Enter to continue...")
                continue

            # Get trading mode
            auto_trade = get_user_input("Enable Auto Trade? (y/n)", "y").lower() == 'y'
            
            if not auto_trade:
                print("ℹ️ Auto trade disabled. Returning to main menu.")
                input("Press Enter to continue...")
                continue

            print("🔄 Starting live trading loop...")
            
            try:
                while True:
                    print(f"\n🔄 [DEBUG] Starting new iteration at {datetime.now().strftime('%H:%M:%S')}")
                    
                    # Update data
                    ltp, chain, curr_date = update_all_data(session_state, session_state.cid, session_state.token, sym)

                    ist = pytz.timezone("Asia/Kolkata")
                    print(f"🕒 Updated: {datetime.now(ist).strftime('%Y-%m-%d %H:%M:%S')}")

                    if ltp:
                        print(f"✅ Underlying LTP: {ltp}")

                    if chain:
                        fy = fyersModel.FyersModel(client_id=session_state.cid, token=session_state.token, is_async=False,
                                                log_path="")
                        signal, atm = format_and_show(chain, f"Current Expiry: {curr_date}", ltp, show_signals=True,
                                                    fyers_api=fy)

                        # Record signal history
                        if signal and ltp:
                            timestamp = datetime.now(ist).strftime("%Y-%m-%d %H:%M:%S")
                            session_state.signal_history.append({
                                "timestamp": timestamp,
                                "signal": signal,
                                "underlying_ltp": ltp,
                                "expiry_date": curr_date
                            })

                        # Select strikes
                        sell_pe, buy_pe, sell_ce, buy_ce = select_strikes_atm_half_price(chain, atm)

                        # Validate pairs
                        valid_buy = (sell_pe is not None and buy_pe is not None)
                        valid_sell = (sell_ce is not None and buy_ce is not None)

                        # Trading logic
                        if signal == "BUY" and not valid_buy:
                            print("⚠️ Missing option data for BUY signal. Unable to place trade.")
                        elif signal == "SELL" and not valid_sell:
                            print("⚠️ Missing option data for SELL signal. Unable to place trade.")
                        elif signal in ("BUY", "SELL"):
                            if session_state.live_last_signal == signal and has_open_orders_for_last_signal(fy, session_state):
                                print(f"ℹ️ Basket for {signal} already open.")
                            else:
                                ids = handle_basket_orders_atomic(session_state, signal, sell_pe, buy_pe, sell_ce, buy_ce, fy)
                                session_state.live_last_signal = signal
                                session_state.live_last_signal_order_ids = ids
                        elif signal == "SIDEWAYS":
                            handle_basket_orders_atomic(session_state, signal, sell_pe, buy_pe, sell_ce, buy_ce, fy)
                        else:
                            print("ℹ️ No action.")

                    print(f"⏳ Waiting {Config.REFRESH_INTERVAL} seconds before next update...")
                    time.sleep(Config.REFRESH_INTERVAL)
                    
            except KeyboardInterrupt:
                print("\n⏹️ Live trading stopped by user")
                input("Press Enter to continue...")
                
            except Exception as e:
                print(f"❌ Error in live trading: {str(e)}")
                input("Press Enter to continue...")

        elif choice == 2:  # Settings
            settings_menu(session_state)

        elif choice == 3:  # Exit
            print("👋 Exiting... Goodbye!")
            break

        else:
            print("❌ Invalid option. Please try again.")
            input("Press Enter to continue...")


if __name__ == "__main__":
    main()