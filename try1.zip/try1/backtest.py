import pandas as pd
import numpy as np
import warnings
from scipy.stats import pearsonr
import matplotlib.pyplot as plt

warnings.filterwarnings('ignore')

# ==========================================
# 1. LOAD & PREPARE DATA
# ==========================================
print("Loading data...")
df = pd.read_csv('option_efficiency_NIFTY_1.csv')
df['Timestamp'] = pd.to_datetime(df['Timestamp'])
df = df.sort_values('Timestamp').reset_index(drop=True)

# Calculate Future Returns (LOOK-AHEAD)
# Shift LTP backwards to get "future price"
df['Future_Price_1m'] = df['Underlying_LTP'].shift(-4)    # 4 bars = 1 minute
df['Future_Price_5m'] = df['Underlying_LTP'].shift(-20)   # 20 bars = 5 minutes
df['Future_Price_15m'] = df['Underlying_LTP'].shift(-60)  # 60 bars = 15 minutes

df['Return_1m'] = (df['Future_Price_1m'] / df['Underlying_LTP']) - 1
df['Return_5m'] = (df['Future_Price_5m'] / df['Underlying_LTP']) - 1
df['Return_15m'] = (df['Future_Price_15m'] / df['Underlying_LTP']) - 1

# Lag the Ratio (to avoid peeking into the future)
df['Ratio_Lag1'] = df['CE_PE_Ratio'].shift(1)
df['Ratio_Change_1m'] = df['CE_PE_Ratio'] - df['CE_PE_Ratio'].shift(4)  # Change over 1 min

# Drop NaN rows (first few and last few bars due to shifts)
df_clean = df.dropna().copy()
print(f"✅ Total clean data points: {len(df_clean)}\n")

# ==========================================
# 2. CORRELATION ANALYSIS
# ==========================================
print("=" * 50)
print("📊 CORRELATION ANALYSIS")
print("=" * 50)

for label, col in [('1-min', 'Return_1m'), ('5-min', 'Return_5m'), ('15-min', 'Return_15m')]:
    corr, p_val = pearsonr(df_clean['Ratio_Lag1'], df_clean[col])
    sig = "✅ SIGNIFICANT" if p_val < 0.05 else "❌ NOT SIGNIFICANT"
    print(f"Ratio vs {label} return: Corr = {corr:.4f}, P-value = {p_val:.4f} {sig}")

print("\n💡 Interpretation: A significant negative correlation means high ratio (puts expensive) predicts price falls.")

# ==========================================
# 3. STRATEGY A: MEAN REVERSION (EXTREMES)
# ==========================================
print("\n" + "=" * 50)
print("🔄 STRATEGY A: MEAN REVERSION (Extremes)")
print("=" * 50)

# Rule: Ratio > 1.15 -> Short (expensive puts, likely overdone)
# Rule: Ratio < 0.85 -> Long (cheap puts, complacency)
df_a = df_clean.copy()
df_a['Signal_A'] = 0
df_a.loc[df_a['Ratio_Lag1'] > 1.15, 'Signal_A'] = -1  # Short
df_a.loc[df_a['Ratio_Lag1'] < 0.85, 'Signal_A'] = 1   # Long

df_a['Strategy_A_Return'] = df_a['Signal_A'] * df_a['Return_1m'] * 100  # in percentage

trades_a = len(df_a[df_a['Signal_A'] != 0])
win_rate_a = (df_a['Strategy_A_Return'] > 0).mean() * 100
total_ret_a = df_a['Strategy_A_Return'].sum()
buy_hold_a = df_a['Return_1m'].sum() * 100

print(f"Trades executed: {trades_a}")
print(f"Win Rate: {win_rate_a:.2f}%")
print(f"Total Strategy Return: {total_ret_a:.2f}%")
print(f"Total Buy & Hold Return: {buy_hold_a:.2f}%")

if trades_a > 10:
    sharpe_a = df_a['Strategy_A_Return'].mean() / df_a['Strategy_A_Return'].std() * (252*6.5*60*4)**0.5
    print(f"Sharpe Ratio (approx): {sharpe_a:.2f}")
else:
    print("Not enough trades for Sharpe.")

# ==========================================
# 4. STRATEGY B: MOMENTUM (CHANGE IN RATIO)
# ==========================================
print("\n" + "=" * 50)
print("📈 STRATEGY B: MOMENTUM (Change in Ratio)")
print("=" * 50)

# If Ratio increased over the last 1 minute -> Short (momentum up, price likely down)
# If Ratio decreased -> Long
df_b = df_clean.copy()
df_b['Signal_B'] = np.where(df_b['Ratio_Change_1m'] > 0, -1, 1)

df_b['Strategy_B_Return'] = df_b['Signal_B'] * df_b['Return_1m'] * 100

trades_b = len(df_b)
win_rate_b = (df_b['Strategy_B_Return'] > 0).mean() * 100
total_ret_b = df_b['Strategy_B_Return'].sum()
buy_hold_b = df_b['Return_1m'].sum() * 100

print(f"Trades executed (always in market): {trades_b}")
print(f"Win Rate: {win_rate_b:.2f}%")
print(f"Total Strategy Return: {total_ret_b:.2f}%")
print(f"Total Buy & Hold Return: {buy_hold_b:.2f}%")
sharpe_b = df_b['Strategy_B_Return'].mean() / df_b['Strategy_B_Return'].std() * (252*6.5*60*4)**0.5
print(f"Sharpe Ratio (approx): {sharpe_b:.2f}")

# ==========================================
# 5. STRATEGY C: GRID SEARCH (FIND BEST THRESHOLD)
# ==========================================
print("\n" + "=" * 50)
print("🎯 STRATEGY C: GRID SEARCH (Best Threshold)")
print("=" * 50)

best_ret = -999
best_thresh = 0
best_trades = 0
best_df = None

for thresh in np.arange(0.70, 1.50, 0.02):
    temp = df_clean.copy()
    temp['Signal_C'] = 0
    temp.loc[temp['Ratio_Lag1'] > thresh, 'Signal_C'] = -1  # Short if above thresh
    temp.loc[temp['Ratio_Lag1'] < thresh, 'Signal_C'] = 1   # Long if below thresh
    
    temp['Strategy_C_Return'] = temp['Signal_C'] * temp['Return_1m'] * 100
    trades_c = len(temp[temp['Signal_C'] != 0])
    
    if trades_c < 10:
        continue  # Skip if too few trades
    
    ret_c = temp['Strategy_C_Return'].sum()
    if ret_c > best_ret:
        best_ret = ret_c
        best_thresh = thresh
        best_trades = trades_c
        best_df = temp.copy()

if best_df is not None:
    win_rate_c = (best_df['Strategy_C_Return'] > 0).mean() * 100
    print(f"🏆 Best Threshold: {best_thresh:.2f}")
    print(f"Trades executed: {best_trades}")
    print(f"Win Rate: {win_rate_c:.2f}%")
    print(f"Total Strategy Return: {best_ret:.2f}%")
else:
    print("No valid threshold found with >10 trades.")

# ==========================================
# 6. EXTREME EVENTS CHECK
# ==========================================
print("\n" + "=" * 50)
print("⚠️ EXTREME EVENTS CHECK")
print("=" * 50)

high = df_clean[df_clean['Ratio_Lag1'] > 1.30]
low = df_clean[df_clean['Ratio_Lag1'] < 0.70]

if len(high) > 5:
    avg_high = high['Return_1m'].mean() * 100
    print(f"Ratio > 1.30 ({len(high)} times): Avg 1-min return = {avg_high:.3f}%")
else:
    print(f"Ratio > 1.30 ({len(high)} times): Not enough data.")

if len(low) > 5:
    avg_low = low['Return_1m'].mean() * 100
    print(f"Ratio < 0.70 ({len(low)} times): Avg 1-min return = {avg_low:.3f}%")
else:
    print(f"Ratio < 0.70 ({len(low)} times): Not enough data.")

# ==========================================
# 7. VISUALIZATION (Equity Curve)
# ==========================================
print("\n" + "=" * 50)
print("📈 GENERATING EQUITY CURVES...")
print("=" * 50)

fig, axes = plt.subplots(2, 2, figsize=(14, 10))
fig.suptitle('Option Efficiency Ratio - Backtest Analysis', fontsize=14)

# Plot 1: Ratio over time
ax1 = axes[0, 0]
ax1.plot(df_clean['Timestamp'], df_clean['CE_PE_Ratio'], color='blue', linewidth=0.8)
ax1.axhline(y=1.0, color='black', linestyle='--', linewidth=0.5, label='Neutral (1.0)')
ax1.axhline(y=1.15, color='red', linestyle='--', linewidth=0.5, label='Short Threshold')
ax1.axhline(y=0.85, color='green', linestyle='--', linewidth=0.5, label='Long Threshold')
ax1.set_title('CE/PE Ratio over time')
ax1.set_ylabel('Ratio')
ax1.legend()
ax1.grid(True, alpha=0.3)

# Plot 2: Equity Curve - Strategy A (Mean Reversion)
ax2 = axes[0, 1]
if trades_a > 0:
    ax2.plot(df_a['Timestamp'], df_a['Strategy_A_Return'].cumsum(), label='Mean Reversion Strategy', color='purple')
ax2.plot(df_clean['Timestamp'], df_clean['Return_1m'].cumsum() * 100, label='Buy & Hold NIFTY', color='gray', alpha=0.6)
ax2.set_title('Equity Curve: Mean Reversion')
ax2.set_ylabel('Cumulative Return (%)')
ax2.legend()
ax2.grid(True, alpha=0.3)

# Plot 3: Equity Curve - Strategy B (Momentum)
ax3 = axes[1, 0]
ax3.plot(df_b['Timestamp'], df_b['Strategy_B_Return'].cumsum(), label='Momentum Strategy', color='green')
ax3.plot(df_clean['Timestamp'], df_clean['Return_1m'].cumsum() * 100, label='Buy & Hold NIFTY', color='gray', alpha=0.6)
ax3.set_title('Equity Curve: Momentum (Change in Ratio)')
ax3.set_ylabel('Cumulative Return (%)')
ax3.legend()
ax3.grid(True, alpha=0.3)

# Plot 4: Scatter - Ratio vs Future 1-min Return
ax4 = axes[1, 1]
ax4.scatter(df_clean['Ratio_Lag1'], df_clean['Return_1m'] * 100, alpha=0.5, s=5, color='navy')
ax4.axhline(y=0, color='black', linestyle='-', linewidth=0.5)
ax4.axvline(x=1.0, color='black', linestyle='--', linewidth=0.5)
ax4.set_title('Ratio vs Next 1-min Return')
ax4.set_xlabel('CE/PE Ratio')
ax4.set_ylabel('Next 1-min Return (%)')
ax4.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('backtest_analysis.png', dpi=150)
print("✅ Chart saved as 'backtest_analysis.png'")

# ==========================================
# 8. FINAL VERDICT
# ==========================================
print("\n" + "=" * 50)
print("📝 FINAL VERDICT")
print("=" * 50)

if total_ret_a > buy_hold_a and trades_a > 10:
    print("✅ Mean Reversion strategy outperforms Buy & Hold.")
else:
    print("❌ Mean Reversion underperforms Buy & Hold (so far).")

if total_ret_b > buy_hold_b:
    print("✅ Momentum strategy outperforms Buy & Hold.")
else:
    print("❌ Momentum underperforms Buy & Hold (so far).")

if len(df_clean) < 1000:
    print("\n⚠️ WARNING: You only have {} data points ({} hours).".format(len(df_clean), round(len(df_clean)/240, 1)))
    print("   Let the logger run for at least a week (10,000+ rows) for reliable results.")
else:
    print("\n✅ You have enough data ({}) for initial analysis.".format(len(df_clean)))