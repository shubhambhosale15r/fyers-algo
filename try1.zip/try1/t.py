#!/usr/bin/env python3
"""
ATM CE/PE Option Efficiency Logger – FULL COLUMNS + SMOOTH INTERPOLATION
+ Paper Trading with Trend-Following Signals.
"""

import os, sys, time, math, datetime, logging, pandas as pd
from typing import Dict, List, Tuple, Optional
from collections import deque
from fyers_apiv3 import fyersModel

# ----------------------------- CONFIGURATION -----------------------------
CLIENT_ID = "J0ENYFX9ME-200"
SECRET_KEY = "3ei40I8iN5nMWxWL"
ACCESS_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOlsiZDoxIiwiZDoyIiwieDowIiwieDoxIiwieDoyIl0sImF0X2hhc2giOiJnQUFBQUFCcWFzNUNVNXZyYm1DNzRmYVNJV1owRUxCRzZkMXJvcHdTUDlSTVNfaTlVTmNBZG5DNGxJREx2eGVWMUVNRlh0TDlwYkFLWkxZenVZaGRvek5aZURCdGQtSXEwTjBwa2lsX3I4LUd0S1lGbUJiRGlfdz0iLCJkaXNwbGF5X25hbWUiOiIiLCJvbXMiOiJLMSIsImhzbV9rZXkiOiI3MGYzYjMwZTE4YzNhNDlhY2MyMzQxMjU4OTEzOWE1Yzk3MDkyMTljNWQ3NzE5ZWYxNTg5ZDM3ZiIsImlzRGRwaUVuYWJsZWQiOiJOIiwiaXNNdGZFbmFibGVkIjoiTiIsImZ5X2lkIjoiRkFBMzE0OTUiLCJhcHBUeXBlIjoyMDAsImV4cCI6MTc4NTQ1NzgwMCwiaWF0IjoxNzg1Mzg0NTE0LCJpc3MiOiJhcGkuZnllcnMuaW4iLCJuYmYiOjE3ODUzODQ1MTQsInN1YiI6ImFjY2Vzc190b2tlbiJ9.PQAkU65skV057bqeBlnMX_-hTBD0UNpk_RPODh5ybv8"

INDEX = "NIFTY"

INDEX_CONFIG = {
    "NIFTY": {"strike_interval": 50, "symbol": "NSE:NIFTY50-INDEX"},
    "BANKNIFTY": {"strike_interval": 100, "symbol": "NSE:BANKNIFTY-INDEX"},
    "FINNIFTY": {"strike_interval": 50, "symbol": "NSE:FINNIFTY-INDEX"},
}

CSV_FILE = f"option_efficiency_{INDEX}.csv"
TRADES_CSV = f"paper_trades_{INDEX}.csv"

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# ----------------------------- FYERS CLIENT -----------------------------
fyers = fyersModel.FyersModel(
    client_id=CLIENT_ID,
    token=ACCESS_TOKEN,
    is_async=False,
    log_path="",
)

# ----------------------------- PAPER TRADING STATE -----------------------------
position = 0          # 0=neutral, 1=long CE, -1=long PE
entry_price = 0.0
entry_ratio = 0.0
entry_time = ""
trade_id = 0
ratio_history = deque(maxlen=5)   # store last 5 ratios

def init_trades_csv():
    if not os.path.isfile(TRADES_CSV):
        header = [
            "Trade_ID", "Entry_Time", "Exit_Time", "Side", 
            "Entry_Ratio", "Exit_Ratio", 
            "Entry_Premium", "Exit_Premium", "PnL_Points", "PnL_Percent"
        ]
        pd.DataFrame(columns=header).to_csv(TRADES_CSV, index=False)

def log_trade_exit(exit_time, exit_ratio, exit_premium, side, pnl_points, pnl_percent):
    # Read existing trades to get the last entry
    trades_df = pd.read_csv(TRADES_CSV)
    # Find the open trade (last row with no Exit_Time)
    # We'll just append a new row with the exit info; we'll assume we have the entry details already
    # Better: we'll store entry info in a global dict and write full row on exit
    pass

# We'll handle trade logging directly in the main loop.

# ----------------------------- API HELPERS -----------------------------

def fetch_option_chain(expiry_timestamp: str = "", strikecount: int = 50) -> Dict:
    data = {
        "symbol": INDEX_CONFIG[INDEX]["symbol"],
        "strikecount": strikecount,
        "timestamp": expiry_timestamp,
        "greeks": "1"
    }
    response = fyers.optionchain(data=data)
    if response.get("code") != 200:
        raise RuntimeError(f"Option chain API failed: {response}")
    return response.get("data", {})

def get_expiry_list(chain_data: Dict) -> List[Dict]:
    return chain_data.get("expiryData", [])

def parse_expiry_date(date_str: str) -> datetime.date:
    return datetime.datetime.strptime(date_str, "%d-%m-%Y").date()

def get_nearest_expiry(expiry_data: List[Dict]) -> str:
    today = datetime.date.today()
    valid = []
    for item in expiry_data:
        date_str = item.get("date")
        ts = item.get("expiry")
        if date_str and ts:
            dt = parse_expiry_date(date_str)
            if dt >= today:
                valid.append((dt, ts))
    if valid:
        valid.sort(key=lambda x: x[0])
        return valid[0][1]
    if expiry_data:
        return expiry_data[0]["expiry"]
    raise RuntimeError("No expiry data available.")

def get_underlying_ltp(chain_data: Dict) -> float:
    for item in chain_data.get("optionsChain", []):
        if item.get("option_type") == "" and item.get("strike_price") == -1:
            ltp = item.get("ltp")
            if ltp is not None:
                return float(ltp)
    raise RuntimeError("Underlying LTP not found.")

def get_option_by_strike(options: List[Dict], strike: int, opt_type: str) -> Optional[Dict]:
    for o in options:
        if o.get("strike_price") == strike and o.get("option_type") == opt_type:
            return o
    return None

def compute_score_from_ltp_greeks(ltp: float, delta: float, gamma: float, theta: float) -> float:
    if None in (ltp, delta, gamma, theta) or ltp == 0 or abs(theta) == 0:
        return 0.0
    return (abs(delta) * gamma) / (ltp * abs(theta))

def interpolate_option_data(opt_low: Dict, opt_high: Dict, weight: float) -> Dict:
    g_low = opt_low.get("greeks", {})
    g_high = opt_high.get("greeks", {})
    return {
        "symbol": opt_low.get("symbol", ""),
        "premium": opt_low["ltp"] * (1 - weight) + opt_high["ltp"] * weight,
        "delta": g_low.get("delta", 0) * (1 - weight) + g_high.get("delta", 0) * weight,
        "gamma": g_low.get("gamma", 0) * (1 - weight) + g_high.get("gamma", 0) * weight,
        "theta": g_low.get("theta", 0) * (1 - weight) + g_high.get("theta", 0) * weight,
        "iv": g_low.get("iv", 0) * (1 - weight) + g_high.get("iv", 0) * weight,
    }

def get_interpolated_snapshot(options: List[Dict], ltp: float) -> Tuple[Dict, Dict, int, int]:
    strikes = sorted(set(
        opt['strike_price'] for opt in options 
        if opt.get('option_type') in ('CE', 'PE') and opt.get('strike_price') is not None
    ))
    if len(strikes) < 2:
        raise RuntimeError("Not enough strikes for interpolation.")
    low_strike = None
    high_strike = None
    for s in strikes:
        if s <= ltp:
            low_strike = s
        if s >= ltp and high_strike is None:
            high_strike = s
    if low_strike == high_strike:
        idx = strikes.index(low_strike)
        if idx + 1 < len(strikes):
            high_strike = strikes[idx + 1]
        else:
            high_strike = low_strike
    if low_strike is None or high_strike is None:
        raise RuntimeError(f"Could not bracket LTP {ltp}.")
    ce_low = get_option_by_strike(options, low_strike, "CE")
    ce_high = get_option_by_strike(options, high_strike, "CE")
    pe_low = get_option_by_strike(options, low_strike, "PE")
    pe_high = get_option_by_strike(options, high_strike, "PE")
    if not all([ce_low, ce_high, pe_low, pe_high]):
        raise RuntimeError(f"Missing CE/PE for strikes {low_strike} or {high_strike}")
    if high_strike == low_strike:
        weight = 0
    else:
        weight = (ltp - low_strike) / (high_strike - low_strike)
    ce_interp = interpolate_option_data(ce_low, ce_high, weight)
    pe_interp = interpolate_option_data(pe_low, pe_high, weight)
    ce_score = compute_score_from_ltp_greeks(
        ce_interp["premium"], ce_interp["delta"], ce_interp["gamma"], ce_interp["theta"]
    )
    pe_score = compute_score_from_ltp_greeks(
        pe_interp["premium"], pe_interp["delta"], pe_interp["gamma"], pe_interp["theta"]
    )
    ce_interp["score"] = ce_score
    pe_interp["score"] = pe_score
    return ce_interp, pe_interp, low_strike, high_strike

# ----------------------------- PAPER TRADING FUNCTIONS -----------------------------

def get_trend(ratios: deque) -> Tuple[str, int]:
    """
    Returns ('rising', up_count) or ('falling', down_count) or ('neutral', 0)
    based on majority of last 4 transitions.
    """
    if len(ratios) < 5:
        return 'neutral', 0
    diffs = [ratios[i] - ratios[i-1] for i in range(1, len(ratios))]
    up = sum(1 for d in diffs if d > 0)
    down = sum(1 for d in diffs if d < 0)
    if up > down:
        return 'rising', up
    elif down > up:
        return 'falling', down
    else:
        return 'neutral', 0

def generate_signal(ratio: float, trend: str) -> int:
    """
    Returns:
      1  -> BUY (long CE) if ratio < 1 and trend == 'falling'
      -1 -> SELL (long PE) if ratio > 1 and trend == 'rising'
      0  -> neutral
    """
    if ratio < 1 and trend == 'falling':
        return 1
    elif ratio > 1 and trend == 'rising':
        return -1
    else:
        return 0

def should_exit(position: int, ratio: float) -> bool:
    if position == 1:   # long CE
        return ratio > 1
    elif position == -1: # long PE
        return ratio < 1
    else:
        return False

# ----------------------------- MAIN LOOP -----------------------------

def run_logger():
    global position, entry_price, entry_ratio, entry_time, trade_id, ratio_history

    # Initialize CSV files
    if not os.path.isfile(CSV_FILE):
        header = [
            "Timestamp", "Underlying_LTP", "ATM_Strike_Low", "ATM_Strike_High",
            "CE_Symbol", "CE_Premium", "CE_Delta", "CE_Gamma", "CE_Theta", "CE_IV", "CE_Score",
            "PE_Symbol", "PE_Premium", "PE_Delta", "PE_Gamma", "PE_Theta", "PE_IV", "PE_Score",
            "CE_PE_Ratio"
        ]
        pd.DataFrame(columns=header).to_csv(CSV_FILE, index=False)

    if not os.path.isfile(TRADES_CSV):
        header = [
            "Trade_ID", "Entry_Time", "Exit_Time", "Side", 
            "Entry_Ratio", "Exit_Ratio", 
            "Entry_Premium", "Exit_Premium", "PnL_Points", "PnL_Percent"
        ]
        pd.DataFrame(columns=header).to_csv(TRADES_CSV, index=False)

    # Get expiry
    chain_data = fetch_option_chain()
    expiry_list = get_expiry_list(chain_data)
    if not expiry_list:
        logger.error("No expiry data found. Exiting.")
        return
    expiry_ts = get_nearest_expiry(expiry_list)
    logger.info(f"Selected expiry timestamp: {expiry_ts}")
    logger.info(f"Starting {INDEX} logger. CSV: {CSV_FILE}")
    logger.info(f"Paper trades will be logged to: {TRADES_CSV}")

    while True:
        try:
            # Sync to 15-second wall clock
            now = time.time()
            next_time = math.ceil(now / 15.0) * 15.0
            sleep_sec = next_time - now
            if sleep_sec > 0:
                time.sleep(sleep_sec)

            snapshot_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            timestamp_dt = datetime.datetime.now()

            # Fetch option chain
            chain_data = fetch_option_chain(expiry_ts, strikecount=50)
            options = chain_data.get("optionsChain", [])
            if not options:
                raise RuntimeError("No options in chain.")

            # Get LTP
            ltp = get_underlying_ltp(chain_data)

            # Get interpolated data
            ce, pe, low_strike, high_strike = get_interpolated_snapshot(options, ltp)
            ratio = ce["score"] / pe["score"] if pe["score"] != 0 else float('inf')

            # ---------- PAPER TRADING LOGIC ----------
            ratio_history.append(ratio)
            trend, _ = get_trend(ratio_history)

            # Generate signal only if we have enough history (5 ratios)
            signal = 0
            if len(ratio_history) >= 5:
                signal = generate_signal(ratio, trend)

            # If no position and signal is triggered, enter trade
            if position == 0 and signal != 0:
                if signal == 1:
                    side = "CE"
                    entry_premium = ce["premium"]
                else:
                    side = "PE"
                    entry_premium = pe["premium"]

                position = signal
                entry_price = entry_premium
                entry_ratio = ratio
                entry_time = snapshot_time
                trade_id += 1
                logger.info(f"📈 ENTRY #{trade_id} | Side: {side} | Ratio: {ratio:.4f} | Premium: {entry_premium:.2f}")

            # If already in a position, check exit
            elif position != 0:
                if should_exit(position, ratio):
                    # Determine exit side and premium
                    if position == 1:
                        side = "CE"
                        exit_premium = ce["premium"]
                    else:
                        side = "PE"
                        exit_premium = pe["premium"]

                    exit_time = snapshot_time
                    exit_ratio = ratio

                    # Compute P&L
                    if side == "CE":
                        pnl_points = exit_premium - entry_price
                    else:  # PE
                        pnl_points = entry_price - exit_premium

                    pnl_percent = (pnl_points / entry_price) * 100 if entry_price != 0 else 0

                    # Log trade
                    trade_row = {
                        "Trade_ID": trade_id,
                        "Entry_Time": entry_time,
                        "Exit_Time": exit_time,
                        "Side": side,
                        "Entry_Ratio": entry_ratio,
                        "Exit_Ratio": exit_ratio,
                        "Entry_Premium": entry_price,
                        "Exit_Premium": exit_premium,
                        "PnL_Points": pnl_points,
                        "PnL_Percent": pnl_percent,
                    }
                    pd.DataFrame([trade_row]).to_csv(TRADES_CSV, mode='a', header=False, index=False)

                    logger.info(f"📉 EXIT #{trade_id} | Side: {side} | PnL: {pnl_points:.2f} points ({pnl_percent:.2f}%)")
                    # Reset position
                    position = 0
                    entry_price = 0.0
                    entry_ratio = 0.0
                    entry_time = ""

            # ---------- LOGGING TO MAIN CSV ----------
            row = {
                "Timestamp": snapshot_time,
                "Underlying_LTP": ltp,
                "ATM_Strike_Low": low_strike,
                "ATM_Strike_High": high_strike,
                "CE_Symbol": ce.get("symbol", "INTERP_CE"),
                "CE_Premium": ce["premium"],
                "CE_Delta": ce["delta"],
                "CE_Gamma": ce["gamma"],
                "CE_Theta": ce["theta"],
                "CE_IV": ce["iv"],
                "CE_Score": ce["score"],
                "PE_Symbol": pe.get("symbol", "INTERP_PE"),
                "PE_Premium": pe["premium"],
                "PE_Delta": pe["delta"],
                "PE_Gamma": pe["gamma"],
                "PE_Theta": pe["theta"],
                "PE_IV": pe["iv"],
                "PE_Score": pe["score"],
                "CE_PE_Ratio": ratio,
            }
            pd.DataFrame([row]).to_csv(CSV_FILE, mode='a', header=False, index=False)

            # Terminal output (include position info)
            pos_str = "NEUTRAL"
            if position == 1:
                pos_str = "LONG CE"
            elif position == -1:
                pos_str = "LONG PE"
            print(f"Time {snapshot_time.split()[1]}  LTP {ltp:.2f}  Ratio {ratio:.3f}  "
                  f"Trend: {trend}  Position: {pos_str}")

        except Exception as e:
            logger.error(f"Error: {e}", exc_info=True)
            continue

if __name__ == "__main__":
    try:
        run_logger()
    except KeyboardInterrupt:
        logger.info("Shutdown requested. Exiting gracefully.")
        sys.exit(0)