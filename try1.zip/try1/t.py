#!/usr/bin/env python3
"""
ATM CE/PE Option Logger – Straddle + Price Breakout (5-min window)
With Pending Entry Confirmation (60-sec timeout).
Entry: LTP breaks 5-min high/low → Pending.
Confirmation: Straddle breaks its 5-min range (high OR low) within 60s → Enter.
Direction: LTP break high → BUY CE; LTP break low → BUY PE.
Exit: Straddle falls 2% from its peak.
Execution: Real ATM premiums for P&L.
"""

import os, sys, time, math, datetime, logging, pandas as pd
from typing import Dict, List, Tuple, Optional
from collections import deque
from fyers_apiv3 import fyersModel

# ----------------------------- CONFIGURATION -----------------------------
CLIENT_ID = "J0ENYFX9ME-200"
SECRET_KEY = "3ei40I8iN5nMWxWL"
ACCESS_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOlsiZDoxIiwiZDoyIiwieDowIiwieDoxIiwieDoyIl0sImF0X2hhc2giOiJnQUFBQUFCcWJiQ2NrRXZDeVlSTG1hSjRmWkxtblZFSkFLOGRJVUN3OFVsQVdHMGNZSlo5b3lYWmhZRVY1SkVfalpuRUs0Q1ZoMjNmVEtGM2JndzVDWEh4TGJwYzNrOTY3MUFVQnpVZmQya0hQRThNdmVGa0xQWT0iLCJkaXNwbGF5X25hbWUiOiIiLCJvbXMiOiJLMSIsImhzbV9rZXkiOiI3MGYzYjMwZTE4YzNhNDlhY2MyMzQxMjU4OTEzOWE1Yzk3MDkyMTljNWQ3NzE5ZWYxNTg5ZDM3ZiIsImlzRGRwaUVuYWJsZWQiOiJOIiwiaXNNdGZFbmFibGVkIjoiTiIsImZ5X2lkIjoiRkFBMzE0OTUiLCJhcHBUeXBlIjoyMDAsImV4cCI6MTc4NTYzMDYwMCwiaWF0IjoxNzg1NTczNTMyLCJpc3MiOiJhcGkuZnllcnMuaW4iLCJuYmYiOjE3ODU1NzM1MzIsInN1YiI6ImFjY2Vzc190b2tlbiJ9._uhpdi4oESGuWVHazBMYoEgK5wFPLyDAbvoR_usT8Oc"

INDEX = "NIFTY"

INDEX_CONFIG = {
    "NIFTY": {"symbol": "NSE:NIFTY50-INDEX"},
    "BANKNIFTY": {"symbol": "NSE:BANKNIFTY-INDEX"},
    "FINNIFTY": {"symbol": "NSE:FINNIFTY-INDEX"},
}

CSV_FILE = f"option_efficiency_{INDEX}.csv"
TRADES_CSV = f"paper_trades_{INDEX}.csv"

WINDOW_BARS = 20
REQUIRED_BARS = WINDOW_BARS + 1
STRADDLE_TRAILING_PERCENT = 2.0
PENDING_WAIT_BARS = 4

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# ----------------------------- FYERS CLIENT -----------------------------
fyers = fyersModel.FyersModel(
    client_id=CLIENT_ID,
    token=ACCESS_TOKEN,
    is_async=False,
    log_path="",
)

# ----------------------------- PAPER TRADING STATE -----------------------------
position = 0
entry_price = 0.0
entry_straddle_value = 0.0
entry_straddle_peak = 0.0
entry_time = ""
trade_id = 0

pending_signal = 0
pending_bars = 0
frozen_ltp_max = 0.0
frozen_ltp_min = 0.0
frozen_straddle_max = 0.0
frozen_straddle_min = 0.0

ltp_history = deque(maxlen=REQUIRED_BARS)
straddle_history = deque(maxlen=REQUIRED_BARS)

def init_trades_csv():
    if not os.path.isfile(TRADES_CSV):
        header = [
            "Trade_ID", "Entry_Time", "Exit_Time", "Side",
            "Entry_Straddle", "Exit_Straddle", "Peak_Straddle",
            "Entry_Premium", "Exit_Premium", "PnL_Points", "PnL_Percent"
        ]
        pd.DataFrame(columns=header).to_csv(TRADES_CSV, index=False)

# ----------------------------- API HELPERS -----------------------------

def fetch_option_chain(expiry_timestamp: str = "", strikecount: int = 50) -> Dict:
    data = {
        "symbol": INDEX_CONFIG[INDEX]["symbol"],
        "strikecount": strikecount,
        "timestamp": expiry_timestamp,
        "greeks": "1"
    }
    response = fyers.optionchain(data=data)
    if response.get("code") != 200:
        raise RuntimeError(f"Option chain API failed: {response}")
    return response.get("data", {})

def get_expiry_list(chain_data: Dict) -> List[Dict]:
    return chain_data.get("expiryData", [])

def parse_expiry_date(date_str: str) -> datetime.date:
    return datetime.datetime.strptime(date_str, "%d-%m-%Y").date()

def get_nearest_expiry(expiry_data: List[Dict]) -> str:
    today = datetime.date.today()
    valid = []
    for item in expiry_data:
        date_str = item.get("date")
        ts = item.get("expiry")
        if date_str and ts:
            dt = parse_expiry_date(date_str)
            if dt >= today:
                valid.append((dt, ts))
    if valid:
        valid.sort(key=lambda x: x[0])
        return valid[0][1]
    if expiry_data:
        return expiry_data[0]["expiry"]
    raise RuntimeError("No expiry data available.")

def get_underlying_ltp(chain_data: Dict) -> float:
    for item in chain_data.get("optionsChain", []):
        if item.get("option_type") == "" and item.get("strike_price") == -1:
            ltp = item.get("ltp")
            if ltp is not None:
                return float(ltp)
    raise RuntimeError("Underlying LTP not found.")

def get_option_by_strike(options: List[Dict], strike: int, opt_type: str) -> Optional[Dict]:
    for o in options:
        if o.get("strike_price") == strike and o.get("option_type") == opt_type:
            return o
    return None

def compute_score_from_ltp_greeks(ltp: float, delta: float, gamma: float, theta: float) -> float:
    if None in (ltp, delta, gamma, theta) or ltp == 0 or abs(theta) == 0:
        return 0.0
    return (abs(delta) * gamma) / (ltp * abs(theta))

def interpolate_option_data(opt_low: Dict, opt_high: Dict, weight: float) -> Dict:
    g_low = opt_low.get("greeks", {})
    g_high = opt_high.get("greeks", {})
    return {
        "symbol": opt_low.get("symbol", ""),
        "premium": opt_low.get("ltp", 0.0) * (1 - weight) + opt_high.get("ltp", 0.0) * weight,
        "delta": g_low.get("delta", 0) * (1 - weight) + g_high.get("delta", 0) * weight,
        "gamma": g_low.get("gamma", 0) * (1 - weight) + g_high.get("gamma", 0) * weight,
        "theta": g_low.get("theta", 0) * (1 - weight) + g_high.get("theta", 0) * weight,
        "iv": g_low.get("iv", 0) * (1 - weight) + g_high.get("iv", 0) * weight,
    }

def get_interpolated_snapshot(options: List[Dict], ltp: float) -> Tuple[Dict, Dict, int, int]:
    strikes = sorted(set(
        opt['strike_price'] for opt in options
        if opt.get('option_type') in ('CE', 'PE') and opt.get('strike_price') is not None
    ))
    if len(strikes) < 2:
        raise RuntimeError("Not enough strikes for interpolation.")
    low_strike = None
    high_strike = None
    for s in strikes:
        if s <= ltp:
            low_strike = s
        if s >= ltp and high_strike is None:
            high_strike = s
    if low_strike == high_strike:
        idx = strikes.index(low_strike)
        if idx + 1 < len(strikes):
            high_strike = strikes[idx + 1]
        else:
            high_strike = low_strike
    if low_strike is None or high_strike is None:
        raise RuntimeError(f"Could not bracket LTP {ltp}.")
    ce_low = get_option_by_strike(options, low_strike, "CE")
    ce_high = get_option_by_strike(options, high_strike, "CE")
    pe_low = get_option_by_strike(options, low_strike, "PE")
    pe_high = get_option_by_strike(options, high_strike, "PE")
    if not all([ce_low, ce_high, pe_low, pe_high]):
        raise RuntimeError(f"Missing CE/PE for strikes {low_strike} or {high_strike}")
    if high_strike == low_strike:
        weight = 0
    else:
        weight = (ltp - low_strike) / (high_strike - low_strike)
    ce_interp = interpolate_option_data(ce_low, ce_high, weight)
    pe_interp = interpolate_option_data(pe_low, pe_high, weight)
    ce_score = compute_score_from_ltp_greeks(
        ce_interp["premium"], ce_interp["delta"], ce_interp["gamma"], ce_interp["theta"]
    )
    pe_score = compute_score_from_ltp_greeks(
        pe_interp["premium"], pe_interp["delta"], pe_interp["gamma"], pe_interp["theta"]
    )
    ce_interp["score"] = ce_score
    pe_interp["score"] = pe_score
    return ce_interp, pe_interp, low_strike, high_strike

# ----------------------------- REAL ATM EXECUTION HELPERS -----------------------------

def get_real_atm_premiums(options: List[Dict], ltp: float) -> Tuple[float, float]:
    strikes = sorted(set(
        opt['strike_price'] for opt in options
        if opt.get('option_type') in ('CE', 'PE') and opt.get('strike_price') is not None
    ))
    if not strikes:
        raise RuntimeError("No strikes found.")
    atm_strike = min(strikes, key=lambda s: abs(s - ltp))
    ce = get_option_by_strike(options, atm_strike, "CE")
    pe = get_option_by_strike(options, atm_strike, "PE")
    if ce is None or pe is None:
        raise RuntimeError(f"CE/PE missing for ATM strike {atm_strike}")
    return ce["ltp"], pe["ltp"]

# ----------------------------- MAIN LOOP -----------------------------

def run_logger():
    global position, entry_price, entry_straddle_value, entry_straddle_peak, entry_time, trade_id
    global ltp_history, straddle_history
    global pending_signal, pending_bars, frozen_ltp_max, frozen_ltp_min, frozen_straddle_max, frozen_straddle_min

    init_trades_csv()

    if not os.path.isfile(CSV_FILE):
        header = [
            "Timestamp", "Underlying_LTP", "ATM_Strike_Low", "ATM_Strike_High",
            "CE_Symbol", "CE_Premium", "CE_Delta", "CE_Gamma", "CE_Theta", "CE_IV", "CE_Score",
            "PE_Symbol", "PE_Premium", "PE_Delta", "PE_Gamma", "PE_Theta", "PE_IV", "PE_Score",
            "CE_PE_Ratio",
            "Straddle_Interp", "Straddle_Real",
            "LTP_Max_5min", "LTP_Min_5min", "Straddle_Max_5min", "Straddle_Min_5min",
            "Frozen_LTP_Max", "Frozen_LTP_Min", "Frozen_Straddle_Max", "Frozen_Straddle_Min",
            "Bars_Collected", "Warmup", "Pending_Signal", "Pending_Bars", "Signal", "Position"
        ]
        pd.DataFrame(columns=header).to_csv(CSV_FILE, index=False)

    chain_data = fetch_option_chain()
    expiry_list = get_expiry_list(chain_data)
    if not expiry_list:
        logger.error("No expiry data found. Exiting.")
        return
    expiry_ts = get_nearest_expiry(expiry_list)
    logger.info(f"Selected expiry timestamp: {expiry_ts}")
    logger.info(f"Starting {INDEX} logger. CSV: {CSV_FILE}")
    logger.info(f"Paper trades will be logged to: {TRADES_CSV}")

    while True:
        try:
            now = time.time()
            next_time = math.ceil(now / 15.0) * 15.0
            sleep_sec = next_time - now
            if sleep_sec > 0:
                time.sleep(sleep_sec)

            snapshot_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            chain_data = fetch_option_chain(expiry_ts, strikecount=50)
            options = chain_data.get("optionsChain", [])
            if not options:
                raise RuntimeError("No options in chain.")

            ltp = get_underlying_ltp(chain_data)

            ce_interp, pe_interp, low_strike, high_strike = get_interpolated_snapshot(options, ltp)
            ratio = ce_interp["score"] / pe_interp["score"] if pe_interp["score"] != 0 else float('inf')

            real_ce_premium, real_pe_premium = get_real_atm_premiums(options, ltp)

            straddle_interp = ce_interp["premium"] + pe_interp["premium"]
            straddle_real = real_ce_premium + real_pe_premium

            ltp_history.append(ltp)
            straddle_history.append(straddle_interp)

            bars_collected = len(ltp_history)
            warmup = bars_collected < REQUIRED_BARS

            signal = 0

            if bars_collected >= REQUIRED_BARS:
                ltp_window = list(ltp_history)[-REQUIRED_BARS:-1]
                straddle_window = list(straddle_history)[-REQUIRED_BARS:-1]
                ltp_max = max(ltp_window)
                ltp_min = min(ltp_window)
                straddle_max = max(straddle_window)
                straddle_min = min(straddle_window)
            else:
                ltp_max = ltp
                ltp_min = ltp
                straddle_max = straddle_interp
                straddle_min = straddle_interp

            # -------------------- PENDING ENTRY LOGIC --------------------
            if position == 0 and not warmup:

                # 1. Check for fresh breakout
                if pending_signal == 0:
                    if ltp > ltp_max:
                        pending_signal = 1
                        pending_bars = 0
                        frozen_ltp_max = ltp_max
                        frozen_ltp_min = ltp_min
                        frozen_straddle_max = straddle_max
                        frozen_straddle_min = straddle_min
                        logger.info(f"⏳ PENDING BUY | LTP broke 5-min high at {ltp:.2f} (frozen high: {frozen_ltp_max:.2f}) | Waiting for Straddle range break...")
                    elif ltp < ltp_min:
                        pending_signal = -1
                        pending_bars = 0
                        frozen_ltp_max = ltp_max
                        frozen_ltp_min = ltp_min
                        frozen_straddle_max = straddle_max
                        frozen_straddle_min = straddle_min
                        logger.info(f"⏳ PENDING SELL | LTP broke 5-min low at {ltp:.2f} (frozen low: {frozen_ltp_min:.2f}) | Waiting for Straddle range break...")

                # 2. If pending, check confirmation or cancellation
                if pending_signal != 0:
                    pending_bars += 1

                    # --- NEW CONFIRMATION: straddle breaks frozen range (high OR low) ---
                    straddle_confirmed = (straddle_interp > frozen_straddle_max) or (straddle_interp < frozen_straddle_min)

                    # Check price reversal against frozen levels
                    price_reversed = False
                    if pending_signal == 1 and ltp < frozen_ltp_max:
                        price_reversed = True
                    elif pending_signal == -1 and ltp > frozen_ltp_min:
                        price_reversed = True

                    time_expired = (pending_bars > PENDING_WAIT_BARS)

                    if straddle_confirmed and pending_bars > 0:
                        # CONFIRMED – enter trade (direction is determined by LTP breakout)
                        if pending_signal == 1:
                            signal = 1  # BUY CE
                            logger.info(f"✅ CONFIRMED BUY | Straddle broke range (high/low) within {pending_bars} bars!")
                        else:
                            signal = -1  # BUY PE
                            logger.info(f"✅ CONFIRMED SELL | Straddle broke range (high/low) within {pending_bars} bars!")
                        # Reset pending state (entry will execute below)
                        pending_signal = 0
                        pending_bars = 0

                    elif price_reversed or time_expired:
                        reason = "Price reversed" if price_reversed else "Confirmation timeout"
                        logger.info(f"❌ PENDING CANCELLED | {reason}")
                        pending_signal = 0
                        pending_bars = 0

            # -------------------- ENTRY EXECUTION --------------------
            if position == 0 and signal != 0 and not warmup:
                if signal == 1:
                    side = "CE"
                    entry_premium = real_ce_premium
                else:
                    side = "PE"
                    entry_premium = real_pe_premium

                position = signal
                entry_price = entry_premium
                entry_straddle_value = straddle_interp
                entry_straddle_peak = straddle_interp
                entry_time = snapshot_time
                trade_id += 1
                logger.info(f"📈 ENTRY #{trade_id} | Side: {side} | LTP: {ltp:.2f} | Straddle: {straddle_interp:.2f} | Premium: {entry_premium:.2f}")

            # -------------------- EXIT LOGIC --------------------
            if position != 0:
                if straddle_interp > entry_straddle_peak:
                    entry_straddle_peak = straddle_interp

                exit_level = entry_straddle_peak * (1 - STRADDLE_TRAILING_PERCENT / 100.0)
                if straddle_interp < exit_level:
                    if position == 1:
                        side = "CE"
                        exit_premium = real_ce_premium
                        entry_premium = entry_price
                    else:
                        side = "PE"
                        exit_premium = real_pe_premium
                        entry_premium = entry_price

                    pnl_points = exit_premium - entry_premium
                    pnl_percent = (pnl_points / entry_premium) * 100 if entry_premium != 0 else 0

                    trade_row = {
                        "Trade_ID": trade_id,
                        "Entry_Time": entry_time,
                        "Exit_Time": snapshot_time,
                        "Side": side,
                        "Entry_Straddle": entry_straddle_value,
                        "Exit_Straddle": straddle_interp,
                        "Peak_Straddle": entry_straddle_peak,
                        "Entry_Premium": entry_premium,
                        "Exit_Premium": exit_premium,
                        "PnL_Points": pnl_points,
                        "PnL_Percent": pnl_percent,
                    }
                    pd.DataFrame([trade_row]).to_csv(TRADES_CSV, mode='a', header=False, index=False)
                    logger.info(f"📉 EXIT #{trade_id} | Side: {side} | PnL: {pnl_points:.2f} pts ({pnl_percent:.2f}%)")
                    position = 0
                    entry_price = 0.0
                    entry_straddle_value = 0.0
                    entry_straddle_peak = 0.0
                    entry_time = ""

            # -------------------- LOGGING TO CSV --------------------
            row = {
                "Timestamp": snapshot_time,
                "Underlying_LTP": ltp,
                "ATM_Strike_Low": low_strike,
                "ATM_Strike_High": high_strike,
                "CE_Symbol": ce_interp.get("symbol", "INTERP_CE"),
                "CE_Premium": ce_interp["premium"],
                "CE_Delta": ce_interp["delta"],
                "CE_Gamma": ce_interp["gamma"],
                "CE_Theta": ce_interp["theta"],
                "CE_IV": ce_interp["iv"],
                "CE_Score": ce_interp["score"],
                "PE_Symbol": pe_interp.get("symbol", "INTERP_PE"),
                "PE_Premium": pe_interp["premium"],
                "PE_Delta": pe_interp["delta"],
                "PE_Gamma": pe_interp["gamma"],
                "PE_Theta": pe_interp["theta"],
                "PE_IV": pe_interp["iv"],
                "PE_Score": pe_interp["score"],
                "CE_PE_Ratio": ratio,
                "Straddle_Interp": straddle_interp,
                "Straddle_Real": straddle_real,
                "LTP_Max_5min": ltp_max,
                "LTP_Min_5min": ltp_min,
                "Straddle_Max_5min": straddle_max,
                "Straddle_Min_5min": straddle_min,
                "Frozen_LTP_Max": frozen_ltp_max,
                "Frozen_LTP_Min": frozen_ltp_min,
                "Frozen_Straddle_Max": frozen_straddle_max,
                "Frozen_Straddle_Min": frozen_straddle_min,
                "Bars_Collected": bars_collected,
                "Warmup": 1 if warmup else 0,
                "Pending_Signal": pending_signal,
                "Pending_Bars": pending_bars,
                "Signal": signal,
                "Position": position,
            }
            pd.DataFrame([row]).to_csv(CSV_FILE, mode='a', header=False, index=False)

            # -------------------- TERMINAL OUTPUT --------------------
            pos_str = "NEUTRAL"
            if position == 1:
                pos_str = "LONG CE"
            elif position == -1:
                pos_str = "LONG PE"

            if warmup:
                status = f"🔥 WARMUP [{bars_collected}/{REQUIRED_BARS}]"
            else:
                status = f"✅ ACTIVE [{bars_collected}/{REQUIRED_BARS}]"

            pending_str = ""
            if pending_signal != 0:
                side_str = "BUY" if pending_signal == 1 else "SELL"
                pending_str = f" ⏳ PENDING {side_str} ({pending_bars}/{PENDING_WAIT_BARS})"

            print(f"{snapshot_time.split()[1]} | {status}{pending_str} | "
                  f"LTP {ltp:.2f} | Strad {straddle_interp:.2f} | "
                  f"Max(LTP) {ltp_max:.2f} | Min(LTP) {ltp_min:.2f} | "
                  f"Max(Strad) {straddle_max:.2f} | Min(Strad) {straddle_min:.2f} | "
                  f"Pos: {pos_str}")

        except Exception as e:
            logger.error(f"Error: {e}", exc_info=True)
            continue

if __name__ == "__main__":
    try:
        run_logger()
    except KeyboardInterrupt:
        logger.info("Shutdown requested. Exiting gracefully.")
        sys.exit(0)