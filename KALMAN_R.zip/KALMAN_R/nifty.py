# ============================================================
# paper_nifty.py – Paper trading with Kalman filter
# ============================================================

import time
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import pytz
from fyers_apiv3 import fyersModel
from fyers_apiv3.FyersWebsocket import data_ws
import logging
import os
import json
from collections import deque
import csv
import threading
import traceback

# ============================================================
# PAPER TRADE FLAG
# ============================================================
PAPER_MODE = True   # set False for live

# ============================================================
# CONFIGURATION
# ============================================================
class Config:
    SAMPLE_INTERVAL = 1
    OPTION_CHAIN_INTERVAL = 30
    OPTION_TRAIL_MULTIPLIER = 1.0
    TARGET_MULTIPLIER = 2
    LOT_SIZE = 195
    MAX_DAILY_ORDERS = 6
    API_RATE_LIMIT = 200
    API_WINDOW = 60
    MAX_RETRIES = 3
    RETRY_DELAY = 2

    # Kalman parameters – tune to your scale
    # INOF (thousands)
    KALMAN_Q_LEVEL_INOF = 1e4
    KALMAN_Q_VEL_INOF   = 1e1          # smaller = smoother velocity
    KALMAN_R_INOF       = 1e6

    # Composite (tens)
    KALMAN_Q_LEVEL_COMP = 1e1
    KALMAN_Q_VEL_COMP   = 1e-2
    KALMAN_R_COMP       = 1e2

    # Signal threshold (velocity crossover level)
    SIGNAL_THRESHOLD = 0.0

    # Kalman warm-up period (number of updates)
    KALMAN_WARMUP_UPDATES = 20

# ============================================================
# LOGGING
# ============================================================
logging.basicConfig(
    filename="trading_app.log",
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)

def log_debug(msg):
    logging.debug(msg)

def log_console(msg):
    print(msg, flush=True)
    logging.info(msg)

IST = pytz.timezone("Asia/Kolkata")

def now_ist():
    return datetime.now(IST)

def timestamp_ist():
    return now_ist().strftime("%Y-%m-%d %H:%M:%S")

# ============================================================
# ERROR HANDLER
# ============================================================
def handle_errors(func):
    def wrapper(*args, **kwargs):
        for retry in range(Config.MAX_RETRIES):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                log_debug(f"{func.__name__} attempt {retry+1} failed: {e}\n{traceback.format_exc()}")
                if retry < Config.MAX_RETRIES-1:
                    time.sleep(Config.RETRY_DELAY)
                else:
                    log_debug(f"{func.__name__} permanently failed")
                    return None
    return wrapper

# ============================================================
# KALMAN FILTER – with Joseph form P‑update
# ============================================================
class KalmanFilter1D:
    """
    1D Kalman filter for scalar observation.
    State: [level, velocity]^T
    Observation: level + noise
    """
    def __init__(self, Q_level, Q_vel, R):
        self.F = np.array([[1, 1],
                           [0, 1]])          # state transition
        self.H = np.array([[1, 0]])          # observation matrix
        self.Q = np.diag([Q_level, Q_vel])   # process noise covariance
        self.R = np.array([[R]])             # measurement noise covariance
        self.x = None                        # state vector [level, velocity]^T
        self.P = np.eye(2) * 1e10            # initial uncertainty

    def update(self, raw_value):
        """Update filter with new raw observation and return (level, velocity)."""
        if self.x is None:
            # First observation: initialize level, velocity=0
            self.x = np.array([[raw_value], [0.0]])
            return raw_value, 0.0

        # Predict
        x_pred = self.F @ self.x
        P_pred = self.F @ self.P @ self.F.T + self.Q

        # Kalman gain
        S = (self.H @ P_pred @ self.H.T) + self.R
        K = P_pred @ self.H.T / S[0, 0]

        # Update state
        innovation = raw_value - (self.H @ x_pred)[0, 0]
        self.x = x_pred + K * innovation

        # Update covariance using Joseph form (numerically stable)
        IKH = np.eye(2) - K @ self.H
        self.P = IKH @ P_pred @ IKH.T + K @ self.R @ K.T

        return self.x[0, 0], self.x[1, 0]   # level, velocity

# ============================================================
# DATA LOGGER – logs Kalman level, velocity, and momentum filters
# ============================================================
class DataLogger:
    def __init__(self, filename="trading_data.csv"):
        self.filename = filename
        self._ensure_header()

    def _ensure_header(self):
        if not os.path.exists(self.filename):
            with open(self.filename, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'timestamp', 'underlying_ltp', 'fut_price', 'signal', 'atm_strike',
                    'expiry_date', 'idwp',
                    'inof_raw', 'inof_level', 'inof_velocity',
                    'comp_raw', 'comp_level', 'comp_velocity',
                    'avg_ce_mom', 'avg_pe_mom',
                    'position',
                    'opt_symbol', 'opt_entry', 'opt_current', 'opt_stop', 'opt_target',
                    'trailing_stop', 'peak_opt_price',
                    'vix', 'sl_pct', 'paper_pnl'
                ])

    def log_data(self, timestamp, underlying_ltp, fut_price, signal, atm_strike,
                 expiry_date, idwp,
                 inof_raw, inof_level, inof_velocity,
                 comp_raw, comp_level, comp_velocity,
                 avg_ce_mom, avg_pe_mom,
                 position,
                 opt_symbol='', opt_entry=0.0, opt_current=0.0, opt_stop=0.0, opt_target=0.0,
                 trailing_stop=0.0, peak_opt_price=0.0,
                 vix=0.0, sl_pct=0.0, paper_pnl=0.0):
        with open(self.filename, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                str(timestamp), underlying_ltp, fut_price, signal, atm_strike,
                expiry_date, round(idwp,2),
                round(inof_raw,2), round(inof_level,2), round(inof_velocity,2),
                round(comp_raw,2), round(comp_level,2), round(comp_velocity,2),
                round(avg_ce_mom,2), round(avg_pe_mom,2),
                position,
                opt_symbol, round(opt_entry,2), round(opt_current,2), round(opt_stop,2), round(opt_target,2),
                round(trailing_stop,2), round(peak_opt_price,2),
                round(vix,2), round(sl_pct*100,2), round(paper_pnl,2)
            ])

    def read_data(self, limit=None):
        try:
            df = pd.read_csv(self.filename)
            return df.tail(limit) if limit else df
        except:
            return pd.DataFrame()

# ============================================================
# STRIKE DETAILS (for display only – no signal logic)
# ============================================================
def get_strike_details(session):
    details = []
    with session.lock:
        if not session.option_chain or session.atm_strike is None:
            return details
        atm = session.atm_strike
        all_strikes = sorted(set(opt["strike_price"] for opt in session.option_chain if opt.get("option_type") in ("CE","PE")))
        if not all_strikes or atm not in all_strikes:
            return details
        idx = all_strikes.index(atm)
        selected = [atm]
        if idx > 0:
            selected.append(all_strikes[idx-1])
        if idx < len(all_strikes)-1:
            selected.append(all_strikes[idx+1])
        for strike in selected:
            ce = next((o for o in session.option_chain if o["strike_price"] == strike and o["option_type"] == "CE"), None)
            pe = next((o for o in session.option_chain if o["strike_price"] == strike and o["option_type"] == "PE"), None)
            if not ce or not pe:
                continue
            ce_ltp = session.get_ltp(ce["symbol"]) or ce.get("ltp", 0)
            pe_ltp = session.get_ltp(pe["symbol"]) or pe.get("ltp", 0)
            ce_vwap = session.get_vwap(ce["symbol"]) or ce_ltp
            pe_vwap = session.get_vwap(pe["symbol"]) or pe_ltp
            ce_current_vol = session.get_volume(ce["symbol"]) or ce.get("volume", 0)
            pe_current_vol = session.get_volume(pe["symbol"]) or pe.get("volume", 0)
            ce_delta = ce.get("greeks", {}).get("delta", 0)
            pe_delta = abs(pe.get("greeks", {}).get("delta", 0))
            parity = (ce_ltp - pe_ltp) / (ce_ltp + pe_ltp) if (ce_ltp + pe_ltp) != 0 else 0
            # For display, compute INOF using diff volumes (but we don't update prev here)
            diff_ce = max(0, ce_current_vol - session.prev_ce_volume.get(ce["symbol"], ce_current_vol))
            diff_pe = max(0, pe_current_vol - session.prev_pe_volume.get(pe["symbol"], pe_current_vol))
            inof = (diff_ce * ce_delta) - (diff_pe * pe_delta)
            ce_mom = ce_ltp - ce_vwap
            pe_mom = pe_ltp - pe_vwap
            details.append({
                "strike": strike,
                "ce_ltp": ce_ltp,
                "ce_vwap": ce_vwap,
                "pe_ltp": pe_ltp,
                "pe_vwap": pe_vwap,
                "parity": parity,
                "inof": inof,
                "ce_mom": ce_mom,
                "pe_mom": pe_mom
            })
    return details

# ============================================================
# DASHBOARD – shows Kalman velocities and warm-up status
# ============================================================
class TerminalDashboard:
    def __init__(self, data_logger, session_state):
        self.data_logger = data_logger
        self.session_state = session_state

    def display(self):
        try:
            os.system('cls' if os.name == 'nt' else 'clear')
            print("\n" + "="*120)
            print("📊 PAPER TRADING DASHBOARD (Kalman Filter)")
            print("="*120)
            print(f"Last Update: {timestamp_ist()}")
            print(f"📈 DAILY ORDER COUNT: {self.session_state.daily_executed_orders}/{Config.MAX_DAILY_ORDERS}")
            print(f"📊 India VIX: {self.session_state.india_vix:.2f}")
            if self.session_state.kalman_update_count < Config.KALMAN_WARMUP_UPDATES:
                print(f"⏳ Kalman warming up: {self.session_state.kalman_update_count}/{Config.KALMAN_WARMUP_UPDATES} updates")
            else:
                print("✅ Kalman filter stable")

            if PAPER_MODE:
                print(f"💰 PAPER P&L (Realized): {self.session_state.paper_realized_pnl:+.2f}")
                if self.session_state.position in ("LONG", "SHORT"):
                    current_opt = self.session_state.get_ltp(self.session_state.held_option_symbol)
                    if current_opt and self.session_state.option_entry_price:
                        unrealized = (current_opt - self.session_state.option_entry_price) * Config.LOT_SIZE
                        print(f"💰 Unrealized P&L: {unrealized:+.2f}")
                        total = self.session_state.paper_realized_pnl + unrealized
                        print(f"💰 Total P&L: {total:+.2f}")

            print("\n" + "-"*80)
            print("📈 KALMAN SIGNAL VALUES")
            print("-"*80)
            metrics = self.session_state.last_metrics
            signal = self.session_state.last_signal
            if metrics:
                print(f"   Nifty LTP: {metrics.get('spot', 0)}")
                print(f"   Signal: {signal}")
                print(f"   Position: {self.session_state.position}")
                print(f"   ATM Strike: {metrics.get('atm_strike', 0)}")
                print(f"   IDWP (parity): {self.session_state.current_idwp:.4f}")
                print(f"   INOF raw: {metrics.get('inof_raw', 0):.2f}")
                print(f"   INOF smoothed level: {metrics.get('inof_level', 0):.2f}")
                print(f"   INOF velocity (delta): {metrics.get('inof_velocity', 0):+.2f}")
                print(f"   Composite raw: {metrics.get('comp_raw', 0):.2f}")
                print(f"   Composite smoothed level: {metrics.get('comp_level', 0):.2f}")
                print(f"   Composite velocity: {metrics.get('comp_velocity', 0):+.2f}")
                print(f"   Signal threshold: {Config.SIGNAL_THRESHOLD}")
                print(f"   avg_ce_mom: {metrics.get('avg_ce_mom', 0):.2f}, avg_pe_mom: {metrics.get('avg_pe_mom', 0):.2f}")
            else:
                print("   Waiting for first data point...")

            # Per-strike details (display only)
            strike_details = get_strike_details(self.session_state)
            if strike_details:
                print("\n" + "-"*80)
                print("🔍 PER‑STRIKE DETAILS (Live from WebSocket)")
                print("-"*80)
                print(f"{'Strike':>8} | {'CE LTP':>8} | {'CE VWAP':>8} | {'PE LTP':>8} | {'PE VWAP':>8} | {'Parity':>10} | {'Inof':>15} | {'CE Mom':>8} | {'PE Mom':>8}")
                print("-"*80)
                for d in strike_details:
                    print(f"{d['strike']:8} | {d['ce_ltp']:8.2f} | {d['ce_vwap']:8.2f} | {d['pe_ltp']:8.2f} | {d['pe_vwap']:8.2f} | {d['parity']:10.2f} | {d['inof']:15.0f} | {d['ce_mom']:8.2f} | {d['pe_mom']:8.2f}")

            pos = self.session_state.position
            if pos in ("LONG", "SHORT"):
                if self.session_state.held_option_symbol:
                    opt_ltp = self.session_state.get_ltp(self.session_state.held_option_symbol)
                    if opt_ltp:
                        trailing_stop = self.session_state.peak_opt_price * (1 - self.session_state.current_sl_pct)
                        print(f"\n{'📈 LONG' if pos == 'LONG' else '📉 SHORT'} POSITION ACTIVE")
                        print(f"   Held option: {self.session_state.held_option_symbol}")
                        print(f"   Entry price: {self.session_state.option_entry_price:.2f}")
                        print(f"   Current price: {opt_ltp:.2f}")
                        print(f"   Peak: {self.session_state.peak_opt_price:.2f}")
                        print(f"   SL: {self.session_state.option_stop_price:.2f} | Target: {self.session_state.option_target_price:.2f}")
                    else:
                        print(f"\n{'📈 LONG' if pos == 'LONG' else '📉 SHORT'} (waiting for price)")
                else:
                    print(f"\n{'📈 LONG' if pos == 'LONG' else '📉 SHORT'} (no symbol stored)")
            elif self.session_state.kalman_update_count >= Config.KALMAN_WARMUP_UPDATES:
                print("\n💤 FLAT - Ready for entry")
            else:
                print("\n💤 FLAT - Warming up")
            print("\n" + "="*120)
        except Exception as e:
            log_debug(f"Dashboard error: {e}")

# ============================================================
# SESSION STATE
# ============================================================
class SessionState:
    def __init__(self):
        self.lock = threading.RLock()
        self.option_chain_api_count = 0
        self.quote_api_count = 0
        self.api_window_start = now_ist()
        self.cid = ""
        self.token = ""
        self._hb_lock = False
        self.daily_executed_orders = 0
        self.last_order_sync = None
        self.position = "FLAT"
        # Kalman filters
        self.kalman_inof = KalmanFilter1D(
            Q_level=Config.KALMAN_Q_LEVEL_INOF,
            Q_vel=Config.KALMAN_Q_VEL_INOF,
            R=Config.KALMAN_R_INOF
        )
        self.kalman_composite = KalmanFilter1D(
            Q_level=Config.KALMAN_Q_LEVEL_COMP,
            Q_vel=Config.KALMAN_Q_VEL_COMP,
            R=Config.KALMAN_R_COMP
        )
        self.kalman_update_count = 0

        # Velocities (signal)
        self.velocity_inof = 0.0
        self.velocity_composite = 0.0
        self.prev_velocity_inof = 0.0
        self.prev_velocity_composite = 0.0

        # Others
        self.current_idwp = 0.0
        self.last_metrics = None
        self.last_signal = "HOLD"
        self.live_ltp = {}
        self.live_vwap = {}
        self.live_volume = {}
        self.option_chain = []
        self.fut_price = None
        self.expiry_date = None
        self.atm_strike = None
        self.option_symbols = []
        self.running = False
        self.held_option_symbol = None
        self.option_entry_price = 0.0
        self.option_stop_price = 0.0
        self.option_target_price = 0.0
        self.current_sl_pct = 0.0
        self.entry_vix = 0.0
        self.peak_opt_price = 0.0
        self.india_vix = 15.0
        self.prev_ce_volume = {}
        self.prev_pe_volume = {}
        self.paper_realized_pnl = 0.0

    def update_ws(self, symbol, ltp, vwap, volume):
        with self.lock:
            if symbol == "NSE:INDIAVIX-INDEX":
                if ltp is not None:
                    self.india_vix = float(ltp)
                return
            if ltp is not None:
                self.live_ltp[symbol] = float(ltp)
            if vwap is not None:
                self.live_vwap[symbol] = float(vwap)
            if volume is not None:
                self.live_volume[symbol] = int(volume)

    def get_ltp(self, symbol):
        with self.lock:
            return self.live_ltp.get(symbol)

    def get_vwap(self, symbol):
        with self.lock:
            return self.live_vwap.get(symbol)

    def get_volume(self, symbol):
        with self.lock:
            return self.live_volume.get(symbol)

    def update_chain(self, chain, fut_price, expiry_date, atm_strike, option_symbols):
        with self.lock:
            self.option_chain = chain
            self.fut_price = float(fut_price) if fut_price else 0.0
            self.expiry_date = expiry_date
            self.atm_strike = int(atm_strike) if atm_strike else None
            self.option_symbols = option_symbols

    def sync_order_count(self, fyers):
        if PAPER_MODE:
            return
        today = now_ist().date()
        if self.last_order_sync != today:
            self.daily_executed_orders = 0
            self.last_order_sync = today
        try:
            resp = fyers.orderbook()
            if resp.get("s") == "ok":
                self.daily_executed_orders = len([o for o in resp.get("orderBook", []) if o.get("status") == 2])
        except Exception as e:
            log_debug(f"Order sync failed: {e}")

    def can_place_order(self, fyers=None):
        if PAPER_MODE:
            return self.daily_executed_orders < Config.MAX_DAILY_ORDERS
        if fyers:
            self.sync_order_count(fyers)
        return self.daily_executed_orders < Config.MAX_DAILY_ORDERS

# ============================================================
# MARKET WEBSOCKET MANAGER
# ============================================================
class MarketWSManager:
    def __init__(self, session_state, access_token):
        self.session = session_state
        self.access_token = access_token
        self.ws = None
        self.subscribed = set()
        self.running = False

    def on_message(self, message):
        symbol = message.get("symbol")
        if symbol:
            ltp = message.get("ltp")
            vwap = message.get("avg_trade_price")
            volume = message.get("vol_traded_today")
            self.session.update_ws(symbol, ltp, vwap, volume)

    def on_error(self, msg):
        log_console(f"WS error: {msg}")

    def on_close(self, msg):
        log_console(f"WS closed: {msg}")
        self.running = False

    def on_open(self):
        log_console("WebSocket connected")
        if self.subscribed:
            self.ws.subscribe(list(self.subscribed), "SymbolUpdate")
        self.ws.keep_running()

    def start(self):
        if self.running:
            return
        self.running = True
        self.ws = data_ws.FyersDataSocket(
            access_token=self.access_token,
            log_path="",
            litemode=False,
            write_to_file=False,
            reconnect=True,
            on_connect=self.on_open,
            on_close=self.on_close,
            on_error=self.on_error,
            on_message=self.on_message
        )
        self.ws.connect()

    def subscribe(self, symbols):
        new_symbols = set(symbols) - self.subscribed
        if new_symbols:
            if self.ws:
                self.ws.subscribe(list(new_symbols), "SymbolUpdate")
            self.subscribed.update(new_symbols)

    def stop(self):
        self.running = False
        if self.ws:
            self.ws.close_connection()

# ============================================================
# REST API HELPERS
# ============================================================
def enforce_rate_limit(session):
    now = now_ist()
    window = (now - session.api_window_start).total_seconds()
    total = session.option_chain_api_count + session.quote_api_count
    if window > Config.API_WINDOW:
        session.api_window_start = now
        session.option_chain_api_count = 0
        session.quote_api_count = 0
    elif total >= Config.API_RATE_LIMIT:
        wait = Config.API_WINDOW - window
        if wait > 0:
            time.sleep(wait)
        session.api_window_start = now
        session.option_chain_api_count = 0
        session.quote_api_count = 0

@handle_errors
def fetch_option_chain(session, index_symbol):
    log_debug("Enter fetch_option_chain")
    enforce_rate_limit(session)
    session.option_chain_api_count += 1
    fy = fyersModel.FyersModel(client_id=session.cid, token=session.token, is_async=False, log_path="")
    meta = fy.optionchain(data={"symbol": index_symbol, "timestamp": ""})
    if meta.get("code") != 200:
        log_debug(f"Meta chain failed: {meta}")
        return None, None, None, None, []
    fut_price = None
    for item in meta["data"]["optionsChain"]:
        if item.get("option_type") == "":
            fut_price = item.get("fp")
            break
    if fut_price is None:
        fut_price = meta["data"].get("fp", 0.0)
    exp_list = sorted([(e["date"], e["expiry"]) for e in meta["data"]["expiryData"]],
                      key=lambda x: datetime.strptime(x[0], "%d-%m-%Y"))
    today = now_ist().date()
    idx = 0
    for i, (d_str, _) in enumerate(exp_list):
        if datetime.strptime(d_str, "%d-%m-%Y").date() >= today:
            idx = i
            break
    curr_date, expiry_ts = exp_list[idx]
    payload = {"symbol": index_symbol, "strikecount": 5, "timestamp": expiry_ts, "greeks": "1"}
    resp = fy.optionchain(data=payload)
    if resp.get("code") != 200:
        log_debug(f"Detailed chain failed: {resp}")
        return None, None, None, None, []
    chain = resp["data"]["optionsChain"]
    option_symbols = [opt["symbol"] for opt in chain if opt.get("option_type") in ("CE","PE")]
    log_debug(f"Got {len(chain)} options, {len(option_symbols)} symbols")
    return chain, fut_price, curr_date, expiry_ts, option_symbols

# ============================================================
# CHAIN POLLER
# ============================================================
def chain_poller(session, ws_manager, index_symbol):
    log_debug("Chain poller thread started")
    while session.running:
        try:
            log_debug("Polling option chain...")
            chain, fut_price, expiry_date, _, opt_symbols = fetch_option_chain(session, index_symbol)
            if chain is None:
                log_debug("Chain fetch returned None")
            else:
                underlying_ltp = session.get_ltp(index_symbol)
                if underlying_ltp is None:
                    underlying_ltp = fut_price
                strikes = sorted(set(opt["strike_price"] for opt in chain if opt.get("option_type") in ("CE","PE")))
                if strikes and underlying_ltp:
                    atm = min(strikes, key=lambda x: abs(x - underlying_ltp))
                else:
                    atm = None
                session.update_chain(chain, fut_price, expiry_date, atm, opt_symbols)
                all_syms = [index_symbol] + opt_symbols
                ws_manager.subscribe(all_syms)
            time.sleep(Config.OPTION_CHAIN_INTERVAL)
        except Exception as e:
            log_debug(f"Chain poller error: {e}\n{traceback.format_exc()}")
            time.sleep(Config.OPTION_CHAIN_INTERVAL)

# ============================================================
# SIGNAL COMPUTATION – Kalman filter
# ============================================================
def compute_signal(session):
    log_debug(">>> compute_signal called")
    try:
        with session.lock:
            log_debug(">>> Lock acquired")
            if not session.option_chain or session.atm_strike is None:
                log_debug(">>> No option chain or ATM strike -> HOLD")
                session.last_metrics = {}
                session.last_signal = "HOLD"
                return "HOLD", {}
            underlying_ltp = session.get_ltp("NSE:NIFTY50-INDEX")
            if underlying_ltp is None:
                log_debug(">>> No underlying LTP -> HOLD")
                session.last_metrics = {}
                session.last_signal = "HOLD"
                return "HOLD", {}
            log_debug(f">>> Underlying LTP: {underlying_ltp}, ATM: {session.atm_strike}")

            strikes = sorted(set(opt["strike_price"] for opt in session.option_chain if opt.get("option_type") in ("CE","PE")))
            if not strikes or session.atm_strike not in strikes:
                log_debug(">>> No valid strikes -> HOLD")
                session.last_metrics = {}
                session.last_signal = "HOLD"
                return "HOLD", {}
            idx = strikes.index(session.atm_strike)
            selected = [session.atm_strike]
            if idx > 0: selected.append(strikes[idx-1])
            if idx < len(strikes)-1: selected.append(strikes[idx+1])
            log_debug(f">>> Selected strikes: {selected}")

            idwps, inofs, ce_moms, pe_moms = [], [], [], []
            for strike in selected:
                ce = next((o for o in session.option_chain if o["strike_price"] == strike and o["option_type"] == "CE"), None)
                pe = next((o for o in session.option_chain if o["strike_price"] == strike and o["option_type"] == "PE"), None)
                if not ce or not pe:
                    log_debug(f">>> Strike {strike} missing CE/PE")
                    continue
                ce_ltp = session.get_ltp(ce["symbol"]) or ce.get("ltp", 0)
                pe_ltp = session.get_ltp(pe["symbol"]) or pe.get("ltp", 0)
                ce_vwap = session.get_vwap(ce["symbol"]) or ce_ltp
                pe_vwap = session.get_vwap(pe["symbol"]) or pe_ltp
                ce_current_vol = session.get_volume(ce["symbol"]) or ce.get("volume", 0)
                pe_current_vol = session.get_volume(pe["symbol"]) or pe.get("volume", 0)
                ce_delta = ce.get("greeks", {}).get("delta", 0)
                pe_delta = abs(pe.get("greeks", {}).get("delta", 0))
                parity = (ce_ltp - pe_ltp) / (ce_ltp + pe_ltp) if (ce_ltp + pe_ltp) != 0 else 0

                ce_prev = session.prev_ce_volume.get(ce["symbol"], ce_current_vol)
                pe_prev = session.prev_pe_volume.get(pe["symbol"], pe_current_vol)
                diff_ce = max(0, ce_current_vol - ce_prev)
                diff_pe = max(0, pe_current_vol - pe_prev)

                session.prev_ce_volume[ce["symbol"]] = ce_current_vol
                session.prev_pe_volume[pe["symbol"]] = pe_current_vol

                inof = (diff_ce * ce_delta) - (diff_pe * pe_delta)
                ce_mom = ce_ltp - ce_vwap
                pe_mom = pe_ltp - pe_vwap
                idwps.append(parity)
                inofs.append(inof)
                ce_moms.append(ce_mom)
                pe_moms.append(pe_mom)
                log_debug(f">>> Strike {strike}: parity={parity:.4f}, inof={inof:.2f}")

            if not idwps:
                log_debug(">>> No valid idwps -> HOLD")
                session.last_metrics = {}
                session.last_signal = "HOLD"
                return "HOLD", {}

            idwp = sum(idwps)/len(idwps)
            inof = sum(inofs)
            avg_ce_mom = sum(ce_moms)/len(ce_moms) if ce_moms else 0.0
            avg_pe_mom = sum(pe_moms)/len(pe_moms) if pe_moms else 0.0
            composite = avg_ce_mom - avg_pe_mom
            log_debug(f">>> Raw: idwp={idwp:.4f}, inof={inof:.2f}, composite={composite:.4f}")

            session.current_idwp = idwp

            level_inof, vel_inof = session.kalman_inof.update(inof)
            level_comp, vel_comp = session.kalman_composite.update(composite)

            session.velocity_inof = vel_inof
            session.velocity_composite = vel_comp
            session.kalman_update_count += 1

            signal = "HOLD"

            # Exit logic – only if position is active and we have a symbol
            if session.position in ("LONG", "SHORT") and session.held_option_symbol is not None:
                opt_ltp = session.get_ltp(session.held_option_symbol)
                if opt_ltp is not None:
                    exit_reason = None
                    if opt_ltp > session.peak_opt_price:
                        session.peak_opt_price = opt_ltp
                    trailing_stop = session.peak_opt_price * (1 - session.current_sl_pct)
                    fixed_stop = session.option_stop_price
                    target = session.option_target_price
                    if opt_ltp <= fixed_stop:
                        exit_reason = f"Fixed SL hit: {opt_ltp:.2f} <= {fixed_stop:.2f}"
                    elif opt_ltp <= trailing_stop:
                        exit_reason = f"Trailing SL hit: {opt_ltp:.2f} <= {trailing_stop:.2f}"
                    elif opt_ltp >= target:
                        exit_reason = f"Target hit: {opt_ltp:.2f} >= {target:.2f}"
                    if exit_reason:
                        log_console(exit_reason)
                        signal = "EXIT"

            # Entry logic – only if flat, not exiting, warm-up complete, and momentum divergence condition
            if (session.position == "FLAT" and signal != "EXIT"
                    and session.kalman_update_count >= Config.KALMAN_WARMUP_UPDATES
                    and (avg_pe_mom * avg_ce_mom < 0)):

                curr_pos_inof = session.velocity_inof > Config.SIGNAL_THRESHOLD
                curr_pos_comp = session.velocity_composite > Config.SIGNAL_THRESHOLD
                curr_neg_inof = session.velocity_inof < -Config.SIGNAL_THRESHOLD
                curr_neg_comp = session.velocity_composite < -Config.SIGNAL_THRESHOLD

                prev_pos_inof = session.prev_velocity_inof > Config.SIGNAL_THRESHOLD
                prev_pos_comp = session.prev_velocity_composite > Config.SIGNAL_THRESHOLD
                prev_neg_inof = session.prev_velocity_inof < -Config.SIGNAL_THRESHOLD
                prev_neg_comp = session.prev_velocity_composite < -Config.SIGNAL_THRESHOLD

                if curr_pos_inof and curr_pos_comp and not (prev_pos_inof and prev_pos_comp):
                    log_debug(f">>> BUY triggered (vel_inof={session.velocity_inof:.2f}, vel_comp={session.velocity_composite:.2f})")
                    signal = "BUY"
                elif curr_neg_inof and curr_neg_comp and not (prev_neg_inof and prev_neg_comp):
                    log_debug(f">>> SELL triggered (vel_inof={session.velocity_inof:.2f}, vel_comp={session.velocity_composite:.2f})")
                    signal = "SELL"

            # Store previous velocities for next crossover
            session.prev_velocity_inof = session.velocity_inof
            session.prev_velocity_composite = session.velocity_composite

            metrics = {
                "spot": underlying_ltp,
                "atm_strike": session.atm_strike,
                "inof_raw": inof,
                "inof_level": level_inof,
                "inof_velocity": vel_inof,
                "comp_raw": composite,
                "comp_level": level_comp,
                "comp_velocity": vel_comp,
                "avg_ce_mom": avg_ce_mom,
                "avg_pe_mom": avg_pe_mom,
            }
            session.last_metrics = metrics
            session.last_signal = signal
            return signal, metrics
    except Exception as e:
        log_debug(f"CRASH in compute_signal: {e}\n{traceback.format_exc()}")
        session.last_metrics = {}
        session.last_signal = "HOLD"
        return "HOLD", {}

# ============================================================
# ORDER PLACEMENT
# ============================================================
def place_order(session, signal, atm_ce, atm_pe, fyers, entry_metrics=None):
    if getattr(session, '_hb_lock', False):
        return False
    session._hb_lock = True
    try:
        if signal == "EXIT":
            log_console("🟡 EXIT signal – closing positions")
            if PAPER_MODE:
                if session.held_option_symbol:
                    current_ltp = session.get_ltp(session.held_option_symbol)
                    if current_ltp is not None:
                        pnl = (current_ltp - session.option_entry_price) * Config.LOT_SIZE
                        session.paper_realized_pnl += pnl
                        log_console(f"📊 Paper trade closed: P&L = {pnl:+.2f}")
                    else:
                        for opt in session.option_chain:
                            if opt["symbol"] == session.held_option_symbol:
                                current_ltp = opt.get("ltp", 0)
                                pnl = (current_ltp - session.option_entry_price) * Config.LOT_SIZE
                                session.paper_realized_pnl += pnl
                                log_console(f"📊 Paper trade closed (est): P&L = {pnl:+.2f}")
                                break
                session.position = "FLAT"
                session.held_option_symbol = None
                session.option_stop_price = 0.0
                session.option_target_price = 0.0
                session.peak_opt_price = 0.0
                return True
            else:
                fyers.exit_positions(data={"segment": [11], "side": [-1], "productType": ["MARGIN"]})
                fyers.exit_positions(data={"segment": [11], "side": [1], "productType": ["MARGIN"]})
                time.sleep(2)
                session.position = "FLAT"
                session.held_option_symbol = None
                session.option_stop_price = 0.0
                session.option_target_price = 0.0
                session.peak_opt_price = 0.0
                return True

        if signal in ("BUY","SELL") and session.can_place_order(fyers):
            leg = atm_ce if signal == "BUY" else atm_pe
            if not leg:
                return False

            if PAPER_MODE:
                current_opt_ltp = session.get_ltp(leg["symbol"])
                if current_opt_ltp is None:
                    for opt in session.option_chain:
                        if opt["symbol"] == leg["symbol"]:
                            current_opt_ltp = opt.get("ltp", 0)
                            break
                if current_opt_ltp is None or current_opt_ltp <= 0:
                    log_console("❌ Paper entry failed: invalid option price")
                    return False

                side = "LONG" if signal == "BUY" else "SHORT"
                session.position = side
                session.held_option_symbol = leg["symbol"]
                session.option_entry_price = current_opt_ltp
                session.entry_vix = session.india_vix
                sl_pct = (session.india_vix / 100.0) * Config.OPTION_TRAIL_MULTIPLIER
                sl_pct = max(0.01, sl_pct)
                session.current_sl_pct = sl_pct
                session.option_stop_price = current_opt_ltp * (1 - sl_pct)
                session.option_target_price = current_opt_ltp * (1 + Config.TARGET_MULTIPLIER * sl_pct)
                session.peak_opt_price = current_opt_ltp
                log_console(f"🟢 {signal} – PAPER {side} entry: {leg['symbol']} at {current_opt_ltp:.2f}")
                log_console(f"   SL: {session.option_stop_price:.2f}, Target: {session.option_target_price:.2f}")
                session.daily_executed_orders += 1
                return True
            else:
                order = {
                    "symbol": leg["symbol"],
                    "qty": Config.LOT_SIZE,
                    "type": 2,
                    "side": 1,
                    "productType": "MARGIN",
                    "validity": "DAY",
                }
                side = "LONG" if signal == "BUY" else "SHORT"
                log_console(f"🟢 {signal} – placing {side} order (buy {leg['symbol']})")
                resp = fyers.place_order(data=order)
                if resp.get("s") == "ok":
                    session.position = side
                    session.held_option_symbol = leg["symbol"]
                    current_opt_ltp = session.get_ltp(leg["symbol"]) or leg.get("ltp", 0)
                    session.option_entry_price = current_opt_ltp
                    session.entry_vix = session.india_vix
                    sl_pct = (session.india_vix / 100.0) * Config.OPTION_TRAIL_MULTIPLIER
                    sl_pct = max(0.01, sl_pct)
                    session.current_sl_pct = sl_pct
                    session.option_stop_price = current_opt_ltp * (1 - sl_pct)
                    session.option_target_price = current_opt_ltp * (1 + Config.TARGET_MULTIPLIER * sl_pct)
                    session.peak_opt_price = current_opt_ltp
                    log_console(f"✓ {side} entry at {current_opt_ltp:.2f}")
                    return True
        return False
    except Exception as e:
        log_console(f"Order error: {e}")
        return False
    finally:
        session._hb_lock = False

# ============================================================
# SAMPLER THREAD
# ============================================================
last_signal_logged = None

def sampler(session, data_logger, auto_trade, fyers):
    global last_signal_logged
    log_debug("Sampler thread started")
    while session.running:
        start = now_ist()
        try:
            signal, metrics = compute_signal(session)
            if metrics:
                opt_symbol = session.held_option_symbol if session.held_option_symbol else ''
                opt_entry = session.option_entry_price if session.held_option_symbol else 0.0
                # FIX: handle None from get_ltp
                opt_current = (session.get_ltp(opt_symbol) or 0.0) if opt_symbol else 0.0
                opt_stop = session.option_stop_price if session.held_option_symbol else 0.0
                opt_target = session.option_target_price if session.held_option_symbol else 0.0
                peak = session.peak_opt_price if session.held_option_symbol else 0.0
                trailing_stop = peak * (1 - session.current_sl_pct) if session.held_option_symbol else 0.0
                vix = session.india_vix
                sl_pct = session.current_sl_pct if session.held_option_symbol else 0.0

                paper_pnl = session.paper_realized_pnl
                if session.position in ("LONG", "SHORT") and opt_current:
                    unrealized = (opt_current - opt_entry) * Config.LOT_SIZE
                    paper_pnl += unrealized

                data_logger.log_data(
                    timestamp=timestamp_ist(),
                    underlying_ltp=metrics.get("spot", 0),
                    fut_price=session.fut_price or 0,
                    signal=signal,
                    atm_strike=metrics.get("atm_strike", 0),
                    expiry_date=session.expiry_date or "",
                    idwp=session.current_idwp,
                    inof_raw=metrics.get("inof_raw", 0),
                    inof_level=metrics.get("inof_level", 0),
                    inof_velocity=metrics.get("inof_velocity", 0),
                    comp_raw=metrics.get("comp_raw", 0),
                    comp_level=metrics.get("comp_level", 0),
                    comp_velocity=metrics.get("comp_velocity", 0),
                    avg_ce_mom=metrics.get("avg_ce_mom", 0),
                    avg_pe_mom=metrics.get("avg_pe_mom", 0),
                    position=session.position,
                    opt_symbol=opt_symbol,
                    opt_entry=opt_entry,
                    opt_current=opt_current,
                    opt_stop=opt_stop,
                    opt_target=opt_target,
                    trailing_stop=trailing_stop,
                    peak_opt_price=peak,
                    vix=vix,
                    sl_pct=sl_pct,
                    paper_pnl=paper_pnl
                )

                if signal != last_signal_logged and signal != "HOLD":
                    log_console(f"📢 Signal changed to: {signal}")
                    last_signal_logged = signal

            if auto_trade and signal in ("BUY","SELL","EXIT"):
                atm_ce = atm_pe = None
                if session.atm_strike:
                    for opt in session.option_chain:
                        if opt["strike_price"] == session.atm_strike:
                            if opt["option_type"] == "CE":
                                atm_ce = {"symbol": opt["symbol"]}
                            elif opt["option_type"] == "PE":
                                atm_pe = {"symbol": opt["symbol"]}
                if signal == "EXIT":
                    place_order(session, signal, None, None, fyers, None)
                elif signal == "BUY" and atm_ce:
                    place_order(session, signal, atm_ce, None, fyers, metrics)
                elif signal == "SELL" and atm_pe:
                    place_order(session, signal, None, atm_pe, fyers, metrics)
            elapsed = (now_ist() - start).total_seconds()
            if elapsed < Config.SAMPLE_INTERVAL:
                time.sleep(Config.SAMPLE_INTERVAL - elapsed)
        except Exception as e:
            log_debug(f"Sampler error: {e}\n{traceback.format_exc()}")
            time.sleep(1)

# ============================================================
# CREDENTIALS
# ============================================================
def load_credentials(session):
    try:
        with open('fyers_credentials.json', 'r') as f:
            creds = json.load(f)
            session.cid = creds.get('client_id', '')
            session.token = creds.get('access_token', '')
        log_console(f"Loaded credentials: {session.cid}")
    except Exception as e:
        session.cid = os.getenv("FYERS_CID", "")
        session.token = os.getenv("FYERS_TOKEN", "")
        log_console(f"Using env vars: {session.cid}")

# ============================================================
# MAIN
# ============================================================
def main():
    log_console("Starting Algo Trading System...")
    session = SessionState()
    load_credentials(session)
    data_logger = DataLogger()
    dashboard = TerminalDashboard(data_logger, session)
    index_symbol = "NSE:NIFTY50-INDEX"
    vix_symbol = "NSE:INDIAVIX-INDEX"

    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        print("="*50)
        mode = "PAPER" if PAPER_MODE else "LIVE"
        print(f"📈 FYERS ALGO TRADING ({mode} MODE)")
        print("1. Start Trading")
        print("2. Settings")
        print("3. Exit")
        choice = input("Select option: ").strip()
        if choice == "1":
            if not (session.cid and session.token):
                print("❌ Set credentials first")
                input("Press Enter...")
                continue
            auto_trade = input("Enable Auto Trade? (y/n): ").lower() == 'y'
            log_console(f"Auto trade: {'ON' if auto_trade else 'OFF'}")
            ws_manager = MarketWSManager(session, session.token)
            ws_manager.start()
            ws_manager.subscribe([index_symbol, vix_symbol])
            session.running = True
            threading.Thread(target=chain_poller, args=(session, ws_manager, index_symbol), daemon=True).start()
            fyers = fyersModel.FyersModel(client_id=session.cid, token=session.token, is_async=False, log_path="")
            threading.Thread(target=sampler, args=(session, data_logger, auto_trade, fyers), daemon=True).start()
            print("\n✅ Trading started. Press Ctrl+C to stop.\n")
            try:
                while True:
                    dashboard.display()
                    time.sleep(2)
            except KeyboardInterrupt:
                session.running = False
                ws_manager.stop()
                log_console("\n🛑 Trading stopped by user")
        elif choice == "2":
            print("\n⚙️ SETTINGS")
            new_cid = input(f"Client ID [{session.cid}]: ").strip()
            if new_cid:
                session.cid = new_cid
            new_token = input("Access token: ").strip()
            if new_token:
                session.token = new_token
            with open('fyers_credentials.json', 'w') as f:
                json.dump({"client_id": session.cid, "access_token": session.token}, f)
            print("✅ Saved")
            input("Press Enter...")
        elif choice == "3":
            break

if __name__ == "__main__":
    main()