import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import time
import threading
import json
import os
import csv
import logging
import queue
from datetime import datetime, timedelta
from collections import deque
import numpy as np

try:
    import pandas as pd
    PANDAS_OK = True
except ImportError:
    PANDAS_OK = False

try:
    import pytz
    IST = pytz.timezone("Asia/Kolkata")
    def now_ist():
        return datetime.now(IST)
except ImportError:
    IST = None
    def now_ist():
        return datetime.now()

def timestamp_ist():
    return now_ist().strftime("%Y-%m-%d %H:%M:%S")

# ============================================================
# CONFIG
# ============================================================
class Config:
    REFRESH_INTERVAL   = 60
    API_RATE_LIMIT     = 200
    API_WINDOW         = 60
    LOT_SIZE           = 65
    MAX_RETRIES        = 3
    RETRY_DELAY        = 2
    MAX_DAILY_ORDERS   = 8
    ROLLING_WINDOW_SIZE= 15
    TRAIL_STOP_PCT     = 0.25
    ENTRY_STD_MULTIPLIER = 1.5

# ============================================================
# LOGGING
# ============================================================
logging.basicConfig(
    filename="trading_app.log",
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)

def debug_msg(msg):
    logging.debug(msg)

log_queue = queue.Queue()

def gui_log(msg, level="INFO"):
    log_queue.put((timestamp_ist(), level, msg))
    logging.info(msg)

# ============================================================
# SESSION STATE
# ============================================================
class SessionState:
    def __init__(self):
        self.option_chain_api_count = 0
        self.quote_api_count = 0
        self.api_window_start = now_ist()
        self.last_signal = None
        self.cid = ""
        self.token = ""
        self._hb_lock = False
        self.daily_executed_orders = 0
        self.last_order_sync = None
        self.idwp_window = deque(maxlen=Config.ROLLING_WINDOW_SIZE)
        self.inof_window = deque(maxlen=Config.ROLLING_WINDOW_SIZE)
        self.window_filled = False
        self.composite_window = deque(maxlen=Config.ROLLING_WINDOW_SIZE)
        self.composite_initialized = False
        self.ema_composite = 0.0
        self.position = "FLAT"
        self.peak_cumul_inof = 0.0
        self.trough_cumul_inof = 0.0
        self.prev_cumul_composite = 0.0
        self.prev_cumul_inof = 0.0

# ============================================================
# DATA LOGGER
# ============================================================
class DataLogger:
    def __init__(self, filename="trading_data.csv"):
        self.filename = filename
        self._ensure_header()

    def _ensure_header(self):
        try:
            with open(self.filename, 'r'):
                pass
        except FileNotFoundError:
            with open(self.filename, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'timestamp','underlying_ltp','fut_price','signal','atm_strike',
                    'expiry_date','idwp','inof','cumul_idwp','cumul_inof',
                    'vwap_composite','cumul_vwap_composite','position'
                ])

    def log_data(self, timestamp, underlying_ltp, fut_price, signal, atm_strike,
                 expiry_date, idwp, inof, cumul_idwp, cumul_inof,
                 vwap_composite, cumul_vwap_composite, position):
        with open(self.filename, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                str(timestamp),
                float(underlying_ltp) if underlying_ltp is not None else 0.0,
                float(fut_price) if fut_price is not None else 0.0,
                str(signal),
                int(atm_strike) if atm_strike is not None else 0,
                str(expiry_date),
                round(float(idwp), 2),
                round(float(inof), 2),
                round(float(cumul_idwp), 2),
                round(float(cumul_inof), 2),
                round(float(vwap_composite), 2),
                round(float(cumul_vwap_composite), 2),
                str(position)
            ])

    def read_data(self, limit=None):
        try:
            if PANDAS_OK:
                df = pd.read_csv(self.filename)
                if limit:
                    return df.tail(limit)
                return df
        except Exception:
            pass
        return None


# ============================================================
# COLOUR PALETTE
# ============================================================
C = {
    "bg":         "#0B0E14",
    "panel":      "#111520",
    "panel2":     "#161C2A",
    "border":     "#1E2840",
    "accent":     "#00C8FF",
    "accent2":    "#7B61FF",
    "green":      "#00E676",
    "red":        "#FF1744",
    "yellow":     "#FFD600",
    "text":       "#E8EDF5",
    "text_dim":   "#5A6785",
    "text_mid":   "#8A99B8",
    "buy_bg":     "#002A18",
    "sell_bg":    "#2A0010",
    "hold_bg":    "#1A1E0A",
    "exit_bg":    "#1A1430",
    "card_glow":  "#00C8FF22",
}

FONTS = {
    "display":  ("Courier New", 22, "bold"),
    "title":    ("Courier New", 13, "bold"),
    "label":    ("Courier New", 9),
    "value":    ("Courier New", 14, "bold"),
    "value_sm": ("Courier New", 10, "bold"),
    "mono":     ("Courier New", 9),
    "mono_sm":  ("Courier New", 8),
    "badge":    ("Courier New", 11, "bold"),
    "nav":      ("Courier New", 10, "bold"),
}

# ============================================================
# MAIN APPLICATION
# ============================================================
class TradingApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("NIFTY ALGO — FYERS TRADING TERMINAL")
        self.configure(bg=C["bg"])
        self.geometry("1280x800")
        self.minsize(1100, 720)

        self.session_state = SessionState()
        self.data_logger   = DataLogger()

        self._trading_thread  = None
        self._trading_active  = False
        self._auto_trade      = tk.BooleanVar(value=False)
        self._status_text     = tk.StringVar(value="IDLE")
        self._clock_text      = tk.StringVar(value="")
        self._signal_data     = {}   # latest signal metrics
        self._history_rows    = []   # for history table

        self._build_ui()
        self._start_clock()
        self._poll_logs()
        self._load_credentials_ui()

    # ─────────────────────────────────────────────
    # UI BUILD
    # ─────────────────────────────────────────────
    def _build_ui(self):
        # ── Top bar
        top = tk.Frame(self, bg=C["panel"], height=56)
        top.pack(fill="x", side="top")
        top.pack_propagate(False)
        self._build_topbar(top)

        # ── Body: sidebar + main content
        body = tk.Frame(self, bg=C["bg"])
        body.pack(fill="both", expand=True)

        sidebar = tk.Frame(body, bg=C["panel"], width=220)
        sidebar.pack(fill="y", side="left")
        sidebar.pack_propagate(False)
        self._build_sidebar(sidebar)

        content = tk.Frame(body, bg=C["bg"])
        content.pack(fill="both", expand=True)

        # Notebook pages
        self._nb = self._make_notebook(content)

        # Status bar
        self._build_statusbar()

    # ── TOP BAR ─────────────────────────────────
    def _build_topbar(self, parent):
        # Logo
        logo_frame = tk.Frame(parent, bg=C["panel"])
        logo_frame.pack(side="left", padx=20)

        tk.Label(logo_frame, text="▲", font=("Courier New", 18, "bold"),
                 fg=C["accent"], bg=C["panel"]).pack(side="left")
        tk.Label(logo_frame, text=" NIFTY ALGO", font=("Courier New", 16, "bold"),
                 fg=C["text"], bg=C["panel"]).pack(side="left")
        tk.Label(logo_frame, text="  FYERS v3", font=("Courier New", 9),
                 fg=C["text_dim"], bg=C["panel"]).pack(side="left", pady=(6,0))

        # Clock
        tk.Label(parent, textvariable=self._clock_text,
                 font=("Courier New", 10), fg=C["accent"], bg=C["panel"]).pack(side="right", padx=20)

        # Status pill
        self._status_pill = tk.Label(parent, textvariable=self._status_text,
                                     font=("Courier New", 9, "bold"),
                                     fg=C["bg"], bg=C["text_dim"],
                                     padx=10, pady=3)
        self._status_pill.pack(side="right", padx=10)

    # ── SIDEBAR ─────────────────────────────────
    def _build_sidebar(self, parent):
        tk.Frame(parent, bg=C["border"], height=1).pack(fill="x")

        nav_items = [
            ("◉  DASHBOARD",  "dashboard"),
            ("⚡  LIVE TRADING", "trading"),
            ("⚙  SETTINGS",  "settings"),
            ("📋  LOG",        "log"),
        ]

        self._nav_var = tk.StringVar(value="dashboard")
        self._nav_btns = {}

        for label, key in nav_items:
            btn = tk.Button(
                parent, text=label, font=FONTS["nav"],
                fg=C["text_mid"], bg=C["panel"],
                activeforeground=C["accent"], activebackground=C["panel2"],
                relief="flat", bd=0, anchor="w", padx=20, pady=14,
                cursor="hand2",
                command=lambda k=key: self._nav_goto(k)
            )
            btn.pack(fill="x")
            self._nav_btns[key] = btn

        tk.Frame(parent, bg=C["border"], height=1).pack(fill="x", pady=(10,0))

        # Credentials indicator
        self._cred_indicator = tk.Label(
            parent, text="⬤  NO CREDENTIALS",
            font=("Courier New", 8), fg=C["red"], bg=C["panel"],
            anchor="w", padx=20
        )
        self._cred_indicator.pack(fill="x", pady=(10,0))

        # Daily order progress
        tk.Label(parent, text="DAILY ORDERS", font=("Courier New", 8),
                 fg=C["text_dim"], bg=C["panel"], anchor="w", padx=20).pack(fill="x", pady=(18,2))

        self._order_bar_frame = tk.Frame(parent, bg=C["panel"])
        self._order_bar_frame.pack(fill="x", padx=20)
        self._order_bar_bg = tk.Frame(self._order_bar_frame, bg=C["border"], height=6)
        self._order_bar_bg.pack(fill="x")
        self._order_bar_fg = tk.Frame(self._order_bar_frame, bg=C["accent2"], height=6)

        self._order_count_label = tk.Label(
            parent, text="0 / 8",
            font=("Courier New", 10, "bold"), fg=C["text"], bg=C["panel"],
            anchor="w", padx=20
        )
        self._order_count_label.pack(fill="x", pady=(4,0))

        # Position badge
        tk.Label(parent, text="POSITION", font=("Courier New", 8),
                 fg=C["text_dim"], bg=C["panel"], anchor="w", padx=20).pack(fill="x", pady=(18,4))
        self._pos_badge = tk.Label(
            parent, text="FLAT",
            font=("Courier New", 13, "bold"),
            fg=C["text_dim"], bg=C["border"],
            padx=14, pady=6
        )
        self._pos_badge.pack(padx=20, anchor="w")

        # Version
        tk.Label(parent, text="v3.0 — IST", font=("Courier New", 7),
                 fg=C["text_dim"], bg=C["panel"], anchor="w", padx=20).pack(
                     fill="x", side="bottom", pady=8)

    # ── NOTEBOOK ────────────────────────────────
    def _make_notebook(self, parent):
        nb = tk.Frame(parent, bg=C["bg"])
        nb.pack(fill="both", expand=True)

        self._pages = {}
        for key in ("dashboard", "trading", "settings", "log"):
            frame = tk.Frame(nb, bg=C["bg"])
            self._pages[key] = frame

        self._build_page_dashboard(self._pages["dashboard"])
        self._build_page_trading(self._pages["trading"])
        self._build_page_settings(self._pages["settings"])
        self._build_page_log(self._pages["log"])

        self._nav_goto("dashboard")
        return nb

    def _nav_goto(self, key):
        self._nav_var.set(key)
        for k, frame in self._pages.items():
            frame.pack_forget()
        self._pages[key].pack(fill="both", expand=True)
        # Highlight active nav
        for k, btn in self._nav_btns.items():
            if k == key:
                btn.config(fg=C["accent"], bg=C["panel2"])
            else:
                btn.config(fg=C["text_mid"], bg=C["panel"])

    # ── STATUS BAR ──────────────────────────────
    def _build_statusbar(self):
        bar = tk.Frame(self, bg=C["panel"], height=28)
        bar.pack(fill="x", side="bottom")
        bar.pack_propagate(False)
        tk.Frame(bar, bg=C["border"], height=1).pack(fill="x", side="top")
        self._statusbar_msg = tk.StringVar(value="Ready — connect to Fyers to begin.")
        tk.Label(bar, textvariable=self._statusbar_msg,
                 font=("Courier New", 8), fg=C["text_dim"], bg=C["panel"],
                 anchor="w", padx=12).pack(fill="x", side="left")
        tk.Label(bar, text="NIFTY50-INDEX  •  FYERS API v3",
                 font=("Courier New", 8), fg=C["text_dim"], bg=C["panel"],
                 anchor="e", padx=12).pack(fill="x", side="right")

    # ============================================================
    # PAGE — DASHBOARD
    # ============================================================
    def _build_page_dashboard(self, parent):
        parent.columnconfigure(0, weight=3)
        parent.columnconfigure(1, weight=2)
        parent.rowconfigure(0, weight=0)
        parent.rowconfigure(1, weight=1)

        # ── Row 0: KPI cards
        kpi_row = tk.Frame(parent, bg=C["bg"])
        kpi_row.grid(row=0, column=0, columnspan=2, sticky="ew", padx=16, pady=(16,8))

        kpi_defs = [
            ("NIFTY LTP",       "ltp",            C["accent"],  "—"),
            ("FUT PRICE",       "fut_price",       C["accent2"], "—"),
            ("ATM STRIKE",      "atm_strike",      C["yellow"],  "—"),
            ("SIGNAL",          "signal",          C["green"],   "HOLD"),
            ("EXPIRY",          "expiry",          C["text_mid"],"—"),
        ]
        self._kpi_vars = {}
        for i, (title, key, color, default) in enumerate(kpi_defs):
            card = self._make_kpi_card(kpi_row, title, default, color)
            card.grid(row=0, column=i, padx=6, sticky="ew")
            kpi_row.columnconfigure(i, weight=1)
            self._kpi_vars[key] = card._value_var

        # ── Row 1 left: metrics panel
        metrics_frame = tk.Frame(parent, bg=C["panel"], bd=0,
                                 highlightthickness=1, highlightbackground=C["border"])
        metrics_frame.grid(row=1, column=0, padx=(16,8), pady=(0,16), sticky="nsew")
        self._build_metrics_panel(metrics_frame)

        # ── Row 1 right: history table
        hist_frame = tk.Frame(parent, bg=C["panel"], bd=0,
                              highlightthickness=1, highlightbackground=C["border"])
        hist_frame.grid(row=1, column=1, padx=(8,16), pady=(0,16), sticky="nsew")
        self._build_history_panel(hist_frame)

    def _make_kpi_card(self, parent, title, default, color):
        card = tk.Frame(parent, bg=C["panel"], bd=0,
                        highlightthickness=1, highlightbackground=C["border"])
        card._value_var = tk.StringVar(value=default)
        tk.Label(card, text=title, font=("Courier New", 8),
                 fg=C["text_dim"], bg=C["panel"], anchor="w",
                 padx=14).pack(fill="x", pady=(10, 0))
        tk.Label(card, textvariable=card._value_var,
                 font=("Courier New", 15, "bold"),
                 fg=color, bg=C["panel"], anchor="w",
                 padx=14).pack(fill="x", pady=(2, 10))
        return card

    def _build_metrics_panel(self, parent):
        hdr = tk.Frame(parent, bg=C["panel2"])
        hdr.pack(fill="x")
        tk.Label(hdr, text="▸ LIVE METRICS", font=FONTS["title"],
                 fg=C["accent"], bg=C["panel2"],
                 padx=14, pady=10).pack(side="left")

        canvas_frame = tk.Frame(parent, bg=C["panel"])
        canvas_frame.pack(fill="both", expand=True, padx=14, pady=10)

        metrics_defs = [
            ("IDWP",                 "idwp",              C["text"]),
            ("INOF",                 "inof",              C["text"]),
            ("CUMUL IDWP",           "cumul_idwp",        C["accent"]),
            ("CUMUL INOF",           "cumul_inof",        C["accent"]),
            ("VWAP COMPOSITE",       "vwap_composite",    C["accent2"]),
            ("CUMUL VWAP COMPOSITE", "cumul_vwap_composite", C["accent2"]),
            ("TRAIL PEAK (LONG)",    "peak_inof",         C["green"]),
            ("TRAIL TROUGH (SHORT)", "trough_inof",       C["red"]),
        ]

        self._metric_vars = {}
        for row_i, (label, key, color) in enumerate(metrics_defs):
            row_frame = tk.Frame(canvas_frame, bg=C["panel"])
            row_frame.pack(fill="x", pady=3)

            tk.Label(row_frame, text=label, font=("Courier New", 8),
                     fg=C["text_dim"], bg=C["panel"], width=24, anchor="w").pack(side="left")

            bar_container = tk.Frame(row_frame, bg=C["border"], height=4, width=160)
            bar_container.pack(side="left", padx=(6,6))
            bar_container.pack_propagate(False)
            bar_fill = tk.Frame(bar_container, bg=color, height=4, width=0)
            bar_fill.place(x=0, y=0, relheight=1)

            var = tk.StringVar(value="—")
            tk.Label(row_frame, textvariable=var, font=("Courier New", 10, "bold"),
                     fg=color, bg=C["panel"], width=10, anchor="e").pack(side="left")

            self._metric_vars[key] = (var, bar_fill)

        # Position trailing stop info
        tk.Frame(canvas_frame, bg=C["border"], height=1).pack(fill="x", pady=(10,8))
        self._trailing_label = tk.Label(canvas_frame, text="No active position",
                                        font=("Courier New", 9),
                                        fg=C["text_dim"], bg=C["panel"], anchor="w")
        self._trailing_label.pack(fill="x")

    def _build_history_panel(self, parent):
        hdr = tk.Frame(parent, bg=C["panel2"])
        hdr.pack(fill="x")
        tk.Label(hdr, text="▸ RECENT SIGNALS", font=FONTS["title"],
                 fg=C["accent"], bg=C["panel2"],
                 padx=14, pady=10).pack(side="left")

        cols = ["Time", "Signal", "LTP", "Cumul INOF", "Pos"]
        self._hist_tree = ttk.Treeview(parent, columns=cols, show="headings",
                                       height=14, selectmode="none")

        col_widths = [80, 62, 82, 100, 62]
        for col, w in zip(cols, col_widths):
            self._hist_tree.heading(col, text=col)
            self._hist_tree.column(col, width=w, anchor="center", minwidth=w)

        self._style_treeview()

        scrollbar = ttk.Scrollbar(parent, orient="vertical",
                                  command=self._hist_tree.yview)
        self._hist_tree.configure(yscrollcommand=scrollbar.set)
        self._hist_tree.pack(side="left", fill="both", expand=True, padx=(14,0), pady=10)
        scrollbar.pack(side="right", fill="y", pady=10, padx=(0,8))

        # Tag colours
        self._hist_tree.tag_configure("BUY",  background="#002A18", foreground=C["green"])
        self._hist_tree.tag_configure("SELL", background="#2A0010", foreground=C["red"])
        self._hist_tree.tag_configure("EXIT", background="#1A1430", foreground=C["accent2"])
        self._hist_tree.tag_configure("HOLD", background=C["panel"], foreground=C["text_dim"])
        self._hist_tree.tag_configure("alt",  background=C["panel2"])

    def _style_treeview(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Treeview",
                        background=C["panel"],
                        foreground=C["text"],
                        fieldbackground=C["panel"],
                        rowheight=26,
                        borderwidth=0,
                        font=("Courier New", 8))
        style.configure("Treeview.Heading",
                        background=C["panel2"],
                        foreground=C["text_dim"],
                        borderwidth=0,
                        font=("Courier New", 8, "bold"))
        style.map("Treeview",
                  background=[("selected", C["border"])],
                  foreground=[("selected", C["accent"])])
        style.configure("Vertical.TScrollbar",
                        background=C["panel"],
                        troughcolor=C["border"],
                        arrowcolor=C["text_dim"])

    # ============================================================
    # PAGE — LIVE TRADING
    # ============================================================
    def _build_page_trading(self, parent):
        # Header
        hdr = tk.Frame(parent, bg=C["panel2"],
                       highlightthickness=1, highlightbackground=C["border"])
        hdr.pack(fill="x", padx=16, pady=(16,10))
        tk.Label(hdr, text="⚡  LIVE TRADING CONTROL",
                 font=("Courier New", 13, "bold"),
                 fg=C["accent"], bg=C["panel2"],
                 padx=16, pady=12).pack(side="left")

        body = tk.Frame(parent, bg=C["bg"])
        body.pack(fill="both", expand=True, padx=16)
        body.columnconfigure(0, weight=1)
        body.columnconfigure(1, weight=1)

        # ── Left: controls
        ctrl = tk.Frame(body, bg=C["panel"],
                        highlightthickness=1, highlightbackground=C["border"])
        ctrl.grid(row=0, column=0, padx=(0,8), pady=4, sticky="nsew")
        self._build_trading_controls(ctrl)

        # ── Right: algo params
        params = tk.Frame(body, bg=C["panel"],
                          highlightthickness=1, highlightbackground=C["border"])
        params.grid(row=0, column=1, padx=(8,0), pady=4, sticky="nsew")
        self._build_algo_params(params)

    def _build_trading_controls(self, parent):
        tk.Label(parent, text="TRADING ENGINE", font=FONTS["title"],
                 fg=C["accent"], bg=C["panel2"],
                 padx=16, pady=10).pack(fill="x")

        body = tk.Frame(parent, bg=C["panel"])
        body.pack(fill="both", expand=True, padx=16, pady=10)

        # Auto-trade toggle
        tgl_frame = tk.Frame(body, bg=C["panel"])
        tgl_frame.pack(fill="x", pady=(6, 10))
        tk.Label(tgl_frame, text="AUTO TRADE", font=("Courier New", 9),
                 fg=C["text_dim"], bg=C["panel"]).pack(side="left")
        self._auto_cb = tk.Checkbutton(
            tgl_frame, variable=self._auto_trade,
            text="", bg=C["panel"],
            activebackground=C["panel"],
            selectcolor=C["accent2"],
            fg=C["accent2"], onvalue=True, offvalue=False,
            cursor="hand2"
        )
        self._auto_cb.pack(side="left", padx=8)
        self._auto_status = tk.Label(tgl_frame, text="OFF",
                                     font=("Courier New", 9, "bold"),
                                     fg=C["red"], bg=C["panel"])
        self._auto_status.pack(side="left")
        self._auto_trade.trace_add("write", self._on_auto_toggle)

        tk.Frame(body, bg=C["border"], height=1).pack(fill="x", pady=8)

        # Start/stop buttons
        self._start_btn = tk.Button(
            body, text="▶  START TRADING",
            font=("Courier New", 11, "bold"),
            fg=C["bg"], bg=C["green"],
            activeforeground=C["bg"], activebackground="#00B854",
            relief="flat", bd=0, pady=10,
            cursor="hand2", command=self._start_trading
        )
        self._start_btn.pack(fill="x", pady=(4,4))

        self._stop_btn = tk.Button(
            body, text="■  STOP TRADING",
            font=("Courier New", 11, "bold"),
            fg=C["bg"], bg=C["red"],
            activeforeground=C["bg"], activebackground="#CC1133",
            relief="flat", bd=0, pady=10,
            cursor="hand2", command=self._stop_trading,
            state="disabled"
        )
        self._stop_btn.pack(fill="x", pady=(0,8))

        tk.Frame(body, bg=C["border"], height=1).pack(fill="x", pady=8)

        # Stat display
        stat_defs = [
            ("Symbol",       "NSE:NIFTY50-INDEX"),
            ("Lot Size",     f"{Config.LOT_SIZE}"),
            ("Refresh (s)",  f"{Config.REFRESH_INTERVAL}"),
            ("Max Orders",   f"{Config.MAX_DAILY_ORDERS}"),
            ("Trail Stop %", f"{Config.TRAIL_STOP_PCT*100:.0f}%"),
            ("Roll Window",  f"{Config.ROLLING_WINDOW_SIZE}"),
        ]
        for label, val in stat_defs:
            r = tk.Frame(body, bg=C["panel"])
            r.pack(fill="x", pady=2)
            tk.Label(r, text=label, font=("Courier New", 8),
                     fg=C["text_dim"], bg=C["panel"], width=14, anchor="w").pack(side="left")
            tk.Label(r, text=val, font=("Courier New", 9, "bold"),
                     fg=C["text"], bg=C["panel"]).pack(side="left")

        # Engine state
        tk.Frame(body, bg=C["border"], height=1).pack(fill="x", pady=10)
        tk.Label(body, text="ENGINE STATE", font=("Courier New", 8),
                 fg=C["text_dim"], bg=C["panel"], anchor="w").pack(fill="x")
        self._engine_state = tk.Label(body, text="● STOPPED",
                                      font=("Courier New", 12, "bold"),
                                      fg=C["red"], bg=C["panel"], anchor="w")
        self._engine_state.pack(fill="x", pady=(4,0))

    def _build_algo_params(self, parent):
        tk.Label(parent, text="ALGO PARAMETERS", font=FONTS["title"],
                 fg=C["accent"], bg=C["panel2"],
                 padx=16, pady=10).pack(fill="x")

        body = tk.Frame(parent, bg=C["panel"])
        body.pack(fill="both", expand=True, padx=16, pady=10)

        params = [
            ("REFRESH_INTERVAL (s)",   "REFRESH_INTERVAL",    str(Config.REFRESH_INTERVAL)),
            ("LOT_SIZE",               "LOT_SIZE",            str(Config.LOT_SIZE)),
            ("MAX_DAILY_ORDERS",       "MAX_DAILY_ORDERS",    str(Config.MAX_DAILY_ORDERS)),
            ("ROLLING_WINDOW_SIZE",    "ROLLING_WINDOW_SIZE", str(Config.ROLLING_WINDOW_SIZE)),
            ("TRAIL_STOP_PCT",         "TRAIL_STOP_PCT",      str(Config.TRAIL_STOP_PCT)),
            ("ENTRY_STD_MULTIPLIER",   "ENTRY_STD_MULTIPLIER",str(Config.ENTRY_STD_MULTIPLIER)),
            ("MAX_RETRIES",            "MAX_RETRIES",         str(Config.MAX_RETRIES)),
            ("RETRY_DELAY (s)",        "RETRY_DELAY",         str(Config.RETRY_DELAY)),
        ]

        self._param_entries = {}
        for label, key, default in params:
            row = tk.Frame(body, bg=C["panel"])
            row.pack(fill="x", pady=4)
            tk.Label(row, text=label, font=("Courier New", 8),
                     fg=C["text_dim"], bg=C["panel"], width=22, anchor="w").pack(side="left")
            entry = tk.Entry(row, font=("Courier New", 9, "bold"),
                             fg=C["accent"], bg=C["border"],
                             insertbackground=C["accent"],
                             relief="flat", bd=0, width=10)
            entry.insert(0, default)
            entry.pack(side="left", padx=(6,0), ipady=4, ipadx=4)
            self._param_entries[key] = entry

        tk.Frame(body, bg=C["border"], height=1).pack(fill="x", pady=(14,8))

        apply_btn = tk.Button(
            body, text="↺  APPLY PARAMETERS",
            font=("Courier New", 9, "bold"),
            fg=C["accent"], bg=C["border"],
            activeforeground=C["accent"], activebackground=C["panel2"],
            relief="flat", bd=0, pady=8,
            cursor="hand2", command=self._apply_params
        )
        apply_btn.pack(fill="x")

    # ============================================================
    # PAGE — SETTINGS
    # ============================================================
    def _build_page_settings(self, parent):
        outer = tk.Frame(parent, bg=C["bg"])
        outer.pack(fill="both", expand=True, padx=16, pady=16)

        # Credentials card
        card = tk.Frame(outer, bg=C["panel"],
                        highlightthickness=1, highlightbackground=C["border"])
        card.pack(fill="x", pady=(0,12))

        tk.Label(card, text="⚿  FYERS CREDENTIALS",
                 font=("Courier New", 13, "bold"),
                 fg=C["accent"], bg=C["panel2"],
                 padx=16, pady=10).pack(fill="x")

        form = tk.Frame(card, bg=C["panel"])
        form.pack(fill="x", padx=16, pady=14)

        tk.Label(form, text="CLIENT ID", font=("Courier New", 8),
                 fg=C["text_dim"], bg=C["panel"], anchor="w").pack(fill="x")
        self._cid_entry = tk.Entry(form, font=("Courier New", 11),
                                    fg=C["text"], bg=C["border"],
                                    insertbackground=C["accent"],
                                    relief="flat", bd=0, show="")
        self._cid_entry.pack(fill="x", pady=(4,12), ipady=8, ipadx=8)

        tk.Label(form, text="ACCESS TOKEN", font=("Courier New", 8),
                 fg=C["text_dim"], bg=C["panel"], anchor="w").pack(fill="x")
        self._token_entry = tk.Entry(form, font=("Courier New", 11),
                                      fg=C["text"], bg=C["border"],
                                      insertbackground=C["accent"],
                                      relief="flat", bd=0, show="•")
        self._token_entry.pack(fill="x", pady=(4,12), ipady=8, ipadx=8)

        # Show/hide token
        show_frame = tk.Frame(form, bg=C["panel"])
        show_frame.pack(fill="x", pady=(0,8))
        self._show_token_var = tk.BooleanVar(value=False)
        tk.Checkbutton(show_frame, text="Show token",
                       variable=self._show_token_var,
                       font=("Courier New", 8),
                       fg=C["text_dim"], bg=C["panel"],
                       activebackground=C["panel"],
                       selectcolor=C["border"],
                       cursor="hand2",
                       command=self._toggle_token_visibility).pack(side="left")

        btn_row = tk.Frame(form, bg=C["panel"])
        btn_row.pack(fill="x", pady=(4,0))

        save_btn = tk.Button(
            btn_row, text="💾  SAVE CREDENTIALS",
            font=("Courier New", 9, "bold"),
            fg=C["bg"], bg=C["accent"],
            activeforeground=C["bg"], activebackground=C["accent2"],
            relief="flat", bd=0, pady=9, padx=16,
            cursor="hand2", command=self._save_credentials
        )
        save_btn.pack(side="left", padx=(0,8))

        clear_btn = tk.Button(
            btn_row, text="✕  CLEAR",
            font=("Courier New", 9, "bold"),
            fg=C["text_dim"], bg=C["border"],
            activeforeground=C["text"], activebackground=C["panel2"],
            relief="flat", bd=0, pady=9, padx=16,
            cursor="hand2", command=self._clear_credentials
        )
        clear_btn.pack(side="left")

        # Data file card
        data_card = tk.Frame(outer, bg=C["panel"],
                             highlightthickness=1, highlightbackground=C["border"])
        data_card.pack(fill="x", pady=(0,12))

        tk.Label(data_card, text="📁  DATA FILES",
                 font=("Courier New", 13, "bold"),
                 fg=C["accent"], bg=C["panel2"],
                 padx=16, pady=10).pack(fill="x")

        dform = tk.Frame(data_card, bg=C["panel"])
        dform.pack(fill="x", padx=16, pady=12)

        file_btns = [
            ("Open trading_data.csv", lambda: self._open_file("trading_data.csv")),
            ("Open trading_app.log",  lambda: self._open_file("trading_app.log")),
            ("Clear CSV data",        self._clear_csv),
        ]
        for label, cmd in file_btns:
            tk.Button(
                dform, text=label,
                font=("Courier New", 8, "bold"),
                fg=C["text_dim"], bg=C["border"],
                activeforeground=C["text"], activebackground=C["panel2"],
                relief="flat", bd=0, pady=7, padx=12,
                cursor="hand2", command=cmd
            ).pack(side="left", padx=(0,8))

    # ============================================================
    # PAGE — LOG
    # ============================================================
    def _build_page_log(self, parent):
        hdr = tk.Frame(parent, bg=C["panel2"],
                       highlightthickness=1, highlightbackground=C["border"])
        hdr.pack(fill="x", padx=16, pady=(16,0))

        tk.Label(hdr, text="📋  ACTIVITY LOG",
                 font=("Courier New", 13, "bold"),
                 fg=C["accent"], bg=C["panel2"],
                 padx=16, pady=10).pack(side="left")

        clear_btn = tk.Button(hdr, text="CLEAR",
                              font=("Courier New", 8, "bold"),
                              fg=C["text_dim"], bg=C["border"],
                              activeforeground=C["text"], activebackground=C["panel2"],
                              relief="flat", bd=0, padx=12, pady=6,
                              cursor="hand2", command=self._clear_log)
        clear_btn.pack(side="right", padx=10, pady=8)

        # Filter buttons
        filter_frame = tk.Frame(parent, bg=C["bg"])
        filter_frame.pack(fill="x", padx=16, pady=4)
        self._log_filter = tk.StringVar(value="ALL")
        for lvl in ("ALL", "INFO", "WARN", "ERROR"):
            b = tk.Button(filter_frame, text=lvl,
                          font=("Courier New", 8, "bold"),
                          fg=C["text_dim"], bg=C["border"],
                          activeforeground=C["accent"], activebackground=C["panel2"],
                          relief="flat", bd=0, padx=10, pady=5,
                          cursor="hand2",
                          command=lambda l=lvl: self._set_log_filter(l))
            b.pack(side="left", padx=(0,4))

        self._log_box = scrolledtext.ScrolledText(
            parent,
            font=("Courier New", 8),
            fg=C["text_mid"],
            bg=C["panel"],
            insertbackground=C["accent"],
            relief="flat", bd=0,
            state="disabled",
            wrap="word"
        )
        self._log_box.pack(fill="both", expand=True, padx=16, pady=(4,16))

        # Configure log level tags
        self._log_box.tag_config("INFO",  foreground=C["text_mid"])
        self._log_box.tag_config("WARN",  foreground=C["yellow"])
        self._log_box.tag_config("ERROR", foreground=C["red"])
        self._log_box.tag_config("BUY",   foreground=C["green"])
        self._log_box.tag_config("SELL",  foreground=C["red"])
        self._log_box.tag_config("EXIT",  foreground=C["accent2"])
        self._log_box.tag_config("ts",    foreground=C["text_dim"])

    # ============================================================
    # CLOCK & POLLING
    # ============================================================
    def _start_clock(self):
        def _tick():
            self._clock_text.set(timestamp_ist() + "  IST")
            self.after(1000, _tick)
        _tick()

    def _poll_logs(self):
        try:
            while True:
                ts, level, msg = log_queue.get_nowait()
                self._append_log(ts, level, msg)
        except queue.Empty:
            pass
        self.after(300, self._poll_logs)

    def _append_log(self, ts, level, msg):
        self._log_box.configure(state="normal")
        self._log_box.insert("end", f"[{ts}] ", "ts")
        tag = level if level in ("INFO","WARN","ERROR","BUY","SELL","EXIT") else "INFO"
        self._log_box.insert("end", f"[{level}] ", tag)
        self._log_box.insert("end", msg + "\n", "INFO")
        self._log_box.configure(state="disabled")
        self._log_box.see("end")

    # ============================================================
    # DASHBOARD UPDATE
    # ============================================================
    def _update_dashboard(self, ltp=None, fut_price=None, atm_strike=None,
                          expiry=None, signal=None, metrics=None,
                          position=None):
        """Called from trading thread via self.after()"""
        if ltp is not None:
            self._kpi_vars["ltp"].set(f"{ltp:,.2f}")
        if fut_price is not None:
            self._kpi_vars["fut_price"].set(f"{fut_price:,.2f}")
        if atm_strike is not None:
            self._kpi_vars["atm_strike"].set(str(atm_strike))
        if expiry is not None:
            self._kpi_vars["expiry"].set(str(expiry))

        if signal is not None:
            signal_colors = {
                "BUY": C["green"], "SELL": C["red"],
                "EXIT": C["accent2"], "HOLD": C["text_dim"]
            }
            self._kpi_vars["signal"].set(signal)
            sig_lbl = self._kpi_vars["signal"]._label if hasattr(self._kpi_vars["signal"], "_label") else None

        if metrics is not None:
            metric_map = {
                "idwp":             metrics.get("idwp", 0),
                "inof":             metrics.get("inof", 0),
                "cumul_idwp":       metrics.get("cumul_idwp", 0),
                "cumul_inof":       metrics.get("cumul_inof", 0),
                "vwap_composite":   metrics.get("vwap_composite", 0),
                "cumul_vwap_composite": metrics.get("cumul_vwap_composite", 0),
                "peak_inof":        self.session_state.peak_cumul_inof,
                "trough_inof":      self.session_state.trough_cumul_inof,
            }
            for key, val in metric_map.items():
                if key in self._metric_vars:
                    var, bar = self._metric_vars[key]
                    try:
                        f_val = float(val)
                        var.set(f"{f_val:+.2f}")
                        # Scale bar: map [-200, 200] → [0, 160]
                        bar_w = int(min(max((abs(f_val) / 200.0) * 160, 0), 160))
                        bar.config(width=bar_w)
                    except Exception:
                        var.set("—")

        if position is not None:
            pos_colors = {
                "LONG": C["green"], "SHORT": C["red"], "FLAT": C["text_dim"]
            }
            self._pos_badge.config(text=position,
                                   fg=pos_colors.get(position, C["text_dim"]))

            # Trailing stop label
            pos = self.session_state.position
            if pos == "LONG":
                peak = self.session_state.peak_cumul_inof
                thresh = peak * (1 - Config.TRAIL_STOP_PCT)
                self._trailing_label.config(
                    text=f"▲ LONG: peak_inof={peak:.2f}  exit<{thresh:.2f}",
                    fg=C["green"])
            elif pos == "SHORT":
                trough = self.session_state.trough_cumul_inof
                thresh = trough * (1 + Config.TRAIL_STOP_PCT)
                self._trailing_label.config(
                    text=f"▼ SHORT: trough_inof={trough:.2f}  exit>{thresh:.2f}",
                    fg=C["red"])
            else:
                self._trailing_label.config(text="No active position",
                                            fg=C["text_dim"])

        # Orders bar
        cnt = self.session_state.daily_executed_orders
        self._order_count_label.config(text=f"{cnt} / {Config.MAX_DAILY_ORDERS}")
        bar_pct = cnt / Config.MAX_DAILY_ORDERS
        # Render bar fill
        bar_width = int(min(bar_pct, 1.0) * 180)
        self._order_bar_fg.place(x=0, y=0, width=bar_width, height=6)

    def _push_history_row(self, ts, signal, ltp, cumul_inof, position):
        tag = signal if signal in ("BUY","SELL","EXIT","HOLD") else "HOLD"
        row_vals = (ts, signal, f"{ltp:,.0f}", f"{cumul_inof:+.2f}", position)
        # Alternate bg for non-signal rows
        if signal == "HOLD":
            iid = self._hist_tree.insert("", 0, values=row_vals, tags=("HOLD",))
        else:
            iid = self._hist_tree.insert("", 0, values=row_vals, tags=(tag,))
        # Keep max 50 rows
        all_items = self._hist_tree.get_children()
        if len(all_items) > 50:
            self._hist_tree.delete(all_items[-1])

    # ============================================================
    # SETTINGS / CREDENTIALS
    # ============================================================
    def _load_credentials_ui(self):
        try:
            with open('fyers_credentials.json', 'r') as f:
                creds = json.load(f)
                cid   = creds.get('client_id', '')
                token = creds.get('access_token', '')
                self.session_state.cid   = cid
                self.session_state.token = token
                self._cid_entry.insert(0, cid)
                self._token_entry.insert(0, token)
                self._update_cred_indicator()
                gui_log("Credentials loaded from fyers_credentials.json", "INFO")
        except Exception:
            gui_log("No saved credentials found.", "WARN")

    def _save_credentials(self):
        cid   = self._cid_entry.get().strip()
        token = self._token_entry.get().strip()
        self.session_state.cid   = cid
        self.session_state.token = token
        try:
            with open('fyers_credentials.json', 'w') as f:
                json.dump({"client_id": cid, "access_token": token}, f)
            self._update_cred_indicator()
            self._statusbar_msg.set("✔  Credentials saved successfully.")
            gui_log("Credentials saved.", "INFO")
            messagebox.showinfo("Saved", "Credentials saved successfully.")
        except Exception as e:
            messagebox.showerror("Error", f"Could not save: {e}")

    def _clear_credentials(self):
        self._cid_entry.delete(0, "end")
        self._token_entry.delete(0, "end")
        self.session_state.cid   = ""
        self.session_state.token = ""
        self._update_cred_indicator()

    def _toggle_token_visibility(self):
        if self._show_token_var.get():
            self._token_entry.config(show="")
        else:
            self._token_entry.config(show="•")

    def _update_cred_indicator(self):
        if self.session_state.cid and self.session_state.token:
            self._cred_indicator.config(text="⬤  CREDENTIALS OK", fg=C["green"])
        else:
            self._cred_indicator.config(text="⬤  NO CREDENTIALS", fg=C["red"])

    # ============================================================
    # ALGO PARAMS
    # ============================================================
    def _apply_params(self):
        try:
            Config.REFRESH_INTERVAL    = int(self._param_entries["REFRESH_INTERVAL"].get())
            Config.LOT_SIZE            = int(self._param_entries["LOT_SIZE"].get())
            Config.MAX_DAILY_ORDERS    = int(self._param_entries["MAX_DAILY_ORDERS"].get())
            Config.ROLLING_WINDOW_SIZE = int(self._param_entries["ROLLING_WINDOW_SIZE"].get())
            Config.TRAIL_STOP_PCT      = float(self._param_entries["TRAIL_STOP_PCT"].get())
            Config.ENTRY_STD_MULTIPLIER= float(self._param_entries["ENTRY_STD_MULTIPLIER"].get())
            Config.MAX_RETRIES         = int(self._param_entries["MAX_RETRIES"].get())
            Config.RETRY_DELAY         = int(self._param_entries["RETRY_DELAY"].get())
            self._statusbar_msg.set("✔  Algo parameters applied.")
            gui_log("Algo parameters updated.", "INFO")
            messagebox.showinfo("Applied", "Parameters updated. Restart trading loop to take effect.")
        except ValueError as e:
            messagebox.showerror("Invalid input", f"Bad parameter value: {e}")

    # ============================================================
    # AUTO TRADE TOGGLE
    # ============================================================
    def _on_auto_toggle(self, *args):
        if self._auto_trade.get():
            self._auto_status.config(text="ON", fg=C["green"])
        else:
            self._auto_status.config(text="OFF", fg=C["red"])

    # ============================================================
    # TRADING ENGINE
    # ============================================================
    def _start_trading(self):
        if not (self.session_state.cid and self.session_state.token):
            messagebox.showerror(
                "No Credentials",
                "Please set your Fyers Client ID and Access Token in Settings first."
            )
            self._nav_goto("settings")
            return

        if self._trading_active:
            return

        self._trading_active = True
        self._start_btn.config(state="disabled")
        self._stop_btn.config(state="normal")
        self._set_status("RUNNING", C["green"])
        self._engine_state.config(text="● RUNNING", fg=C["green"])
        self._statusbar_msg.set("Trading engine started.")
        gui_log("Trading engine started.", "INFO")

        self._trading_thread = threading.Thread(
            target=self._trading_loop, daemon=True
        )
        self._trading_thread.start()

    def _stop_trading(self):
        self._trading_active = False
        self._start_btn.config(state="normal")
        self._stop_btn.config(state="disabled")
        self._set_status("STOPPED", C["red"])
        self._engine_state.config(text="● STOPPED", fg=C["red"])
        self._statusbar_msg.set("Trading engine stopped.")
        gui_log("Trading engine stopped by user.", "WARN")

    def _set_status(self, text, color):
        self._status_text.set(text)
        self._status_pill.config(
            fg=C["bg"] if text != "IDLE" else C["text_dim"],
            bg=color
        )

    def _trading_loop(self):
        """
        Runs in a daemon thread. All algo logic is inlined here — no dynamic
        import of nifty.py needed. Falls back to simulation if fyers_apiv3
        is not importable.
        """
        # ── try to import fyers ──────────────────────────────────────────
        try:
            from fyers_apiv3 import fyersModel
            FYERS_OK = True
            gui_log("fyers_apiv3 loaded successfully.", "INFO")
        except ImportError:
            FYERS_OK = False
            fyersModel = None
            gui_log("fyers_apiv3 not installed — running in SIMULATION mode.", "WARN")
            self.after(0, lambda: self._set_status("SIMULATE", C["yellow"]))

        # ── helper: enforce rate limit ───────────────────────────────────
        def enforce_rate_limit(ss):
            n = now_ist()
            window = n - ss.api_window_start
            total = ss.option_chain_api_count + ss.quote_api_count
            if window.total_seconds() > Config.API_WINDOW:
                ss.api_window_start = n
                ss.option_chain_api_count = 0
                ss.quote_api_count = 0
            elif total >= Config.API_RATE_LIMIT:
                wait = Config.API_WINDOW - int(window.total_seconds())
                if wait > 0:
                    gui_log(f"Rate limit hit, waiting {wait}s", "WARN")
                    time.sleep(wait)
                ss.api_window_start = n
                ss.option_chain_api_count = 0
                ss.quote_api_count = 0

        # ── helper: fetch underlying LTP ────────────────────────────────
        def get_underlying_ltp(ss, fy, sym):
            enforce_rate_limit(ss)
            ss.quote_api_count += 1
            for attempt in range(Config.MAX_RETRIES):
                try:
                    resp = fy.quotes(data={"symbols": sym})
                    if resp and resp.get("code") == 200 and resp.get("d"):
                        return resp["d"][0]["v"]["lp"]
                except Exception as e:
                    gui_log(f"get_underlying_ltp attempt {attempt+1} failed: {e}", "WARN")
                    time.sleep(Config.RETRY_DELAY)
            return None

        # ── helper: fetch option chain ───────────────────────────────────
        def get_option_chain(ss, fy, sym, expiry_ts=""):
            enforce_rate_limit(ss)
            ss.option_chain_api_count += 1
            for attempt in range(Config.MAX_RETRIES):
                try:
                    resp = fy.optionchain(data={
                        "symbol": sym, "strikecount": 5,
                        "timestamp": expiry_ts, "greeks": "1"
                    })
                    if resp and resp.get("code") == 200:
                        return resp["data"]["optionsChain"]
                except Exception as e:
                    gui_log(f"get_option_chain attempt {attempt+1} failed: {e}", "WARN")
                    time.sleep(Config.RETRY_DELAY)
            return None

        # ── helper: fetch VWAP for one option symbol ─────────────────────
        def get_option_vwap(ss, fy, sym):
            enforce_rate_limit(ss)
            ss.quote_api_count += 1
            for attempt in range(Config.MAX_RETRIES):
                try:
                    resp = fy.quotes(data={"symbols": sym})
                    if resp and resp.get("code") == 200 and resp.get("d"):
                        return resp["d"][0]["v"]["atp"]
                except Exception as e:
                    gui_log(f"get_option_vwap attempt {attempt+1} failed: {e}", "WARN")
                    time.sleep(Config.RETRY_DELAY)
            return None

        # ── helper: update all market data ───────────────────────────────
        def update_all_data(ss, fy, sym):
            enforce_rate_limit(ss)
            ss.option_chain_api_count += 1
            meta = fy.optionchain(data={"symbol": sym, "timestamp": ""})
            if not meta or meta.get("code") != 200:
                gui_log(f"Meta option chain failed: {meta}", "WARN")
                return None, None, None, None

            # futures price
            fut_price = None
            for item in meta.get("data", {}).get("optionsChain", []):
                if item.get("option_type") == "":
                    fut_price = item.get("fp")
                    if fut_price is not None:
                        break
            if fut_price is None:
                fut_price = meta.get("data", {}).get("fp", 0.0) or 0.0

            # nearest expiry
            exp_data = meta["data"]["expiryData"]
            exp = sorted(
                [(e["date"], e.get("expiry")) for e in exp_data],
                key=lambda x: datetime.strptime(x[0], "%d-%m-%Y")
            )
            today = now_ist().date()
            dates = [datetime.strptime(d, "%d-%m-%Y").date() for d, _ in exp]
            idx = next((i for i, d in enumerate(dates) if d >= today), 0)
            curr_date, curr_ts = exp[idx]

            ltp   = get_underlying_ltp(ss, fy, sym)
            chain = get_option_chain(ss, fy, sym, expiry_ts=curr_ts)
            return ltp, chain, curr_date, fut_price

        # ── helper: compute signals (full logic from nifty.py) ───────────
        def compute_signals(merged_df, atm_strike, ltp, fut_price, ss, vwap_dict):
            if merged_df is None or merged_df.empty:
                return "HOLD", {}, "FLAT"

            available_strikes = sorted(merged_df["strike"].unique())
            if atm_strike not in available_strikes:
                return "HOLD", {}, "FLAT"

            atm_idx = available_strikes.index(atm_strike)
            selected = [atm_strike]
            if atm_idx > 0:
                selected.append(available_strikes[atm_idx - 1])
            if atm_idx < len(available_strikes) - 1:
                selected.append(available_strikes[atm_idx + 1])

            idwps, inofs, ce_mom_list, pe_mom_list = [], [], [], []
            for strike in selected:
                rows = merged_df[merged_df["strike"] == strike]
                ce = rows[rows["option_type"] == "CE"]
                pe = rows[rows["option_type"] == "PE"]
                if ce.empty or pe.empty:
                    continue
                ce = ce.iloc[0]
                pe = pe.iloc[0]
                ce_ltp    = float(ce.get("ltp", 0))
                pe_ltp    = float(pe.get("ltp", 0))
                ce_symbol = ce.get("symbol", "")
                pe_symbol = pe.get("symbol", "")
                parity    = (ce_ltp - pe_ltp) - (fut_price - strike)
                idwps.append(parity)
                ce_delta = float(ce.get("delta", 0))
                pe_delta = abs(float(pe.get("delta", 0)))
                ce_vol   = float(ce.get("volume", 0))
                pe_vol   = float(pe.get("volume", 0))
                inofs.append((ce_vol * ce_delta) - (pe_vol * pe_delta))
                ce_vwap      = vwap_dict.get(ce_symbol, ce_ltp)
                pe_vwap      = vwap_dict.get(pe_symbol, pe_ltp)
                ce_mom_list.append(ce_ltp - ce_vwap)
                pe_mom_list.append(pe_ltp - pe_vwap)

            if not idwps or not inofs:
                return "HOLD", {}, ss.position

            idwp = sum(idwps) / len(idwps)
            inof = sum(inofs) / len(inofs)
            avg_ce_mom  = sum(ce_mom_list) / len(ce_mom_list) if ce_mom_list else 0.0
            avg_pe_mom  = sum(pe_mom_list) / len(pe_mom_list) if pe_mom_list else 0.0
            composite   = avg_ce_mom - avg_pe_mom

            ss.idwp_window.append(idwp)
            ss.inof_window.append(inof)
            ss.composite_window.append(composite)

            if not ss.window_filled:
                if len(ss.inof_window) < Config.ROLLING_WINDOW_SIZE:
                    metrics = {"idwp": idwp, "inof": inof, "cumul_idwp": 0.0,
                               "cumul_inof": 0.0, "vwap_composite": composite,
                               "cumul_vwap_composite": 0.0}
                    return "HOLD", metrics, ss.position
                ss.window_filled = True

            alpha = 2 / (Config.ROLLING_WINDOW_SIZE + 1)

            def ema(lst):
                v = lst[0]
                for x in lst[1:]:
                    v = alpha * x + (1 - alpha) * v
                return v

            cumul_composite = ema(list(ss.composite_window))
            cumul_idwp      = ema(list(ss.idwp_window))
            cumul_inof      = ema(list(ss.inof_window))

            # dynamic peak/trough
            if ss.position == "LONG" and cumul_inof > ss.peak_cumul_inof:
                ss.peak_cumul_inof = cumul_inof
            elif ss.position == "SHORT" and cumul_inof < ss.trough_cumul_inof:
                ss.trough_cumul_inof = cumul_inof

            signal          = "HOLD"
            intended_pos    = ss.position

            # exit logic
            if ss.position == "LONG":
                thresh = ss.peak_cumul_inof * (1 - Config.TRAIL_STOP_PCT)
                if cumul_inof < thresh:
                    signal       = "EXIT"
                    intended_pos = "FLAT"
            elif ss.position == "SHORT":
                thresh = ss.trough_cumul_inof * (1 + Config.TRAIL_STOP_PCT)
                if cumul_inof > thresh:
                    signal       = "EXIT"
                    intended_pos = "FLAT"

            # entry logic
            prev_both_pos = ss.prev_cumul_composite > 0 and ss.prev_cumul_inof > 0
            prev_both_neg = ss.prev_cumul_composite < 0 and ss.prev_cumul_inof < 0
            curr_both_pos = cumul_composite > 0 and cumul_inof > 0
            curr_both_neg = cumul_composite < 0 and cumul_inof < 0

            if ss.position == "FLAT" and signal != "EXIT":
                if curr_both_pos and not prev_both_pos:
                    signal       = "BUY"
                    intended_pos = "LONG"
                elif curr_both_neg and not prev_both_neg:
                    signal       = "SELL"
                    intended_pos = "SHORT"

            ss.prev_cumul_composite = cumul_composite
            ss.prev_cumul_inof      = cumul_inof

            metrics = {
                "atm_strike": atm_strike, "spot": ltp,
                "idwp": idwp, "inof": inof,
                "cumul_idwp": cumul_idwp, "cumul_inof": cumul_inof,
                "vwap_composite": composite, "cumul_vwap_composite": cumul_composite
            }
            return signal, metrics, intended_pos

        # ── helper: select ATM option ────────────────────────────────────
        def select_atm_option(chain, atm_strike, option_type):
            try:
                import pandas as pd
                df = pd.DataFrame(chain)
                if df.empty:
                    return None
                opt = df[(df["strike_price"] == atm_strike) &
                         (df["option_type"] == option_type)]
                return opt.iloc[0].to_dict() if not opt.empty else None
            except Exception:
                return None

        # ── helper: place order ──────────────────────────────────────────
        def place_order(ss, signal, atm_ce, atm_pe, fy, entry_metrics=None):
            if getattr(ss, '_hb_lock', False):
                return False
            ss._hb_lock = True
            try:
                lot = Config.LOT_SIZE
                if signal == "EXIT":
                    fy.exit_positions(data={"segment": [11], "side": [-1], "productType": ["MARGIN"]})
                    fy.exit_positions(data={"segment": [11], "side": [1],  "productType": ["MARGIN"]})
                    time.sleep(2)
                    ss.last_signal        = signal
                    ss.position           = "FLAT"
                    ss.peak_cumul_inof    = 0.0
                    ss.trough_cumul_inof  = 0.0
                    gui_log("EXIT positions placed, state → FLAT", "EXIT")
                    return True

                if signal in ("BUY", "SELL") and ss.daily_executed_orders < Config.MAX_DAILY_ORDERS:
                    leg = atm_ce if signal == "BUY" else atm_pe
                    if not leg:
                        return False
                    order = {
                        "symbol": leg["symbol"], "qty": lot,
                        "type": 2, "side": 1,
                        "productType": "MARGIN",
                        "limitPrice": 0, "stopPrice": 0,
                        "validity": "DAY",
                    }
                    resp = fy.place_order(data=order)
                    gui_log(f"Order response: {resp}", "INFO")
                    if resp.get("s") == "ok":
                        ss.last_signal = signal
                        ss.daily_executed_orders += 1
                        if signal == "BUY":
                            ss.position = "LONG"
                            if entry_metrics:
                                ss.peak_cumul_inof = entry_metrics.get("cumul_inof", 0.0)
                        elif signal == "SELL":
                            ss.position = "SHORT"
                            if entry_metrics:
                                ss.trough_cumul_inof = entry_metrics.get("cumul_inof", 0.0)
                        gui_log(f"Order placed: {signal}, pos → {ss.position}", signal)
                        return True
                    else:
                        gui_log(f"Order failed: {resp.get('message')}", "ERROR")
            except Exception as e:
                gui_log(f"place_order error: {e}", "ERROR")
            finally:
                ss._hb_lock = False
            return False

        # ═══════════════════════════════════════════════════════════════
        # MAIN LOOP
        # ═══════════════════════════════════════════════════════════════
        INDEX_SYM = 'NSE:NIFTY50-INDEX'
        ss = self.session_state

        while self._trading_active:
            try:
                gui_log("=== NEW ITERATION ===", "INFO")

                if FYERS_OK:
                    # ── build Fyers model ────────────────────────────────
                    fy = fyersModel.FyersModel(
                        client_id=ss.cid, token=ss.token,
                        is_async=False, log_path=""
                    )

                    # ── sync order count ─────────────────────────────────
                    today = now_ist().date()
                    if ss.last_order_sync != today:
                        ss.daily_executed_orders = 0
                        ss.last_order_sync = today
                    try:
                        resp = fy.orderbook()
                        if resp.get("s") == "ok":
                            ss.daily_executed_orders = len(
                                [o for o in resp.get("orderBook", [])
                                 if o.get("status") == 2]
                            )
                    except Exception as e:
                        gui_log(f"Order sync failed: {e}", "WARN")

                    # ── fetch market data ────────────────────────────────
                    ltp, chain, curr_date, fut_price = update_all_data(ss, fy, INDEX_SYM)

                    if ltp is None or chain is None:
                        missing = []
                        if ltp is None:   missing.append("LTP")
                        if chain is None: missing.append("Option chain")
                        gui_log(f"Data fetch incomplete — missing: {', '.join(missing)}", "WARN")
                        self._wait_or_stop(Config.REFRESH_INTERVAL)
                        continue

                    # ── build merged dataframe ───────────────────────────
                    import pandas as pd
                    records = []
                    for opt in chain:
                        if opt.get("option_type") in ("CE", "PE"):
                            greeks = opt.get("greeks", {})
                            records.append({
                                "strike":      opt["strike_price"],
                                "option_type": opt["option_type"],
                                "ltp":         opt.get("ltp", 0),
                                "delta":       greeks.get("delta", 0),
                                "volume":      opt.get("volume", 0),
                                "symbol":      opt.get("symbol", "")
                            })
                    merged_df = pd.DataFrame(records)

                    if merged_df.empty:
                        gui_log("Merged DF empty, skipping.", "WARN")
                        self._wait_or_stop(Config.REFRESH_INTERVAL)
                        continue

                    atm_strike = min(merged_df["strike"].unique(),
                                     key=lambda x: abs(x - ltp))

                    # ── collect VWAP symbols ─────────────────────────────
                    available_strikes = sorted(merged_df["strike"].unique())
                    atm_idx  = available_strikes.index(atm_strike)
                    selected = [atm_strike]
                    if atm_idx > 0:
                        selected.append(available_strikes[atm_idx - 1])
                    if atm_idx < len(available_strikes) - 1:
                        selected.append(available_strikes[atm_idx + 1])

                    vwap_symbols = []
                    for strike in selected:
                        ce_row = merged_df[(merged_df["strike"] == strike) &
                                           (merged_df["option_type"] == "CE")]
                        pe_row = merged_df[(merged_df["strike"] == strike) &
                                           (merged_df["option_type"] == "PE")]
                        if not ce_row.empty:
                            vwap_symbols.append(ce_row.iloc[0]["symbol"])
                        if not pe_row.empty:
                            vwap_symbols.append(pe_row.iloc[0]["symbol"])

                    vwap_dict = {}
                    for opt_sym in vwap_symbols:
                        vwap = get_option_vwap(ss, fy, opt_sym)
                        if vwap is not None:
                            vwap_dict[opt_sym] = vwap
                        time.sleep(0.05)

                    # ── compute signals ──────────────────────────────────
                    signal, metrics, intended_position = compute_signals(
                        merged_df, atm_strike, ltp, fut_price, ss, vwap_dict
                    )

                    # ── log to CSV ───────────────────────────────────────
                    self.data_logger.log_data(
                        timestamp=timestamp_ist(),
                        underlying_ltp=ltp, fut_price=fut_price,
                        signal=signal, atm_strike=atm_strike,
                        expiry_date=curr_date,
                        idwp=metrics.get("idwp", 0),
                        inof=metrics.get("inof", 0),
                        cumul_idwp=metrics.get("cumul_idwp", 0),
                        cumul_inof=metrics.get("cumul_inof", 0),
                        vwap_composite=metrics.get("vwap_composite", 0),
                        cumul_vwap_composite=metrics.get("cumul_vwap_composite", 0),
                        position=ss.position
                    )

                    # ── place order if auto-trade ────────────────────────
                    if self._auto_trade.get():
                        atm_ce = select_atm_option(chain, atm_strike, "CE")
                        atm_pe = select_atm_option(chain, atm_strike, "PE")
                        place_order(ss, signal, atm_ce, atm_pe, fy,
                                    entry_metrics=metrics if signal in ("BUY","SELL") else None)

                else:
                    # ── SIMULATION mode ──────────────────────────────────
                    ltp        = 24500.0 + (time.time() % 200 - 100)
                    fut_price  = ltp + 15.0
                    atm_strike = round(ltp / 50) * 50
                    curr_date  = (datetime.now() + timedelta(days=2)).strftime("%d-%m-%Y")
                    _signals   = ["HOLD","HOLD","HOLD","BUY","HOLD","SELL","HOLD","EXIT"]
                    signal     = _signals[int(time.time() / 10) % len(_signals)]
                    metrics    = {
                        "idwp":              round((ltp % 10) - 5,    2),
                        "inof":              round((ltp % 20) - 10,   2),
                        "cumul_idwp":        round((ltp % 30) - 15,   2),
                        "cumul_inof":        round((ltp % 40) - 20,   2),
                        "vwap_composite":    round((ltp % 15) - 7.5,  2),
                        "cumul_vwap_composite": round((ltp % 25) - 12.5, 2),
                    }

                # ── push updates to UI (must be on main thread) ──────────
                _sig  = signal
                _mets = dict(metrics)
                _ltp  = ltp
                _fp   = fut_price
                _atm  = atm_strike
                _exp  = curr_date
                _pos  = ss.position
                _ci   = metrics.get("cumul_inof", 0)
                _ts   = timestamp_ist()[11:19]   # HH:MM:SS portion only

                self.after(0, lambda s=_sig, m=_mets, l=_ltp, f=_fp,
                                      a=_atm, e=_exp, p=_pos:
                           self._update_dashboard(
                               ltp=l, fut_price=f, atm_strike=a,
                               expiry=e, signal=s, metrics=m, position=p))

                self.after(0, lambda t=_ts, s=_sig, l=_ltp, c=_ci, p=_pos:
                           self._push_history_row(t, s, l, c, p))

                gui_log(
                    f"Signal={signal} | LTP={ltp:.0f} | ATM={atm_strike} | "
                    f"cumul_inof={metrics.get('cumul_inof',0):.2f} | POS={ss.position}",
                    signal if signal in ("BUY","SELL","EXIT") else "INFO"
                )

            except Exception as e:
                gui_log(f"Trading loop error: {e}", "ERROR")
                self.after(0, lambda msg=str(e): self._set_status("ERROR", C["red"]))

            self._wait_or_stop(Config.REFRESH_INTERVAL)

        gui_log("Trading loop exited cleanly.", "INFO")

    # ============================================================
    # ALIGNED INTERVAL HELPERS
    # ============================================================
    def get_next_aligned_time(self, interval_seconds):
        """Return the next wall-clock time that is aligned to interval_seconds
        boundaries counted from midnight IST (e.g. every 60 s lands at :00,
        :01, :02 … regardless of when the loop started)."""
        now = now_ist()
        midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
        current_seconds = (now - midnight).total_seconds()
        intervals_passed = current_seconds // interval_seconds
        next_aligned_seconds = (intervals_passed + 1) * interval_seconds
        next_time = midnight + timedelta(seconds=next_aligned_seconds)
        return next_time

    def wait_until_next_interval(self, interval_seconds):
        """Block (in small increments so stop is clean) until the next
        interval boundary, then return.  If we are already past the boundary
        (e.g. the loop body took longer than interval_seconds) we return
        immediately."""
        next_time = self.get_next_aligned_time(interval_seconds)
        wait_seconds = (next_time - now_ist()).total_seconds()
        if wait_seconds > 0:
            debug_msg(
                f"Next update at {next_time.strftime('%H:%M:%S')} "
                f"(waiting {wait_seconds:.1f}s)"
            )
            end = time.time() + wait_seconds
            while self._trading_active and time.time() < end:
                time.sleep(0.5)
        else:
            debug_msg("No wait needed – immediate update")

    def _wait_or_stop(self, seconds):
        """Wait until the next clock-aligned boundary for *seconds* interval.
        Replaces the old fixed-duration sleep so refreshes stay in sync with
        wall-clock boundaries (e.g. every 60 s always fires at :00, :01 …)."""
        self.wait_until_next_interval(seconds)

    # ============================================================
    # LOG HELPERS
    # ============================================================
    def _clear_log(self):
        self._log_box.configure(state="normal")
        self._log_box.delete("1.0", "end")
        self._log_box.configure(state="disabled")

    def _set_log_filter(self, level):
        self._log_filter.set(level)
        # Visual-only filter; full implementation would re-render from buffer

    # ============================================================
    # FILE HELPERS
    # ============================================================
    def _open_file(self, filename):
        try:
            if os.name == "nt":
                os.startfile(filename)
            elif os.uname().sysname == "Darwin":
                os.system(f"open '{filename}'")
            else:
                os.system(f"xdg-open '{filename}'")
        except Exception as e:
            messagebox.showinfo("Open File", f"File: {os.path.abspath(filename)}")

    def _clear_csv(self):
        if messagebox.askyesno("Clear CSV", "Delete all rows from trading_data.csv?"):
            try:
                os.remove("trading_data.csv")
                self.data_logger = DataLogger()
                gui_log("trading_data.csv cleared.", "WARN")
                self._statusbar_msg.set("CSV data cleared.")
            except Exception as e:
                messagebox.showerror("Error", str(e))


# ============================================================
# ENTRY POINT
# ============================================================
if __name__ == "__main__":
    app = TradingApp()
    app.mainloop()
