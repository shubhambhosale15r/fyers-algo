import time
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import pytz
from fyers_apiv3 import fyersModel
import logging
import uuid
from functools import lru_cache
import os


# Constants
class Config:
    REFRESH_INTERVAL = 10  # seconds
    API_RATE_LIMIT = 200
    API_WINDOW = 60  # seconds
    LOT_SIZE = 75
    MAX_RETRIES = 3
    RETRY_DELAY = 2  # seconds


# Initialize logging
logging.basicConfig(
    filename="trading_app.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)


# Error handling decorator
def handle_errors(func):
    def wrapper(*args, **kwargs):
        retries = 0
        while retries < Config.MAX_RETRIES:
            try:
                return func(*args, **kwargs)
            except Exception as e:
                retries += 1
                logging.error(f"Error in {func.__name__} (attempt {retries}): {str(e)}", exc_info=True)
                if retries < Config.MAX_RETRIES:
                    time.sleep(Config.RETRY_DELAY)
                else:
                    print(f"Operation failed after {Config.MAX_RETRIES} attempts: {str(e)}")
                    return None

    return wrapper


class TradingCore:
    def __init__(self):
        self.init_session_state()
        self.load_credentials()

    def init_session_state(self):
        defaults = {
            "option_chain_api_count": 0,
            "quote_api_count": 0,
            "api_window_start": datetime.now(),
            "last_signal": None,
            "last_signal_order_ids": [],
            "paper_trades": [],
            "paper_positions": {},
            "paper_pnl": {"realized": 0.0, "unrealized": 0.0},
            "trade_history": [],
            "paper_trade_active": False,
            "pnl_update_time": datetime.now(),
            "paper_last_signal": None,
            "paper_last_signal_order_ids": [],
            "live_last_signal": None,
            "live_last_signal_order_ids": [],
            "signal_history": [],
            "cid": "",
            "token": "",
            "page": "trading"
        }

        self.session_state = defaults.copy()

    def load_credentials(self):
        self.session_state["cid"] = os.getenv("FYERS_CID", self.session_state.get("cid", ""))
        self.session_state["token"] = os.getenv("FYERS_TOKEN", self.session_state.get("token", ""))

    def set_credentials(self, cid, token):
        self.session_state["cid"] = cid
        self.session_state["token"] = token

    def set_lot_size(self, size):
        Config.LOT_SIZE = size

    def enforce_rate_limit(self):
        now = datetime.now()
        window = now - self.session_state["api_window_start"]
        total_calls = self.session_state["option_chain_api_count"] + self.session_state["quote_api_count"]

        if window > timedelta(seconds=Config.API_WINDOW):
            self.session_state["api_window_start"] = now
            self.session_state["option_chain_api_count"] = 0
            self.session_state["quote_api_count"] = 0
        elif total_calls >= Config.API_RATE_LIMIT:
            wait = Config.API_WINDOW - window.seconds
            logging.warning(f"Approaching rate limit, waiting {wait}s...")
            time.sleep(wait)
            self.session_state["api_window_start"] = datetime.now()
            self.session_state["option_chain_api_count"] = 0
            self.session_state["quote_api_count"] = 0

    # API calls with retry logic
    @handle_errors
    @lru_cache(maxsize=32)
    def get_option_chain_data(self, sym, expiry_ts=""):
        self.enforce_rate_limit()
        self.session_state["option_chain_api_count"] += 1

        cid = self.session_state["cid"]
        token = self.session_state["token"]

        fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
        resp = fy.optionchain(data={"symbol": sym, "timestamp": expiry_ts})
        if not resp or resp.get("code") != 200:
            error_msg = f"Option chain error ({expiry_ts or 'nearest'}): {resp.get('message', 'Unknown')}"
            logging.error(error_msg)
            return None
        return resp["data"]["optionsChain"]

    @handle_errors
    def get_underlying_ltp(self, sym):
        self.enforce_rate_limit()
        self.session_state["quote_api_count"] += 1

        cid = self.session_state["cid"]
        token = self.session_state["token"]

        fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
        resp = fy.quotes(data={"symbols": sym})
        if not resp or resp.get("code") != 200 or not resp.get("d"):
            error_msg = f"Quotes API error ({resp.get('code')}): {resp.get('message', 'Unknown')}"
            logging.error(error_msg)
            return None
        return resp["d"][0]["v"]["lp"]

    @handle_errors
    def get_symbol_ltp(self, symbol):
        self.enforce_rate_limit()
        self.session_state["quote_api_count"] += 1

        cid = self.session_state["cid"]
        token = self.session_state["token"]

        fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
        resp = fy.quotes(data={"symbols": symbol})
        if not resp or resp.get("code") != 200 or not resp.get("d"):
            error_msg = f"Quotes API error for {symbol}: {resp.get('message', 'Unknown')}"
            logging.error(error_msg)
            return None
        return resp["d"][0]["v"]["lp"]

    def get_expiry_data(self, sym):
        cid = self.session_state["cid"]
        token = self.session_state["token"]

        fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
        meta = fy.optionchain(data={"symbol": sym, "timestamp": ""})
        if meta.get("code") != 200:
            logging.error("Failed to fetch expiry data")
            return None

        exp = sorted(
            [(e["date"], e.get("expiry")) for e in meta["data"]["expiryData"]],
            key=lambda x: datetime.strptime(x[0], "%d-%m-%Y")
        )
        today = datetime.today().date()
        dates = [datetime.strptime(d, "%d-%m-%Y").date() for d, _ in exp]
        idx = next((i for i, d in enumerate(dates) if d >= today), 0)
        curr_date, curr_ts = exp[idx]

        return curr_date, curr_ts

    def update_all_data(self, sym):
        curr_date, curr_ts = self.get_expiry_data(sym)
        ltp = self.get_underlying_ltp(sym)
        chain = self.get_option_chain_data(sym, expiry_ts=curr_ts)

        # Update paper positions if enabled
        if self.session_state.get("paper_positions"):
            self.update_position_prices()
            self.update_unrealized_pnl()

        return ltp, chain, curr_date

    def format_option_chain(self, chain, ltp):
        df = pd.DataFrame(chain)
        if df.empty:
            return None, None

        # Process CE and PE data
        ce = df[df["option_type"] == "CE"]
        pe = df[df["option_type"] == "PE"]

        # Define columns and rename them
        cols = ["symbol", "strike_price", "oi", "volume", "ltp", "ask", "bid",
                "ltpch", "ltpchp", "oich", "oichp", "prev_oi"]

        ce_df = ce[cols].rename(columns={
            "strike_price": "Strike",
            "oi": "OI",
            "volume": "Vol",
            "ltpch": "LTPCh",
            "ltpchp": "LTPChP",
            "oich": "OICh",
            "oichp": "OIChP",
            "prev_oi": "PrevOI"
        })

        pe_df = pe[cols].rename(columns={
            "strike_price": "Strike",
            "oi": "OI",
            "volume": "Vol",
            "ltpch": "LTPCh",
            "ltpchp": "LTPChP",
            "oich": "OICh",
            "oichp": "OIChP",
            "prev_oi": "PrevOI"
        })

        # Merge CE and PE data
        merged = pd.merge(
            ce_df.add_prefix("CE_"),
            pe_df.add_prefix("PE_"),
            left_on="CE_Strike",
            right_on="PE_Strike",
            how="outer"
        ).rename(columns={"CE_Strike": "Strike"}).drop("PE_Strike", axis=1)

        # Find ATM strike
        atm = None
        if ltp is not None and not merged["Strike"].dropna().empty:
            atm = min(merged["Strike"].dropna(), key=lambda x: abs(x - ltp))

        return merged, atm

    # Signal computation with improved error handling
    def compute_signals(self, merged_df, atm_strike, ltp, min_range_pct=1, tolerance_pct=1, fyers_api=None):
        """
        Compute intraday trading signals using ITM options only.
        Now using ATP (Average Traded Price) instead of VWAP for comparison.
        Returns: (signal, net_flow, direction_ratio)
        """
        try:
            def safe_val(series, default=0):
                """Safe extraction from series."""
                return series.iloc[0] if not series.empty and not pd.isna(series.iloc[0]) else default

            # 1. Determine price range around ATM
            atm_row = merged_df[merged_df["Strike"] == atm_strike]
            atm_ce_price = safe_val(atm_row["CE_ltp"])
            atm_pe_price = safe_val(atm_row["PE_ltp"])
            atm_ce_volume = safe_val(atm_row["CE_Vol"])
            atm_pe_volume = safe_val(atm_row["PE_Vol"])
            atm_ce_moneyflow = atm_ce_price * atm_ce_volume
            atm_pe_moneyflow = atm_pe_price * atm_pe_volume
            price_range = atm_ce_price + atm_pe_price

            min_range_abs = ltp * (min_range_pct / 100)

            if price_range >= min_range_abs:
                lower_bound = atm_strike - price_range
                upper_bound = atm_strike + price_range
                range_type = f"ATM+CE Range (±{price_range:.2f} points)"
            else:
                lower_bound = ltp * (1 - min_range_pct / 100)
                upper_bound = ltp * (1 + min_range_pct / 100)
                range_type = f"{min_range_pct}% Underlying Range"

            def round_to_nearest_strike(value, strikes):
                """Round to the nearest available strike price"""
                if not strikes:
                    return value
                return min(strikes, key=lambda x: abs(x - value))

            strikes = sorted(merged_df["Strike"].dropna().unique())
            lower_bound = round_to_nearest_strike(lower_bound, strikes)
            upper_bound = round_to_nearest_strike(upper_bound, strikes)
            range_strikes = [s for s in strikes if lower_bound <= s <= upper_bound]

            if not range_strikes:
                logging.warning(f"No strikes in range {lower_bound:.2f}-{upper_bound:.2f}")
                return "SIDEWAYS", 0, 0

            # 2. Fill missing values
            merged_df = merged_df.fillna(0)
            merged_df["CE_moneyflow"] = merged_df["CE_ltp"] * merged_df["CE_OICh"]
            merged_df["PE_moneyflow"] = merged_df["PE_ltp"] * merged_df["PE_OICh"]

            range_df = merged_df[merged_df["Strike"].isin(range_strikes)].copy()
            # st.write(range_df)

            # 3. Fyers API quotes for ITM strikes - comparing LTP vs ATP
            if fyers_api and 'CE_symbol' in range_df.columns and 'PE_symbol' in range_df.columns:
                try:
                    symbols = list(set(range_df['CE_symbol'].tolist() + range_df['PE_symbol'].tolist()))
                    symbols = [s for s in symbols if s != 0 and isinstance(s, str)]
                    quotes = {}
                    for i in range(0, len(symbols), 50):
                        batch = symbols[i:i + 50]
                        response = fyers_api.quotes({"symbols": ",".join(batch)})
                        if response.get('code') == 200:
                            quotes.update({item['n']: item['v'] for item in response['d'] if item['s'] == 'ok'})

                    # Initialize default values
                    range_df['CE_vs_atp'] = 'BELOW'  # Default to BELOW if no data
                    range_df['PE_vs_atp'] = 'BELOW'
                    range_df['ce_strength'] = "LOW"
                    range_df['pe_strength'] = "LOW"

                    for idx, row in range_df.iterrows():
                        if row['CE_symbol'] in quotes:
                            ce_data = quotes[row['CE_symbol']]
                            ltp = ce_data.get('lp', 0)
                            atp = ce_data.get('atp', 0)
                            high_price = ce_data.get('high_price', 0)
                            if atp > 0:
                                range_df.at[idx, 'CE_vs_atp'] = 'ABOVE' if ltp > atp else 'BELOW'
                            if high_price > 0 and ltp > 0:
                                range_df.at[idx, 'CE_high'] = high_price
                                range_df.at[idx, 'CE_high_diff'] = high_price - ltp
                            range_df.at[idx, 'CE_ltp'] = ltp

                        if row['PE_symbol'] in quotes:
                            pe_data = quotes[row['PE_symbol']]
                            ltp = pe_data.get('lp', 0)
                            atp = pe_data.get('atp', 0)
                            high_price = pe_data.get('high_price', 0)
                            if atp > 0:
                                range_df.at[idx, 'PE_vs_atp'] = 'ABOVE' if ltp > atp else 'BELOW'
                            if high_price > 0 and ltp > 0:
                                range_df.at[idx, 'PE_high'] = high_price
                                range_df.at[idx, 'PE_high_diff'] = high_price - ltp
                            range_df.at[idx, 'PE_ltp'] = ltp

                except Exception as e:
                    logging.warning(f"Fyers quotes error: {str(e)}")
            # st.write(range_df)
            # 4. Select ITM strikes
            atm_idx = range_strikes.index(atm_strike) if atm_strike in range_strikes else len(range_strikes) // 2
            num_strikes = min(len(range_strikes[:atm_idx]), len(range_strikes[atm_idx + 1:]))
            itm_ce_strikes = range_strikes[atm_idx - num_strikes:atm_idx]
            itm_pe_strikes = range_strikes[atm_idx + 1:atm_idx + 1 + num_strikes]

            # 5. Calculate money flow and direction ratio (using ATP comparison)
            ce_net = range_df[range_df["Strike"].isin(itm_ce_strikes)]["CE_moneyflow"].sum()
            pe_net = range_df[range_df["Strike"].isin(itm_pe_strikes)]["PE_moneyflow"].sum()
            if ce_net > 0 and pe_net > 0:
                net_flow = (ce_net - pe_net) / (ce_net + pe_net) if (ce_net + pe_net) != 0 else 0
            elif ce_net < 0 and pe_net > 0:
                moneyflow = 'Bullish'
            elif ce_net > 0 and pe_net < 0:
                moneyflow = 'Bearish'
            else:
                moneyflow = 'Neutral'

            ce_above_atp = range_df[range_df["Strike"].isin(itm_ce_strikes) & (range_df["CE_vs_atp"] == 'ABOVE')].shape[
                0]
            pe_above_atp = range_df[range_df["Strike"].isin(itm_pe_strikes) & (range_df["PE_vs_atp"] == 'ABOVE')].shape[
                0]

            direction_ratio = (ce_above_atp - pe_above_atp) / max(len(itm_ce_strikes) + len(itm_pe_strikes), 1)

            # 6. Convert absolute high diff → % diff from high
            range_df["CE_high_pct"] = np.where(
                range_df["CE_high"] > 0,
                range_df["CE_high_diff"] / range_df["CE_high"],
                0
            )
            range_df["PE_high_pct"] = np.where(
                range_df["PE_high"] > 0,
                range_df["PE_high_diff"] / range_df["PE_high"],
                0
            )

            ce_high_pct_avg = range_df[range_df["Strike"].isin(itm_ce_strikes)]["CE_high_pct"].mean()
            pe_high_pct_avg = range_df[range_df["Strike"].isin(itm_pe_strikes)]["PE_high_pct"].mean()

            # Strength metric: -1 (PE stronger) → +1 (CE stronger)
            strength = (ce_high_pct_avg - pe_high_pct_avg) / max(ce_high_pct_avg + pe_high_pct_avg, 1e-6)

            # 7. Generate signal
            signal = "SIDEWAYS"
            if direction_ratio >= 0.5 and strength < 0:
                print("Market is in BUY entry found entering the trade")
                signal = "BUY"

            elif direction_ratio <= -0.5 and strength > 0:
                print("Market is in SELL entry found entering the trade")
                signal = "SELL"

            details = f"""
            {range_type}
            Range: {lower_bound:.2f} to {upper_bound:.2f}
            ITM CE Strikes: {list(itm_ce_strikes)}
            ITM PE Strikes: {list(itm_pe_strikes)}
            CE Money Flow: {ce_net:.2f}
            PE Money Flow: {pe_net:.2f}
            Net Money Flow: {net_flow:.2f}
            Direction Ratio: {direction_ratio:.2f} | CE Above ATP: {ce_above_atp} | PE Above ATP: {pe_above_atp} | Total Strikes: {len(itm_ce_strikes) + len(itm_pe_strikes)}
            Avg CE % below High: {ce_high_pct_avg:.2%} | Avg PE % below High: {pe_high_pct_avg:.2%} | Strength: {strength:.2f}
            """
            return signal, details

        except Exception as e:
            logging.error(f"Error in compute_signals: {str(e)}", exc_info=True)
            return "SIDEWAYS", f"Error: {str(e)}"

    # Optimized strike selection
    def select_strikes_atm_half_price(self, chain, atm_strike):
        try:
            df = pd.DataFrame(chain)
            if df.empty or atm_strike is None:
                return None, None, None, None

            ce = df[df["option_type"] == "CE"].copy()
            pe = df[df["option_type"] == "PE"].copy()

            # Find ATM PE and CE rows
            atm_pe_row = pe[pe["strike_price"] == atm_strike]
            atm_ce_row = ce[ce["strike_price"] == atm_strike]

            sell_pe_row = atm_pe_row.iloc[0].to_dict() if not atm_pe_row.empty else None
            sell_ce_row = atm_ce_row.iloc[0].to_dict() if not atm_ce_row.empty else None

            # Find half-price strikes with vectorized operations
            buy_pe_row = None
            if sell_pe_row and "ltp" in sell_pe_row and sell_pe_row["ltp"] > 0:
                target = sell_pe_row["ltp"] / 2
                pe_candidates = pe[pe["strike_price"] != atm_strike].copy()
                pe_candidates["ltp_diff"] = (pe_candidates["ltp"] - target).abs()
                if not pe_candidates.empty:
                    buy_pe_row = pe_candidates.nsmallest(1, "ltp_diff").iloc[0].to_dict()

            buy_ce_row = None
            if sell_ce_row and "ltp" in sell_ce_row and sell_ce_row["ltp"] > 0:
                target = sell_ce_row["ltp"] / 2
                ce_candidates = ce[ce["strike_price"] != atm_strike].copy()
                ce_candidates["ltp_diff"] = (ce_candidates["ltp"] - target).abs()
                if not ce_candidates.empty:
                    buy_ce_row = ce_candidates.nsmallest(1, "ltp_diff").iloc[0].to_dict()

            return sell_pe_row, buy_pe_row, sell_ce_row, buy_ce_row

        except Exception as e:
            logging.error(f"Error in select_strikes_atm_half_price: {str(e)}", exc_info=True)
            return None, None, None, None

    # Order management with improved error handling
    @handle_errors
    def cancel_order(self, fyers, order_id):
        try:
            resp = fyers.cancel_order(data={"id": order_id})
            logging.info(f"Cancelled order {order_id}: {resp}")
            return resp
        except Exception as e:
            logging.error(f"Exception while cancelling order {order_id}: {e}", exc_info=True)
            raise

    @handle_errors
    def get_order_status_by_id(self, fyers, order_id):
        try:
            orderbook = fyers.orderbook()
            for o in orderbook.get("orderBook", []):
                if o.get("id") == order_id:
                    return o.get("status")
            return None
        except Exception as e:
            logging.warning(f"Could not fetch order status for {order_id}: {e}")
            return None

    @handle_errors
    def place_order_and_check(self, fyers, order):
        try:
            resp = fyers.place_order(data=order)
            logging.info(f"Order placed for {order['symbol']}: {resp}")

            if resp.get("s") == "ok":
                oid = resp.get("id")
                time.sleep(2)  # Wait for order to process
                status = self.get_order_status_by_id(fyers, oid)
                if status in [1, 5]:  # Rejected or canceled
                    logging.error(f"Order {oid} was rejected or canceled. Status: {status}")
                    return None, status
                logging.info(f"Order {oid} status: {status}")
                return oid, status
            else:
                logging.error(f"Order failed: {resp}")
                return None, None
        except Exception as e:
            logging.exception(f"Place order error: {e}")
            raise

    # Trading logic with improved state management
    def has_open_orders_for_last_signal(self, fyers):
        ids = self.session_state.get("live_last_signal_order_ids", [])
        if not ids:
            return False
        try:
            ob = fyers.orderbook().get("orderBook", [])
            return any(o.get("id") in ids and o.get("status") == 2 for o in ob)
        except Exception as e:
            logging.warning(f"Could not check open orders: {e}")
            return False

    # Paper trading with improved position tracking
    def handle_paper_trade(self, signal, sell_pe, buy_pe, sell_ce, buy_ce):
        try:
            orders = []
            lot = Config.LOT_SIZE
            timestamp = datetime.now(pytz.timezone('Asia/Kolkata')).strftime("%Y-%m-%d %H:%M:%S")
            current_signal = self.session_state.get("paper_last_signal")

            # Skip if signal is the same as last time
            if current_signal == signal and self.session_state.paper_positions:
                logging.info(f"[PAPER] Signal {signal} is already active. No new trades.")
                return []

            # Case 1: BUY → SELL (Exit BUY, Enter SELL)
            if current_signal == "BUY" and signal == "SELL":
                for symbol, position in list(self.session_state.paper_positions.items()):
                    close_action = "SELL" if position["action"] == "BUY" else "BUY"
                    orders.append({
                        "symbol": symbol,
                        "qty": position["qty"],
                        "action": close_action,
                        "price": position["current_price"],
                        "type": "CLOSE"
                    })
                logging.info("[PAPER] Exiting BUY positions for SELL signal")

                if buy_ce and sell_ce:
                    orders.append({
                        "symbol": buy_ce["symbol"],
                        "qty": lot,
                        "side": 1,
                        "action": "BUY",
                        "price": buy_ce["ltp"]
                    })
                    orders.append({
                        "symbol": sell_ce["symbol"],
                        "qty": lot,
                        "side": -1,
                        "action": "SELL",
                        "price": sell_ce["ltp"]
                    })

            # Case 2: SELL → BUY (Exit SELL, Enter BUY)
            elif current_signal == "SELL" and signal == "BUY":
                for symbol, position in list(self.session_state.paper_positions.items()):
                    close_action = "SELL" if position["action"] == "BUY" else "BUY"
                    orders.append({
                        "symbol": symbol,
                        "qty": position["qty"],
                        "action": close_action,
                        "price": position["current_price"],
                        "type": "CLOSE"
                    })
                logging.info("[PAPER] Exiting SELL positions for BUY signal")

                if buy_pe and sell_pe:
                    orders.append({
                        "symbol": buy_pe["symbol"],
                        "qty": lot,
                        "side": 1,
                        "action": "BUY",
                        "price": buy_pe["ltp"]
                    })
                    orders.append({
                        "symbol": sell_pe["symbol"],
                        "qty": lot,
                        "side": -1,
                        "action": "SELL",
                        "price": sell_pe["ltp"]
                    })

            # Case 3: New signal (no existing position)
            elif current_signal is None and signal in ["BUY", "SELL"]:
                if signal == "BUY" and buy_pe and sell_pe:
                    orders.append({
                        "symbol": buy_pe["symbol"],
                        "qty": lot,
                        "side": 1,
                        "action": "BUY",
                        "price": buy_pe["ltp"]
                    })
                    orders.append({
                        "symbol": sell_pe["symbol"],
                        "qty": lot,
                        "side": -1,
                        "action": "SELL",
                        "price": sell_pe["ltp"]
                    })
                elif signal == "SELL" and buy_ce and sell_ce:
                    orders.append({
                        "symbol": buy_ce["symbol"],
                        "qty": lot,
                        "side": 1,
                        "action": "BUY",
                        "price": buy_ce["ltp"]
                    })
                    orders.append({
                        "symbol": sell_ce["symbol"],
                        "qty": lot,
                        "side": -1,
                        "action": "SELL",
                        "price": sell_ce["ltp"]
                    })

            # Case 4: SIDEWAYS (do nothing)
            elif signal == "SIDEWAYS":
                logging.info("[PAPER] SIDEWAYS: Holding existing positions")
                return []

            # Execute orders
            placed_ids = []
            for order in orders:
                trade_id = str(uuid.uuid4())[:8]
                trade = {
                    "id": trade_id,
                    "timestamp": timestamp,
                    "symbol": order["symbol"],
                    "qty": order["qty"],
                    "action": order["action"],
                    "price": order["price"],
                    "signal": signal,
                    "type": order.get("type", "OPEN")
                }
                self.update_paper_positions(trade)
                self.session_state["trade_history"].append(trade)
                placed_ids.append(trade_id)
                logging.info(
                    f"[PAPER] {order['action']} {order['qty']} of {order['symbol']} "
                    f"at {order['price']}"
                )

            if placed_ids and signal in ["BUY", "SELL"]:
                self.session_state["paper_last_signal"] = signal

            return placed_ids

        except Exception as e:
            logging.error(f"Error in handle_paper_trade: {str(e)}", exc_info=True)
            return []

    def update_paper_positions(self, trade):
        try:
            symbol = trade["symbol"]
            if trade["type"] == "OPEN":
                self.session_state["paper_positions"][symbol] = {
                    "symbol": trade["symbol"],
                    "id": trade["id"],
                    "entry_time": trade["timestamp"],
                    "qty": trade["qty"],
                    "action": trade["action"],
                    "side": 1 if trade["action"] == "BUY" else -1,
                    "entry_price": trade["price"],
                    "current_price": trade["price"],
                    "signal": trade["signal"]
                }
            else:
                if symbol in self.session_state["paper_positions"]:
                    position = self.session_state["paper_positions"][symbol]

                    # Calculate PnL
                    if position["action"] == "BUY":
                        pnl = (trade["price"] - position["entry_price"]) * position["qty"]
                    else:
                        pnl = (position["entry_price"] - trade["price"]) * position["qty"]

                    self.session_state["paper_pnl"]["realized"] += pnl
                    trade["pnl"] = pnl

                    del self.session_state["paper_positions"][symbol]

                    if not self.session_state["paper_positions"]:
                        self.session_state["last_signal"] = None
        except Exception as e:
            logging.error(f"Error in update_paper_positions: {str(e)}", exc_info=True)

    @handle_errors
    def update_unrealized_pnl(self):
        if not self.session_state["paper_positions"]:
            self.session_state["paper_pnl"]["unrealized"] = 0.0
            return

        total_unrealized = 0.0
        for symbol, position in self.session_state["paper_positions"].items():
            ltp = self.get_symbol_ltp(symbol)
            if ltp is None:
                ltp = position.get("current_price", position["entry_price"])

            position["current_price"] = ltp

            if position["action"] == "BUY":
                pnl = (ltp - position["entry_price"]) * position["qty"]
            else:
                pnl = (position["entry_price"] - ltp) * position["qty"]

            total_unrealized += pnl

        self.session_state["paper_pnl"]["unrealized"] = total_unrealized
        self.session_state["pnl_update_time"] = datetime.now()

    @handle_errors
    def update_position_prices(self):
        if not self.session_state["paper_positions"]:
            return

        for symbol, position in self.session_state["paper_positions"].items():
            ltp = self.get_symbol_ltp(symbol)
            if ltp is not None:
                position["current_price"] = ltp

    # Live trading with improved order handling
    def handle_basket_orders_atomic(self, signal, sell_pe, buy_pe, sell_ce, buy_ce, fyers):
        """
        Atomic-ish rebalancing:
        - If SIDEWAYS: do nothing.
        - If signal changed vs last_signal:
            1) exit ALL current positions via EXIT BASKET
            2) wait for fill (orderbook) + verify flat (positions)
            3) enter new basket for `signal`
        - If same signal: avoid duplicate entries (re-check positions)
        Notes:
          - Uses orderbook polling (report_type/ord_status) to confirm fills.
          - Exits use *actual* netQty to flatten fully (not LOT_SIZE).
          - Adds a simple re-entrancy lock in st.session_state to avoid overlapping runs.
        """
        # ------- simple lock to avoid overlapping runs -------
        if self.session_state.get("_hb_lock", False):
            print("Another rebalance is in progress; skipping this run.")
            return []
        self.session_state["_hb_lock"] = True

        placed_ids = []
        try:
            lot = Config.LOT_SIZE
            current_signal = self.session_state.get("last_signal")
            print(f"🔄 Current signal: {current_signal}, New signal: {signal}")

            if signal not in ["BUY", "SELL"]:
                print("SIDEWAYS signal → No action needed")
                return []

            # Map entry legs for the new signal
            signal_map = {
                "BUY": {
                    "enter_hedge": buy_pe,  # buy PE (hedge)
                    "enter_short": sell_pe,  # sell PE (short premium)
                },
                "SELL": {
                    "enter_hedge": buy_ce,  # buy CE (hedge)
                    "enter_short": sell_ce,  # sell CE (short premium)
                }
            }

            # ---------- helper: poll orderbook for fills (inline) ----------
            def _exit_orders_filled(order_ids, timeout=45, interval=2):
                """Return True when ALL given order_ids are filled; False on timeout/failure."""
                end = time.time() + timeout
                filled = set()
                while time.time() < end:
                    ob = fyers.orderbook()
                    if ob.get("s") == "ok" and "orderBook" in ob:
                        for o in ob["orderBook"]:
                            oid = o.get("id")
                            if oid in order_ids:
                                rep = str(o.get("report_type", "")).upper()
                                status = o.get("ord_status")
                                # Consider these as FILLED; broaden slightly for broker variations
                                if rep in {"TRADED", "FILLED", "EXECUTED", "COMPLETE", "COMPLETED"} or status in {2}:
                                    filled.add(oid)
                                # Early-fail on reject/cancel
                                if rep in {"REJECTED", "CANCELLED", "CANCELED"} or status in {-1}:
                                    print(f"Exit order {oid} failed ({rep or status})")
                                    return False
                        if filled == set(order_ids):
                            return True
                    time.sleep(interval)
                return False

            # ---------- current positions ----------
            pos_resp = fyers.positions()
            net_positions = []
            if pos_resp.get("s") == "ok":
                net_positions = [p for p in pos_resp.get("netPositions", []) if abs(p.get("netQty", 0)) != 0]

            print(f"🔍 Found {len(net_positions)} active positions")
            for p in net_positions:
                print(f"  - {p.get('symbol')}: {p.get('netQty')} units")

            # ============================================================
            #               1) FLATTEN EVERYTHING on SIGNAL CHANGE
            # ============================================================
            if current_signal in ["BUY", "SELL"] and current_signal != signal and net_positions:
                print(f"Signal changed ({current_signal} → {signal}). Exiting ALL open positions first…")

                # Build an EXIT basket from *all* open positions using their actual qty and opposite side
                exit_basket = []
                for p in net_positions:
                    symbol = p.get("symbol")
                    net_qty = int(p.get("netQty", 0))
                    if net_qty == 0:
                        continue
                    # If long (+qty) → sell to close (-1); If short (-qty) → buy to close (+1)
                    side = -1 if net_qty > 0 else 1
                    qty_to_close = abs(net_qty)  # close fully, not just 1 lot
                    product_type = p.get("productType", "MARGIN")

                    exit_basket.append({
                        "symbol": symbol,
                        "qty": qty_to_close,
                        "type": 2,  # market
                        "side": side,
                        "productType": product_type,
                        "validity": "DAY"
                    })

                if not exit_basket:
                    print("No non-zero positions to exit.")
                else:
                    print(f"🧺 Placing EXIT basket for {len(exit_basket)} legs…")
                    exit_resp = fyers.place_basket_orders(data=exit_basket)
                    print(f"Exit basket response: {exit_resp}")

                    if not exit_resp or exit_resp.get("s") != "ok":
                        print(
                            f"Exit basket placement failed: {exit_resp.get('message', 'Unknown error') if isinstance(exit_resp, dict) else 'Unknown error'}")
                        return placed_ids

                    # Collect exit order IDs from basket response
                    exit_order_ids = []
                    for item in exit_resp.get("data", []):
                        body = item.get("body", {})
                        if body.get("s") == "ok" and body.get("id"):
                            exit_order_ids.append(body["id"])
                            placed_ids.append(body["id"])
                        else:
                            # If any leg fails to place, abort re-entry
                            print(f"Exit leg failed to place: {body.get('message', 'Unknown error')}")
                            return placed_ids

                    # Wait for fills via ORDERBOOK
                    print("⏳ Waiting for all exit orders to FILL…")
                    if not _exit_orders_filled(exit_order_ids, timeout=60, interval=2):
                        print("Timeout or failure while exiting positions. Aborting new entry.")
                        return placed_ids

                    # Extra safety: verify FLAT via positions
                    verify_deadline = time.time() + 10
                    while time.time() < verify_deadline:
                        chk = fyers.positions()
                        if chk.get("s") == "ok":
                            still_open = [p for p in chk.get("netPositions", []) if abs(p.get("netQty", 0)) != 0]
                            if not still_open:
                                print("All positions closed ✅")
                                break
                        time.sleep(1)
                    else:
                        print("Positions not flat after exit fills (broker lag). Aborting new entry.")
                        return placed_ids

            # ============================================================
            #      2) ENTER NEW BASKET (only if nothing is open)
            # ============================================================
            # Refresh positions right before entry
            pos_resp = fyers.positions()
            current_positions = []
            if pos_resp.get("s") == "ok":
                current_positions = [p for p in pos_resp.get("netPositions", []) if abs(p.get("netQty", 0)) != 0]

            if current_positions:
                # If anything still open, do NOT enter new positions
                print("Positions still open; skipping new entry to prevent overlap.")
                for p in current_positions:
                    print(f"  - Open: {p.get('symbol')} {p.get('netQty')}")
                return placed_ids

            # Now enter the fresh signal (hedge buy + short sell)
            enter_hedge = signal_map[signal]["enter_hedge"]
            enter_short = signal_map[signal]["enter_short"]

            print(f"📥 Entering new {signal} positions as a basket…")
            entry_basket = [
                {
                    "symbol": enter_hedge["symbol"],
                    "qty": lot,
                    "type": 2,
                    "side": 1,  # Buy hedge
                    "productType": "MARGIN",
                    "validity": "DAY",
                },
                {
                    "symbol": enter_short["symbol"],
                    "qty": lot,
                    "type": 2,
                    "side": -1,  # Sell short leg
                    "productType": "MARGIN",
                    "validity": "DAY",
                }
            ]

            entry_resp = fyers.place_basket_orders(data=entry_basket)
            print(f"Entry basket response: {entry_resp}")

            if entry_resp and entry_resp.get("s") == "ok":
                for item in entry_resp.get("data", []):
                    body = item.get("body", {})
                    if body.get("s") == "ok" and body.get("id"):
                        placed_ids.append(body["id"])
                self.session_state["last_signal"] = signal
                print(f"{signal} positions entered successfully ✅")
            else:
                print(
                    f"Basket order failed: {entry_resp.get('message', 'Unknown error') if isinstance(entry_resp, dict) else 'Unknown error'}")

            return placed_ids

        except Exception as e:
            print(f"Error: {str(e)}")
            return []
        finally:
            self.session_state["_hb_lock"] = False

    def calculate_daily_metrics(self, trade_history):
        if not trade_history:
            return None

        df = pd.DataFrame(trade_history)

        # Convert timestamp to datetime
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        df['date'] = df['timestamp'].dt.date

        # Calculate PnL if not present
        if 'pnl' not in df.columns:
            df['pnl'] = 0  # Default to 0 if PnL not calculated

        # Group by date
        daily = df.groupby('date').agg({
            'symbol': 'count',
            'pnl': ['sum', lambda x: (x > 0).sum(), lambda x: (x < 0).sum()],
            'price': lambda x: abs(x).sum()  # For volume proxy
        })

        daily.columns = ['total_trades', 'net_pnl', 'winning_trades', 'losing_trades', 'volume']

        # Calculate additional metrics
        daily['win_rate'] = (daily['winning_trades'] / daily['total_trades']) * 100
        daily['loss_rate'] = (daily['losing_trades'] / daily['total_trades']) * 100

        # Calculate profit factor
        gross_profit = df[df['pnl'] > 0].groupby('date')['pnl'].sum()
        gross_loss = abs(df[df['pnl'] < 0].groupby('date')['pnl'].sum())
        daily['profit_factor'] = gross_profit / gross_loss.replace(0, 1)  # Avoid division by zero

        # Calculate expectancy
        avg_win = df[df['pnl'] > 0].groupby('date')['pnl'].mean()
        avg_loss = df[df['pnl'] < 0].groupby('date')['pnl'].mean()
        daily['expectancy'] = (daily['win_rate'] / 100 * avg_win) + (daily['loss_rate'] / 100 * avg_loss)

        # Calculate max win/loss per trade
        daily['max_win'] = df.groupby('date')['pnl'].max()
        daily['max_loss'] = df.groupby('date')['pnl'].min()

        # Calculate risk-reward ratio
        daily['risk_reward'] = abs(avg_win / avg_loss.replace(0, 1))  # Avoid division by zero

        return daily.reset_index()

    def get_api_usage(self):
        oc = self.session_state.get("option_chain_api_count", 0)
        qc = self.session_state.get("quote_api_count", 0)
        return oc, qc