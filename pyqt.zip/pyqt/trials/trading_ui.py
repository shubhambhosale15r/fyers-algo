import sys
import pandas as pd
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                             QLabel, QLineEdit, QPushButton, QComboBox, QCheckBox,
                             QTableWidget, QTableWidgetItem, QTabWidget, QTextEdit,
                             QSpinBox, QGroupBox, QScrollArea, QSplitter, QHeaderView,
                             QMessageBox, QFileDialog, QFrame, QProgressBar, QToolBar, QStatusBar)
from PyQt5.QtCore import QTimer, Qt, QThread, pyqtSignal
from PyQt5.QtGui import QFont, QColor, QPalette, QIcon, QPixmap
from datetime import datetime
import pytz
import time

from trading_core import TradingCore, Config


class ApiWorker(QThread):
    """
    Worker thread for API calls to prevent UI freezing.
    Emits signals when data is ready or when an error occurs.
    """
    data_ready = pyqtSignal(object)
    error_occurred = pyqtSignal(str)
    progress_update = pyqtSignal(int, str)  # progress percentage, status message

    def __init__(self, function, *args, **kwargs):
        super().__init__()
        self.function = function
        self.args = args
        self.kwargs = kwargs
        self.is_running = True

    def run(self):
        """Execute the API function in a separate thread."""
        try:
            self.progress_update.emit(10, "Starting API call...")
            time.sleep(0.1)  # Small delay to show progress

            self.progress_update.emit(30, "Processing request...")
            result = self.function(*self.args, **self.kwargs)

            self.progress_update.emit(80, "Processing response...")
            time.sleep(0.1)  # Simulate processing time

            if not self.is_running:
                return

            self.progress_update.emit(100, "Data ready!")
            self.data_ready.emit(result)

        except Exception as e:
            if not self.is_running:
                return
            error_msg = f"API Error: {str(e)}"
            self.progress_update.emit(0, error_msg)
            self.error_occurred.emit(error_msg)

    def stop(self):
        """Stop the worker thread."""
        self.is_running = False
        self.quit()
        self.wait()


class ModernTradingApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.trading_core = TradingCore()
        self.api_worker = None
        self.init_ui()
        self.setup_timers()

    def init_ui(self):
        self.setWindowTitle("Fyers Algo Trading Pro")
        self.setGeometry(100, 50, 1600, 900)

        # Set application style
        self.setStyleSheet("""
            QMainWindow {
                # background-color: #2c3e50;
            }
            QWidget {
                # background-color: #34495e;
                # color: #ecf0f1;
                border: none;
                font-family: 'Segoe UI', Arial;
            }
            QGroupBox {
                font-weight: bold;
                border: 2px solid #7f8c8d;
                border-radius: 8px;
                margin-top: 1ex;
                padding-top: 10px;
                # background-color: #2c3e50;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px 0 5px;
                # color: #3498db;
            }
            QPushButton {
                # background-color: #3498db;
                border: none;
                # color: white;
                padding: 8px 16px;
                border-radius: 6px;
                font-weight: bold;
                margin: 2px;
            }
            QPushButton:hover {
                # background-color: #2980b9;
            }
            QPushButton:pressed {
                # background-color: #21618c;
            }
            QPushButton:disabled {
                # background-color: #7f8c8d;
                # color: #bdc3c7;
            }
            QLineEdit, QSpinBox, QComboBox {
                # background-color: #ecf0f1;
                # color: #2c3e50;
                border: 2px solid #bdc3c7;
                border-radius: 4px;
                padding: 5px;
                selection-background-color: #3498db;
            }
            QLineEdit:focus, QSpinBox:focus, QComboBox:focus {
                border: 2px solid #3498db;
            }
            QCheckBox {
                spacing: 5px;
            }
            QCheckBox::indicator {
                width: 18px;
                height: 18px;
            }
            QCheckBox::indicator:unchecked {
                # background-color: #ecf0f1;
                border: 2px solid #bdc3c7;
                border-radius: 3px;
            }
            QCheckBox::indicator:checked {
                # background-color: #3498db;
                border: 2px solid #3498db;
                border-radius: 3px;
                image: url(:/images/checkmark.png);
            }
            QTabWidget::pane {
                border: 1px solid #7f8c8d;
                # background-color: #2c3e50;
                border-radius: 4px;
            }
            QTabBar::tab {
                # background-color: #34495e;
                # color: #bdc3c7;
                padding: 8px 16px;
                margin-right: 2px;
                border-top-left-radius: 4px;
                border-top-right-radius: 4px;
            }
            QTabBar::tab:selected {
                # background-color: #2c3e50;
                # color: #3498db;
                border-bottom: 2px solid #3498db;
            }
            QTabBar::tab:hover:!selected {
                # background-color: #3d566e;
            }
            QTableWidget {
                # background-color: #ecf0f1;
                # color: #2c3e50;
                gridline-color: #bdc3c7;
                border: 1px solid #7f8c8d;
                border-radius: 4px;
            }
            QTableWidget::item:selected {
                # background-color: #3498db;
                # color: white;
            }
            QHeaderView::section {
                # background-color: #3498db;
                # color: white;
                padding: 6px;
                border: none;
                font-weight: bold;
            }
            QTextEdit {
                # background-color: #ecf0f1;
                # color: #2c3e50;
                border: 1px solid #bdc3c7;
                border-radius: 4px;
                font-family: 'Consolas', 'Monaco', monospace;
            }
            QLabel {
                # color: #ecf0f1;
            }
            QStatusBar {
                # background-color: #2c3e50;
                # color: #ecf0f1;
            }
            QProgressBar {
                border: 1px solid #7f8c8d;
                border-radius: 4px;
                text-align: center;
                # background-color: #34495e;
            }
            QProgressBar::chunk {
                background-color: #3498db;
                width: 10px;
            }
        """)

        # Create central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QHBoxLayout(central_widget)
        main_layout.setSpacing(10)
        main_layout.setContentsMargins(10, 10, 10, 10)

        # Create sidebar
        sidebar = QWidget()
        sidebar.setFixedWidth(320)
        sidebar.setStyleSheet(" border-right: 2px solid #7f8c8d;")
        sidebar_layout = QVBoxLayout(sidebar)
        sidebar_layout.setSpacing(15)
        sidebar_layout.setContentsMargins(10, 10, 10, 10)

        # App title in sidebar
        title_label = QLabel("Fyers Algo Trading")
        title_label.setStyleSheet("""
            QLabel {
                color: #3498db;
                font-size: 20px;
                font-weight: bold;
                padding: 10px;
                # background-color: #34495e;
                border-radius: 8px;
                qproperty-alignment: AlignCenter;
            }
        """)
        sidebar_layout.addWidget(title_label)

        # Navigation buttons
        nav_group = QGroupBox("Navigation")
        nav_layout = QVBoxLayout(nav_group)
        nav_layout.setSpacing(5)

        self.trading_btn = self.create_nav_button("📈 Live Trading", "trading")
        self.signal_history_btn = self.create_nav_button("📊 Signal History", "signal_history")
        self.daily_analysis_btn = self.create_nav_button("📋 Daily Analysis", "daily_analysis")
        self.paper_trading_btn = self.create_nav_button("💸 Paper Trading", "paper_trading")

        nav_layout.addWidget(self.trading_btn)
        nav_layout.addWidget(self.signal_history_btn)
        nav_layout.addWidget(self.daily_analysis_btn)
        nav_layout.addWidget(self.paper_trading_btn)
        sidebar_layout.addWidget(nav_group)

        # Settings group
        settings_group = QGroupBox("Trading Settings")
        settings_layout = QVBoxLayout(settings_group)
        settings_layout.setSpacing(8)

        self.auto_trade_check = QCheckBox("Enable Auto Trade")
        # self.auto_trade_check.setStyleSheet("color: #ecf0f1;")
        self.paper_trade_check = QCheckBox("Enable Paper Trading")
        # self.paper_trade_check.setStyleSheet("color: #ecf0f1;")

        settings_layout.addWidget(self.auto_trade_check)
        settings_layout.addWidget(self.paper_trade_check)
        sidebar_layout.addWidget(settings_group)

        # Credentials group
        cred_group = QGroupBox("API Credentials")
        cred_layout = QVBoxLayout(cred_group)
        cred_layout.setSpacing(8)

        cred_layout.addWidget(QLabel("Client ID:"))
        self.cid_input = QLineEdit()
        self.cid_input.setText(self.trading_core.session_state["cid"])
        self.cid_input.textChanged.connect(self.update_credentials)
        cred_layout.addWidget(self.cid_input)

        cred_layout.addWidget(QLabel("Access Token:"))
        self.token_input = QLineEdit()
        self.token_input.setEchoMode(QLineEdit.Password)
        self.token_input.setText(self.trading_core.session_state["token"])
        self.token_input.textChanged.connect(self.update_credentials)
        cred_layout.addWidget(self.token_input)

        cred_layout.addWidget(QLabel("Choose Index:"))
        self.sym_combo = QComboBox()
        self.sym_combo.addItems(["NSE:NIFTY50-INDEX", "BSE:SENSEX-INDEX"])
        cred_layout.addWidget(self.sym_combo)

        cred_layout.addWidget(QLabel("Quantity:"))
        self.quantity_spin = QSpinBox()
        self.quantity_spin.setMinimum(1)
        self.quantity_spin.setMaximum(1000)
        self.quantity_spin.setValue(Config.LOT_SIZE)
        self.quantity_spin.valueChanged.connect(self.update_quantity)
        cred_layout.addWidget(self.quantity_spin)
        sidebar_layout.addWidget(cred_group)

        # API usage group
        api_group = QGroupBox("API Usage")
        api_layout = QVBoxLayout(api_group)
        api_layout.setSpacing(8)

        self.oc_label = QLabel("Option Chain API: 0")
        self.qc_label = QLabel("Quote API: 0")
        self.total_label = QLabel("Total: 0/200 per minute")

        # Add progress bar for API usage
        self.api_progress = QProgressBar()
        self.api_progress.setRange(0, Config.API_RATE_LIMIT)
        self.api_progress.setValue(0)
        self.api_progress.setFormat("%v/%m API calls")

        api_layout.addWidget(self.oc_label)
        api_layout.addWidget(self.qc_label)
        api_layout.addWidget(self.total_label)
        api_layout.addWidget(self.api_progress)
        sidebar_layout.addWidget(api_group)

        # Add spacer at the bottom
        sidebar_layout.addStretch()

        # Main content area
        self.content_area = QTabWidget()
        self.content_area.setDocumentMode(True)
        self.content_area.tabBar().setExpanding(True)

        # Create pages
        self.trading_page = ModernTradingPage(self)
        self.signal_history_page = ModernSignalHistoryPage(self)
        self.daily_analysis_page = ModernDailyAnalysisPage(self)
        self.paper_trading_page = ModernPaperTradingPage(self)

        self.content_area.addTab(self.trading_page, "📈 Trading")
        self.content_area.addTab(self.signal_history_page, "📊 Signals")
        self.content_area.addTab(self.daily_analysis_page, "📋 Analysis")
        self.content_area.addTab(self.paper_trading_page, "💸 Paper Trading")

        # Add sidebar and content to main layout
        main_layout.addWidget(sidebar)
        main_layout.addWidget(self.content_area)

        # Create status bar
        self.statusBar = QStatusBar()
        self.setStatusBar(self.statusBar)
        self.status_label = QLabel("Ready")
        self.statusBar.addWidget(self.status_label)

        # Connection status indicator
        self.connection_status = QLabel("🔴 Disconnected")
        self.statusBar.addPermanentWidget(self.connection_status)

        # API progress indicator
        self.api_progress_label = QLabel("")
        self.statusBar.addPermanentWidget(self.api_progress_label)

        # Set initial page
        self.show_page("trading")

    def create_nav_button(self, text, page_name):
        button = QPushButton(text)
        button.setMinimumHeight(40)
        button.clicked.connect(lambda: self.show_page(page_name))
        return button

    def update_credentials(self):
        self.trading_core.set_credentials(self.cid_input.text(), self.token_input.text())

    def update_quantity(self, value):
        self.trading_core.set_lot_size(value)

    def show_page(self, page_name):
        self.trading_core.session_state["page"] = page_name
        if page_name == "trading":
            self.content_area.setCurrentIndex(0)
            self.trading_page.refresh()
        elif page_name == "signal_history":
            self.content_area.setCurrentIndex(1)
            self.signal_history_page.refresh()
        elif page_name == "daily_analysis":
            self.content_area.setCurrentIndex(2)
            self.daily_analysis_page.refresh()
        elif page_name == "paper_trading":
            self.content_area.setCurrentIndex(3)
            self.paper_trading_page.refresh()

    def setup_timers(self):
        self.refresh_timer = QTimer()
        self.refresh_timer.timeout.connect(self.refresh_data)
        self.refresh_timer.start(Config.REFRESH_INTERVAL * 1000)

    def refresh_data(self):
        if self.trading_core.session_state["page"] == "trading":
            self.trading_page.refresh()

        # Update API counters
        oc, qc = self.trading_core.get_api_usage()
        self.oc_label.setText(f"Option Chain API: {oc}")
        self.qc_label.setText(f"Quote API: {qc}")
        total = oc + qc
        self.total_label.setText(f"Total: {total}/{Config.API_RATE_LIMIT} per minute")
        self.api_progress.setValue(total)

        # Update connection status
        if total > 0:
            self.connection_status.setText("🟢 Connected")
        else:
            self.connection_status.setText("🔴 Disconnected")

        # Update status bar
        ist = pytz.timezone("Asia/Kolkata")
        self.status_label.setText(f"Last updated: {datetime.now(ist).strftime('%Y-%m-%d %H:%M:%S')}")

    def handle_api_progress(self, progress, message):
        """Handle progress updates from API worker."""
        self.api_progress_label.setText(message)

    def closeEvent(self, event):
        """Ensure worker threads are properly stopped when closing the app."""
        if self.api_worker and self.api_worker.isRunning():
            self.api_worker.stop()
        event.accept()


class ModernTradingPage(QWidget):
    def __init__(self, parent):
        super().__init__()
        self.parent = parent
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(10)
        layout.setContentsMargins(15, 15, 15, 15)

        # Header with title and refresh button
        header_layout = QHBoxLayout()

        title = QLabel("Live Trading Dashboard")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #3498db;")
        header_layout.addWidget(title)

        header_layout.addStretch()

        self.refresh_btn = QPushButton("🔄 Refresh")
        self.refresh_btn.clicked.connect(self.refresh)
        header_layout.addWidget(self.refresh_btn)

        layout.addLayout(header_layout)

        # Stats row
        stats_layout = QHBoxLayout()

        self.status_label = QLabel()
        self.status_label.setStyleSheet(" padding: 8px; border-radius: 6px;")
        stats_layout.addWidget(self.status_label)

        self.ltp_label = QLabel()
        self.ltp_label.setStyleSheet("""
            QLabel {
                # background-color: #27ae60;
                color: white;
                padding: 8px;
                border-radius: 6px;
                font-weight: bold;
            }
        """)
        stats_layout.addWidget(self.ltp_label)

        self.signal_label = QLabel()
        self.signal_label.setStyleSheet("""
            QLabel {
                padding: 8px;
                border-radius: 6px;
                font-weight: bold;
            }
        """)
        stats_layout.addWidget(self.signal_label)

        layout.addLayout(stats_layout)

        # Splitter for table and details
        splitter = QSplitter(Qt.Horizontal)

        # Option chain table
        table_frame = QFrame()
        table_layout = QVBoxLayout(table_frame)
        table_layout.addWidget(QLabel("Option Chain Data"))

        self.table = QTableWidget()
        self.table.setAlternatingRowColors(True)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        table_layout.addWidget(self.table)

        splitter.addWidget(table_frame)

        # Signal details
        details_frame = QFrame()
        details_layout = QVBoxLayout(details_frame)
        details_layout.addWidget(QLabel("Signal Analysis"))

        self.signal_details = QTextEdit()
        self.signal_details.setReadOnly(True)
        details_layout.addWidget(self.signal_details)

        splitter.addWidget(details_frame)

        # Set splitter sizes
        splitter.setSizes([700, 300])

        layout.addWidget(splitter)

    def refresh(self):
        # Update status
        ist = pytz.timezone("Asia/Kolkata")
        self.status_label.setText(f"Updated: {datetime.now(ist).strftime('%Y-%m-%d %H:%M:%S')}")

        # Get data from API
        sym = self.parent.sym_combo.currentText()

        # Start API worker to prevent UI freezing
        self.parent.api_worker = ApiWorker(self.parent.trading_core.update_all_data, sym)
        self.parent.api_worker.data_ready.connect(self.update_data)
        self.parent.api_worker.error_occurred.connect(self.handle_error)
        self.parent.api_worker.progress_update.connect(self.parent.handle_api_progress)
        self.parent.api_worker.start()

    def update_data(self, data):
        if not data or data[0] is None:
            return

        ltp, chain, curr_date = data

        # Update LTP
        self.ltp_label.setText(f"Underlying LTP: {ltp}")

        # Format and display option chain
        merged, atm = self.parent.trading_core.format_option_chain(chain, ltp)
        if merged is not None:
            self.update_table(merged, atm)

            # Get Fyers API instance for signal computation
            cid = self.parent.trading_core.session_state["cid"]
            token = self.parent.trading_core.session_state["token"]
            fy = None
            if cid and token:
                from fyers_apiv3 import fyersModel
                fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")

            # Compute signals
            signal, details = self.parent.trading_core.compute_signals(merged, atm, ltp, fyers_api=fy)

            # Update signal label with color coding
            if signal == "BUY":
                self.signal_label.setText("🟢 BUY Signal")
                self.signal_label.setStyleSheet(
                     " padding: 8px; border-radius: 6px; font-weight: bold;")
            elif signal == "SELL":
                self.signal_label.setText("🔴 SELL Signal")
                self.signal_label.setStyleSheet(
                     " padding: 8px; border-radius: 6px; font-weight: bold;")
            else:
                self.signal_label.setText("🟡 SIDEWAYS")
                self.signal_label.setStyleSheet(
                     " padding: 8px; border-radius: 6px; font-weight: bold;")

            self.signal_details.setText(details)

            # Record signal history
            if signal and ltp:
                ist = pytz.timezone("Asia/Kolkata")
                timestamp = datetime.now(ist).strftime('%Y-%m-%d %H:%M:%S')
                self.parent.trading_core.session_state["signal_history"].append({
                    "timestamp": timestamp,
                    "signal": signal,
                    "underlying_ltp": ltp,
                    "expiry_date": curr_date
                })

            # Select strikes
            sell_pe, buy_pe, sell_ce, buy_ce = self.parent.trading_core.select_strikes_atm_half_price(chain, atm)

            # Handle trading based on signal
            self.handle_trading(signal, sell_pe, buy_pe, sell_ce, buy_ce)

    def handle_error(self, error_msg):
        self.status_label.setText(f"Error: {error_msg}")

    def update_table(self, df, atm_strike):
        self.table.setRowCount(len(df))
        self.table.setColumnCount(len(df.columns))
        self.table.setHorizontalHeaderLabels(df.columns)

        for i, row in df.iterrows():
            for j, value in enumerate(row):
                item = QTableWidgetItem(str(value))

                # Highlight ATM row
                if j == 0 and value == atm_strike:
                    item.setBackground(QColor(52, 152, 219))
                    item.setForeground(QColor(255, 255, 255))

                self.table.setItem(i, j, item)

        self.table.resizeColumnsToContents()

    def handle_trading(self, signal, sell_pe, buy_pe, sell_ce, buy_ce):
        # Validate pairs
        valid_buy = (sell_pe is not None and buy_pe is not None)
        valid_sell = (sell_ce is not None and buy_ce is not None)

        # Initialize Fyers for auto trading
        fy = None
        if self.parent.auto_trade_check.isChecked():
            cid = self.parent.trading_core.session_state["cid"]
            token = self.parent.trading_core.session_state["token"]
            if cid and token:
                from fyers_apiv3 import fyersModel
                fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")

        # Trading logic
        if signal == "BUY" and not valid_buy:
            print("Missing option data for BUY signal. Unable to place trade.")
        elif signal == "SELL" and not valid_sell:
            print("Missing option data for SELL signal. Unable to place trade.")
        elif signal in ("BUY", "SELL"):
            if self.parent.paper_trade_check.isChecked():
                print(f"Signal detected: {signal} - Attempting paper trade")
                ids = self.parent.trading_core.handle_paper_trade(signal, sell_pe, buy_pe, sell_ce, buy_ce)
                self.parent.trading_core.session_state["paper_last_signal_order_ids"] = ids
            elif self.parent.auto_trade_check.isChecked() and fy:
                if self.parent.trading_core.session_state.get(
                        "live_last_signal") == signal and self.parent.trading_core.has_open_orders_for_last_signal(fy):
                    print(f"Basket for {signal} already open.")
                else:
                    ids = self.parent.trading_core.handle_basket_orders_atomic(signal, sell_pe, buy_pe, sell_ce, buy_ce,
                                                                               fy)
                    self.parent.trading_core.session_state["live_last_signal"] = signal
                    self.parent.trading_core.session_state["live_last_signal_order_ids"] = ids
            else:
                print(f"Auto trade disabled; signal: {signal}.")
        elif signal == "SIDEWAYS":
            if self.parent.paper_trade_check.isChecked():
                self.parent.trading_core.handle_paper_trade(signal, sell_pe, buy_pe, sell_ce, buy_ce)
            elif self.parent.auto_trade_check.isChecked() and fy:
                self.parent.trading_core.handle_basket_orders_atomic(signal, sell_pe, buy_pe, sell_ce, buy_ce, fy)
            else:
                print("Auto trade disabled; sideways.")
        else:
            print("No action.")


class ModernSignalHistoryPage(QWidget):
    def __init__(self, parent):
        super().__init__()
        self.parent = parent
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(10)
        layout.setContentsMargins(15, 15, 15, 15)

        # Header
        header_layout = QHBoxLayout()

        title = QLabel("Signal History")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #3498db;")
        header_layout.addWidget(title)

        header_layout.addStretch()

        self.export_btn = QPushButton("💾 Export to CSV")
        self.export_btn.clicked.connect(self.export_csv)
        header_layout.addWidget(self.export_btn)

        layout.addLayout(header_layout)

        # Table
        self.table = QTableWidget()
        self.table.setAlternatingRowColors(True)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.table)

    def refresh(self):
        history = self.parent.trading_core.session_state.get("signal_history", [])
        if not history:
            self.table.setRowCount(0)
            self.table.setColumnCount(0)
            return

        df = pd.DataFrame(history)
        df = df.sort_values("timestamp", ascending=False)

        self.table.setRowCount(len(df))
        self.table.setColumnCount(len(df.columns))
        self.table.setHorizontalHeaderLabels(df.columns)

        for i, row in df.iterrows():
            for j, value in enumerate(row):
                item = QTableWidgetItem(str(value))

                # Color code signals
                if j == 1:  # Signal column
                    if value == "BUY":
                        item.setBackground(QColor(39, 174, 96))
                        item.setForeground(QColor(255, 255, 255))
                    elif value == "SELL":
                        item.setBackground(QColor(231, 76, 60))
                        item.setForeground(QColor(255, 255, 255))

                self.table.setItem(i, j, item)

        self.table.resizeColumnsToContents()

    def export_csv(self):
        history = self.parent.trading_core.session_state.get("signal_history", [])
        if not history:
            return

        df = pd.DataFrame(history)
        filename, _ = QFileDialog.getSaveFileName(self, "Save CSV", "", "CSV Files (*.csv)")
        if filename:
            df.to_csv(filename, index=False)
            QMessageBox.information(self, "Success", f"Exported to {filename}")


class ModernDailyAnalysisPage(QWidget):
    def __init__(self, parent):
        super().__init__()
        self.parent = parent
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(10)
        layout.setContentsMargins(15, 15, 15, 15)

        # Header
        header_layout = QHBoxLayout()

        title = QLabel("Daily Trade Analysis")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #3498db;")
        header_layout.addWidget(title)

        header_layout.addStretch()

        self.export_btn = QPushButton("💾 Export to CSV")
        self.export_btn.clicked.connect(self.export_csv)
        header_layout.addWidget(self.export_btn)

        layout.addLayout(header_layout)

        # Metrics display
        metrics_group = QGroupBox("Performance Metrics")
        metrics_layout = QHBoxLayout(metrics_group)

        self.days_label = QLabel("Total Trading Days: 0")
        self.avg_pnl_label = QLabel("Average Daily PnL: ₹0.00")
        self.win_rate_label = QLabel("Average Win Rate: 0%")

        for label in [self.days_label, self.avg_pnl_label, self.win_rate_label]:
            label.setStyleSheet("""
                QLabel {
                    # background-color: #34495e;
                    padding: 10px;
                    border-radius: 6px;
                    font-weight: bold;
                }
            """)

        metrics_layout.addWidget(self.days_label)
        metrics_layout.addWidget(self.avg_pnl_label)
        metrics_layout.addWidget(self.win_rate_label)

        layout.addWidget(metrics_group)

        # Table for daily performance
        self.table = QTableWidget()
        self.table.setAlternatingRowColors(True)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.table)

    def refresh(self):
        trade_history = self.parent.trading_core.session_state.get("trade_history", [])
        if not trade_history:
            self.table.setRowCount(0)
            self.table.setColumnCount(0)
            self.days_label.setText("Total Trading Days: 0")
            self.avg_pnl_label.setText("Average Daily PnL: ₹0.00")
            self.win_rate_label.setText("Average Win Rate: 0%")
            return

        daily_metrics = self.parent.trading_core.calculate_daily_metrics(trade_history)
        if daily_metrics is None:
            return

        # Update metrics
        self.days_label.setText(f"Total Trading Days: {len(daily_metrics)}")
        self.avg_pnl_label.setText(f"Average Daily PnL: ₹{daily_metrics['net_pnl'].mean():.2f}")
        self.win_rate_label.setText(f"Average Win Rate: {daily_metrics['win_rate'].mean():.1f}%")

        # Update table
        self.update_table(daily_metrics)

    def update_table(self, daily_metrics):
        self.table.setRowCount(len(daily_metrics))
        self.table.setColumnCount(len(daily_metrics.columns))
        self.table.setHorizontalHeaderLabels(daily_metrics.columns)

        for i, row in daily_metrics.iterrows():
            for j, value in enumerate(row):
                item = QTableWidgetItem(str(value))

                # Color code PnL values
                if "pnl" in daily_metrics.columns[j].lower() and isinstance(value, (int, float)):
                    if value > 0:
                        item.setBackground(QColor(39, 174, 96))
                        item.setForeground(QColor(255, 255, 255))
                    elif value < 0:
                        item.setBackground(QColor(231, 76, 60))
                        item.setForeground(QColor(255, 255, 255))

                self.table.setItem(i, j, item)

        self.table.resizeColumnsToContents()

    def export_csv(self):
        trade_history = self.parent.trading_core.session_state.get("trade_history", [])
        if not trade_history:
            return

        daily_metrics = self.parent.trading_core.calculate_daily_metrics(trade_history)
        if daily_metrics is None:
            return

        filename, _ = QFileDialog.getSaveFileName(self, "Save CSV", "", "CSV Files (*.csv)")
        if filename:
            daily_metrics.to_csv(filename, index=False)
            QMessageBox.information(self, "Success", f"Exported to {filename}")


class ModernPaperTradingPage(QWidget):
    def __init__(self, parent):
        super().__init__()
        self.parent = parent
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(10)
        layout.setContentsMargins(15, 15, 15, 15)

        # Header
        header_layout = QHBoxLayout()

        title = QLabel("Paper Trading Dashboard")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #3498db;")
        header_layout.addWidget(title)

        header_layout.addStretch()

        self.export_btn = QPushButton("💾 Export History")
        self.export_btn.clicked.connect(self.export_csv)
        self.reset_btn = QPushButton("🔄 Reset Paper Trading")
        self.reset_btn.clicked.connect(self.reset_paper_trading)

        header_layout.addWidget(self.export_btn)
        header_layout.addWidget(self.reset_btn)

        layout.addLayout(header_layout)

        # PnL metrics
        pnl_group = QGroupBox("Profit & Loss")
        pnl_layout = QHBoxLayout(pnl_group)

        self.realized_label = QLabel("Realized PnL: ₹0.00")
        self.unrealized_label = QLabel("Unrealized PnL: ₹0.00")
        self.total_label = QLabel("Total PnL: ₹0.00")

        for label in [self.realized_label, self.unrealized_label, self.total_label]:
            label.setStyleSheet("""
                QLabel {
                    # background-color: #34495e;
                    padding: 10px;
                    border-radius: 6px;
                    font-weight: bold;
                }
            """)

        pnl_layout.addWidget(self.realized_label)
        pnl_layout.addWidget(self.unrealized_label)
        pnl_layout.addWidget(self.total_label)

        layout.addWidget(pnl_group)

        # Splitter for positions and history
        splitter = QSplitter(Qt.Horizontal)

        # Positions table
        positions_group = QGroupBox("Current Positions")
        positions_layout = QVBoxLayout(positions_group)
        self.positions_table = QTableWidget()
        self.positions_table.setAlternatingRowColors(True)
        self.positions_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        positions_layout.addWidget(self.positions_table)
        splitter.addWidget(positions_group)

        # Trade history table
        history_group = QGroupBox("Trade History")
        history_layout = QVBoxLayout(history_group)
        self.history_table = QTableWidget()
        self.history_table.setAlternatingRowColors(True)
        self.history_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        history_layout.addWidget(self.history_table)
        splitter.addWidget(history_group)

        # Set splitter sizes
        splitter.setSizes([400, 600])

        layout.addWidget(splitter)

    def refresh(self):
        # Update PnL
        realized = self.parent.trading_core.session_state["paper_pnl"]["realized"]
        unrealized = self.parent.trading_core.session_state["paper_pnl"]["unrealized"]
        total = realized + unrealized

        # Color code PnL values
        realized_color = "#27ae60" if realized >= 0 else "#e74c3c"
        unrealized_color = "#27ae60" if unrealized >= 0 else "#e74c3c"
        total_color = "#27ae60" if total >= 0 else "#e74c3c"

        self.realized_label.setText(f"Realized PnL: ₹{realized:.2f}")
        self.realized_label.setStyleSheet(
            f"background-color: {realized_color}; color: white; padding: 10px; border-radius: 6px; font-weight: bold;")

        self.unrealized_label.setText(f"Unrealized PnL: ₹{unrealized:.2f}")
        self.unrealized_label.setStyleSheet(
            f"background-color: {unrealized_color}; color: white; padding: 10px; border-radius: 6px; font-weight: bold;")

        self.total_label.setText(f"Total PnL: ₹{total:.2f}")
        self.total_label.setStyleSheet(
            f"background-color: {total_color}; color: white; padding: 10px; border-radius: 6px; font-weight: bold;")

        # Update positions table
        self.update_positions_table()

        # Update history table
        self.update_history_table()

    def update_positions_table(self):
        positions = self.parent.trading_core.session_state.get("paper_positions", {})
        if not positions:
            self.positions_table.setRowCount(0)
            self.positions_table.setColumnCount(0)
            return

        # Create dataframe from positions
        positions_list = []
        for symbol, position in positions.items():
            if position["action"] == "BUY":
                pnl = (position["current_price"] - position["entry_price"]) * position["qty"]
            else:
                pnl = (position["entry_price"] - position["current_price"]) * position["qty"]

            positions_list.append({
                "Symbol": position["symbol"],
                "Action": position["action"],
                "Qty": position["qty"],
                "Entry Price": position["entry_price"],
                "Current Price": position["current_price"],
                "PnL": pnl,
                "Signal": position["signal"]
            })

        df = pd.DataFrame(positions_list)

        self.positions_table.setRowCount(len(df))
        self.positions_table.setColumnCount(len(df.columns))
        self.positions_table.setHorizontalHeaderLabels(df.columns)

        for i, row in df.iterrows():
            for j, value in enumerate(row):
                item = QTableWidgetItem(str(value))

                # Color code PnL values
                if "PnL" in df.columns[j] and isinstance(value, (int, float)):
                    if value > 0:
                        item.setBackground(QColor(39, 174, 96))
                        item.setForeground(QColor(255, 255, 255))
                    elif value < 0:
                        item.setBackground(QColor(231, 76, 60))
                        item.setForeground(QColor(255, 255, 255))

                self.positions_table.setItem(i, j, item)

        self.positions_table.resizeColumnsToContents()

    def update_history_table(self):
        history = self.parent.trading_core.session_state.get("trade_history", [])
        if not history:
            self.history_table.setRowCount(0)
            self.history_table.setColumnCount(0)
            return

        df = pd.DataFrame(history)

        # Select desired columns
        desired_columns = ["timestamp", "symbol", "action", "qty", "price", "signal", "type", "pnl"]
        available_columns = [col for col in desired_columns if col in df.columns]
        df = df[available_columns]

        # Format timestamp
        df["timestamp"] = pd.to_datetime(df["timestamp"])
        df["timestamp"] = df["timestamp"].dt.strftime("%Y-%m-%d %H:%M:%S")
        df = df.sort_values("timestamp", ascending=False)

        self.history_table.setRowCount(len(df))
        self.history_table.setColumnCount(len(df.columns))
        self.history_table.setHorizontalHeaderLabels(df.columns)

        for i, row in df.iterrows():
            for j, value in enumerate(row):
                item = QTableWidgetItem(str(value))

                # Color code PnL values
                if "pnl" in df.columns[j] and isinstance(value, (int, float)):
                    if value > 0:
                        item.setBackground(QColor(39, 174, 96))
                        item.setForeground(QColor(255, 255, 255))
                    elif value < 0:
                        item.setBackground(QColor(231, 76, 60))
                        item.setForeground(QColor(255, 255, 255))

                self.history_table.setItem(i, j, item)

        self.history_table.resizeColumnsToContents()

    def export_csv(self):
        history = self.parent.trading_core.session_state.get("trade_history", [])
        if not history:
            return

        df = pd.DataFrame(history)
        filename, _ = QFileDialog.getSaveFileName(self, "Save CSV", "", "CSV Files (*.csv)")
        if filename:
            df.to_csv(filename, index=False)
            QMessageBox.information(self, "Success", f"Exported to {filename}")

    def reset_paper_trading(self):
        reply = QMessageBox.question(self, "Confirm Reset",
                                     "Are you sure you want to reset all paper trading data?",
                                     QMessageBox.Yes | QMessageBox.No, QMessageBox.No)

        if reply == QMessageBox.Yes:
            self.parent.trading_core.session_state["paper_trades"] = []
            self.parent.trading_core.session_state["paper_positions"] = {}
            self.parent.trading_core.session_state["paper_pnl"] = {"realized": 0.0, "unrealized": 0.0}
            self.parent.trading_core.session_state["trade_history"] = []
            self.parent.trading_core.session_state["last_signal"] = None
            self.refresh()
            QMessageBox.information(self, "Success", "Paper trading data reset!")


def main():
    app = QApplication(sys.argv)

    # Set application style
    app.setStyle('Fusion')

    window = ModernTradingApp()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()