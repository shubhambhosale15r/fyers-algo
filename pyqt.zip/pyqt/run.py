import  os
os.system("python trading_core.py")
os.system("python trading_ui.py")