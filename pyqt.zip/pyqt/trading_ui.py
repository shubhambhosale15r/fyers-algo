import sys
import pandas as pd
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                             QLabel, QLineEdit, QPushButton, QComboBox, QCheckBox,
                             QTableWidget, QTableWidgetItem, QTabWidget, QTextEdit,
                             QSpinBox, QGroupBox, QScrollArea, QSplitter, QHeaderView,
                             QMessageBox, QFileDialog)
from PyQt5.QtCore import QTimer, Qt, QThread, pyqtSignal
from PyQt5.QtGui import QFont, QColor, QPalette
from datetime import datetime
import pytz

from trading_core import *


class ApiWorker(QThread):
    data_ready = pyqtSignal(object)
    error_occurred = pyqtSignal(str)

    def __init__(self, function, *args, **kwargs):
        super().__init__()
        self.function = function
        self.args = args
        self.kwargs = kwargs

    def run(self):
        try:
            result = self.function(*self.args, **self.kwargs)
            self.data_ready.emit(result)
        except Exception as e:
            self.error_occurred.emit(str(e))


class TradingApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.trading_core = TradingCore()
        self.init_ui()
        self.setup_timers()

    def init_ui(self):
        self.setWindowTitle("Fyers Algo Trading")
        self.setGeometry(100, 100, 1400, 800)

        # Central widget and main layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QHBoxLayout(central_widget)

        # Sidebar
        sidebar = QWidget()
        sidebar.setFixedWidth(300)
        sidebar_layout = QVBoxLayout(sidebar)

        # Settings group
        settings_group = QGroupBox("Trading Settings")
        settings_layout = QVBoxLayout(settings_group)

        self.auto_trade_check = QCheckBox("Enable Auto Trade")
        self.paper_trade_check = QCheckBox("Enable Paper Trading")
        settings_layout.addWidget(self.auto_trade_check)
        settings_layout.addWidget(self.paper_trade_check)

        # Navigation group
        nav_group = QGroupBox("Navigation")
        nav_layout = QVBoxLayout(nav_group)

        self.trading_btn = QPushButton("Trading")
        self.signal_history_btn = QPushButton("Signal History")
        self.daily_analysis_btn = QPushButton("Daily Analysis")
        self.paper_trading_btn = QPushButton("Paper Trading")

        self.trading_btn.clicked.connect(lambda: self.show_page("trading"))
        self.signal_history_btn.clicked.connect(lambda: self.show_page("signal_history"))
        self.daily_analysis_btn.clicked.connect(lambda: self.show_page("daily_analysis"))
        self.paper_trading_btn.clicked.connect(lambda: self.show_page("paper_trading"))

        nav_layout.addWidget(self.trading_btn)
        nav_layout.addWidget(self.signal_history_btn)
        nav_layout.addWidget(self.daily_analysis_btn)
        nav_layout.addWidget(self.paper_trading_btn)

        # Credentials group
        cred_group = QGroupBox("API Credentials")
        cred_layout = QVBoxLayout(cred_group)

        cred_layout.addWidget(QLabel("Client ID:"))
        self.cid_input = QLineEdit()
        self.cid_input.setText(self.trading_core.session_state["cid"])
        self.cid_input.textChanged.connect(self.update_credentials)
        cred_layout.addWidget(self.cid_input)

        cred_layout.addWidget(QLabel("Access Token:"))
        self.token_input = QLineEdit()
        self.token_input.setEchoMode(QLineEdit.Password)
        self.token_input.setText(self.trading_core.session_state["token"])
        self.token_input.textChanged.connect(self.update_credentials)
        cred_layout.addWidget(self.token_input)

        cred_layout.addWidget(QLabel("Choose Index:"))
        self.sym_combo = QComboBox()
        self.sym_combo.addItems(["NSE:NIFTY50-INDEX", "BSE:SENSEX-INDEX"])
        cred_layout.addWidget(self.sym_combo)

        cred_layout.addWidget(QLabel("Quantity:"))
        self.quantity_spin = QSpinBox()
        self.quantity_spin.setMinimum(1)
        self.quantity_spin.setMaximum(1000)
        self.quantity_spin.setValue(Config.LOT_SIZE)
        self.quantity_spin.valueChanged.connect(self.update_quantity)
        cred_layout.addWidget(self.quantity_spin)

        # API usage group
        api_group = QGroupBox("API Usage")
        api_layout = QVBoxLayout(api_group)

        self.oc_label = QLabel("Option Chain API: 0")
        self.qc_label = QLabel("Quote API: 0")
        self.total_label = QLabel("Total: 0/200 per minute")

        api_layout.addWidget(self.oc_label)
        api_layout.addWidget(self.qc_label)
        api_layout.addWidget(self.total_label)

        # Add all groups to sidebar
        sidebar_layout.addWidget(settings_group)
        sidebar_layout.addWidget(nav_group)
        sidebar_layout.addWidget(cred_group)
        sidebar_layout.addWidget(api_group)
        sidebar_layout.addStretch()

        # Main content area
        self.content_area = QTabWidget()

        # Create pages
        self.trading_page = TradingPage(self)
        self.signal_history_page = SignalHistoryPage(self)
        self.daily_analysis_page = DailyAnalysisPage(self)
        self.paper_trading_page = PaperTradingPage(self)

        self.content_area.addTab(self.trading_page, "Trading")
        self.content_area.addTab(self.signal_history_page, "Signal History")
        self.content_area.addTab(self.daily_analysis_page, "Daily Analysis")
        self.content_area.addTab(self.paper_trading_page, "Paper Trading")

        # Add sidebar and content to main layout
        main_layout.addWidget(sidebar)
        main_layout.addWidget(self.content_area)

        # Set initial page
        self.show_page("trading")

    def update_credentials(self):
        self.trading_core.set_credentials(self.cid_input.text(), self.token_input.text())

    def update_quantity(self, value):
        self.trading_core.set_lot_size(value)

    def show_page(self, page_name):
        self.trading_core.session_state["page"] = page_name
        if page_name == "trading":
            self.content_area.setCurrentIndex(0)
            self.trading_page.refresh()
        elif page_name == "signal_history":
            self.content_area.setCurrentIndex(1)
            self.signal_history_page.refresh()
        elif page_name == "daily_analysis":
            self.content_area.setCurrentIndex(2)
            self.daily_analysis_page.refresh()
        elif page_name == "paper_trading":
            self.content_area.setCurrentIndex(3)
            self.paper_trading_page.refresh()

    def setup_timers(self):
        self.refresh_timer = QTimer()
        self.refresh_timer.timeout.connect(self.refresh_data)
        self.refresh_timer.start(Config.REFRESH_INTERVAL * 1000)

    def refresh_data(self):
        if self.trading_core.session_state["page"] == "trading":
            self.trading_page.refresh()

        # Update API counters
        oc, qc = self.trading_core.get_api_usage()
        self.oc_label.setText(f"Option Chain API: {oc}")
        self.qc_label.setText(f"Quote API: {qc}")
        self.total_label.setText(f"Total: {oc + qc}/{Config.API_RATE_LIMIT} per minute")



class TradingPage(QWidget):
    def __init__(self, parent):
        super().__init__()
        self.parent = parent
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)

        # Title
        title = QLabel("Live Trading")
        title.setFont(QFont("Arial", 16, QFont.Bold))
        layout.addWidget(title)

        # Status bar
        self.status_label = QLabel()
        layout.addWidget(self.status_label)

        # Underlying price
        self.ltp_label = QLabel()
        layout.addWidget(self.ltp_label)

        # Option chain table
        self.table = QTableWidget()
        layout.addWidget(self.table)

        # Signal info
        self.signal_label = QLabel()
        self.signal_label.setFont(QFont("Arial", 14))
        layout.addWidget(self.signal_label)

        # Signal details
        self.signal_details = QTextEdit()
        self.signal_details.setReadOnly(True)
        layout.addWidget(self.signal_details)

    def refresh(self):
        # Update status
        ist = pytz.timezone("Asia/Kolkata")
        self.status_label.setText(f"Updated: {datetime.now(ist).strftime('%Y-%m-%d %H:%M:%S')}")

        # Get data from API
        sym = self.parent.sym_combo.currentText()

        # Start API worker to prevent UI freezing
        self.worker = ApiWorker(self.parent.trading_core.update_all_data, sym)
        self.worker.data_ready.connect(self.update_data)
        self.worker.error_occurred.connect(self.handle_error)
        self.worker.start()


    def update_data(self, data):
        if not data or data[0] is None:
            return

        ltp, chain, curr_date = data

        # Update LTP
        self.ltp_label.setText(f"Underlying LTP: {ltp}")

        # Format and display option chain
        merged, atm = self.parent.trading_core.format_option_chain(chain, ltp)
        if merged is not None:
            self.update_table(merged, atm)

            # Get Fyers API instance for signal computation
            cid = self.parent.trading_core.session_state["cid"]
            token = self.parent.trading_core.session_state["token"]
            fy = None
            if cid and token:
                from fyers_apiv3 import fyersModel
                fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")

            # Compute signals
            signal, details = self.parent.trading_core.compute_signals(merged, atm, ltp, fyers_api=fy)
            self.signal_label.setText(f"Signal: {signal}")
            self.signal_details.setText(details)

            # Record signal history
            if signal and ltp:
                ist = pytz.timezone("Asia/Kolkata")
                timestamp = datetime.now(ist).strftime("%Y-%m-%d %H:%M:%S")
                self.parent.trading_core.session_state["signal_history"].append({
                    "timestamp": timestamp,
                    "signal": signal,
                    "underlying_ltp": ltp,
                    "expiry_date": curr_date
                })

            # Select strikes
            sell_pe, buy_pe, sell_ce, buy_ce = self.parent.trading_core.select_strikes_atm_half_price(chain, atm)

            # Handle trading based on signal
            self.handle_trading(signal, sell_pe, buy_pe, sell_ce, buy_ce)

    def handle_error(self, error_msg):
        self.status_label.setText(f"Error: {error_msg}")

    def update_table(self, df, atm_strike):
        self.table.setRowCount(len(df))
        self.table.setColumnCount(len(df.columns))
        self.table.setHorizontalHeaderLabels(df.columns)

        for i, row in df.iterrows():
            for j, value in enumerate(row):
                item = QTableWidgetItem(str(value))

                # Highlight ATM row
                if j == 0 and value == atm_strike:
                    item.setBackground(QColor("yellow"))

                self.table.setItem(i, j, item)

        self.table.resizeColumnsToContents()

    def handle_trading(self, signal, sell_pe, buy_pe, sell_ce, buy_ce):
        # Validate pairs
        valid_buy = (sell_pe is not None and buy_pe is not None)
        valid_sell = (sell_ce is not None and buy_ce is not None)

        # Initialize Fyers for auto trading
        fy = None
        if self.parent.auto_trade_check.isChecked():
            cid = self.parent.trading_core.session_state["cid"]
            token = self.parent.trading_core.session_state["token"]
            if cid and token:
                from fyers_apiv3 import fyersModel
                fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")

        # Trading logic
        if signal == "BUY" and not valid_buy:
            print("Missing option data for BUY signal. Unable to place trade.")
        elif signal == "SELL" and not valid_sell:
            print("Missing option data for SELL signal. Unable to place trade.")
        elif signal in ("BUY", "SELL"):
            if self.parent.paper_trade_check.isChecked():
                print(f"Signal detected: {signal} - Attempting paper trade")
                ids = self.parent.trading_core.handle_paper_trade(signal, sell_pe, buy_pe, sell_ce, buy_ce)
                self.parent.trading_core.session_state["paper_last_signal_order_ids"] = ids
            elif self.parent.auto_trade_check.isChecked() and fy:
                if self.parent.trading_core.session_state.get(
                        "live_last_signal") == signal and self.parent.trading_core.has_open_orders_for_last_signal(fy):
                    print(f"Basket for {signal} already open.")
                else:
                    ids = self.parent.trading_core.handle_basket_orders_atomic(signal, sell_pe, buy_pe, sell_ce, buy_ce,
                                                                               fy)
                    self.parent.trading_core.session_state["live_last_signal"] = signal
                    self.parent.trading_core.session_state["live_last_signal_order_ids"] = ids
            else:
                print(f"Auto trade disabled; signal: {signal}.")
        elif signal == "SIDEWAYS":
            if self.parent.paper_trade_check.isChecked():
                self.parent.trading_core.handle_paper_trade(signal, sell_pe, buy_pe, sell_ce, buy_ce)
            elif self.parent.auto_trade_check.isChecked() and fy:
                self.parent.trading_core.handle_basket_orders_atomic(signal, sell_pe, buy_pe, sell_ce, buy_ce, fy)
            else:
                print("Auto trade disabled; sideways.")
        else:
            print("No action.")


class SignalHistoryPage(QWidget):
    def __init__(self, parent):
        super().__init__()
        self.parent = parent
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)

        title = QLabel("Signal History")
        title.setFont(QFont("Arial", 16, QFont.Bold))
        layout.addWidget(title)

        self.table = QTableWidget()
        layout.addWidget(self.table)

        self.export_btn = QPushButton("Export to CSV")
        self.export_btn.clicked.connect(self.export_csv)
        layout.addWidget(self.export_btn)

    def refresh(self):
        history = self.parent.trading_core.session_state.get("signal_history", [])
        if not history:
            self.table.setRowCount(0)
            self.table.setColumnCount(0)
            return

        df = pd.DataFrame(history)
        df = df.sort_values("timestamp", ascending=False)

        self.table.setRowCount(len(df))
        self.table.setColumnCount(len(df.columns))
        self.table.setHorizontalHeaderLabels(df.columns)

        for i, row in df.iterrows():
            for j, value in enumerate(row):
                item = QTableWidgetItem(str(value))
                self.table.setItem(i, j, item)

        self.table.resizeColumnsToContents()

    def export_csv(self):
        history = self.parent.trading_core.session_state.get("signal_history", [])
        if not history:
            return

        df = pd.DataFrame(history)
        filename, _ = QFileDialog.getSaveFileName(self, "Save CSV", "", "CSV Files (*.csv)")
        if filename:
            df.to_csv(filename, index=False)
            QMessageBox.information(self, "Success", f"Exported to {filename}")


class DailyAnalysisPage(QWidget):
    def __init__(self, parent):
        super().__init__()
        self.parent = parent
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)

        title = QLabel("Daily Trade Analysis")
        title.setFont(QFont("Arial", 16, QFont.Bold))
        layout.addWidget(title)

        # Metrics display
        metrics_layout = QHBoxLayout()

        self.days_label = QLabel("Total Trading Days: 0")
        self.avg_pnl_label = QLabel("Average Daily PnL: ₹0.00")
        self.win_rate_label = QLabel("Average Win Rate: 0%")

        metrics_layout.addWidget(self.days_label)
        metrics_layout.addWidget(self.avg_pnl_label)
        metrics_layout.addWidget(self.win_rate_label)

        layout.addLayout(metrics_layout)

        # Table for daily performance
        self.table = QTableWidget()
        layout.addWidget(self.table)

        self.export_btn = QPushButton("Export to CSV")
        self.export_btn.clicked.connect(self.export_csv)
        layout.addWidget(self.export_btn)

    def refresh(self):
        trade_history = self.parent.trading_core.session_state.get("trade_history", [])
        if not trade_history:
            self.table.setRowCount(0)
            self.table.setColumnCount(0)
            self.days_label.setText("Total Trading Days: 0")
            self.avg_pnl_label.setText("Average Daily PnL: ₹0.00")
            self.win_rate_label.setText("Average Win Rate: 0%")
            return

        daily_metrics = self.parent.trading_core.calculate_daily_metrics(trade_history)
        if daily_metrics is None:
            return

        # Update metrics
        self.days_label.setText(f"Total Trading Days: {len(daily_metrics)}")
        self.avg_pnl_label.setText(f"Average Daily PnL: ₹{daily_metrics['net_pnl'].mean():.2f}")
        self.win_rate_label.setText(f"Average Win Rate: {daily_metrics['win_rate'].mean():.1f}%")

        # Update table
        self.update_table(daily_metrics)

    def update_table(self, daily_metrics):
        self.table.setRowCount(len(daily_metrics))
        self.table.setColumnCount(len(daily_metrics.columns))
        self.table.setHorizontalHeaderLabels(daily_metrics.columns)

        for i, row in daily_metrics.iterrows():
            for j, value in enumerate(row):
                item = QTableWidgetItem(str(value))
                self.table.setItem(i, j, item)

        self.table.resizeColumnsToContents()

    def export_csv(self):
        trade_history = self.parent.trading_core.session_state.get("trade_history", [])
        if not trade_history:
            return

        daily_metrics = self.parent.trading_core.calculate_daily_metrics(trade_history)
        if daily_metrics is None:
            return

        filename, _ = QFileDialog.getSaveFileName(self, "Save CSV", "", "CSV Files (*.csv)")
        if filename:
            daily_metrics.to_csv(filename, index=False)
            QMessageBox.information(self, "Success", f"Exported to {filename}")


class PaperTradingPage(QWidget):
    def __init__(self, parent):
        super().__init__()
        self.parent = parent
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)

        title = QLabel("Paper Trading Dashboard")
        title.setFont(QFont("Arial", 16, QFont.Bold))
        layout.addWidget(title)

        # PnL metrics
        pnl_layout = QHBoxLayout()

        self.realized_label = QLabel("Realized PnL: ₹0.00")
        self.unrealized_label = QLabel("Unrealized PnL: ₹0.00")
        self.total_label = QLabel("Total PnL: ₹0.00")

        pnl_layout.addWidget(self.realized_label)
        pnl_layout.addWidget(self.unrealized_label)
        pnl_layout.addWidget(self.total_label)

        layout.addLayout(pnl_layout)

        # Positions table
        positions_group = QGroupBox("Current Positions")
        positions_layout = QVBoxLayout(positions_group)
        self.positions_table = QTableWidget()
        positions_layout.addWidget(self.positions_table)
        layout.addWidget(positions_group)

        # Trade history table
        history_group = QGroupBox("Trade History")
        history_layout = QVBoxLayout(history_group)
        self.history_table = QTableWidget()
        history_layout.addWidget(self.history_table)
        layout.addWidget(history_group)

        # Buttons
        button_layout = QHBoxLayout()
        self.export_btn = QPushButton("Export History")
        self.reset_btn = QPushButton("Reset Paper Trading")

        self.export_btn.clicked.connect(self.export_csv)
        self.reset_btn.clicked.connect(self.reset_paper_trading)

        button_layout.addWidget(self.export_btn)
        button_layout.addWidget(self.reset_btn)
        layout.addLayout(button_layout)

    def refresh(self):
        # Update PnL
        realized = self.parent.trading_core.session_state["paper_pnl"]["realized"]
        unrealized = self.parent.trading_core.session_state["paper_pnl"]["unrealized"]
        total = realized + unrealized

        self.realized_label.setText(f"Realized PnL: ₹{realized:.2f}")
        self.unrealized_label.setText(f"Unrealized PnL: ₹{unrealized:.2f}")
        self.total_label.setText(f"Total PnL: ₹{total:.2f}")

        # Update positions table
        self.update_positions_table()

        # Update history table
        self.update_history_table()

    def update_positions_table(self):
        positions = self.parent.trading_core.session_state.get("paper_positions", {})
        if not positions:
            self.positions_table.setRowCount(0)
            self.positions_table.setColumnCount(0)
            return

        # Create dataframe from positions
        positions_list = []
        for symbol, position in positions.items():
            if position["action"] == "BUY":
                pnl = (position["current_price"] - position["entry_price"]) * position["qty"]
            else:
                pnl = (position["entry_price"] - position["current_price"]) * position["qty"]

            positions_list.append({
                "Symbol": position["symbol"],
                "Action": position["action"],
                "Qty": position["qty"],
                "Entry Price": position["entry_price"],
                "Current Price": position["current_price"],
                "PnL": pnl,
                "Signal": position["signal"]
            })

        df = pd.DataFrame(positions_list)

        self.positions_table.setRowCount(len(df))
        self.positions_table.setColumnCount(len(df.columns))
        self.positions_table.setHorizontalHeaderLabels(df.columns)

        for i, row in df.iterrows():
            for j, value in enumerate(row):
                item = QTableWidgetItem(str(value))
                self.positions_table.setItem(i, j, item)

        self.positions_table.resizeColumnsToContents()

    def update_history_table(self):
        history = self.parent.trading_core.session_state.get("trade_history", [])
        if not history:
            self.history_table.setRowCount(0)
            self.history_table.setColumnCount(0)
            return

        df = pd.DataFrame(history)

        # Select desired columns
        desired_columns = ["timestamp", "symbol", "action", "qty", "price", "signal", "type", "pnl"]
        available_columns = [col for col in desired_columns if col in df.columns]
        df = df[available_columns]

        # Format timestamp
        df["timestamp"] = pd.to_datetime(df["timestamp"])
        df["timestamp"] = df["timestamp"].dt.strftime("%Y-%m-%d %H:%M:%S")
        df = df.sort_values("timestamp", ascending=False)

        self.history_table.setRowCount(len(df))
        self.history_table.setColumnCount(len(df.columns))
        self.history_table.setHorizontalHeaderLabels(df.columns)

        for i, row in df.iterrows():
            for j, value in enumerate(row):
                item = QTableWidgetItem(str(value))
                self.history_table.setItem(i, j, item)

        self.history_table.resizeColumnsToContents()

    def export_csv(self):
        history = self.parent.trading_core.session_state.get("trade_history", [])
        if not history:
            return

        df = pd.DataFrame(history)
        filename, _ = QFileDialog.getSaveFileName(self, "Save CSV", "", "CSV Files (*.csv)")
        if filename:
            df.to_csv(filename, index=False)
            QMessageBox.information(self, "Success", f"Exported to {filename}")

    def reset_paper_trading(self):
        reply = QMessageBox.question(self, "Confirm Reset",
                                     "Are you sure you want to reset all paper trading data?",
                                     QMessageBox.Yes | QMessageBox.No, QMessageBox.No)

        if reply == QMessageBox.Yes:
            self.parent.trading_core.session_state["paper_trades"] = []
            self.parent.trading_core.session_state["paper_positions"] = {}
            self.parent.trading_core.session_state["paper_pnl"] = {"realized": 0.0, "unrealized": 0.0}
            self.parent.trading_core.session_state["trade_history"] = []
            self.parent.trading_core.session_state["last_signal"] = None
            self.refresh()
            QMessageBox.information(self, "Success", "Paper trading data reset!")


def main():
    app = QApplication(sys.argv)
    window = TradingApp()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()