import time
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import pytz
from fyers_apiv3 import fyersModel
import logging
import uuid
from functools import lru_cache
import os
import sys
import json
from typing import Dict, List, Any, Optional, Tuple
from collections import OrderedDict
import threading
import re
from pathlib import Path
import atexit
import signal
import hashlib
import shutil


# ============================================================================
# ENHANCED CONSTANTS WITH PERSISTENCE
# ============================================================================

class Config:
    REFRESH_INTERVAL = 30  # seconds
    API_RATE_LIMIT = 200
    API_WINDOW = 60  # seconds
    LOT_SIZE = 75  # nifty lot size
    MAX_RETRIES = 3
    RETRY_DELAY = 2  # seconds
    EXIT_ON_SIDEWAYS = True
    STOP_LOSS_PERCENT = 12.5  # of premium
    TARGET_PERCENT = 31.25    # of premium
    
    STATE_DIR = "trading_state"
    STATE_FILE = "trading_state.json"
    BACKUP_DIR = "state_backups"
    MAX_BACKUPS = 10
    AUTO_SAVE_INTERVAL = 300
    STATE_VERSION = "2.0"
    
    @classmethod
    def setup_directories(cls):
        for directory in [cls.STATE_DIR, cls.BACKUP_DIR]:
            Path(directory).mkdir(exist_ok=True)


Config.setup_directories()

logging.basicConfig(
    filename="trading_app.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)


class SignalMapper:
    BUY_CE = "BUY_CE"
    BUY_PE = "BUY_PE"
    HOLD = "HOLD"
    SIDEWAYS = "SIDEWAYS"
    
    @staticmethod
    def from_compute_to_tracker(signal):
        mapping = {
            "BUY": SignalMapper.BUY_CE,
            "SELL": SignalMapper.BUY_PE,
            "HOLD": SignalMapper.HOLD,
            "SIDEWAYS": SignalMapper.SIDEWAYS
        }
        return mapping.get(signal, signal)
    
    @staticmethod
    def to_display(signal):
        display_map = {
            SignalMapper.BUY_CE: "BUY CE",
            SignalMapper.BUY_PE: "BUY PE",
            SignalMapper.HOLD: "HOLD",
            SignalMapper.SIDEWAYS: "SIDEWAYS"
        }
        return display_map.get(signal, signal)
    
    @staticmethod
    def is_entry_signal(signal):
        return signal in [SignalMapper.BUY_CE, SignalMapper.BUY_PE]


def get_next_aligned_time(interval_seconds):
    now = datetime.now()
    current_seconds = (now - now.replace(hour=0, minute=0, second=0, microsecond=0)).total_seconds()
    intervals_passed = current_seconds // interval_seconds
    next_aligned_seconds = (intervals_passed + 1) * interval_seconds
    
    next_time = now.replace(hour=0, minute=0, second=0, microsecond=0) + timedelta(seconds=next_aligned_seconds)
    return next_time

def wait_until_next_interval(interval_seconds):
    next_time = get_next_aligned_time(interval_seconds)
    wait_seconds = (next_time - datetime.now()).total_seconds()
    
    if wait_seconds > 0:
        print(f"⏳ Next update at {next_time.strftime('%H:%M:%S')} (waiting {wait_seconds:.1f}s)")
        time.sleep(wait_seconds)


# ============================================================================
# STATE MANAGER WITH CORRUPTION DETECTION
# ============================================================================

class StateManager:
    def __init__(self):
        self.state_file = Path(Config.STATE_DIR) / Config.STATE_FILE
        self.backup_dir = Path(Config.BACKUP_DIR)
        self.lock = threading.RLock()
        self.register_shutdown_hook()
    
    def register_shutdown_hook(self):
        atexit.register(self.emergency_save)
        signal.signal(signal.SIGTERM, self.signal_handler)
        signal.signal(signal.SIGINT, self.signal_handler)
    
    def signal_handler(self, signum, frame):
        print(f"\n⚠️ Received signal {signum}. Saving state...")
        self.emergency_save()
        sys.exit(0)
    
    def emergency_save(self):
        try:
            print("💾 Emergency save attempted")
        except:
            pass
    
    def save_state(self, data: Dict) -> bool:
        with self.lock:
            try:
                state_data = {
                    'version': Config.STATE_VERSION,
                    'timestamp': datetime.now().isoformat(),
                    'data': data,
                }
                
                temp_file = self.state_file.with_suffix('.tmp')
                
                with open(temp_file, 'w') as f:
                    json.dump(state_data, f, indent=2, default=str)
                
                if os.name == 'nt':
                    try:
                        if self.state_file.exists():
                            os.remove(self.state_file)
                    except:
                        pass
                
                if os.name == 'nt':
                    os.replace(temp_file, self.state_file)
                else:
                    temp_file.rename(self.state_file)
                
                self._create_backup()
                print(f"💾 State saved")
                return True
                
            except Exception as e:
                print(f"❌ Failed to save state: {str(e)}")
                return False
    
    def load_state(self) -> Optional[Dict]:
        with self.lock:
            if not self.state_file.exists():
                print("📭 No saved state found")
                return None
            
            try:
                with open(self.state_file, 'r') as f:
                    state_data = json.load(f)
                
                if state_data.get('version') != Config.STATE_VERSION:
                    print(f"⚠️ State version mismatch. Expected {Config.STATE_VERSION}, got {state_data.get('version')}")
                    return None
                
                data = state_data['data']
                
                if not self._validate_state(data):
                    print("❌ State validation failed - possible corruption")
                    return None
                
                return data
                
            except Exception as e:
                print(f"❌ Failed to load state: {str(e)}")
                return self._load_from_backup()
    
    def _validate_state(self, data: Dict) -> bool:
        try:
            total_pnl = data.get('total_pnl', 0)
            if abs(total_pnl) > 1000000:
                print(f"⚠️ Suspicious total P&L: {total_pnl:.2f}")
                return False
            
            closed_trades = data.get('closed_trades', [])
            for trade in closed_trades:
                entry_price = trade.get('entry_price', 0)
                exit_price = trade.get('exit_price', 0)
                quantity = trade.get('quantity', 0)
                reported_pnl = trade.get('pnl', 0)
                
                if entry_price == 0 and quantity > 0:
                    print(f"⚠️ Corrupted trade: entry_price=0 for {trade.get('symbol')}")
                    return False
                
                calculated_pnl = (exit_price - entry_price) * quantity
                if abs(calculated_pnl - reported_pnl) > 0.01:
                    print(f"⚠️ P&L mismatch for {trade.get('symbol')}: reported={reported_pnl:.2f}, calculated={calculated_pnl:.2f}")
                    return False
                
                if entry_price < 0 or exit_price < 0:
                    print(f"⚠️ Negative prices for {trade.get('symbol')}")
                    return False
            
            active_trades = data.get('active_trades', {})
            for symbol, trade in active_trades.items():
                entry_price = trade.get('entry_price', 0)
                if entry_price <= 0:
                    print(f"⚠️ Invalid entry price for active trade {symbol}: {entry_price}")
                    return False
                
                sl_price = trade.get('sl_price', 0)
                target_price = trade.get('target_price', 0)
                
                if not (sl_price < entry_price < target_price):
                    print(f"⚠️ Invalid SL/Target for {symbol}: SL={sl_price:.2f}, Entry={entry_price:.2f}, Target={target_price:.2f}")
                    return False
            
            return True
            
        except Exception as e:
            print(f"⚠️ State validation error: {str(e)}")
            return False
    
    def _create_backup(self):
        try:
            if self.state_file.exists():
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                backup_file = self.backup_dir / f"state_backup_{timestamp}.json"
                shutil.copy2(self.state_file, backup_file)
                self._cleanup_old_backups()
        except Exception as e:
            print(f"⚠️ Backup creation failed: {str(e)}")
    
    def _cleanup_old_backups(self):
        try:
            backups = sorted(self.backup_dir.glob("state_backup_*.json"))
            if len(backups) > Config.MAX_BACKUPS:
                for old_backup in backups[:-Config.MAX_BACKUPS]:
                    old_backup.unlink()
        except Exception as e:
            print(f"⚠️ Backup cleanup failed: {str(e)}")
    
    def _load_from_backup(self) -> Optional[Dict]:
        try:
            backups = sorted(self.backup_dir.glob("state_backup_*.json"))
            if backups:
                print(f"🔄 Attempting to load from {len(backups)} backups...")
                
                for backup in reversed(backups):
                    try:
                        print(f"  Trying backup: {backup.name}")
                        with open(backup, 'r') as f:
                            state_data = json.load(f)
                        
                        data = state_data['data']
                        if self._validate_state(data):
                            print(f"✅ Valid backup found: {backup.name}")
                            return data
                        else:
                            print(f"⚠️ Backup failed validation: {backup.name}")
                    except:
                        continue
                
                print("❌ No valid backups found")
            else:
                print("📭 No backups available")
        
        except Exception as e:
            print(f"❌ Failed to load from backups: {str(e)}")
        
        return None


# ============================================================================
# ERROR HANDLING AND SESSION STATE
# ============================================================================

def handle_errors(func):
    def wrapper(*args, **kwargs):
        retries = 0
        while retries < Config.MAX_RETRIES:
            try:
                return func(*args, **kwargs)
            except Exception as e:
                retries += 1
                logging.error(f"Error in {func.__name__} (attempt {retries}): {str(e)}", exc_info=True)
                if retries < Config.MAX_RETRIES:
                    time.sleep(Config.RETRY_DELAY)
                else:
                    print(f"❌ Operation failed after {Config.MAX_RETRIES} attempts: {str(e)}")
                    return None
    return wrapper


class SessionState:
    def __init__(self):
        self.option_chain_api_count = 0
        self.quote_api_count = 0
        self.api_window_start = datetime.now()
        self.last_compute_signal = None
        self.last_tracker_signal = None
        self.cid = ""
        self.token = ""
        self._hb_lock = False
        self.position_tracker = None
        self.signal_buffer = []


def load_credentials(session_state):
    try:
        with open('fyers_credentials.json', 'r') as f:
            creds = json.load(f)
            session_state.cid = creds.get('client_id', '')
            session_state.token = creds.get('access_token', '')
            print("✅ Credentials loaded from JSON file")
    except FileNotFoundError:
        print("⚠️ JSON file not found, checking environment variables")
        session_state.cid = os.getenv("FYERS_CID", session_state.cid)
        session_state.token = os.getenv("FYERS_TOKEN", session_state.token)
    except Exception as e:
        print(f"❌ Error loading credentials: {str(e)}")
        session_state.cid = os.getenv("FYERS_CID", session_state.cid)
        session_state.token = os.getenv("FYERS_TOKEN", session_state.token)


def enforce_rate_limit(session_state):
    now = datetime.now()
    window = now - session_state.api_window_start
    total_calls = session_state.option_chain_api_count + session_state.quote_api_count

    if window > timedelta(seconds=Config.API_WINDOW):
        session_state.api_window_start = now
        session_state.option_chain_api_count = 0
        session_state.quote_api_count = 0
    elif total_calls >= Config.API_RATE_LIMIT:
        wait = Config.API_WINDOW - window.seconds
        print(f"⚠️ Approaching rate limit, waiting {wait}s...")
        time.sleep(wait)
        session_state.api_window_start = datetime.now()
        session_state.option_chain_api_count = 0
        session_state.quote_api_count = 0


# ============================================================================
# API FUNCTIONS
# ============================================================================

@handle_errors
@lru_cache(maxsize=32)
def get_option_chain_data(session_state, cid, token, sym, expiry_ts=""):
    print(f"🔍 Fetching option chain data for {sym}")
    enforce_rate_limit(session_state)
    session_state.option_chain_api_count += 1
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    resp = fy.optionchain(data={"symbol": sym, "timestamp": expiry_ts})
    if not resp or resp.get("code") != 200:
        error_msg = f"Option chain error: {resp.get('message', 'Unknown')}"
        logging.error(error_msg)
        print(f"❌ {error_msg}")
        return None
    print(f"✅ Option chain data fetched")
    return resp["data"]["optionsChain"]


@handle_errors
def get_underlying_ltp(session_state, cid, token, sym):
    print(f"🔍 Fetching underlying LTP for {sym}")
    enforce_rate_limit(session_state)
    session_state.quote_api_count += 1
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    resp = fy.quotes(data={"symbols": sym})
    if not resp or resp.get("code") != 200 or not resp.get("d"):
        error_msg = f"Quotes API error: {resp.get('message', 'Unknown')}"
        logging.error(error_msg)
        print(f"❌ {error_msg}")
        return None
    ltp = resp["d"][0]["v"]["lp"]
    print(f"✅ Underlying LTP: {ltp}")
    return ltp


# ============================================================================
# SIGNAL COMPUTATION
# ============================================================================

MAX_HISTORY = 1

def compute_signals(merged_df, atm_strike, sym='BSE:SENSEX-INDEX', fyers_api=None, session_state=None):
    print("\n[DEBUG] ================= compute_signals START =================")
    
    if not isinstance(sym, str) or ":" not in sym:
        print(f"[FATAL] Invalid underlying symbol: {sym}")
        return "SIDEWAYS", {}, {}

    try:
        resp = fyers_api.quotes(data={"symbols": sym})
        if resp.get("code") == 200 and resp.get("d"):
            v = resp["d"][0]["v"]
            nifty_ltp = float(v.get("lp", 0))
            nifty_high = float(v.get("high_price", 0))
            nifty_low = float(v.get("low_price", 0))
        else:
            nifty_ltp = nifty_high = nifty_low = 0.0
    except Exception as e:
        print(f"[FATAL] Underlying fetch failed: {e}")
        nifty_ltp = nifty_high = nifty_low = 0.0

    nifty_norm = (nifty_ltp - nifty_low) / max(nifty_high - nifty_low, 1e-6) if nifty_high > nifty_low else 0.5

    strikes = sorted(merged_df["Strike"].dropna().unique())
    if atm_strike not in strikes:
        print("[WARN] ATM strike missing")
        return "SIDEWAYS", {}, {}

    idx = strikes.index(atm_strike)
    sel = strikes[max(0, idx-1): idx+2]
    df = merged_df[merged_df["Strike"].isin(sel)].copy()

    for col in ["CE_symbol","PE_symbol","CE_ltp","PE_ltp"]:
        if col not in df.columns:
            df[col] = 0.0

    ce_symbols = df["CE_symbol"].dropna().astype(str).tolist()
    pe_symbols = df["PE_symbol"].dropna().astype(str).tolist()
    all_symbols = ce_symbols + pe_symbols

    if fyers_api and all_symbols:
        try:
            quotes_resp = fyers_api.quotes(data={"symbols": ",".join(all_symbols)})
            quotes_dict = {}
            if quotes_resp.get("code") == 200 and quotes_resp.get("d"):
                for item in quotes_resp["d"]:
                    quotes_dict[item["n"]] = item["v"]

            for idx_row, row in df.iterrows():
                ce_sym = str(row["CE_symbol"])
                ce_data = quotes_dict.get(ce_sym, {})
                df.at[idx_row, "CE_ltp"] = float(ce_data.get("lp", row["CE_ltp"] or 0))
                df.at[idx_row, "CE_high"] = float(ce_data.get("high_price", row.get("CE_high", row["CE_ltp"] or 0)))
                df.at[idx_row, "CE_low"] = float(ce_data.get("low_price", row.get("CE_low", row["CE_ltp"] or 0)))

                pe_sym = str(row["PE_symbol"])
                pe_data = quotes_dict.get(pe_sym, {})
                df.at[idx_row, "PE_ltp"] = float(pe_data.get("lp", row["PE_ltp"] or 0))
                df.at[idx_row, "PE_high"] = float(pe_data.get("high_price", row.get("PE_high", row["PE_ltp"] or 0)))
                df.at[idx_row, "PE_low"] = float(pe_data.get("low_price", row.get("PE_low", row["PE_ltp"] or 0)))
        except Exception as e:
            print(f"[WARN] CE/PE quote fetch failed: {e}")
            df["CE_high"] = df["CE_high"].replace(0, df["CE_ltp"])
            df["CE_low"] = df["CE_low"].replace(0, df["CE_ltp"])
            df["PE_high"] = df["PE_high"].replace(0, df["PE_ltp"])
            df["PE_low"] = df["PE_low"].replace(0, df["PE_ltp"])

    df["CE_norm"] = np.where(
        (df["CE_high"] - df["CE_low"]) > 0,
        (df["CE_ltp"] - df["CE_low"]) / (df["CE_high"] - df["CE_low"]),
        0
    )

    df["PE_norm"] = np.where(
        (df["PE_high"] - df["PE_low"]) > 0,
        (df["PE_ltp"] - df["PE_low"]) / (df["PE_high"] - df["PE_low"]),
        0
    )

    ce_norm = df["CE_norm"].mean()
    pe_norm = df["PE_norm"].mean()

    eps = 1e-6
    R1 = ce_norm / max(nifty_norm, eps)
    R2 = pe_norm / max(nifty_norm, eps)
    R3 = R1 / max(R2, eps)
    R3 = R3 / (R3+1)

    signal = "HOLD"
    if R1 > 1 and R3 > 0.75 and nifty_norm > 0.6:
        signal = "BUY"
        print(f"[SIGNAL] BUY  [R1 > 1 and R3 > 0.75 and {sym}_norm > 0.6]")
    elif R2 > 1 and R3 < 0.25 and nifty_norm < 0.4:
        signal = "SELL"
        print(f"[SIGNAL] SELL [R2 > 1 and R3 < 0.25 and {sym}_norm < 0.4]")
    else:
        signal = "HOLD"
        print("[SIGNAL] HOLD [No clear signal]")

    if session_state is not None:
        if not hasattr(session_state, "signal_buffer"):
            session_state.signal_buffer = []
        session_state.signal_buffer.append(signal)
        if len(session_state.signal_buffer) > MAX_HISTORY:
            session_state.signal_buffer.pop(0)
    print(f"[DEBUG] {sym} Norm: {nifty_norm:.4f}, R1: {R1:.4f}, R2: {R2:.4f}, R3: {R3:.4f}")
    print(f"[DEBUG] CE Norm: {ce_norm:.4f}, PE Norm: {pe_norm:.4f}")

    # Get option data for selected strike
    option_data = {}
    atm_row = df[df["Strike"] == atm_strike]
    if not atm_row.empty:
        option_data = {
            "ce_symbol": atm_row["CE_symbol"].iloc[0],
            "pe_symbol": atm_row["PE_symbol"].iloc[0],
            "ce_ltp": atm_row["CE_ltp"].iloc[0],
            "pe_ltp": atm_row["PE_ltp"].iloc[0],
        }

    print("[DEBUG] ================= compute_signals END =================\n")

    metrics = {
        "ce_norm": ce_norm,
        "pe_norm": pe_norm,
        "nifty_norm": nifty_norm,
        "R1": R1,
        "R2": R2,
        "R3": R3
    }

    return signal, metrics, option_data


def select_strikes_simple(chain, atm_strike, compute_signal=None):
    print(f"🔍 Selecting ATM strikes for signal: {compute_signal}")
    try:
        df = pd.DataFrame(chain)
        if df.empty or atm_strike is None:
            print("⚠️ No data or ATM strike for selection")
            return None, None

        ce = df[df["option_type"] == "CE"].copy()
        pe = df[df["option_type"] == "PE"].copy()

        atm_pe_row = pe[pe["strike_price"] == atm_strike]
        atm_ce_row = ce[ce["strike_price"] == atm_strike]

        if compute_signal == "BUY":
            option_row = atm_ce_row.iloc[0].to_dict() if not atm_ce_row.empty else None
            print(f"✅ Selected ATM CE for BUY signal")
            return option_row, None
            
        elif compute_signal == "SELL":
            option_row = atm_pe_row.iloc[0].to_dict() if not atm_pe_row.empty else None
            print(f"✅ Selected ATM PE for SELL signal")
            return None, option_row
            
        else:
            buy_pe_row = atm_pe_row.iloc[0].to_dict() if not atm_pe_row.empty else None
            buy_ce_row = atm_ce_row.iloc[0].to_dict() if not atm_ce_row.empty else None
            print(f"✅ Selected both ATM strikes")
            return buy_ce_row, buy_pe_row

    except Exception as e:
        logging.error(f"Error in select_strikes_simple: {str(e)}", exc_info=True)
        print(f"❌ Error in select_strikes_simple: {str(e)}")
        return None, None


# ============================================================================
# PRICE VALIDATION FUNCTIONS (NEW)
# ============================================================================

def get_current_option_price(session_state, fyers, atm_strike, compute_signal):
    """Get current price from option chain immediately after order placement"""
    try:
        # Get FRESH option chain data
        chain = get_option_chain_data(session_state, session_state.cid, session_state.token, 
                                     'BSE:SENSEX-INDEX', "")
        
        if not chain:
            print("❌ Could not fetch option chain for price validation")
            return 0
        
        option_type = "CE" if compute_signal == "BUY" else "PE"
        
        for option in chain:
            if (option['strike_price'] == atm_strike and 
                option['option_type'] == option_type):
                
                # Use ASK price for buying (what you'll pay)
                ask_price = option.get('ask', 0)
                ltp_price = option.get('ltp', 0)
                
                print(f"📊 Fresh option chain data:")
                print(f"   Ask: {ask_price}")
                print(f"   LTP: {ltp_price}")
                print(f"   Bid: {option.get('bid', 'N/A')}")
                
                # Prefer ask price, fallback to LTP
                current_price = ask_price if ask_price > 0 else ltp_price
                
                # Validate price
                if current_price <= 0.01:
                    print(f"❌ Invalid price from chain: {current_price}")
                    return 0
                
                if current_price > 1000:
                    print(f"⚠️ Suspiciously high price: {current_price}")
                
                # Check spread
                if ask_price > 0 and ltp_price > 0:
                    spread_pct = ((ask_price - ltp_price) / ltp_price) * 100
                    if spread_pct > 20:
                        print(f"⚠️ Wide spread: {spread_pct:.1f}%")
                
                return current_price
        
        print(f"❌ Could not find {option_type} option at strike {atm_strike} in chain")
        return 0
                
    except Exception as e:
        print(f"❌ Error getting option chain price: {e}")
        return 0


def get_exit_price_from_chain(fyers, symbol):
    """Get current exit price from option chain"""
    try:
        # Parse symbol to get strike and type
        if 'CE' in symbol:
            option_type = "CE"
        elif 'PE' in symbol:
            option_type = "PE"
        else:
            print(f"❌ Cannot parse option type from {symbol}")
            return 0
        
        # Extract strike price
        import re
        strike_match = re.search(r'(\d{4,5})(CE|PE)', symbol)
        if strike_match:
            strike_price = int(strike_match.group(1))
        else:
            print(f"❌ Cannot parse strike from {symbol}")
            return 0
        
        # Get option chain
        underlying = "BSE:SENSEX-INDEX"
        chain_resp = fyers.optionchain(data={"symbol": underlying, "timestamp": ""})
        
        if chain_resp.get("code") == 200:
            chain = chain_resp["data"]["optionsChain"]
            
            for option in chain:
                if (option['strike_price'] == strike_price and 
                    option['option_type'] == option_type):
                    
                    # Use BID price for selling (what you'll receive)
                    bid_price = option.get('bid', 0)
                    ltp_price = option.get('ltp', 0)
                    
                    print(f"📊 Exit price from chain:")
                    print(f"   Bid: {bid_price}")
                    print(f"   LTP: {ltp_price}")
                    print(f"   Ask: {option.get('ask', 'N/A')}")
                    
                    # Prefer bid price, fallback to LTP
                    exit_price = bid_price if bid_price > 0 else ltp_price
                    
                    if exit_price <= 0.01:
                        print(f"⚠️ Invalid exit price from chain: {exit_price}")
                        return 0
                    
                    return exit_price
            
            print(f"❌ Could not find {symbol} in option chain")
            return 0
        else:
            print(f"❌ Failed to fetch option chain for exit price")
            return 0
            
    except Exception as e:
        print(f"❌ Error getting exit price: {e}")
        return 0


# ============================================================================
# POSITION TRACKER WITH OPTION CHAIN PRICING
# ============================================================================

class PositionTracker:
    def __init__(self, fyers_api, session_state=None):
        self.fyers = fyers_api
        self.session_state = session_state
        
        # Simple trade tracking
        self.active_trades = {}  # symbol -> trade_info
        self.closed_trades = []  # List of completed trades
        self.total_pnl = 0.0
        
        # State management
        self.state_manager = StateManager()
        self._load_state()
        
        print(f"🔄 PositionTracker initialized with {len(self.active_trades)} active trades")
    
    def _load_state(self):
        saved_state = self.state_manager.load_state()
        
        if saved_state:
            active_trades = saved_state.get('active_trades', {})
            closed_trades = saved_state.get('closed_trades', [])
            total_pnl = saved_state.get('total_pnl', 0.0)
            
            cleaned_active_trades = {}
            for symbol, trade in active_trades.items():
                if self._validate_trade(trade, symbol, "active"):
                    cleaned_active_trades[symbol] = trade
                else:
                    print(f"⚠️ Removing corrupted active trade: {symbol}")
            
            cleaned_closed_trades = []
            recovered_pnl = 0.0
            for trade in closed_trades:
                if self._validate_trade(trade, trade.get('symbol', 'unknown'), "closed"):
                    cleaned_closed_trades.append(trade)
                    recovered_pnl += trade.get('pnl', 0)
                else:
                    print(f"⚠️ Removing corrupted closed trade: {trade.get('symbol', 'unknown')}")
            
            if abs(total_pnl - recovered_pnl) > 1000:
                print(f"⚠️ P&L mismatch: saved={total_pnl:.2f}, calculated={recovered_pnl:.2f}. Using calculated.")
                total_pnl = recovered_pnl
            
            self.active_trades = cleaned_active_trades
            self.closed_trades = cleaned_closed_trades
            self.total_pnl = total_pnl
            
            print(f"📂 Loaded {len(self.active_trades)} active trades, {len(self.closed_trades)} closed trades")
            print(f"💰 Total P&L: {self.total_pnl:.2f}")
            
            self.sync_with_broker()
        else:
            print("📭 No saved state found or state was corrupted")
    
    def _validate_trade(self, trade, symbol, trade_type):
        try:
            if not symbol or symbol == "":
                return False
            
            entry_price = trade.get('entry_price', 0)
            quantity = trade.get('quantity', 0)
            
            if entry_price <= 0 or entry_price > 10000:
                print(f"⚠️ Invalid entry price for {symbol}: {entry_price}")
                return False
            
            if quantity <= 0:
                print(f"⚠️ Invalid quantity for {symbol}: {quantity}")
                return False
            
            if trade_type == "active":
                sl_price = trade.get('sl_price', 0)
                target_price = trade.get('target_price', 0)
                
                if not (sl_price < entry_price < target_price):
                    print(f"⚠️ Invalid SL/Target for {symbol}: SL={sl_price:.2f}, Entry={entry_price:.2f}, Target={target_price:.2f}")
                    return False
            
            elif trade_type == "closed":
                exit_price = trade.get('exit_price', 0)
                reported_pnl = trade.get('pnl', 0)
                calculated_pnl = (exit_price - entry_price) * quantity
                
                if abs(reported_pnl - calculated_pnl) > 0.01:
                    print(f"⚠️ P&L mismatch for {symbol}: reported={reported_pnl:.2f}, calculated={calculated_pnl:.2f}")
                    return False
            
            return True
            
        except Exception as e:
            print(f"⚠️ Trade validation error for {symbol}: {str(e)}")
            return False
    
    def _save_state(self):
        state_data = {
            'active_trades': self.active_trades,
            'closed_trades': self.closed_trades,
            'total_pnl': self.total_pnl,
            'last_save': datetime.now().isoformat()
        }
        return self.state_manager.save_state(state_data)
    
    def start_tracking(self, symbol, entry_price, quantity, signal):
        """
        Start tracking a new position with price from option chain
        """
        print(f"🎯 Starting tracking for {symbol}")
        
        # Final price validation
        if entry_price <= 0.01:
            print(f"❌ INVALID entry price: {entry_price}")
            
            # Try to get price from quotes as last resort
            try:
                resp = self.fyers.quotes(data={"symbols": symbol})
                if resp.get("code") == 200:
                    entry_price = resp["d"][0]["v"]["lp"]
                    print(f"✅ Using LTP as entry: {entry_price}")
                else:
                    print(f"❌ Failed to get price. Skipping tracking.")
                    return False
            except Exception as e:
                print(f"❌ Error fetching price: {e}")
                return False
        
        # Check if already tracking
        if symbol in self.active_trades:
            print(f"⚠️ Already tracking {symbol}, skipping duplicate")
            return False
        
        # Calculate SL and Target
        sl_price = entry_price * (1 - Config.STOP_LOSS_PERCENT / 100)
        target_price = entry_price * (1 + Config.TARGET_PERCENT / 100)
        
        trade_info = {
            'symbol': symbol,
            'entry_price': entry_price,
            'quantity': quantity,
            'signal': signal,
            'entry_time': datetime.now().isoformat(),
            'sl_price': sl_price,
            'target_price': target_price,
            'current_price': entry_price,
            'current_pnl': 0.0,
            'status': 'ACTIVE'
        }
        
        # Validate before saving
        if not self._validate_trade(trade_info, symbol, "active"):
            print(f"❌ Failed to validate trade for {symbol}")
            return False
        
        self.active_trades[symbol] = trade_info
        
        print(f"📝 Tracking started:")
        print(f"   Symbol: {symbol}")
        print(f"   Entry: {entry_price:.2f} (from option chain)")
        print(f"   Quantity: {quantity}")
        print(f"   SL: {sl_price:.2f} (-{Config.STOP_LOSS_PERCENT}%)")
        print(f"   Target: {target_price:.2f} (+{Config.TARGET_PERCENT}%)")
        print(f"   Signal: {SignalMapper.to_display(signal)}")
        
        self._save_state()
        return True
    
    def check_sl_target(self):
        trades_to_exit = []
        
        if not self.active_trades:
            return trades_to_exit
        
        # Update current prices
        self._update_current_prices()
        
        for symbol, trade in list(self.active_trades.items()):
            current_price = trade['current_price']
            entry_price = trade['entry_price']
            
            print(f"🔍 Checking {symbol}: Entry={entry_price:.2f}, Current={current_price:.2f}, "
                  f"SL={trade['sl_price']:.2f}, Target={trade['target_price']:.2f}")
            
            # For LONG positions (we only buy options)
            if current_price <= trade['sl_price']:
                print(f"🛑 STOP LOSS HIT for {symbol}! (Current: {current_price:.2f} ≤ SL: {trade['sl_price']:.2f})")
                trades_to_exit.append((symbol, "SL_HIT"))
                
            elif current_price >= trade['target_price']:
                print(f"✅ TARGET HIT for {symbol}! (Current: {current_price:.2f} ≥ Target: {trade['target_price']:.2f})")
                trades_to_exit.append((symbol, "TARGET_HIT"))
        
        return trades_to_exit
    
    def _update_current_prices(self):
        if not self.active_trades:
            return
        
        symbols = list(self.active_trades.keys())
        
        try:
            resp = self.fyers.quotes(data={"symbols": ",".join(symbols)})
            
            if resp.get("code") == 200:
                for item in resp.get("d", []):
                    symbol = item["n"]
                    current_price = item["v"]["lp"]
                    
                    if symbol in self.active_trades:
                        self.active_trades[symbol]['current_price'] = current_price
                        
                        # Update current P&L
                        entry_price = self.active_trades[symbol]['entry_price']
                        quantity = self.active_trades[symbol]['quantity']
                        self.active_trades[symbol]['current_pnl'] = (current_price - entry_price) * quantity
                        
        except Exception as e:
            print(f"⚠️ Failed to update prices: {e}")
    
    def exit_trade(self, symbol, exit_reason):
        """
        Exit a trade using option chain price for accuracy
        """
        if symbol not in self.active_trades:
            print(f"⚠️ No active trade for {symbol}")
            return False
        
        try:
            trade = self.active_trades[symbol]
            quantity = trade['quantity']
            entry_price = trade['entry_price']
            
            # Get exit price from option chain
            exit_price = get_exit_price_from_chain(self.fyers, symbol)
            
            if exit_price <= 0:
                # Fallback to current price
                self._update_current_prices()
                exit_price = trade['current_price']
                print(f"⚠️ Using tracker price for exit: {exit_price:.2f}")
            else:
                print(f"📊 Using option chain price for exit: {exit_price:.2f}")
            
            # Validate prices
            if entry_price <= 0:
                print(f"❌ INVALID entry price: {entry_price}")
                return False
            
            # Calculate P&L
            pnl = (exit_price - entry_price) * quantity
            
            print(f"📊 P&L calculation:")
            print(f"   Entry: {entry_price:.2f} (from option chain at entry)")
            print(f"   Exit: {exit_price:.2f} (from option chain at exit)")
            print(f"   P&L: {pnl:.2f}")
            
            # Place exit order
            exit_order = {
                "symbol": symbol,
                "qty": quantity,
                "type": 2,  # Market order
                "side": -1,  # Sell to close
                "productType": "MARGIN",
                "validity": "DAY",
            }
            
            response = self.fyers.place_order(data=exit_order)
            
            if response and response.get("s") == "ok":
                # Create closed trade record
                closed_trade = trade.copy()
                closed_trade['exit_price'] = exit_price
                closed_trade['exit_time'] = datetime.now().isoformat()
                closed_trade['exit_reason'] = exit_reason
                closed_trade['pnl'] = pnl
                closed_trade['status'] = 'CLOSED'
                
                # Validate closed trade
                if not self._validate_trade(closed_trade, symbol, "closed"):
                    print(f"⚠️ Closed trade validation failed, but recording anyway")
                
                self.closed_trades.append(closed_trade)
                self.total_pnl += pnl
                
                # Remove from active trades
                del self.active_trades[symbol]
                
                print(f"✅ Successfully exited {symbol}:")
                print(f"   Reason: {exit_reason}")
                
                self._save_state()
                return True
            else:
                print(f"❌ Failed to exit {symbol}: {response}")
                return False
                
        except Exception as e:
            print(f"❌ Error exiting trade {symbol}: {str(e)}")
            import traceback
            traceback.print_exc()
            return False
    
    def exit_all_trades(self, exit_reason=""):
        symbols = list(self.active_trades.keys())
        print(f"🔄 Exiting all {len(symbols)} trades: {symbols}")
        
        success_count = 0
        for symbol in symbols:
            if self.exit_trade(symbol, exit_reason):
                success_count += 1
        
        print(f"✅ Exited {success_count}/{len(symbols)} trades successfully")
        return success_count
    
    def sync_with_broker(self):
        try:
            resp = self.fyers.positions()
            if resp.get("s") != "ok":
                return False
            
            broker_active = {}
            for p in resp.get("netPositions", []):
                net_qty = p.get('netQty', 0)
                if net_qty > 0:
                    broker_active[p['symbol']] = {
                        'avg_price': p.get('avgPrice', p.get('buyAvg', 0)),
                        'quantity': net_qty
                    }
            
            # Clean ghost positions
            for symbol in list(self.active_trades.keys()):
                if symbol not in broker_active:
                    print(f"⚠️ {symbol} tracked but not in broker positions - cleaning up")
                    del self.active_trades[symbol]
            
            # Recover orphaned positions
            for symbol, broker_data in broker_active.items():
                if symbol not in self.active_trades:
                    print(f"⚠️ {symbol} in broker but not tracked - trying to recover")
                    
                    signal = SignalMapper.BUY_CE if 'CE' in symbol.upper() else SignalMapper.BUY_PE
                    
                    # Try to get price from option chain
                    entry_price = get_exit_price_from_chain(self.fyers, symbol)
                    if entry_price <= 0:
                        entry_price = broker_data['avg_price']
                    
                    self.start_tracking(
                        symbol=symbol,
                        entry_price=entry_price,
                        quantity=broker_data['quantity'],
                        signal=signal
                    )
            
            self._save_state()
            return True
            
        except Exception as e:
            print(f"❌ Error syncing with broker: {str(e)}")
            return False
    
    def get_active_trades(self):
        return dict(self.active_trades)
    
    def get_total_pnl(self):
        return self.total_pnl
    
    def get_closed_trades(self):
        return self.closed_trades.copy()
    
    def debug_print(self):
        print("\n" + "=" * 80)
        print("🧠 POSITION TRACKER DEBUG")
        print("=" * 80)
        print(f"Active Trades: {len(self.active_trades)}")
        for symbol, trade in self.active_trades.items():
            print(f"  {symbol}:")
            print(f"    Entry: {trade['entry_price']:.2f}, Current: {trade['current_price']:.2f}")
            print(f"    SL: {trade['sl_price']:.2f}, Target: {trade['target_price']:.2f}")
            print(f"    P&L: {trade['current_pnl']:.2f}, Signal: {SignalMapper.to_display(trade['signal'])}")
        
        print(f"\nTotal P&L: {self.total_pnl:.2f}")
        print(f"Closed Trades: {len(self.closed_trades)}")
        if self.closed_trades:
            print("Recent closed trades:")
            for trade in self.closed_trades[-3:]:
                pnl = trade.get('pnl', 0)
                pnl_color = "🟢" if pnl > 0 else "🔴" if pnl < 0 else "⚪"
                print(f"  {trade['symbol']}: {pnl_color} P&L={pnl:.2f}, Reason={trade.get('exit_reason', 'N/A')}")
        
        calculated_total = sum(t.get('pnl', 0) for t in self.closed_trades)
        if abs(calculated_total - self.total_pnl) > 0.01:
            print(f"⚠️ P&L MISMATCH: Total={self.total_pnl:.2f}, Sum of trades={calculated_total:.2f}")
        
        print("=" * 80 + "\n")


# ============================================================================
# TRADE EXECUTION WITH OPTION CHAIN PRICING
# ============================================================================

def wait_and_track_position(symbol, expected_price, fyers, position_tracker, signal, session_state, max_attempts=10):
    """
    Wait for order to appear in positions and start tracking with expected price
    """
    print(f"⏳ Waiting for {symbol} to appear in positions...")
    print(f"📊 Expected entry price from option chain: {expected_price:.2f}")
    
    for attempt in range(max_attempts):
        time.sleep(2)
        
        resp = fyers.positions()
        if resp.get("s") != "ok":
            print(f"⚠️ Failed to get positions (attempt {attempt+1}/{max_attempts})")
            continue
        
        for position in resp.get("netPositions", []):
            if (position['symbol'] == symbol and 
                position.get('netQty', 0) > 0):
                
                quantity = position.get('netQty', 0)
                
                # Use expected price from option chain, not broker's average
                entry_price = expected_price
                
                # Optional: Compare with broker's price
                broker_price = position.get('avgPrice', 0)
                if broker_price > 0:
                    diff_pct = abs(broker_price - entry_price) / entry_price * 100
                    if diff_pct > 20:
                        print(f"⚠️ Large price difference:")
                        print(f"   Option chain: {entry_price:.2f}")
                        print(f"   Broker avg: {broker_price:.2f}")
                        print(f"   Difference: {diff_pct:.1f}%")
                
                print(f"✅ Position found!")
                print(f"   Symbol: {symbol}")
                print(f"   Quantity: {quantity}")
                print(f"   Entry Price (from option chain): {entry_price:.2f}")
                
                # Start tracking with option chain price
                success = position_tracker.start_tracking(
                    symbol=symbol,
                    entry_price=entry_price,
                    quantity=quantity,
                    signal=signal
                )
                
                if success:
                    session_state.last_tracker_signal = signal
                    session_state.last_compute_signal = "BUY" if signal == SignalMapper.BUY_CE else "SELL"
                    return True
                else:
                    print(f"❌ Failed to start tracking for {symbol}")
                    return False
        
        print(f"⏳ Position not yet visible (attempt {attempt+1}/{max_attempts})")
    
    print(f"❌ Position never appeared after {max_attempts} attempts")
    return False


def place_trade_order(session_state, compute_signal, atm_strike, fyers, position_tracker):
    """
    Place trade based on signal with option chain price validation
    """
    print(f"\n📊 Processing {compute_signal} signal")
    
    # Map signal
    if compute_signal == "BUY":
        option_type = "CE"
        tracker_signal = SignalMapper.BUY_CE
    elif compute_signal == "SELL":
        option_type = "PE"
        tracker_signal = SignalMapper.BUY_PE
    else:
        print(f"❌ Invalid signal for trading: {compute_signal}")
        return False
    
    # Get option chain
    chain = get_option_chain_data(session_state, session_state.cid, session_state.token, 
                                 'BSE:SENSEX-INDEX', "")
    if not chain:
        return False
    
    # Find option symbol and get current price from chain
    option_symbol = None
    current_price = 0
    
    for option in chain:
        if (option['strike_price'] == atm_strike and 
            option['option_type'] == option_type):
            option_symbol = option['symbol']
            # Get current market price
            current_price = option.get('ask', option.get('ltp', 0))
            break
    
    if not option_symbol:
        print(f"❌ Could not find {option_type} option for strike {atm_strike}")
        return False
    
    # ✅ PRICE VALIDATION BEFORE ORDER
    print(f"📊 Current market price from option chain: {current_price:.2f}")
    
    if current_price <= 0.01:
        print(f"❌ INVALID PRICE: {current_price}")
        print(f"   Market may be closed or option not trading")
        return False
    
    if current_price > 1000:
        print(f"⚠️ UNUSUALLY HIGH PRICE: {current_price}")
        confirm = input("Continue with order? (y/n): ").lower()
        if confirm != 'y':
            print("❌ Order cancelled by user")
            return False
    
    # Check if already have position
    active_trades = position_tracker.get_active_trades()
    if option_symbol in active_trades:
        print(f"⚠️ Already have position in {option_symbol}, skipping")
        return False
    
    # Calculate expected SL/Target for display
    expected_sl = current_price * (1 - Config.STOP_LOSS_PERCENT / 100)
    expected_target = current_price * (1 + Config.TARGET_PERCENT / 100)
    
    print(f"📈 Expected levels:")
    print(f"   Entry: {current_price:.2f}")
    print(f"   SL: {expected_sl:.2f} (-{Config.STOP_LOSS_PERCENT}%)")
    print(f"   Target: {expected_target:.2f} (+{Config.TARGET_PERCENT}%)")
    
    # Place order
    order_data = {
        "symbol": option_symbol,
        "qty": Config.LOT_SIZE,
        "type": 2,  # Market order
        "side": 1,  # Buy
        "productType": "MARGIN",
        "validity": "DAY",
    }
    
    print(f"📤 Placing order: {order_data}")
    response = fyers.place_order(data=order_data)
    
    if response and response.get("s") == "ok":
        order_id = response.get('id', 'Unknown')
        print(f"✅ Order placed successfully! Order ID: {order_id}")
        
        # Get fresh price from option chain immediately after order
        fresh_price = get_current_option_price(session_state, fyers, atm_strike, compute_signal)
        
        if fresh_price <= 0:
            print(f"⚠️ Could not get fresh price, using previous: {current_price:.2f}")
            fresh_price = current_price
        else:
            print(f"📊 Fresh price after order: {fresh_price:.2f}")
        
        # Wait and track with option chain price
        return wait_and_track_position(
            option_symbol, fresh_price, fyers, position_tracker, 
            tracker_signal, session_state
        )
    else:
        print(f"❌ Order failed: {response}")
        return False


# ============================================================================
# MAIN TRADE HANDLING
# ============================================================================

def handle_trades(session_state, compute_signal, atm_strike, fyers, position_tracker, option_data=None):
    """
    Main trade handling function
    """
    print(f"\n🔍 Handling trades for signal: {compute_signal}")
    
    if session_state._hb_lock:
        print("⚠️ Another trade is already running. Skipping this cycle.")
        return
    
    session_state._hb_lock = True
    
    try:
        # 1. Sync with broker
        position_tracker.sync_with_broker()
        
        # 2. Check for SL/Target hits
        trades_to_exit = position_tracker.check_sl_target()
        if trades_to_exit:
            print(f"⚠️ Found {len(trades_to_exit)} positions to exit due to SL/Target")
            for symbol, exit_reason in trades_to_exit:
                position_tracker.exit_trade(symbol, exit_reason)
        
        # 3. Handle SIDEWAYS signal
        if compute_signal == "SIDEWAYS" and Config.EXIT_ON_SIDEWAYS:
            print("📊 SIDEWAYS signal -> Exiting all positions")
            active_trades = position_tracker.get_active_trades()
            if active_trades:
                position_tracker.exit_all_trades("SIDEWAYS_EXIT")
            else:
                print("✅ No positions to exit for SIDEWAYS signal")
            return
        
        # 4. Check signal change
        current_signal = session_state.last_tracker_signal
        tracker_signal = SignalMapper.from_compute_to_tracker(compute_signal)
        
        active_trades = position_tracker.get_active_trades()
        if (current_signal in [SignalMapper.BUY_CE, SignalMapper.BUY_PE] and 
            current_signal != tracker_signal and active_trades):
            print(f"⚠️ Signal changed ({current_signal} → {tracker_signal}). Exiting all positions...")
            position_tracker.exit_all_trades("SIGNAL_CHANGE")
        
        # 5. Enter new trade for BUY/SELL signals
        active_trades = position_tracker.get_active_trades()
        if not active_trades and compute_signal in ["BUY", "SELL"]:
            print(f"📥 Preparing new {compute_signal} trade entry...")
            place_trade_order(session_state, compute_signal, atm_strike, fyers, position_tracker)
        elif compute_signal in ["BUY", "SELL"] and active_trades:
            print(f"⚠️ Active trades exist. Skipping new {compute_signal} entry.")
            
    except Exception as e:
        print(f"❌ Error in handle_trades: {str(e)}")
        import traceback
        traceback.print_exc()
    finally:
        session_state._hb_lock = False
        print("🔓 Lock released.\n")


# ============================================================================
# DATA FUNCTIONS
# ============================================================================

def format_and_show(chain, title, ltp, show_signals=False, fyers_api=None, session_state=None):
    df = pd.DataFrame(chain)
    if df.empty:
        print(f"ℹ️ No data for {title}")
        return None, None, None, None

    ce = df[df["option_type"] == "CE"]
    pe = df[df["option_type"] == "PE"]

    cols = ["symbol", "strike_price", "oi", "volume", "ltp", "ask", "bid",
            "ltpch", "ltpchp", "oich", "oichp", "prev_oi"]

    ce_df = ce[cols].rename(columns={
        "strike_price": "Strike",
        "oi": "OI",
        "volume": "Vol",
        "ltpch": "LTPCh",
        "ltpchp": "LTPChP",
        "oich": "OICh",
        "oichp": "OIChP",
        "prev_oi": "PrevOI"
    })

    pe_df = pe[cols].rename(columns={
        "strike_price": "Strike",
        "oi": "OI",
        "volume": "Vol",
        "ltpch": "LTPCh",
        "ltpchp": "LTPChP",
        "oich": "OICh",
        "oichp": "OIChP",
        "prev_oi": "PrevOI"
    })

    merged = pd.merge(
        ce_df.add_prefix("CE_"),
        pe_df.add_prefix("PE_"),
        left_on="CE_Strike",
        right_on="PE_Strike",
        how="outer"
    ).rename(columns={"CE_Strike": "Strike"}).drop("PE_Strike", axis=1)

    atm = None
    if ltp is not None and not merged["Strike"].dropna().empty:
        atm = min(merged["Strike"].dropna(), key=lambda x: abs(x - ltp))

    print(f"\n📈 {title}")

    if show_signals and atm is not None:
        compute_signal, metrics, option_data = compute_signals(merged, atm, sym='BSE:SENSEX-INDEX',
                                                              fyers_api=fyers_api, session_state=session_state)
        
        tracker_signal = SignalMapper.from_compute_to_tracker(compute_signal)
        print(f"✅ Compute Signal: {compute_signal} -> Tracker Signal: {tracker_signal}")

    print(f"📊 ATM Strike: {atm} | Underlying LTP: {ltp}")

    if show_signals and atm is not None:
        return compute_signal, atm, metrics, option_data
    return None, atm, None, None


@handle_errors
def update_all_data(session_state, cid, token, sym):
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    enforce_rate_limit(session_state)
    session_state.option_chain_api_count += 1

    meta = fy.optionchain(data={"symbol": sym, "timestamp": ""})
    if meta.get("code") != 200:
        print("❌ Failed to fetch expiry data")
        return None, None, None

    exp = sorted(
        [(e["date"], e.get("expiry")) for e in meta["data"]["expiryData"]],
        key=lambda x: datetime.strptime(x[0], "%d-%m-%Y")
    )
    today = datetime.today().date()
    dates = [datetime.strptime(d, "%d-%m-%Y").date() for d, _ in exp]
    idx = next((i for i, d in enumerate(dates) if d >= today), 0)
    curr_date, curr_ts = exp[idx]

    ltp = get_underlying_ltp(session_state, cid, token, sym)
    chain = get_option_chain_data(session_state, cid, token, sym, expiry_ts=curr_ts)

    return ltp, chain, curr_date


# ============================================================================
# DASHBOARD
# ============================================================================

class TerminalDashboard:
    def __init__(self, position_tracker):
        self.position_tracker = position_tracker

    def display_live_dashboard(self):
        os.system('cls' if os.name == 'nt' else 'clear')

        # Sync with broker
        self.position_tracker.sync_with_broker()
        
        # Get data
        active_trades = self.position_tracker.get_active_trades()
        total_pnl = self.position_tracker.get_total_pnl()
        closed_trades = self.position_tracker.get_closed_trades()

        print("\n" + "=" * 100)
        print("📊 LIVE TRADING DASHBOARD - OPTION CHAIN PRICING")
        print("=" * 100)
        print(f"Last Update: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"SL: {Config.STOP_LOSS_PERCENT}% | Target: {Config.TARGET_PERCENT}%")
        print("💰 Strategy: BUY CE for BUY signal | BUY PE for SELL signal")
        print("📊 Pricing: Entry/Exit prices from Option Chain (Ask/Bid)")
        print("-" * 100)

        # Display active trades
        if active_trades:
            print(f"\n💰 ACTIVE TRADES ({len(active_trades)}):")
            for symbol, trade in active_trades.items():
                pnl_color = "🟢" if trade['current_pnl'] > 0 else "🔴" if trade['current_pnl'] < 0 else "⚪"
                
                signal_display = SignalMapper.to_display(trade.get('signal', ''))
                
                print(f"   {symbol} ({signal_display})")
                print(f"     Entry: {trade['entry_price']:.2f} | Current: {trade['current_price']:.2f}")
                print(f"     Qty: {trade['quantity']} | Unrealized P&L: {pnl_color} {trade['current_pnl']:.2f}")
                print(f"     SL: {trade['sl_price']:.2f} | Target: {trade['target_price']:.2f}")
        else:
            print(f"\n💰 ACTIVE TRADES: No active trades")

        # Display P&L summary
        print(f"\n📊 P&L SUMMARY:")
        print(f"   Total P&L: {total_pnl:.2f}")
        
        if closed_trades:
            profitable = len([t for t in closed_trades if t['pnl'] > 0])
            total = len(closed_trades)
            win_rate = (profitable / total * 100) if total > 0 else 0
            
            sl_hits = len([t for t in closed_trades if t.get('exit_reason') == 'SL_HIT'])
            target_hits = len([t for t in closed_trades if t.get('exit_reason') == 'TARGET_HIT'])
            
            print(f"   Total Trades: {total}")
            print(f"   Profitable: {profitable}")
            print(f"   Win Rate: {win_rate:.1f}%")
            print(f"   SL Hits: {sl_hits} | Target Hits: {target_hits}")
            
            if closed_trades:
                print(f"\n📋 RECENT CLOSED TRADES:")
                for trade in closed_trades[-3:]:
                    pnl = trade.get('pnl', 0)
                    pnl_color = "🟢" if pnl > 0 else "🔴" if pnl < 0 else "⚪"
                    exit_reason_icon = {
                        'SL_HIT': '🛑',
                        'TARGET_HIT': '✅',
                        'SIDEWAYS_EXIT': '🔄',
                        'SIGNAL_CHANGE': '🔄',
                        'MANUAL_EXIT': '👋'
                    }.get(trade.get('exit_reason', ''), '❓')
                    
                    print(f"   {trade.get('symbol', 'N/A')} - {pnl_color} P&L: {pnl:.2f} {exit_reason_icon} ({trade.get('exit_reason', 'N/A')})")
        else:
            print(f"   No closed trades yet")

        print("\n" + "=" * 100)
        print(f"💾 State: {len(closed_trades)} trades saved | 🔄 Next update in {Config.REFRESH_INTERVAL} seconds")
        print("📊 Pricing: Option Chain Based | ✅ Corruption Detection: ACTIVE")
        print("=" * 100)


# ============================================================================
# MAIN APPLICATION
# ============================================================================

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def get_user_input(prompt, default=None, input_type=str):
    try:
        if default is not None:
            user_input = input(f"{prompt} [{default}]: ").strip()
            if user_input == "":
                return default
            return input_type(user_input)
        else:
            return input_type(input(f"{prompt}: ").strip())
    except ValueError:
        print("❌ Invalid input. Please try again.")
        return get_user_input(prompt, default, input_type)

def settings_menu(session_state):
    while True:
        clear_screen()
        print("\n" + "=" * 50)
        print("⚙️ SETTINGS")
        print("=" * 50)
        print(f"1. Client ID: {session_state.cid}")
        print(f"2. Access Token: {'*' * len(session_state.token) if session_state.token else 'Not set'}")
        print(f"3. Lot Size: {Config.LOT_SIZE}")
        print(f"4. Stop Loss %: {Config.STOP_LOSS_PERCENT}")
        print(f"5. Target %: {Config.TARGET_PERCENT}")
        print("6. 🔙 Back to Main Menu")

        choice = get_user_input("Select option", input_type=int)

        if choice == 1:
            session_state.cid = get_user_input("Enter Client ID", session_state.cid)
        elif choice == 2:
            session_state.token = get_user_input("Enter Access Token", session_state.token)
        elif choice == 3:
            Config.LOT_SIZE = get_user_input("Enter Lot Size", Config.LOT_SIZE, int)
        elif choice == 4:
            Config.STOP_LOSS_PERCENT = get_user_input("Enter Stop Loss %", Config.STOP_LOSS_PERCENT, float)
        elif choice == 5:
            Config.TARGET_PERCENT = get_user_input("Enter Target %", Config.TARGET_PERCENT, float)
        elif choice == 6:
            break
        else:
            print("❌ Invalid option. Please try again.")

def main():
    print("🚀 Starting Live Auto Trading Application - OPTION CHAIN PRICING FIX")
    print("📈 Strategy: BUY CE for BUY signals | BUY PE for SELL signals")
    print(f"💰 SL: {Config.STOP_LOSS_PERCENT}% | Target: {Config.TARGET_PERCENT}%")
    print("📊 Pricing: Entry/Exit prices from Option Chain (Ask/Bid)")
    print("🔧 Corruption detection: ENABLED")
    
    session_state = SessionState()
    load_credentials(session_state)

    sym = 'BSE:SENSEX-INDEX'

    while True:
        clear_screen()
        print("\n" + "=" * 100)
        print("📈 FYERS ALGO TRADING - OPTION CHAIN PRICING FIX")
        print("=" * 50)
        print("1. 📈 Start Live Trading (with Auto Dashboard)")
        print("2. ⚙️ Settings")
        print("3. 🐛 Debug State (Check for corruption)")
        print("4. 🧹 Reset State (Delete all saved data)")
        print("5. 🚪 Exit")
        print("=" * 50)

        choice = get_user_input("Select option", input_type=int)

        if choice == 1:
            clear_screen()
            print("\n" + "=" * 100)
            print("📈 LIVE AUTO TRADING - OPTION CHAIN PRICING")
            print("=" * 100)
            print(f"Strategy: BUY CE for BUY signals | BUY PE for SELL signals")
            print(f"SL: {Config.STOP_LOSS_PERCENT}% of premium | Target: {Config.TARGET_PERCENT}% of premium")
            print("📊 Pricing: Entry price = Option Chain Ask | Exit price = Option Chain Bid")
            print("🔧 Corruption detection: ACTIVE")
            print("=" * 100)

            if not (session_state.cid and session_state.token):
                print("❌ Please set Client ID and Access Token in Settings first.")
                input("Press Enter to continue...")
                continue

            auto_trade = get_user_input("Enable Auto Trade? (y/n)", "y").lower() == 'y'
            if not auto_trade:
                print("ℹ️ Auto trade disabled.")
                input("Press Enter to continue...")
                continue

            print("🔄 Starting live trading...")

            # Initialize Fyers API
            fy = fyersModel.FyersModel(
                client_id=session_state.cid, 
                token=session_state.token,
                is_async=False,
                log_path=""
            )
            
            # Initialize Position Tracker
            position_tracker = PositionTracker(fy, session_state)
            session_state.position_tracker = position_tracker
            
            # Initialize Dashboard
            dashboard = TerminalDashboard(position_tracker)

            try:
                iteration_count = 0
                while True:
                    iteration_count += 1

                    # Display dashboard
                    dashboard.display_live_dashboard()

                    print(f"\n🔄 Starting iteration {iteration_count} at {datetime.now().strftime('%H:%M:%S')}")

                    # Update data
                    ltp, chain, curr_date = update_all_data(session_state, session_state.cid, session_state.token, sym)

                    ist = pytz.timezone("Asia/Kolkata")
                    print(f"🕒 Data Updated: {datetime.now(ist).strftime('%Y-%m-%d %H:%M:%S')}") 

                    if ltp and chain:
                        compute_signal, atm, metrics, option_data = format_and_show(
                            chain, f"Current Expiry: {curr_date}", ltp,
                            show_signals=True,
                            fyers_api=fy, session_state=session_state
                        )

                        # Handle trades with option data
                        handle_trades(session_state, compute_signal, atm, fy, position_tracker, option_data)

                    print(f"⏳ Waiting {Config.REFRESH_INTERVAL} seconds before next update...")
                    wait_until_next_interval(Config.REFRESH_INTERVAL)

            except KeyboardInterrupt:
                print("\n⏹️ Live trading stopped by user")
                position_tracker.debug_print()
                input("Press Enter to continue...")

            except Exception as e:
                print(f"❌ Error in live trading: {str(e)}")
                import traceback
                traceback.print_exc()
                input("Press Enter to continue...")

        elif choice == 2:
            settings_menu(session_state)

        elif choice == 3:
            clear_screen()
            print("\n" + "=" * 50)
            print("🐛 DEBUG STATE")
            print("=" * 50)
            
            if session_state.position_tracker:
                session_state.position_tracker.debug_print()
            else:
                print("⚠️ Position tracker not initialized")
                
                state_file = Path(Config.STATE_DIR) / Config.STATE_FILE
                if state_file.exists():
                    print(f"\n📄 State file exists: {state_file}")
                    try:
                        with open(state_file, 'r') as f:
                            state = json.load(f)
                        
                        print(f"Version: {state.get('version')}")
                        print(f"Saved: {state.get('timestamp')}")
                        
                        data = state.get('data', {})
                        print(f"Total P&L: {data.get('total_pnl', 0):.2f}")
                        print(f"Active trades: {len(data.get('active_trades', {}))}")
                        print(f"Closed trades: {len(data.get('closed_trades', []))}")
                        
                    except Exception as e:
                        print(f"❌ Error reading state: {e}")
                else:
                    print("📭 No state file found")
            
            input("\nPress Enter to continue...")

        elif choice == 4:
            clear_screen()
            print("\n" + "=" * 50)
            print("🧹 RESET STATE")
            print("=" * 50)
            print("WARNING: This will delete ALL saved trading data!")
            print("This includes:")
            print("  - Active trades tracking")
            print("  - Closed trades history")
            print("  - Total P&L")
            print("  - All backups")
            print("\nThis action cannot be undone!")
            
            confirm = input("\nType 'RESET' to confirm: ").strip()
            if confirm == "RESET":
                try:
                    import shutil
                    shutil.rmtree(Config.STATE_DIR, ignore_errors=True)
                    shutil.rmtree(Config.BACKUP_DIR, ignore_errors=True)
                    Config.setup_directories()
                    print("✅ State reset complete. Starting fresh.")
                except Exception as e:
                    print(f"❌ Error resetting: {e}")
            else:
                print("❌ Reset cancelled.")
            
            input("\nPress Enter to continue...")

        elif choice == 5:
            print("👋 Exiting... Goodbye!")
            break

        else:
            print("❌ Invalid option. Please try again.")
            input("Press Enter to continue...")


if __name__ == "__main__":
    main()