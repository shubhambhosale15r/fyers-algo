import time
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import pytz
from fyers_apiv3 import fyersModel
import logging
import uuid
from functools import lru_cache
import os
import sys
import json
from typing import Dict, List, Any, Optional, Tuple, Set
from collections import OrderedDict
import threading


# Constants
class Config:
    REFRESH_INTERVAL = 60  # seconds
    API_RATE_LIMIT = 200
    API_WINDOW = 60  # seconds
    LOT_SIZE = 75  # nifty lot size
    MAX_RETRIES = 3
    RETRY_DELAY = 2  # seconds
    EXIT_ON_SIDEWAYS = True
    # Add SL and Target parameters (as percentage of premium)
    STOP_LOSS_PERCENT = 12.5  # of premium
    TARGET_PERCENT = 31.25    # of premium


# Initialize logging
logging.basicConfig(
    filename="trading_app.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)

def get_next_aligned_time(interval_seconds):
    """Get next time aligned to the interval"""
    now = datetime.now()
    current_seconds = (now - now.replace(hour=0, minute=0, second=0, microsecond=0)).total_seconds()
    intervals_passed = current_seconds // interval_seconds
    next_aligned_seconds = (intervals_passed + 1) * interval_seconds
    
    next_time = now.replace(hour=0, minute=0, second=0, microsecond=0) + timedelta(seconds=next_aligned_seconds)
    return next_time

def wait_until_next_interval(interval_seconds):
    """Wait until next aligned interval"""
    next_time = get_next_aligned_time(interval_seconds)
    wait_seconds = (next_time - datetime.now()).total_seconds()
    
    if wait_seconds > 0:
        print(f"⏳ Next update at {next_time.strftime('%H:%M:%S')} (waiting {wait_seconds:.1f}s)")
        time.sleep(wait_seconds)


# Position Tracker Class (IN-MEMORY ONLY)
class PositionTracker:
    """Track positions using Fyers API + In-Memory storage"""
    
    def __init__(self, fyers_api):
        self.fyers = fyers_api
        self.active_positions = OrderedDict()  # symbol -> position_data
        self.position_history = []  # List of closed positions
        self.last_refresh = None
        self.lock = threading.RLock()  # Thread-safe access
        self.total_pnl = 0.0
        
        # For manual SL/Target tracking (since no bracket orders for options)
        self.entry_prices = {}  # symbol -> entry_price
        self.sl_prices = {}     # symbol -> stop_loss_price
        self.target_prices = {} # symbol -> target_price
        self.trade_signals = {} # symbol -> signal ("BUY"/"SELL")
        self.trade_ids = {}     # symbol -> trade_id
        
        print("🔄 [DEBUG] PositionTracker initialized with empty in-memory storage")
    
    def refresh_positions(self):
        """Get fresh positions from Fyers API and update in-memory cache"""
        with self.lock:
            try:
                print("🔄 [DEBUG] Refreshing positions from Fyers API...")
                
                resp = self.fyers.positions()
                print(f"📡 [DEBUG] Raw Fyers positions response: {resp}")
                
                if resp.get("s") == "ok":
                    # Get only non-zero positions
                    net_positions = [p for p in resp.get("netPositions", [])
                                   if abs(p.get("netQty", 0)) != 0]
                    
                    print(f"🔍 [DEBUG] Found {len(net_positions)} non-zero positions")
                    
                    # Clear and rebuild active positions
                    old_active = set(self.active_positions.keys())
                    self.active_positions.clear()
                    
                    for p in net_positions:
                        symbol = p['symbol']
                        qty = p.get('netQty', 0)
                        avg_price = p.get('avgPrice', 0)
                        
                        # Get current price
                        current_price = self._get_current_price(symbol)
                        
                        position_data = {
                            'symbol': symbol,
                            'netQty': qty,
                            'avgPrice': avg_price,
                            'currentPrice': current_price,
                            'buyQty': p.get('buyQty', 0),
                            'sellQty': p.get('sellQty', 0),
                            'realized_profit': p.get('realized_profit', 0),
                            'unrealized_profit': p.get('pl', 0),
                            'exchange': p.get('exchange', ''),
                            'segment': p.get('segment', ''),
                            'productType': p.get('productType', ''),
                            'last_updated': datetime.now()
                        }
                        
                        self.active_positions[symbol] = position_data
                        
                        # If this is a new position, initialize SL/Target tracking
                        if symbol not in old_active and qty > 0:
                            self._initialize_sl_target(symbol, avg_price, "BUY" if qty > 0 else "SELL")
                            print(f"📝 [DEBUG] New position detected: {symbol}, Qty: {qty}, Avg Price: {avg_price}")
                        
                        print(f"📊 [DEBUG] Position {symbol}: Qty={qty}, Avg={avg_price:.2f}, Current={current_price:.2f}")
                    
                    self.last_refresh = datetime.now()
                    print(f"✅ [DEBUG] Positions refreshed. Active positions: {list(self.active_positions.keys())}")
                    return True
                    
                else:
                    print(f"❌ [DEBUG] Fyers positions API error: {resp.get('message', 'Unknown error')}")
                    return False
                    
            except Exception as e:
                print(f"❌ [DEBUG] Exception refreshing positions: {str(e)}")
                import traceback
                traceback.print_exc()
                return False
    
    def _get_current_price(self, symbol):
        """Get current LTP for a symbol"""
        try:
            resp = self.fyers.quotes({"symbols": symbol})
            if resp.get("code") == 200:
                return resp["d"][0]["v"]["lp"]
        except Exception as e:
            print(f"⚠️ [DEBUG] Error getting price for {symbol}: {e}")
        return 0
    
    def _initialize_sl_target(self, symbol, entry_price, signal):
        """Initialize SL and Target tracking for a new position"""
        with self.lock:
            self.entry_prices[symbol] = entry_price
            self.trade_signals[symbol] = signal
            self.trade_ids[symbol] = str(uuid.uuid4())[:8]
            
            # Calculate SL and Target
            if signal == "BUY":
                self.sl_prices[symbol] = entry_price * (1 - Config.STOP_LOSS_PERCENT/100)
                self.target_prices[symbol] = entry_price * (1 + Config.TARGET_PERCENT/100)
            else:  # SELL
                self.sl_prices[symbol] = entry_price * (1 - Config.STOP_LOSS_PERCENT/100)
                self.target_prices[symbol] = entry_price * (1 + Config.TARGET_PERCENT/100)
            
            print(f"🎯 [DEBUG] Initialized SL/Target for {symbol}:")
            print(f"   Entry: {entry_price:.2f}, Signal: {signal}")
            print(f"   SL: {self.sl_prices[symbol]:.2f} (-{Config.STOP_LOSS_PERCENT}%)")
            print(f"   Target: {self.target_prices[symbol]:.2f} (+{Config.TARGET_PERCENT}%)")
            print(f"   Trade ID: {self.trade_ids[symbol]}")
    
    def check_sl_target(self):
        """Check all active positions for SL/Target hits"""
        with self.lock:
            print(f"🔍 [DEBUG] Checking SL/Target for {len(self.active_positions)} active positions...")
            
            positions_to_exit = []
            
            for symbol, position in self.active_positions.items():
                if symbol not in self.entry_prices:
                    print(f"⚠️ [DEBUG] No entry price found for {symbol}, skipping SL/Target check")
                    continue
                
                current_price = position['currentPrice']
                entry_price = self.entry_prices[symbol]
                signal = self.trade_signals.get(symbol, "BUY")
                
                print(f"📊 [DEBUG] Checking {symbol}: Entry={entry_price:.2f}, Current={current_price:.2f}, Signal={signal}")
                
                # Check SL
                if signal == "BUY":
                    if current_price <= self.sl_prices[symbol]:
                        print(f"🛑 [DEBUG] {symbol}: SL HIT! Current={current_price:.2f}, SL={self.sl_prices[symbol]:.2f}")
                        positions_to_exit.append((symbol, "SL_HIT"))
                    elif current_price >= self.target_prices[symbol]:
                        print(f"✅ [DEBUG] {symbol}: TARGET HIT! Current={current_price:.2f}, Target={self.target_prices[symbol]:.2f}")
                        positions_to_exit.append((symbol, "TARGET_HIT"))
                else:  # SELL
                    if current_price <= self.sl_prices[symbol]:
                        print(f"🛑 [DEBUG] {symbol}: SL HIT! Current={current_price:.2f}, SL={self.sl_prices[symbol]:.2f}")
                        positions_to_exit.append((symbol, "SL_HIT"))
                    elif current_price >= self.target_prices[symbol]:
                        print(f"✅ [DEBUG] {symbol}: TARGET HIT! Current={current_price:.2f}, Target={self.target_prices[symbol]:.2f}")
                        positions_to_exit.append((symbol, "TARGET_HIT"))
            
            return positions_to_exit
    
    def exit_position(self, symbol, exit_reason=""):
        """Exit a position and update tracking"""
        with self.lock:
            if symbol not in self.active_positions:
                print(f"⚠️ [DEBUG] Cannot exit {symbol}: not in active positions")
                return False
            
            try:
                position = self.active_positions[symbol]
                qty = position['netQty']
                
                # Place exit order
                exit_order = {
                    "symbol": symbol,
                    "qty": abs(qty),
                    "type": 2,  # Market order
                    "side": -1 if qty > 0 else 1,  # Opposite side to exit
                    "productType": "MARGIN",
                    "validity": "DAY",
                }
                
                print(f"📤 [DEBUG] Exiting position {symbol}: {exit_order}")
                resp = self.fyers.place_order(data=exit_order)
                
                if resp and resp.get("s") == "ok":
                    # Calculate P&L
                    entry_price = self.entry_prices.get(symbol, 0)
                    exit_price = position['currentPrice']
                    pnl = (exit_price - entry_price) * abs(qty) if qty > 0 else (entry_price - exit_price) * abs(qty)
                    
                    # Record in history
                    closed_position = {
                        'trade_id': self.trade_ids.get(symbol, ''),
                        'symbol': symbol,
                        'signal': self.trade_signals.get(symbol, ''),
                        'entry_price': entry_price,
                        'exit_price': exit_price,
                        'quantity': abs(qty),
                        'pnl': pnl,
                        'exit_reason': exit_reason,
                        'exit_time': datetime.now(),
                        'entry_time': self.last_refresh if self.last_refresh else datetime.now()
                    }
                    
                    self.position_history.append(closed_position)
                    self.total_pnl += pnl
                    
                    # Clean up tracking
                    self._cleanup_position(symbol)
                    
                    print(f"✅ [DEBUG] Successfully exited {symbol}: P&L={pnl:.2f}, Reason={exit_reason}")
                    print(f"💰 [DEBUG] Total P&L: {self.total_pnl:.2f}")
                    return True
                else:
                    print(f"❌ [DEBUG] Failed to exit {symbol}: {resp}")
                    return False
                    
            except Exception as e:
                print(f"❌ [DEBUG] Error exiting position {symbol}: {str(e)}")
                return False
    
    def _cleanup_position(self, symbol):
        """Clean up tracking for a closed position"""
        with self.lock:
            if symbol in self.active_positions:
                del self.active_positions[symbol]
            if symbol in self.entry_prices:
                del self.entry_prices[symbol]
            if symbol in self.sl_prices:
                del self.sl_prices[symbol]
            if symbol in self.target_prices:
                del self.target_prices[symbol]
            if symbol in self.trade_signals:
                del self.trade_signals[symbol]
            if symbol in self.trade_ids:
                del self.trade_ids[symbol]
            
            print(f"🧹 [DEBUG] Cleaned up tracking for {symbol}")
    
    def exit_all_positions(self, exit_reason=""):
        """Exit all active positions"""
        with self.lock:
            symbols = list(self.active_positions.keys())
            print(f"🔄 [DEBUG] Exiting all {len(symbols)} positions: {symbols}")
            
            success_count = 0
            for symbol in symbols:
                if self.exit_position(symbol, exit_reason):
                    success_count += 1
            
            print(f"✅ [DEBUG] Exited {success_count}/{len(symbols)} positions successfully")
            return success_count
    
    def get_active_positions(self):
        """Return all active positions"""
        with self.lock:
            return dict(self.active_positions)
    
    def has_position(self, symbol):
        """Check if we have position in a symbol"""
        with self.lock:
            return symbol in self.active_positions
    
    def get_position_info(self, symbol):
        """Get detailed info for a position including SL/Target"""
        with self.lock:
            if symbol not in self.active_positions:
                return None
            
            position = self.active_positions[symbol].copy()
            position['entry_price'] = self.entry_prices.get(symbol, 0)
            position['stop_loss'] = self.sl_prices.get(symbol, 0)
            position['target'] = self.target_prices.get(symbol, 0)
            position['signal'] = self.trade_signals.get(symbol, '')
            position['trade_id'] = self.trade_ids.get(symbol, '')
            
            # Calculate current P&L
            if position['entry_price'] > 0:
                if position['signal'] == "BUY":
                    position['current_pnl'] = (position['currentPrice'] - position['entry_price']) * position['netQty']
                else:
                    position['current_pnl'] = (position['entry_price'] - position['currentPrice']) * position['netQty']
            else:
                position['current_pnl'] = 0
            
            return position
    
    def get_all_positions_info(self):
        """Get info for all positions"""
        with self.lock:
            positions_info = []
            for symbol in self.active_positions:
                pos_info = self.get_position_info(symbol)
                if pos_info:
                    positions_info.append(pos_info)
            return positions_info
    
    def get_total_pnl(self):
        """Get total P&L"""
        with self.lock:
            return self.total_pnl
    
    def get_position_history(self):
        """Get position history"""
        with self.lock:
            return self.position_history.copy()
    
    def debug_print_state(self):
        """Print debug info about current state"""
        with self.lock:
            print("\n" + "=" * 80)
            print("🧠 [DEBUG] POSITION TRACKER STATE")
            print("=" * 80)
            
            print(f"📊 Active Positions: {len(self.active_positions)}")
            for symbol, pos in self.active_positions.items():
                print(f"  {symbol}:")
                print(f"    Qty: {pos['netQty']}, Avg: {pos['avgPrice']:.2f}, Current: {pos['currentPrice']:.2f}")
                print(f"    Unrealized P&L: {pos['unrealized_profit']:.2f}")
                
                if symbol in self.entry_prices:
                    print(f"    Entry: {self.entry_prices[symbol]:.2f}, SL: {self.sl_prices.get(symbol, 0):.2f}, Target: {self.target_prices.get(symbol, 0):.2f}")
                    print(f"    Signal: {self.trade_signals.get(symbol, 'N/A')}, Trade ID: {self.trade_ids.get(symbol, 'N/A')}")
            
            print(f"\n📈 Total P&L: {self.total_pnl:.2f}")
            print(f"📋 Position History: {len(self.position_history)} closed trades")
            
            if self.position_history:
                print("  Recent closed trades:")
                for trade in self.position_history[-3:]:  # Last 3 trades
                    print(f"    {trade['symbol']}: P&L={trade['pnl']:.2f}, Reason={trade['exit_reason']}")
            
            print(f"\n🔄 Last refresh: {self.last_refresh}")
            print("=" * 80 + "\n")


# Terminal-based Live Dashboard
class TerminalDashboard:
    def __init__(self, position_tracker):
        self.position_tracker = position_tracker
        self.last_update = None

    def display_live_dashboard(self):
        """Display live dashboard in terminal"""
        try:
            # Clear screen
            os.system('cls' if os.name == 'nt' else 'clear')

            # Refresh positions from tracker
            self.position_tracker.refresh_positions()
            
            # Get position info
            positions_info = self.position_tracker.get_all_positions_info()
            total_pnl = self.position_tracker.get_total_pnl()
            position_history = self.position_tracker.get_position_history()

            print("\n" + "=" * 100)
            print("📊 LIVE TRADING DASHBOARD - IN-MEMORY TRACKING")
            print("=" * 100)
            print(f"Last Update: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
            print(f"SL: {Config.STOP_LOSS_PERCENT}% | Target: {Config.TARGET_PERCENT}%")
            print("Storage: 🧠 IN-MEMORY (No CSV files)")
            print("-" * 100)

            # Display current positions
            if positions_info:
                print(f"\n💰 ACTIVE POSITIONS ({len(positions_info)}):")
                for pos in positions_info:
                    pnl_color = "🟢" if pos['current_pnl'] > 0 else "🔴" if pos['current_pnl'] < 0 else "⚪"
                    
                    print(f"   {pos['symbol']} ({pos.get('signal', 'N/A')})")
                    print(f"     Qty: {pos['netQty']} | Avg Entry: {pos.get('entry_price', 0):.2f}")
                    print(f"     Current: {pos['currentPrice']:.2f} | Unrealized: {pos['unrealized_profit']:.2f}")
                    
                    if pos.get('entry_price', 0) > 0:
                        sl_percent = ((pos['entry_price'] - pos['stop_loss']) / pos['entry_price'] * 100) if pos['entry_price'] > 0 else 0
                        target_percent = ((pos['target'] - pos['entry_price']) / pos['entry_price'] * 100) if pos['entry_price'] > 0 else 0
                        
                        print(f"     SL: {pos.get('stop_loss', 0):.2f} (-{sl_percent:.1f}%)")
                        print(f"     Target: {pos.get('target', 0):.2f} (+{target_percent:.1f}%)")
                    
                    print(f"     Current P&L: {pnl_color} {pos['current_pnl']:.2f}")
                    print(f"     Trade ID: {pos.get('trade_id', 'N/A')}")
            else:
                print(f"\n💰 ACTIVE POSITIONS: No active positions")

            # Display P&L summary
            print(f"\n📊 P&L SUMMARY:")
            print(f"   Total P&L: {total_pnl:.2f}")
            
            if position_history:
                profitable_trades = len([t for t in position_history if t['pnl'] > 0])
                total_trades = len(position_history)
                win_rate = (profitable_trades / total_trades * 100) if total_trades > 0 else 0
                
                sl_hits = len([t for t in position_history if t['exit_reason'] == 'SL_HIT'])
                target_hits = len([t for t in position_history if t['exit_reason'] == 'TARGET_HIT'])
                
                print(f"   Total Trades: {total_trades}")
                print(f"   Profitable: {profitable_trades}")
                print(f"   Win Rate: {win_rate:.1f}%")
                print(f"   SL Hits: {sl_hits} | Target Hits: {target_hits}")
                
                # Show recent trades
                if position_history:
                    print(f"\n📋 RECENT CLOSED TRADES:")
                    for trade in position_history[-3:]:  # Last 3 trades
                        pnl_color = "🟢" if trade['pnl'] > 0 else "🔴" if trade['pnl'] < 0 else "⚪"
                        exit_reason_icon = {
                            'SL_HIT': '🛑',
                            'TARGET_HIT': '✅',
                            'MANUAL_EXIT': '👋',
                            'SIDEWAYS_EXIT': '🔄',
                            'SIGNAL_CHANGE': '🔄'
                        }.get(trade['exit_reason'], '❓')
                        
                        exit_time = trade.get('exit_time', datetime.now())
                        if isinstance(exit_time, datetime):
                            time_str = exit_time.strftime('%H:%M:%S')
                        else:
                            time_str = str(exit_time)
                        
                        print(f"   {time_str} - {trade['symbol']} - {pnl_color} P&L: {trade['pnl']:.2f} {exit_reason_icon} ({trade['exit_reason']})")
            else:
                print(f"   No closed trades yet")

            print("\n" + "=" * 100)
            print("🔄 Next update in 30 seconds... (Press Ctrl+C to stop)")
            print("=" * 100)

        except Exception as e:
            print(f"❌ Error displaying dashboard: {e}")
            import traceback
            traceback.print_exc()


# Error handling decorator
def handle_errors(func):
    def wrapper(*args, **kwargs):
        retries = 0
        while retries < Config.MAX_RETRIES:
            try:
                return func(*args, **kwargs)
            except Exception as e:
                retries += 1
                logging.error(f"Error in {func.__name__} (attempt {retries}): {str(e)}", exc_info=True)
                if retries < Config.MAX_RETRIES:
                    time.sleep(Config.RETRY_DELAY)
                else:
                    print(f"❌ Operation failed after {Config.MAX_RETRIES} attempts: {str(e)}")
                    return None

    return wrapper


# Initialize all session state in one place
class SessionState:
    def __init__(self):
        self.option_chain_api_count = 0
        self.quote_api_count = 0
        self.api_window_start = datetime.now()
        self.last_signal = None
        self.cid = ""
        self.token = ""
        self._hb_lock = False
        self.position_tracker = None  # Will be initialized later

    def get(self, key, default=None):
        """Dictionary-like get method for session state attributes"""
        return getattr(self, key, default)


# Load credentials from environment variables
def load_credentials(session_state):
    """Load credentials from JSON file or environment variables"""
    try:
        # Try to load from JSON file first
        with open('fyers_credentials.json', 'r') as f:
            creds = json.load(f)
            session_state.cid = creds.get('client_id', '')
            session_state.token = creds.get('access_token', '')
            print("✅ Credentials loaded from JSON file")
    except FileNotFoundError:
        # Fall back to environment variables if file doesn't exist
        print("⚠️ JSON file not found, checking environment variables")
        session_state.cid = os.getenv("FYERS_CID", session_state.cid)
        session_state.token = os.getenv("FYERS_TOKEN", session_state.token)
    except Exception as e:
        print(f"❌ Error loading credentials: {str(e)}")
        # Fall back to environment variables
        session_state.cid = os.getenv("FYERS CID", session_state.cid)
        session_state.token = os.getenv("FYERS_TOKEN", session_state.token)


# Rate limiting with improved logic
def enforce_rate_limit(session_state):
    now = datetime.now()
    window = now - session_state.api_window_start
    total_calls = session_state.option_chain_api_count + session_state.quote_api_count

    if window > timedelta(seconds=Config.API_WINDOW):
        session_state.api_window_start = now
        session_state.option_chain_api_count = 0
        session_state.quote_api_count = 0
    elif total_calls >= Config.API_RATE_LIMIT:
        wait = Config.API_WINDOW - window.seconds
        logging.warning(f"Approaching rate limit, waiting {wait}s...")
        print(f"⚠️ Approaching rate limit, waiting {wait}s...")
        time.sleep(wait)
        session_state.api_window_start = datetime.now()
        session_state.option_chain_api_count = 0
        session_state.quote_api_count = 0


# API calls with retry logic
@handle_errors
@lru_cache(maxsize=32)
def get_option_chain_data(session_state, cid, token, sym, expiry_ts=""):
    print(f"🔍 [DEBUG] Fetching option chain data for {sym}, expiry: {expiry_ts or 'nearest'}")
    enforce_rate_limit(session_state)
    session_state.option_chain_api_count += 1
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    resp = fy.optionchain(data={"symbol": sym, "timestamp": expiry_ts})
    if not resp or resp.get("code") != 200:
        error_msg = f"Option chain error ({expiry_ts or 'nearest'}): {resp.get('message', 'Unknown')}"
        logging.error(error_msg)
        print(f"❌ {error_msg}")
        return None
    print(f"✅ [DEBUG] Option chain data fetched successfully")
    return resp["data"]["optionsChain"]


@handle_errors
def get_underlying_ltp(session_state, cid, token, sym):
    print(f"🔍 [DEBUG] Fetching underlying LTP for {sym}")
    enforce_rate_limit(session_state)
    session_state.quote_api_count += 1
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    resp = fy.quotes(data={"symbols": sym})
    if not resp or resp.get("code") != 200 or not resp.get("d"):
        error_msg = f"Quotes API error ({resp.get('code')}): {resp.get('message', 'Unknown')}"
        logging.error(error_msg)
        print(f"❌ {error_msg}")
        return None
    ltp = resp["d"][0]["v"]["lp"]
    print(f"✅ [DEBUG] Underlying LTP: {ltp}")
    return ltp


MAX_HISTORY = 1  # last N signals for majority check
MAJORITY_THRESHOLD = 1  # number of same signals to confirm majority


def majority_signal(history, threshold=MAJORITY_THRESHOLD):
    """
    Determine majority signal from the history.
    Returns the majority signal if all signals in buffer are the same, else HOLD.
    """
    if not history or len(history) < threshold:
        return "HOLD"

    if all(signal == history[0] for signal in history):
        return history[0]

    return "HOLD"


def compute_signals(
        merged_df,
        atm_strike,
        sym='NSE:NIFTY50-INDEX',  # underlying symbol
        fyers_api=None,
        session_state=None
):
    print("\n[DEBUG] ================= compute_signals START =================")
    print(f"[DEBUG] underlying symbol received: {sym} ({type(sym)})")

    # ----------------------------
    # 1️⃣ Validate symbol
    # ----------------------------
    if not isinstance(sym, str) or ":" not in sym:
        print(f"[FATAL] Invalid underlying symbol: {sym}")
        return "SIDEWAYS", {}

    # ----------------------------
    # 2️⃣ Fetch underlying data
    # ----------------------------
    try:
        resp = fyers_api.quotes({"symbols": sym})
        # print(f"[DEBUG] Underlying raw response: {resp}")

        if resp.get("code") == 200 and resp.get("d"):
            v = resp["d"][0]["v"]
            nifty_ltp = float(v.get("lp", 0))
            nifty_high = float(v.get("high_price", 0))
            nifty_low = float(v.get("low_price", 0))
        else:
            nifty_ltp = nifty_high = nifty_low = 0.0
    except Exception as e:
        print(f"[FATAL] Underlying fetch failed: {e}")
        nifty_ltp = nifty_high = nifty_low = 0.0

    print(f"[DEBUG] Underlying LTP={nifty_ltp}, High={nifty_high}, Low={nifty_low}")

    nifty_norm = (nifty_ltp - nifty_low) / max(nifty_high - nifty_low, 1e-6) if nifty_high > nifty_low else 0.5
    print(f"[DEBUG] NIFTY normalised={nifty_norm:.3f}")

    # ----------------------------
    # 3️⃣ Select ATM, ATM±1 strikes
    # ----------------------------
    strikes = sorted(merged_df["Strike"].dropna().unique())
    if atm_strike not in strikes:
        print("[WARN] ATM strike missing")
        return "SIDEWAYS", {}

    idx = strikes.index(atm_strike)
    sel = strikes[max(0, idx-1): idx+2]
    df = merged_df[merged_df["Strike"].isin(sel)].copy()
    print(f"[DEBUG] Selected strikes: {sel}")

    # ----------------------------
    # 4️⃣ Ensure required columns exist
    # ----------------------------
    for col in ["CE_symbol","PE_symbol","CE_ltp","PE_ltp"]:
        if col not in df.columns:
            print(f"[WARN] Missing column {col}, filling with default")
            df[col] = 0.0

    # ----------------------------
    # 5️⃣ Fetch CE/PE quotes for high/low/ltp
    # ----------------------------
    ce_symbols = df["CE_symbol"].dropna().astype(str).tolist()
    pe_symbols = df["PE_symbol"].dropna().astype(str).tolist()
    all_symbols = ce_symbols + pe_symbols

    if fyers_api and all_symbols:
        try:
            quotes_resp = fyers_api.quotes({"symbols": ",".join(all_symbols)})
            quotes_dict = {}
            if quotes_resp.get("code") == 200 and quotes_resp.get("d"):
                for item in quotes_resp["d"]:
                    quotes_dict[item["n"]] = item["v"]

            # Fill CE/PE high/low/ltp
            for idx_row, row in df.iterrows():
                # CE
                ce_sym = str(row["CE_symbol"])
                ce_data = quotes_dict.get(ce_sym, {})
                df.at[idx_row, "CE_ltp"] = float(ce_data.get("lp", row["CE_ltp"] or 0))
                df.at[idx_row, "CE_high"] = float(ce_data.get("high_price", row.get("CE_high", row["CE_ltp"] or 0)))
                df.at[idx_row, "CE_low"] = float(ce_data.get("low_price", row.get("CE_low", row["CE_ltp"] or 0)))

                # PE
                pe_sym = str(row["PE_symbol"])
                pe_data = quotes_dict.get(pe_sym, {})
                df.at[idx_row, "PE_ltp"] = float(pe_data.get("lp", row["PE_ltp"] or 0))
                df.at[idx_row, "PE_high"] = float(pe_data.get("high_price", row.get("PE_high", row["PE_ltp"] or 0)))
                df.at[idx_row, "PE_low"] = float(pe_data.get("low_price", row.get("PE_low", row["PE_ltp"] or 0)))

        except Exception as e:
            print(f"[WARN] CE/PE quote fetch failed: {e}")
            # fallback to LTP for high/low
            df["CE_high"] = df["CE_high"].replace(0, df["CE_ltp"])
            df["CE_low"] = df["CE_low"].replace(0, df["CE_ltp"])
            df["PE_high"] = df["PE_high"].replace(0, df["PE_ltp"])
            df["PE_low"] = df["PE_low"].replace(0, df["PE_ltp"])

    # ----------------------------
    # 6️⃣ Compute CE / PE placement (0..1)
    # ----------------------------
    df["CE_norm"] = np.where(
        (df["CE_high"] - df["CE_low"]) > 0,
        (df["CE_ltp"] - df["CE_low"]) / (df["CE_high"] - df["CE_low"]),
        0
    )

    df["PE_norm"] = np.where(
        (df["PE_high"] - df["PE_low"]) > 0,
        (df["PE_ltp"] - df["PE_low"]) / (df["PE_high"] - df["PE_low"]),
        0
    )

    ce_norm = df["CE_norm"].mean()
    pe_norm = df["PE_norm"].mean()
    print(f"[DEBUG] CE_norm={ce_norm:.3f}, PE_norm={pe_norm:.3f}")

    # ----------------------------
    # 7️⃣ R1 / R2 / R3 logic
    # ----------------------------
    eps = 1e-6
    R1 = ce_norm / max(nifty_norm, eps)
    R2 = pe_norm / max(nifty_norm, eps)
    R3 = R1 / max(R2, eps)
    R3 = R3 / (R3+1)  # normalize R3 to 0..1

    print(f"[DEBUG] R1 (CE/NIFTY)={R1:.3f}, R2 (PE/NIFTY)={R2:.3f}, R3 (CE/PE)={R3:.3f}")

    # ----------------------------
    # 8️⃣ Decision logic with trend filter
    # ----------------------------
    signal = "HOLD"
    if R1 > 1 and R3 > 0.75 and nifty_norm > 0.6:
        signal = "BUY"   # CE
        print("[SIGNAL] BUY  [R1 > 1 and R3 > 0.75 and nifty_norm > 0.6]")
    elif R2 > 1 and R3 < 0.25 and nifty_norm < 0.4:
        signal = "SELL"  # PE
        print("[SIGNAL] SELL [R2 > 1 and R3 < 0.25 and nifty_norm < 0.4]")
    else:
        signal = "HOLD"
        print("[SIGNAL] HOLD [No clear signal]")

    # ----------------------------
    # 9️⃣ Session buffer
    # ----------------------------
    if session_state is not None:
        if not hasattr(session_state, "signal_buffer"):
            session_state.signal_buffer = []
        session_state.signal_buffer.append(signal)
        if len(session_state.signal_buffer) > MAX_HISTORY:
            session_state.signal_buffer.pop(0)
        print(f"[DEBUG] Signal buffer: {session_state.signal_buffer}")

    print("[DEBUG] ================= compute_signals END =================\n")

    metrics = {
        "ce_norm": ce_norm,
        "pe_norm": pe_norm,
        "nifty_norm": nifty_norm,
        "R1": R1,
        "R2": R2,
        "R3": R3
    }

    return signal, metrics


def select_strikes_simple(chain, atm_strike):
    """
    Simple strategy:
      - For BUY signal: Buy ATM CE
      - For SELL signal: Buy ATM PE
    """
    print(f"🔍 [DEBUG] Selecting ATM strikes for simple strategy: {atm_strike}")
    try:
        df = pd.DataFrame(chain)
        if df.empty or atm_strike is None:
            print("⚠️ [DEBUG] No data or ATM strike for selection")
            return None, None, None, None

        ce = df[df["option_type"] == "CE"].copy()
        pe = df[df["option_type"] == "PE"].copy()

        # Get ATM options
        atm_pe_row = pe[pe["strike_price"] == atm_strike]
        atm_ce_row = ce[ce["strike_price"] == atm_strike]

        buy_pe_row = atm_pe_row.iloc[0].to_dict() if not atm_pe_row.empty else None
        buy_ce_row = atm_ce_row.iloc[0].to_dict() if not atm_ce_row.empty else None

        # For simple strategy, we don't need sell legs
        print(f"✅ [DEBUG] Strike selection complete:")
        print(f"   - ATM CE: {buy_ce_row['symbol'] if buy_ce_row else 'None'} @ {buy_ce_row['ltp'] if buy_ce_row else 'N/A'}")
        print(f"   - ATM PE: {buy_pe_row['symbol'] if buy_pe_row else 'None'} @ {buy_pe_row['ltp'] if buy_pe_row else 'N/A'}")

        return buy_pe_row, None, buy_ce_row, None  # Only return buy options

    except Exception as e:
        logging.error(f"Error in select_strikes_simple: {str(e)}", exc_info=True)
        print(f"❌ [DEBUG] Error in select_strikes_simple: {str(e)}")
        return None, None, None, None


# FIXED FUNCTION: Simplified trading with position tracker
def handle_trades(session_state, signal, atm_ce, atm_pe, fyers, position_tracker):
    """
    Handle trades using position tracker
    """
    print(f"\n🔍 [DEBUG] Handling trades for signal: {signal}")
    
    # Prevent overlapping execution
    if session_state._hb_lock:
        print("⚠️ [DEBUG] Another trade is already running. Skipping this cycle.")
        return
    
    session_state._hb_lock = True
    
    try:
        current_signal = session_state.last_signal
        print(f"🔄 [DEBUG] Current signal: {current_signal}, Incoming signal: {signal}")
        
        # Refresh positions from Fyers
        position_tracker.refresh_positions()
        
        # Debug print current state
        position_tracker.debug_print_state()
        
        # ============================================================
        # 1) Check for SL/Target hits (ALWAYS check, regardless of signal)
        # ============================================================
        positions_to_exit = position_tracker.check_sl_target()
        if positions_to_exit:
            print(f"⚠️ [DEBUG] Found {len(positions_to_exit)} positions to exit due to SL/Target")
            for symbol, exit_reason in positions_to_exit:
                position_tracker.exit_position(symbol, exit_reason)
        
        # ============================================================
        # 2) Handle SIDEWAYS signal (exit all positions)
        # ============================================================
        if signal == "SIDEWAYS" and Config.EXIT_ON_SIDEWAYS == True:
            print("📊 [DEBUG] SIDEWAYS signal -> EXIT_ON_SIDEWAYS == True -> Exiting all positions.")
            active_positions = position_tracker.get_active_positions()
            if active_positions:
                position_tracker.exit_all_positions("SIDEWAYS_EXIT")
            else:
                print("✅ [DEBUG] No positions to exit for SIDEWAYS signal.")
            session_state.last_signal = signal
            return
        
        if signal == "SIDEWAYS" and Config.EXIT_ON_SIDEWAYS == False:
            print("📊 [DEBUG] SIDEWAYS signal -> EXIT_ON_SIDEWAYS == False -> Holding all positions.")
            return

        # ============================================================
        # 3) FLATTEN on SIGNAL CHANGE (BUY/SELL to different BUY/SELL)
        # ============================================================
        active_positions = position_tracker.get_active_positions()
        if current_signal in ["BUY", "SELL"] and current_signal != signal and active_positions:
            print(f"⚠️ [DEBUG] Signal changed ({current_signal} → {signal}). Exiting all positions...")
            position_tracker.exit_all_positions("SIGNAL_CHANGE")

        # ============================================================
        # 4) ENTER NEW TRADE for BUY/SELL signals
        # ============================================================
        active_positions = position_tracker.get_active_positions()
        if not active_positions and signal in ["BUY", "SELL"]:
            print(f"📥 [DEBUG] Preparing new {signal} trade entry...")
            
            # Select the appropriate option
            option_row = None
            if signal == "BUY" and atm_ce is not None:
                option_row = atm_ce
            elif signal == "SELL" and atm_pe is not None:
                option_row = atm_pe
            
            if not option_row:
                print(f"❌ [DEBUG] No valid option found for {signal} signal")
                return
            
            # Place regular buy order (NO BRACKET ORDERS for options!)
            buy_order = {
                "symbol": option_row["symbol"],
                "qty": Config.LOT_SIZE,
                "type": 2,  # Market order
                "side": 1,  # Buy
                "productType": "MARGIN",  # MUST BE "MARGIN" for options
                "validity": "DAY",
            }
            
            print(f"📤 [DEBUG] Placing buy order: {buy_order}")
            buy_resp = fyers.place_order(data=buy_order)
            print(f"📥 [DEBUG] Buy order response: {buy_resp}")
            
            if buy_resp and buy_resp.get("s") == "ok":
                print(f"✅ [DEBUG] Successfully placed {signal} order for {option_row['symbol']}")
                print(f"⚠️ [DEBUG] Position tracker will automatically detect new position on next refresh")
                session_state.last_signal = signal
            else:
                msg = buy_resp.get("message", "Unknown error") if isinstance(buy_resp, dict) else "Unknown error"
                print(f"❌ [DEBUG] Buy order FAILED. Reason: {msg}")

        elif signal in ["BUY", "SELL"] and active_positions:
            print(f"⚠️ [DEBUG] Active positions exist. Skipping new {signal} entry.")
            print(f"📊 [DEBUG] Current active positions: {list(active_positions.keys())}")

    except Exception as e:
        print(f"❌ [DEBUG] Fatal error in handle_trades: {str(e)}")
        import traceback
        traceback.print_exc()
    finally:
        session_state._hb_lock = False
        print("🔓 [DEBUG] Lock released.\n")


# Data display functions
def format_and_show(chain, title, ltp, show_signals=False, fyers_api=None, session_state=None):
    print(f"🔍 [DEBUG] Formatting and displaying data for: {title}")
    df = pd.DataFrame(chain)
    if df.empty:
        print(f"ℹ️ [DEBUG] No data for {title}")
        return None, None, None

    # Process CE and PE data
    ce = df[df["option_type"] == "CE"]
    pe = df[df["option_type"] == "PE"]

    # Define columns and rename them
    cols = ["symbol", "strike_price", "oi", "volume", "ltp", "ask", "bid",
            "ltpch", "ltpchp", "oich", "oichp", "prev_oi"]

    ce_df = ce[cols].rename(columns={
        "strike_price": "Strike",
        "oi": "OI",
        "volume": "Vol",
        "ltpch": "LTPCh",
        "ltpchp": "LTPChP",
        "oich": "OICh",
        "oichp": "OIChP",
        "prev_oi": "PrevOI"
    })

    pe_df = pe[cols].rename(columns={
        "strike_price": "Strike",
        "oi": "OI",
        "volume": "Vol",
        "ltpch": "LTPCh",
        "ltpchp": "LTPChP",
        "oich": "OICh",
        "oichp": "OIChP",
        "prev_oi": "PrevOI"
    })

    # Merge CE and PE data
    merged = pd.merge(
        ce_df.add_prefix("CE_"),
        pe_df.add_prefix("PE_"),
        left_on="CE_Strike",
        right_on="PE_Strike",
        how="outer"
    ).rename(columns={"CE_Strike": "Strike"}).drop("PE_Strike", axis=1)

    # Find ATM strike
    atm = None
    if ltp is not None and not merged["Strike"].dropna().empty:
        atm = min(merged["Strike"].dropna(), key=lambda x: abs(x - ltp))

    print(f"\n📈 {title}")

    if show_signals and atm is not None:
        # Calculate all required metrics
        strikes = sorted(merged["Strike"].dropna().unique().tolist())
        idx = strikes.index(atm)
        signal, metrics = compute_signals(merged, atm,sym='NSE:NIFTY50-INDEX',fyers_api=fyers_api, session_state=session_state)
        # Display results with improved formatting
        print(f"✅ Signal: {signal}")

    # Display the dataframe
    print(f"📊 ATM Strike: {atm} | Underlying LTP: {ltp}")

    if show_signals and atm is not None:
        return signal, atm, metrics
    return None, atm, None


@handle_errors
def update_all_data(session_state, cid, token, sym):
    print(f"🔍 [DEBUG] Updating all data for {sym}")
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    enforce_rate_limit(session_state)
    session_state.option_chain_api_count += 1

    meta = fy.optionchain(data={"symbol": sym, "timestamp": ""})
    if meta.get("code") != 200:
        print(f"❌ [DEBUG] Option chain API error: {meta}")
        logging.error("Failed to fetch expiry data")
        print("❌ [DEBUG] Failed to fetch expiry data")
        return None, None, None

    exp = sorted(
        [(e["date"], e.get("expiry")) for e in meta["data"]["expiryData"]],
        key=lambda x: datetime.strptime(x[0], "%d-%m-%Y")
    )
    today = datetime.today().date()
    dates = [datetime.strptime(d, "%d-%m-%Y").date() for d, _ in exp]
    idx = next((i for i, d in enumerate(dates) if d >= today), 0)
    curr_date, curr_ts = exp[idx]

    ltp = get_underlying_ltp(session_state, cid, token, sym)
    chain = get_option_chain_data(session_state, cid, token, sym, expiry_ts=curr_ts)

    print(f"✅ [DEBUG] Data update complete")
    return ltp, chain, curr_date


def clear_screen():
    """Clear the terminal screen"""
    os.system('cls' if os.name == 'nt' else 'clear')


def get_user_input(prompt, default=None, input_type=str):
    """Get user input with optional default value"""
    try:
        if default is not None:
            user_input = input(f"{prompt} [{default}]: ").strip()
            if user_input == "":
                return default
            return input_type(user_input)
        else:
            return input_type(input(f"{prompt}: ").strip())
    except ValueError:
        print("❌ Invalid input. Please try again.")
        return get_user_input(prompt, default, input_type)


def settings_menu(session_state):
    """Display and handle settings menu"""
    while True:
        clear_screen()
        print("\n" + "=" * 50)
        print("⚙️ SETTINGS")
        print("=" * 50)
        print(f"1. Client ID: {session_state.cid}")
        print(f"2. Access Token: {'*' * len(session_state.token) if session_state.token else 'Not set'}")
        print(f"3. Lot Size: {Config.LOT_SIZE}")
        print(f"4. Stop Loss %: {Config.STOP_LOSS_PERCENT}")
        print(f"5. Target %: {Config.TARGET_PERCENT}")
        print("6. 🔙 Back to Main Menu")

        choice = get_user_input("Select option", input_type=int)

        if choice == 1:
            session_state.cid = get_user_input("Enter Client ID", session_state.cid)
        elif choice == 2:
            session_state.token = get_user_input("Enter Access Token", session_state.token)
        elif choice == 3:
            Config.LOT_SIZE = get_user_input("Enter Lot Size", Config.LOT_SIZE, int)
        elif choice == 4:
            Config.STOP_LOSS_PERCENT = get_user_input("Enter Stop Loss %", Config.STOP_LOSS_PERCENT, float)
        elif choice == 5:
            Config.TARGET_PERCENT = get_user_input("Enter Target %", Config.TARGET_PERCENT, float)
        elif choice == 6:
            break
        else:
            print("❌ Invalid option. Please try again.")


# Main application
def main():
    print("🚀 Starting Live Auto Trading Application - SIMPLE STRATEGY")
    print("📈 Strategy: Buy ATM CE for BUY signals, Buy ATM PE for SELL signals")
    print(f"💰 SL: {Config.STOP_LOSS_PERCENT}% | Target: {Config.TARGET_PERCENT}%")
    print("🧠 Storage: IN-MEMORY ONLY (No CSV files for active trades)")
    
    # Initialize session state
    session_state = SessionState()
    load_credentials(session_state)

    # Default symbol
    sym = 'NSE:NIFTY50-INDEX'

    while True:
        clear_screen()
        print("\n" + "=" * 100)
        print("📈 FYERS ALGO TRADING - SIMPLE STRATEGY")
        print("=" * 50)
        print("1. 📈 Start Live Trading (with Auto Dashboard)")
        print("2. ⚙️ Settings")
        print("3. 🚪 Exit")
        print("=" * 50)

        choice = get_user_input("Select option", input_type=int)

        if choice == 1:  # Live Trading
            clear_screen()
            print("\n" + "=" * 100)
            print("📈 LIVE AUTO TRADING - SIMPLE STRATEGY")
            print("=" * 100)
            print(f"Strategy: Buy ATM CE for BUY, Buy ATM PE for SELL")
            print(f"SL: {Config.STOP_LOSS_PERCENT}% of premium | Target: {Config.TARGET_PERCENT}% of premium")
            print("🧠 Storage: IN-MEMORY ONLY")
            print("=" * 100)

            # Check credentials
            if not (session_state.cid and session_state.token):
                print("❌ Please set Client ID and Access Token in Settings first.")
                input("Press Enter to continue...")
                continue

            # Get trading mode
            auto_trade = get_user_input("Enable Auto Trade? (y/n)", "y").lower() == 'y'

            if not auto_trade:
                print("ℹ️ Auto trade disabled. Returning to main menu.")
                input("Press Enter to continue...")
                continue

            print("🔄 Starting live trading loop...")
            print("📊 Live dashboard will update automatically every cycle...")

            # Initialize Fyers API
            fy = fyersModel.FyersModel(
                client_id=session_state.cid, 
                token=session_state.token,
                is_async=False,
                log_path=""
            )
            
            # Initialize Position Tracker
            position_tracker = PositionTracker(fy)
            session_state.position_tracker = position_tracker
            
            # Initialize Dashboard
            dashboard = TerminalDashboard(position_tracker)

            try:
                iteration_count = 0
                while True:
                    iteration_count += 1

                    # Display dashboard every iteration
                    dashboard.display_live_dashboard()

                    print(f"\n🔄 [DEBUG] Starting iteration {iteration_count} at {datetime.now().strftime('%H:%M:%S')}")

                    # Update data
                    ltp, chain, curr_date = update_all_data(session_state, session_state.cid, session_state.token, sym)

                    ist = pytz.timezone("Asia/Kolkata")
                    print(f"🕒 Data Updated: {datetime.now(ist).strftime('%Y-%m-%d %H:%M:%S')}")

                    if ltp:
                        print(f"✅ Underlying LTP: {ltp}")

                    if chain:
                        signal, atm, metrics = format_and_show(chain, f"Current Expiry: {curr_date}", ltp,
                                                               show_signals=True,
                                                               fyers_api=fy, session_state=session_state)

                        # Select strikes using simple strategy
                        buy_pe, sell_pe, buy_ce, sell_ce = select_strikes_simple(chain, atm)

                        # Handle trades based on signal
                        handle_trades(session_state, signal, buy_ce, buy_pe, fy, position_tracker)

                    print(f"⏳ Waiting {Config.REFRESH_INTERVAL} seconds before next update...")
                    wait_until_next_interval(Config.REFRESH_INTERVAL)

            except KeyboardInterrupt:
                print("\n⏹️ Live trading stopped by user")
                print("🧹 Cleaning up position tracker...")
                position_tracker.debug_print_state()
                input("Press Enter to continue...")

            except Exception as e:
                print(f"❌ Error in live trading: {str(e)}")
                import traceback
                traceback.print_exc()
                input("Press Enter to continue...")

        elif choice == 2:  # Settings
            settings_menu(session_state)

        elif choice == 3:  # Exit
            print("👋 Exiting... Goodbye!")
            break

        else:
            print("❌ Invalid option. Please try again.")
            input("Press Enter to continue...")


if __name__ == "__main__":
    main()