import csv
import json
import logging
import os
import threading
import time
import traceback
from collections import deque
from datetime import datetime
from typing import Dict, Optional, Tuple

import pytz
from fyers_apiv3 import fyersModel
from fyers_apiv3.FyersWebsocket import data_ws


# ============================================================
# PAPER / LIVE
# ============================================================
PAPER_MODE = True  # False = live orders


# ============================================================
# CONFIGURATION
# ============================================================
class Config:
    SAMPLE_INTERVAL = 1
    OPTION_CHAIN_INTERVAL = 30
    OPTION_PRICE_STALE_SECONDS = 5
    WS_HEARTBEAT_TIMEOUT = 10

    SHORT_VWAP_SECONDS = 5 * 60
    LONG_VWAP_SECONDS = 15 * 60
    WARMUP_SECONDS = LONG_VWAP_SECONDS

    # Current ATM plus one strike below and above.
    ATM_NEIGHBOR_COUNT = 1
    OPTION_CHAIN_STRIKECOUNT = 2

    LOT_SIZE = 195
    MAX_DAILY_ENTRIES = 100

    API_RATE_LIMIT = 200
    API_WINDOW = 60
    MAX_RETRIES = 3
    RETRY_DELAY = 2

    CSV_FILE = "trading_data_vwap.csv"
    LOG_FILE = "trading_app_vwap.log"
    CREDENTIALS_FILE = "fyers_credentials.json"

    INDEX_SYMBOL = "NSE:NIFTY50-INDEX"
    VIX_SYMBOL = "NSE:INDIAVIX-INDEX"


# ============================================================
# LOGGING
# ============================================================
logging.basicConfig(
    filename=Config.LOG_FILE,
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)


def log_debug(msg: str):
    logging.debug(msg)


def log_console(msg: str):
    print(msg, flush=True)
    logging.info(msg)


IST = pytz.timezone("Asia/Kolkata")


def now_ist() -> datetime:
    return datetime.now(IST)


def timestamp_ist() -> str:
    return now_ist().strftime("%Y-%m-%d %H:%M:%S")


# ============================================================
# CSV LOGGER
# ============================================================
class DataLogger:
    def __init__(self, filename: str = Config.CSV_FILE):
        self.filename = filename
        self._ensure_header()

    def _ensure_header(self):
        if os.path.exists(self.filename):
            return
        with open(self.filename, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow([
                "timestamp",
                "spot_ltp",
                "current_atm_strike",
                "atm_minus_1",
                "atm",
                "atm_plus_1",
                "atm_ce_symbol",
                "atm_pe_symbol",
                "atm_ce_ltp",
                "atm_pe_ltp",
                "atm_ce_vwap_5m",
                "atm_ce_vwap_15m",
                "atm_ce_spread",
                "atm_pe_vwap_5m",
                "atm_pe_vwap_15m",
                "atm_pe_spread",
                "atm_ce_cross",
                "atm_pe_cross",
                "tracked_minus_1_ce_vwap_5m",
                "tracked_minus_1_ce_vwap_15m",
                "tracked_minus_1_pe_vwap_5m",
                "tracked_minus_1_pe_vwap_15m",
                "tracked_plus_1_ce_vwap_5m",
                "tracked_plus_1_ce_vwap_15m",
                "tracked_plus_1_pe_vwap_5m",
                "tracked_plus_1_pe_vwap_15m",
                "held_symbol",
                "held_type",
                "held_entry_premium",
                "held_current_premium",
                "held_vwap_5m",
                "held_vwap_15m",
                "held_cross",
                "position_state",
                "warmup_elapsed",
                "vwap_ready",
                "daily_entries",
                "realized_pnl",
                "total_pnl",
                "ws_connected",
                "ws_message_count",
                "nifty_tick_count",
                "chain_api_status",
                "chain_api_message",
                "decision_reason",
            ])

    @staticmethod
    def r(value, digits=4):
        if value is None:
            return ""
        try:
            return round(float(value), digits)
        except Exception:
            return ""

    def log_data(self, session):
        with session.lock:
            snap = session.make_logging_snapshot()

        with open(self.filename, "a", newline="") as f:
            csv.writer(f).writerow([
                snap["timestamp"],
                self.r(snap["spot_ltp"], 2),
                snap["current_atm_strike"],
                snap["atm_minus_1"],
                snap["atm"],
                snap["atm_plus_1"],
                snap["atm_ce_symbol"],
                snap["atm_pe_symbol"],
                self.r(snap["atm_ce_ltp"], 2),
                self.r(snap["atm_pe_ltp"], 2),
                self.r(snap["atm_ce_vwap_5m"]),
                self.r(snap["atm_ce_vwap_15m"]),
                self.r(snap["atm_ce_spread"]),
                self.r(snap["atm_pe_vwap_5m"]),
                self.r(snap["atm_pe_vwap_15m"]),
                self.r(snap["atm_pe_spread"]),
                self.r(snap["minus_1_ce_vwap_5m"]),
                self.r(snap["minus_1_ce_vwap_15m"]),
                self.r(snap["minus_1_pe_vwap_5m"]),
                self.r(snap["minus_1_pe_vwap_15m"]),
                self.r(snap["plus_1_ce_vwap_5m"]),
                self.r(snap["plus_1_ce_vwap_15m"]),
                self.r(snap["plus_1_pe_vwap_5m"]),
                self.r(snap["plus_1_pe_vwap_15m"]),
                snap["held_symbol"],
                snap["held_type"],
                self.r(snap["held_entry_premium"], 2),
                self.r(snap["held_current_premium"], 2),
                self.r(snap["held_vwap_5m"]),
                self.r(snap["held_vwap_15m"]),
                snap["held_cross"],
                snap["position_state"],
                self.r(snap["warmup_elapsed"], 1),
                snap["vwap_ready"],
                snap["daily_entries"],
                self.r(snap["realized_pnl"], 2),
                self.r(snap["total_pnl"], 2),
                snap["ws_connected"],
                snap["ws_message_count"],
                snap["nifty_tick_count"],
                snap["chain_api_status"],
                snap["chain_api_message"],
                snap["decision_reason"],
            ])


# ============================================================
# SESSION STATE
# ============================================================
class SessionState:
    def __init__(self):
        self.lock = threading.RLock()

        # Credentials / lifecycle
        self.cid = ""
        self.token = ""
        self.running = False
        self._order_lock = False

        # Trading state
        self.daily_entries = 0
        self.position_state = "FLAT"
        self.active_position = None
        self.paper_realized_pnl = 0.0
        self.decision_reason = ""

        # Warmup: starts on first actual NIFTY tick.
        self.warmup_start_time = None

        # Market data
        self.live_ltp: Dict[str, float] = {}
        self.live_ltp_time: Dict[str, float] = {}
        self.live_volume: Dict[str, float] = {}
        self.last_volume: Dict[str, float] = {}
        self.symbol_histories: Dict[str, deque] = {}

        # Option-chain state
        self.option_chain = []
        self.fut_price = 0.0
        self.expiry_date = None
        self.atm_strike = None
        self.strike_to_symbols: Dict[float, Dict[str, str]] = {}
        self.tracked_strikes = set()
        self.option_symbols = []

        # Monitoring / diagnostics
        self.india_vix = 15.0
        self.current_spot = 0.0
        self.current_atm_vwaps = {}
        self.held_vwaps = (None, None)

        self.ws_connected = False
        self.ws_last_error = ""
        self.ws_last_open_time = None
        self.ws_message_count = 0
        self.nifty_tick_count = 0
        self.option_tick_count = 0
        self.first_message_raw = ""
        self.last_message_time = None
        self.last_nifty_tick_time = None
        self.last_nifty_ltp = None

        self.chain_api_status = "NOT_RUN"
        self.chain_api_message = ""
        self.chain_last_update_time = None
        self.chain_update_count = 0

        # Crossover state keyed by ACTUAL SYMBOL.
        # symbol -> {"v5": x, "v15": y, "last_up": bool, "last_down": bool}
        self.crossover_state: Dict[str, Dict[str, object]] = {}

    # --------------------------------------------------------
    # Warmup / readiness
    # --------------------------------------------------------
    def warmup_elapsed(self) -> float:
        if self.warmup_start_time is None:
            return 0.0
        return max(0.0, time.time() - self.warmup_start_time)

    def warmup_complete(self) -> bool:
        return self.warmup_elapsed() >= Config.WARMUP_SECONDS

    def warmup_remaining(self) -> float:
        if self.warmup_start_time is None:
            return float(Config.WARMUP_SECONDS)
        return max(0.0, Config.WARMUP_SECONDS - self.warmup_elapsed())

    def start_warmup_from_nifty_tick(self):
        if self.warmup_start_time is None:
            self.warmup_start_time = time.time()
            log_console(
                f"⏳ First NIFTY tick received. 15-minute warmup started. "
                f"Need {Config.WARMUP_SECONDS}s of actual market time."
            )

    # --------------------------------------------------------
    # WebSocket update
    # --------------------------------------------------------
    def update_ws(self, symbol, ltp, vwap, volume):
        del vwap  # We calculate our own rolling VWAP.

        with self.lock:
            self.ws_message_count += 1
            self.last_message_time = time.time()

            if not symbol or ltp is None:
                return

            try:
                price = float(ltp)
            except (TypeError, ValueError):
                return

            if price <= 0:
                return

            now_ts = time.time()
            self.live_ltp[symbol] = price
            self.live_ltp_time[symbol] = now_ts

            if not self.first_message_raw:
                self.first_message_raw = f"symbol={symbol}, ltp={price}, volume={volume}"

            if symbol == Config.INDEX_SYMBOL:
                self.nifty_tick_count += 1
                self.last_nifty_tick_time = now_ts
                self.last_nifty_ltp = price
                self.current_spot = price
                self.start_warmup_from_nifty_tick()

            if symbol == Config.VIX_SYMBOL:
                self.india_vix = price
                return

            # Fyers volume is cumulative for the session. Convert to delta volume.
            delta_volume = 0.0
            if volume is not None:
                try:
                    current_volume = float(volume)
                except (TypeError, ValueError):
                    current_volume = 0.0

                previous_volume = self.last_volume.get(symbol)
                if previous_volume is not None:
                    delta_volume = current_volume - previous_volume
                    if delta_volume < 0:
                        # Session volume reset / rollover: re-baseline.
                        delta_volume = 0.0

                self.last_volume[symbol] = current_volume
                self.live_volume[symbol] = current_volume

            # Keep history for NIFTY and option symbols.
            if symbol == Config.INDEX_SYMBOL or symbol.endswith(("CE", "PE")):
                if symbol not in self.symbol_histories:
                    self.symbol_histories[symbol] = deque(maxlen=50000)
                self.symbol_histories[symbol].append(
                    (now_ts, price, max(0.0, delta_volume))
                )

                if symbol.endswith(("CE", "PE")):
                    self.option_tick_count += 1

    # --------------------------------------------------------
    # Safe getters
    # --------------------------------------------------------
    def get_ltp(self, symbol) -> Optional[float]:
        with self.lock:
            return self.live_ltp.get(symbol)

    def get_ltp_time(self, symbol) -> Optional[float]:
        with self.lock:
            return self.live_ltp_time.get(symbol)

    def get_symbol_data_counts(self, recency_seconds=5):
        with self.lock:
            now = time.time()
            total = len(self.live_ltp_time)
            active = sum(1 for t in self.live_ltp_time.values() if now - t <= recency_seconds)
            return total, active

    # --------------------------------------------------------
    # Chain update
    # --------------------------------------------------------
    def update_chain(self, chain, fut_price, expiry_date, atm_strike, option_symbols):
        with self.lock:
            previous_atm = self.atm_strike

            self.option_chain = list(chain or [])
            self.fut_price = float(fut_price) if fut_price else 0.0
            self.expiry_date = expiry_date
            self.atm_strike = float(atm_strike) if atm_strike is not None else None
            self.option_symbols = list(option_symbols or [])

            self.strike_to_symbols = {}
            for opt in self.option_chain:
                strike = opt.get("strike_price")
                option_type = opt.get("option_type")
                symbol = opt.get("symbol")
                if strike is None or option_type not in ("CE", "PE") or not symbol:
                    continue
                strike = float(strike)
                self.strike_to_symbols.setdefault(strike, {})[option_type] = symbol

            available = sorted(self.strike_to_symbols)
            if not available or self.atm_strike is None:
                self.atm_strike = None
                self.tracked_strikes = set()
            else:
                # Force ATM to the actual nearest available strike.
                self.atm_strike = min(available, key=lambda s: abs(s - self.atm_strike))

                try:
                    atm_index = available.index(self.atm_strike)
                    tracked = []
                    for offset in range(
                        -Config.ATM_NEIGHBOR_COUNT,
                        Config.ATM_NEIGHBOR_COUNT + 1,
                    ):
                        idx = atm_index + offset
                        if 0 <= idx < len(available):
                            tracked.append(available[idx])
                    self.tracked_strikes = set(tracked)
                except ValueError:
                    self.tracked_strikes = {self.atm_strike}

            self.chain_last_update_time = time.time()
            self.chain_update_count += 1

            if previous_atm != self.atm_strike and previous_atm is not None:
                log_console(
                    f"🔄 ATM changed {previous_atm:.0f} -> "
                    f"{self.atm_strike:.0f}" if self.atm_strike is not None else
                    f"🔄 ATM became unavailable"
                )

    # --------------------------------------------------------
    # VWAP calculation
    # --------------------------------------------------------
    def _prune_history_locked(self, symbol, now_ts):
        history = self.symbol_histories.get(symbol)
        if not history:
            return None

        oldest_needed = now_ts - Config.LONG_VWAP_SECONDS - 2
        while history and history[0][0] < oldest_needed:
            history.popleft()
        return history

    def history_span(self, symbol, now_ts=None) -> float:
        now_ts = time.time() if now_ts is None else now_ts
        with self.lock:
            history = self.symbol_histories.get(symbol)
            if not history:
                return 0.0
            return max(0.0, now_ts - history[0][0])

    def has_full_time_window(self, symbol, seconds, now_ts=None) -> bool:
        now_ts = time.time() if now_ts is None else now_ts
        with self.lock:
            history = self.symbol_histories.get(symbol)
            if not history:
                return False
            return history[0][0] <= now_ts - seconds

    def rolling_vwap(self, symbol, seconds: int, now_ts=None) -> Optional[float]:
        now_ts = time.time() if now_ts is None else now_ts

        with self.lock:
            history = self._prune_history_locked(symbol, now_ts)
            if not history:
                return None

            cutoff = now_ts - seconds
            total_pv = 0.0
            total_volume = 0.0

            for ts, price, delta_volume in history:
                if ts < cutoff:
                    continue
                if delta_volume <= 0:
                    continue
                total_pv += price * delta_volume
                total_volume += delta_volume

            if total_volume <= 0:
                return None

            # For 15m VWAP require the full 15m observation window.
            if seconds >= Config.LONG_VWAP_SECONDS and history[0][0] > cutoff:
                return None

            return total_pv / total_volume

    def get_symbol_vwaps(self, symbol, now_ts=None) -> Tuple[Optional[float], Optional[float]]:
        now_ts = time.time() if now_ts is None else now_ts
        return (
            self.rolling_vwap(symbol, Config.SHORT_VWAP_SECONDS, now_ts),
            self.rolling_vwap(symbol, Config.LONG_VWAP_SECONDS, now_ts),
        )

    # --------------------------------------------------------
    # VWAP readiness
    # --------------------------------------------------------
    def symbol_vwap_ready(self, symbol) -> bool:
        if not symbol:
            return False
        now_ts = time.time()
        v5, v15 = self.get_symbol_vwaps(symbol, now_ts)
        if v5 is None or v15 is None:
            return False
        return self.has_full_time_window(symbol, Config.LONG_VWAP_SECONDS, now_ts)

    def current_atm_symbols(self):
        with self.lock:
            atm = self.atm_strike
            mapping = dict(self.strike_to_symbols)
        if atm is None:
            return None, None, None
        symbols = mapping.get(float(atm), {})
        return atm, symbols.get("CE"), symbols.get("PE")

    def tracked_symbol(self, strike, option_type):
        if strike is None:
            return None
        with self.lock:
            return self.strike_to_symbols.get(float(strike), {}).get(option_type)

    # --------------------------------------------------------
    # Crossover state
    # --------------------------------------------------------
    def detect_crossover(self, symbol, v5, v15):
        """Detect current crossing using previous values for THIS exact symbol."""
        if not symbol or v5 is None or v15 is None:
            return False, False

        previous = self.crossover_state.get(symbol)
        up = False
        down = False

        if previous is not None:
            p5 = previous.get("v5")
            p15 = previous.get("v15")
            if p5 is not None and p15 is not None:
                up = p5 <= p15 and v5 > v15
                down = p5 >= p15 and v5 < v15

        self.crossover_state[symbol] = {
            "v5": v5,
            "v15": v15,
            "last_up": up,
            "last_down": down,
            "updated_at": time.time(),
        }
        return up, down

    # --------------------------------------------------------
    # Reset
    # --------------------------------------------------------
    def reset_for_new_day(self):
        with self.lock:
            if self.active_position is not None:
                log_console("⚠️ Active position still exists. Refusing reset.")
                return

            self.daily_entries = 0
            self.position_state = "FLAT"
            self.active_position = None
            self.paper_realized_pnl = 0.0
            self.decision_reason = ""

            self.warmup_start_time = None
            self.live_ltp.clear()
            self.live_ltp_time.clear()
            self.live_volume.clear()
            self.last_volume.clear()
            self.symbol_histories.clear()

            self.option_chain.clear()
            self.fut_price = 0.0
            self.expiry_date = None
            self.atm_strike = None
            self.strike_to_symbols.clear()
            self.tracked_strikes.clear()
            self.option_symbols.clear()

            self.current_spot = 0.0
            self.current_atm_vwaps = {}
            self.held_vwaps = (None, None)
            self.crossover_state.clear()

            self.ws_connected = False
            self.ws_last_error = ""
            self.ws_last_open_time = None
            self.ws_message_count = 0
            self.nifty_tick_count = 0
            self.option_tick_count = 0
            self.first_message_raw = ""
            self.last_message_time = None
            self.last_nifty_tick_time = None
            self.last_nifty_ltp = None

            self.chain_api_status = "NOT_RUN"
            self.chain_api_message = ""
            self.chain_last_update_time = None
            self.chain_update_count = 0

    # --------------------------------------------------------
    # Logging snapshot
    # --------------------------------------------------------
    def make_logging_snapshot(self):
        now_ts = time.time()
        with self.lock:
            spot = self.current_spot
            atm = self.atm_strike
            tracked = sorted(self.tracked_strikes)
            position = dict(self.active_position) if self.active_position else None

        minus_1 = None
        plus_1 = None
        if atm is not None:
            lowers = [x for x in tracked if x < atm]
            uppers = [x for x in tracked if x > atm]
            minus_1 = max(lowers) if lowers else None
            plus_1 = min(uppers) if uppers else None

        def pair(strike, option_type):
            symbol = self.tracked_symbol(strike, option_type)
            if not symbol:
                return None, None, None
            v5, v15 = self.get_symbol_vwaps(symbol, now_ts)
            return symbol, v5, v15

        atm_ce_symbol, atm_ce_5, atm_ce_15 = pair(atm, "CE")
        atm_pe_symbol, atm_pe_5, atm_pe_15 = pair(atm, "PE")
        _, mce5, mce15 = pair(minus_1, "CE")
        _, mpe5, mpe15 = pair(minus_1, "PE")
        _, pce5, pce15 = pair(plus_1, "CE")
        _, ppe5, ppe15 = pair(plus_1, "PE")

        held_symbol = position.get("symbol") if position else None
        held_type = position.get("entry_type", "") if position else ""
        held_v5, held_v15 = self.get_symbol_vwaps(held_symbol, now_ts) if held_symbol else (None, None)

        realized = self.paper_realized_pnl
        unrealized = 0.0
        held_current = 0.0
        if position:
            held_current = self.get_ltp(held_symbol) or position.get("entry_premium", 0.0)
            unrealized = (held_current - position.get("entry_premium", 0.0)) * Config.LOT_SIZE

        vwap_ready = (
            atm_ce_symbol and atm_pe_symbol and
            self.symbol_vwap_ready(atm_ce_symbol) and
            self.symbol_vwap_ready(atm_pe_symbol)
        )

        return {
            "timestamp": timestamp_ist(),
            "spot_ltp": spot,
            "current_atm_strike": atm,
            "atm_minus_1": minus_1,
            "atm": atm,
            "atm_plus_1": plus_1,
            "atm_ce_symbol": atm_ce_symbol or "",
            "atm_pe_symbol": atm_pe_symbol or "",
            "atm_ce_ltp": self.get_ltp(atm_ce_symbol) if atm_ce_symbol else None,
            "atm_pe_ltp": self.get_ltp(atm_pe_symbol) if atm_pe_symbol else None,
            "atm_ce_vwap_5m": atm_ce_5,
            "atm_ce_vwap_15m": atm_ce_15,
            "atm_ce_spread": (atm_ce_5 - atm_ce_15) if atm_ce_5 is not None and atm_ce_15 is not None else None,
            "atm_pe_vwap_5m": atm_pe_5,
            "atm_pe_vwap_15m": atm_pe_15,
            "atm_pe_spread": (atm_pe_5 - atm_pe_15) if atm_pe_5 is not None and atm_pe_15 is not None else None,
            "atm_ce_cross": self.crossover_state.get(atm_ce_symbol, {}).get("last_up", False) if atm_ce_symbol else False,
            "atm_pe_cross": self.crossover_state.get(atm_pe_symbol, {}).get("last_up", False) if atm_pe_symbol else False,
            "minus_1_ce_vwap_5m": mce5,
            "minus_1_ce_vwap_15m": mce15,
            "minus_1_pe_vwap_5m": mpe5,
            "minus_1_pe_vwap_15m": mpe15,
            "plus_1_ce_vwap_5m": pce5,
            "plus_1_ce_vwap_15m": pce15,
            "plus_1_pe_vwap_5m": ppe5,
            "plus_1_pe_vwap_15m": ppe15,
            "held_symbol": held_symbol or "",
            "held_type": held_type,
            "held_entry_premium": position.get("entry_premium", 0.0) if position else 0.0,
            "held_current_premium": held_current,
            "held_vwap_5m": held_v5,
            "held_vwap_15m": held_v15,
            "held_cross": self.crossover_state.get(held_symbol, {}).get("last_down", False) if held_symbol else False,
            "position_state": self.position_state,
            "warmup_elapsed": self.warmup_elapsed(),
            "vwap_ready": bool(vwap_ready),
            "daily_entries": self.daily_entries,
            "realized_pnl": realized,
            "total_pnl": realized + unrealized,
            "ws_connected": self.ws_connected,
            "ws_message_count": self.ws_message_count,
            "nifty_tick_count": self.nifty_tick_count,
            "chain_api_status": self.chain_api_status,
            "chain_api_message": self.chain_api_message,
            "decision_reason": self.decision_reason,
        }


# ============================================================
# WEBSOCKET MANAGER
# ============================================================
class MarketWSManager:
    def __init__(self, session: SessionState, access_token: str):
        self.session = session
        self.access_token = access_token
        self.ws = None
        self.subscribed = set()
        self.subscribed_at = {}
        self.running = False
        self.ws_thread = None
        self._lock = threading.RLock()

    def on_message(self, message):
        try:
            if isinstance(message, (bytes, bytearray)):
                message = message.decode("utf-8", errors="ignore")
            if isinstance(message, str):
                message = json.loads(message)
        except Exception as exc:
            self.session.ws_last_error = f"Message decode error: {exc}"
            log_console(f"⚠️ WS decode failed: {exc} | raw={message!r}")
            return

        if not isinstance(message, dict):
            return

        # Keep the first raw packet in the log for diagnosis.
        if not self.session.first_message_raw:
            try:
                self.session.first_message_raw = json.dumps(message, default=str)[:1000]
            except Exception:
                self.session.first_message_raw = repr(message)[:1000]

        symbol = message.get("symbol")
        if not symbol:
            # Some informational WS packets do not have a symbol; don't treat them
            # as market ticks, but retain the diagnostic count.
            log_debug(f"WS non-market packet: {message}")
            return

        ltp = message.get("ltp")
        vwap = message.get("avg_trade_price")
        volume = message.get("vol_traded_today")

        self.session.update_ws(symbol, ltp, vwap, volume)

    def on_error(self, msg):
        with self.session.lock:
            self.session.ws_last_error = str(msg)
            self.session.ws_connected = False
        log_console(f"❌ WS error: {msg}")

    def on_close(self, msg):
        with self.session.lock:
            self.session.ws_connected = False
        log_console(f"⚠️ WS closed: {msg}")

    def on_open(self):
        with self.session.lock:
            self.session.ws_connected = True
            self.session.ws_last_open_time = time.time()
            self.session.ws_last_error = ""

        log_console(
            f"✅ WebSocket connected | queued subscriptions={len(self.subscribed)}"
        )

        self._subscribe_all_now()

        try:
            self.ws.keep_running()
        except Exception as exc:
            log_console(f"❌ keep_running() failed: {exc}")
            log_debug(traceback.format_exc())

    def _subscribe_all_now(self):
        with self._lock:
            symbols = sorted(self.subscribed)

        if not symbols or not self.ws:
            return

        try:
            self.ws.subscribe(symbols, "SymbolUpdate")
            log_console(f"📡 WS subscription sent | symbols={len(symbols)}")
            log_debug(f"Subscribed symbols: {symbols}")
        except Exception as exc:
            self.session.ws_last_error = f"Subscribe failed: {exc}"
            log_console(f"❌ WS subscribe failed: {exc}")
            log_debug(traceback.format_exc())

    def _ws_connect(self):
        try:
            self.ws = data_ws.FyersDataSocket(
                access_token=self.access_token,
                log_path="",
                litemode=False,
                write_to_file=False,
                reconnect=True,
                on_connect=self.on_open,
                on_close=self.on_close,
                on_error=self.on_error,
                on_message=self.on_message,
            )
            self.ws.connect()
        except Exception as exc:
            with self.session.lock:
                self.session.ws_connected = False
                self.session.ws_last_error = str(exc)
            log_console(f"❌ WebSocket thread crashed: {exc}")
            log_debug(traceback.format_exc())

    def start(self):
        with self._lock:
            if self.running:
                return
            self.running = True
            self.ws_thread = threading.Thread(
                target=self._ws_connect,
                name="FyersWS",
                daemon=True,
            )
            self.ws_thread.start()

    def subscribe(self, symbols):
        symbols = [s for s in symbols if s]
        if not symbols:
            return

        now = time.time()
        new_symbols = []

        with self._lock:
            for symbol in symbols:
                if symbol not in self.subscribed:
                    self.subscribed.add(symbol)
                    self.subscribed_at[symbol] = now
                    new_symbols.append(symbol)

        if not new_symbols:
            return

        log_console(f"📌 Queued {len(new_symbols)} new subscription(s)")

        if self.ws:
            try:
                self.ws.subscribe(new_symbols, "SymbolUpdate")
                log_console(f"📡 Incremental subscription sent | +{len(new_symbols)}")
            except Exception as exc:
                log_console(f"⚠️ Incremental subscribe failed: {exc}")
                log_debug(traceback.format_exc())

    def resubscribe(self, symbols):
        symbols = list(symbols)
        if not symbols or not self.ws:
            return
        try:
            self.ws.subscribe(symbols, "SymbolUpdate")
            log_console(f"🔁 Resubscribe sent | symbols={len(symbols)}")
        except Exception as exc:
            log_console(f"⚠️ Resubscribe failed: {exc}")
            log_debug(traceback.format_exc())

    def stop(self):
        with self._lock:
            self.running = False
            ws = self.ws
            thread = self.ws_thread

        if ws:
            try:
                ws.close_connection()
            except Exception:
                pass

        if thread and thread.is_alive() and thread is not threading.current_thread():
            thread.join(timeout=3)

        with self.session.lock:
            self.session.ws_connected = False


# ============================================================
# REST API
# ============================================================
def enforce_rate_limit(session: SessionState):
    with session.lock:
        if not hasattr(session, "option_chain_api_count"):
            session.option_chain_api_count = 0
            session.api_window_start = now_ist()

        now = now_ist()
        window = (now - session.api_window_start).total_seconds()
        if window > Config.API_WINDOW:
            session.api_window_start = now
            session.option_chain_api_count = 0
        elif session.option_chain_api_count >= Config.API_RATE_LIMIT:
            wait = Config.API_WINDOW - window
            if wait > 0:
                time.sleep(wait)
            session.api_window_start = now_ist()
            session.option_chain_api_count = 0


def fetch_option_chain(session: SessionState, index_symbol):
    enforce_rate_limit(session)
    session.option_chain_api_count += 1

    fy = fyersModel.FyersModel(
        client_id=session.cid,
        token=session.token,
        is_async=False,
        log_path="",
    )

    try:
        meta = fy.optionchain(data={"symbol": index_symbol, "timestamp": ""})
    except Exception as exc:
        session.chain_api_status = "ERROR"
        session.chain_api_message = f"metadata request exception: {exc}"
        log_console(f"❌ OPTION CHAIN metadata request exception: {exc}")
        log_debug(traceback.format_exc())
        return None, None, None, None, []

    if not isinstance(meta, dict) or meta.get("code") != 200:
        msg = repr(meta)[:1000]
        session.chain_api_status = "ERROR"
        session.chain_api_message = msg
        log_console(f"❌ OPTION CHAIN metadata failed: {msg}")
        return None, None, None, None, []

    data = meta.get("data") or {}
    fut_price = None
    for item in data.get("optionsChain", []) or []:
        if item.get("option_type") == "":
            fut_price = item.get("fp")
            break
    if fut_price is None:
        fut_price = data.get("fp", 0.0)

    expiry_data = data.get("expiryData") or []
    if not expiry_data:
        session.chain_api_status = "ERROR"
        session.chain_api_message = "No expiryData returned"
        log_console("❌ OPTION CHAIN metadata has no expiryData")
        return None, None, None, None, []

    exp_list = sorted(
        [(e["date"], e["expiry"]) for e in expiry_data],
        key=lambda x: datetime.strptime(x[0], "%d-%m-%Y"),
    )

    today = now_ist().date()
    idx = None
    for i, (date_str, _) in enumerate(exp_list):
        if datetime.strptime(date_str, "%d-%m-%Y").date() >= today:
            idx = i
            break
    if idx is None:
        idx = len(exp_list) - 1

    curr_date, expiry_ts = exp_list[idx]
    payload = {
        "symbol": index_symbol,
        "strikecount": Config.OPTION_CHAIN_STRIKECOUNT,
        "timestamp": expiry_ts,
        "greeks": "1",
    }

    enforce_rate_limit(session)
    session.option_chain_api_count += 1

    try:
        resp = fy.optionchain(data=payload)
    except Exception as exc:
        session.chain_api_status = "ERROR"
        session.chain_api_message = f"chain request exception: {exc}"
        log_console(f"❌ OPTION CHAIN request exception: {exc}")
        log_debug(traceback.format_exc())
        return None, None, None, None, []

    if not isinstance(resp, dict) or resp.get("code") != 200:
        msg = repr(resp)[:1000]
        session.chain_api_status = "ERROR"
        session.chain_api_message = msg
        log_console(f"❌ OPTION CHAIN request failed: {msg}")
        return None, None, None, None, []

    chain = (resp.get("data") or {}).get("optionsChain") or []
    if not chain:
        session.chain_api_status = "ERROR"
        session.chain_api_message = "Empty optionsChain"
        log_console("❌ OPTION CHAIN returned an empty optionsChain")
        return None, None, None, None, []

    option_symbols = [
        opt["symbol"]
        for opt in chain
        if opt.get("option_type") in ("CE", "PE") and opt.get("symbol")
    ]

    session.chain_api_status = "OK"
    session.chain_api_message = f"chain={len(chain)} options={len(option_symbols)} expiry={curr_date}"
    return chain, fut_price, curr_date, expiry_ts, option_symbols


# ============================================================
# CHAIN POLLER
# ============================================================
def chain_poller(session: SessionState, ws_manager: MarketWSManager, index_symbol: str):
    while session.running:
        try:
            chain, fut_price, expiry_date, _, option_symbols = fetch_option_chain(session, index_symbol)

            if chain is not None:
                underlying_ltp = session.get_ltp(index_symbol)
                if underlying_ltp is None or underlying_ltp <= 0:
                    underlying_ltp = fut_price

                strikes = sorted({
                    float(opt["strike_price"])
                    for opt in chain
                    if opt.get("option_type") in ("CE", "PE")
                    and opt.get("strike_price") is not None
                })

                atm = None
                if strikes and underlying_ltp and float(underlying_ltp) > 0:
                    atm = min(strikes, key=lambda x: abs(x - float(underlying_ltp)))

                session.update_chain(
                    chain,
                    fut_price,
                    expiry_date,
                    atm,
                    option_symbols,
                )

                # Subscribe NIFTY + VIX + all option-chain contracts returned by REST.
                # Strategy calculations still use only ATM-1 / ATM / ATM+1.
                ws_manager.subscribe(
                    [Config.INDEX_SYMBOL, Config.VIX_SYMBOL] + option_symbols
                )

                log_console(
                    f"📦 CHAIN OK | ATM={session.atm_strike if session.atm_strike is not None else 'N/A'} | "
                    f"tracked={sorted(session.tracked_strikes)} | options={len(option_symbols)}"
                )

            time.sleep(Config.OPTION_CHAIN_INTERVAL)

        except Exception as exc:
            session.chain_api_status = "ERROR"
            session.chain_api_message = str(exc)
            log_console(f"❌ Chain poller error: {exc}")
            log_debug(traceback.format_exc())
            time.sleep(Config.OPTION_CHAIN_INTERVAL)


# ============================================================
# POSITION HELPERS
# ============================================================
def create_position(session: SessionState, symbol: str, premium: float, option_type: str, strike: float):
    with session.lock:
        session.active_position = {
            "symbol": symbol,
            "entry_type": option_type,
            "entry_strike": float(strike),
            "entry_premium": float(premium),
            "entry_time": timestamp_ist(),
            "current_premium": float(premium),
        }
        session.position_state = "ACTIVE"
        session.daily_entries += 1


def paper_enter(session: SessionState, symbol: str, premium: float, option_type: str, strike: float):
    create_position(session, symbol, premium, option_type, strike)
    session.decision_reason = (
        f"PAPER BUY {option_type} | {symbol} | strike={strike:.0f} | premium={premium:.2f}"
    )
    log_console(
        f"🟢 PAPER BUY {option_type} | {symbol} @ {premium:.2f} | strike={strike:.0f}"
    )


def live_enter(session: SessionState, fyers, symbol: str, premium: float, option_type: str, strike: float):
    order = {
        "symbol": symbol,
        "qty": Config.LOT_SIZE,
        "type": 2,
        "side": 1,
        "productType": "MARGIN",
        "validity": "DAY",
    }
    try:
        resp = fyers.place_order(data=order)
    except Exception as exc:
        session.decision_reason = f"LIVE entry exception: {exc}"
        log_console(f"❌ LIVE BUY exception: {exc}")
        return False

    if isinstance(resp, dict) and resp.get("s") == "ok":
        create_position(session, symbol, premium, option_type, strike)
        session.decision_reason = (
            f"LIVE BUY submitted | {option_type} | {symbol} | observed premium={premium:.2f} | "
            f"order={resp.get('id')}"
        )
        log_console(
            f"🟢 LIVE BUY {option_type} | {symbol} | observed={premium:.2f} | "
            f"strike={strike:.0f} | order={resp.get('id')}"
        )
        return True

    session.decision_reason = f"LIVE entry failed: {resp}"
    log_console(f"❌ LIVE BUY failed for {symbol}: {resp}")
    return False


def paper_exit(session: SessionState, reason: str):
    with session.lock:
        pos = dict(session.active_position) if session.active_position else None
    if not pos:
        return

    current = session.get_ltp(pos["symbol"])
    if current is None or current <= 0:
        current = pos["entry_premium"]

    pnl = (current - pos["entry_premium"]) * Config.LOT_SIZE
    session.paper_realized_pnl += pnl

    log_console(
        f"🔴 PAPER EXIT {pos['entry_type']} | {pos['symbol']} @ {current:.2f} | "
        f"reason={reason} | P&L={pnl:+.2f}"
    )

    with session.lock:
        session.active_position = None
        session.position_state = "FLAT"
        session.decision_reason = (
            f"PAPER EXIT {pos['entry_type']} | reason={reason} | P&L={pnl:+.2f}"
        )


def live_exit(session: SessionState, fyers, reason: str):
    with session.lock:
        pos = dict(session.active_position) if session.active_position else None
    if not pos:
        return False

    order = {
        "symbol": pos["symbol"],
        "qty": Config.LOT_SIZE,
        "type": 2,
        "side": -1,
        "productType": "MARGIN",
        "validity": "DAY",
    }

    try:
        resp = fyers.place_order(data=order)
    except Exception as exc:
        session.decision_reason = f"LIVE exit exception: {exc}"
        log_console(f"❌ LIVE EXIT exception: {exc}")
        return False

    if isinstance(resp, dict) and resp.get("s") == "ok":
        log_console(
            f"🔴 LIVE EXIT {pos['entry_type']} | {pos['symbol']} | "
            f"reason={reason} | order={resp.get('id')}"
        )
        with session.lock:
            session.active_position = None
            session.position_state = "FLAT"
            session.decision_reason = (
                f"LIVE EXIT {pos['entry_type']} | reason={reason} | order={resp.get('id')}"
            )
        return True

    session.decision_reason = f"LIVE exit failed: {resp}"
    log_console(f"❌ LIVE EXIT failed for {pos['symbol']}: {resp}")
    return False


# ============================================================
# STRATEGY ENGINE
# ============================================================
def process_snapshot(session: SessionState, fyers, execute_trades: bool):
    if getattr(session, "_order_lock", False):
        return

    session._order_lock = True
    try:
        now_ts = time.time()
        spot = session.get_ltp(Config.INDEX_SYMBOL)

        # --------------------------------------------------------
        # No NIFTY tick yet.
        # --------------------------------------------------------
        if spot is None or spot <= 0:
            if not session.ws_connected:
                session.decision_reason = "WAITING | WebSocket disconnected; no NIFTY tick"
            else:
                session.decision_reason = "WAITING | WebSocket connected but no NIFTY market tick"
            return

        session.current_spot = float(spot)

        # --------------------------------------------------------
        # ACTIVE POSITION HAS PRIORITY.
        # Exit is based on the HELD OPTION SYMBOL, not current ATM.
        # --------------------------------------------------------
        if session.active_position is not None:
            with session.lock:
                pos = dict(session.active_position)
            held_symbol = pos["symbol"]

            # Need a fresh tick for the held contract.
            if session.get_ltp_time(held_symbol) is None or (
                now_ts - session.get_ltp_time(held_symbol) > Config.OPTION_PRICE_STALE_SECONDS
            ):
                session.decision_reason = (
                    f"HOLD {pos['entry_type']} | held option tick stale/unavailable | {held_symbol}"
                )
                return

            held_5, held_15 = session.get_symbol_vwaps(held_symbol, now_ts)
            session.held_vwaps = (held_5, held_15)

            current_premium = session.get_ltp(held_symbol)
            if current_premium and current_premium > 0:
                with session.lock:
                    if session.active_position:
                        session.active_position["current_premium"] = current_premium

            if held_5 is None or held_15 is None:
                session.decision_reason = (
                    f"HOLD {pos['entry_type']} | waiting for held-symbol 5m/15m VWAP | {held_symbol}"
                )
                return

            cross_up, cross_down = session.detect_crossover(held_symbol, held_5, held_15)
            del cross_up

            if cross_down:
                reason = f"Held 5m VWAP {held_5:.4f} crossed below 15m VWAP {held_15:.4f}"
                log_console(f"🔻 EXIT SIGNAL | {pos['entry_type']} | {reason}")

                if not execute_trades:
                    session.decision_reason = f"EXIT SIGNAL | {reason} | Auto-trade OFF"
                    return

                if PAPER_MODE:
                    paper_exit(session, reason)
                else:
                    live_exit(session, fyers, reason)
                return

            session.decision_reason = (
                f"HOLD {pos['entry_type']} | {held_symbol} | "
                f"5m={held_5:.4f} | 15m={held_15:.4f} | no DOWN crossover"
            )
            return

        # --------------------------------------------------------
        # FLAT: 15m time warmup first.
        # --------------------------------------------------------
        if not session.warmup_complete():
            if session.warmup_start_time is None:
                session.decision_reason = "WAITING | First NIFTY tick required before warmup"
            else:
                session.decision_reason = (
                    f"WARMUP | {session.warmup_remaining():.0f}s remaining | no entries"
                )
            return

        # --------------------------------------------------------
        # Current ATM for entries only.
        # --------------------------------------------------------
        atm, atm_ce, atm_pe = session.current_atm_symbols()
        if atm is None or not atm_ce or not atm_pe:
            session.decision_reason = "WAITING | Current ATM CE/PE symbols unavailable"
            return

        # Freshness check for current ATM entry contracts.
        for symbol, label in ((atm_ce, "ATM CE"), (atm_pe, "ATM PE")):
            ts = session.get_ltp_time(symbol)
            if ts is None or now_ts - ts > Config.OPTION_PRICE_STALE_SECONDS:
                session.decision_reason = f"WAITING | {label} tick stale/unavailable"
                return

        ce_5, ce_15 = session.get_symbol_vwaps(atm_ce, now_ts)
        pe_5, pe_15 = session.get_symbol_vwaps(atm_pe, now_ts)
        session.current_atm_vwaps = {
            "CE": (ce_5, ce_15),
            "PE": (pe_5, pe_15),
        }

        # Require both current ATM 5m/15m VWAPs.
        if None in (ce_5, ce_15, pe_5, pe_15):
            session.decision_reason = (
                "WAITING | Current ATM CE/PE does not yet have valid 5m+15m VWAPs"
            )
            return

        # IMPORTANT: Update actual-symbol crossover state continuously while flat.
        ce_up, _ = session.detect_crossover(atm_ce, ce_5, ce_15)
        pe_up, _ = session.detect_crossover(atm_pe, pe_5, pe_15)

        # Do NOT invent a tie-break rule. If both cross on the exact same sample,
        # do not enter either; wait for the next clean single-symbol crossover.
        if ce_up and pe_up:
            session.decision_reason = (
                f"BOTH ATM CE and PE crossed UP simultaneously | no entry"
            )
            log_console("⚠️ Both ATM CE and PE crossed UP on the same sample; no entry")
            return

        selected_type = None
        selected_symbol = None
        selected_5 = None
        selected_15 = None

        if ce_up:
            selected_type = "CE"
            selected_symbol = atm_ce
            selected_5, selected_15 = ce_5, ce_15
        elif pe_up:
            selected_type = "PE"
            selected_symbol = atm_pe
            selected_5, selected_15 = pe_5, pe_15
        else:
            session.decision_reason = (
                f"FLAT | ATM CE 5m/15m={ce_5:.4f}/{ce_15:.4f} | "
                f"ATM PE 5m/15m={pe_5:.4f}/{pe_15:.4f} | no UP crossover"
            )
            return

        if session.daily_entries >= Config.MAX_DAILY_ENTRIES:
            session.decision_reason = "MAX DAILY ENTRIES REACHED"
            return

        premium = session.get_ltp(selected_symbol)
        if premium is None or premium <= 0:
            session.decision_reason = (
                f"{selected_type} SIGNAL | premium unavailable | {selected_symbol}"
            )
            return

        session.decision_reason = (
            f"BUY {selected_type} SIGNAL | ATM={atm:.0f} | {selected_symbol} | "
            f"5m={selected_5:.4f} crossed ABOVE 15m={selected_15:.4f} | LTP={premium:.2f}"
        )
        log_console(
            f"🔔 BUY {selected_type} SIGNAL | ATM={atm:.0f} | {selected_symbol} | "
            f"5m={selected_5:.4f} > 15m={selected_15:.4f} | LTP={premium:.2f}"
        )

        if not execute_trades:
            session.decision_reason += " | Auto-trade OFF"
            return

        if PAPER_MODE:
            paper_enter(session, selected_symbol, premium, selected_type, atm)
        else:
            live_enter(session, fyers, selected_symbol, premium, selected_type, atm)

    except Exception as exc:
        session.decision_reason = f"ERROR | {exc}"
        log_console(f"❌ process_snapshot error: {exc}")
        log_debug(traceback.format_exc())
    finally:
        session._order_lock = False


# ============================================================
# SAMPLER
# ============================================================
def sampler(session: SessionState, data_logger: DataLogger, auto_trade: bool, fyers):
    log_console("✅ Sampler thread started")

    while session.running:
        started = time.time()
        try:
            process_snapshot(session, fyers, execute_trades=auto_trade)
            data_logger.log_data(session)

            elapsed = time.time() - started
            if elapsed < Config.SAMPLE_INTERVAL:
                time.sleep(Config.SAMPLE_INTERVAL - elapsed)
        except Exception as exc:
            log_console(f"❌ Sampler error: {exc}")
            log_debug(traceback.format_exc())
            time.sleep(1)


# ============================================================
# DASHBOARD
# ============================================================
class TerminalDashboard:
    @staticmethod
    def fmt(value, digits=4):
        if value is None:
            return "N/A"
        try:
            return f"{float(value):.{digits}f}"
        except Exception:
            return "N/A"

    def __init__(self, session: SessionState):
        self.session = session

    def display(self):
        try:
            os.system("cls" if os.name == "nt" else "clear")
            s = self.session

            with s.lock:
                spot = s.current_spot
                atm = s.atm_strike
                position = dict(s.active_position) if s.active_position else None
                reason = s.decision_reason
                realized = s.paper_realized_pnl
                daily_entries = s.daily_entries
                ws_connected = s.ws_connected
                ws_error = s.ws_last_error
                msg_count = s.ws_message_count
                nifty_ticks = s.nifty_tick_count
                option_ticks = s.option_tick_count
                chain_status = s.chain_api_status
                chain_message = s.chain_api_message
                chain_updates = s.chain_update_count
                warmup_start = s.warmup_start_time
                warmup_remaining = s.warmup_remaining()
                tracked = sorted(s.tracked_strikes)
                mapping = dict(s.strike_to_symbols)
                first_message = s.first_message_raw
                last_nifty = s.last_nifty_tick_time
                chain_last = s.chain_last_update_time
                warmup_complete = s.warmup_complete()
                atm_vwaps = dict(s.current_atm_vwaps)

            total_symbols, active_symbols = s.get_symbol_data_counts(5)

            if position:
                state = "ACTIVE POSITION"
            elif not warmup_complete or warmup_start is None:
                state = "WARMUP / WAITING DATA"
            else:
                state = "FLAT"

            mode = "PAPER" if PAPER_MODE else "LIVE"

            print("=" * 118)
            print(f"📊 FYERS ATM 5m/15m VWAP CROSSOVER STRATEGY — {mode}")
            print("=" * 118)
            print(
                f"Time: {timestamp_ist()} | Spot: {self.fmt(spot,2)} | "
                f"Current ATM: {self.fmt(atm,0)} | State: {state}"
            )
            print(
                f"WS: {'CONNECTED' if ws_connected else 'DISCONNECTED'} | "
                f"messages={msg_count} | NIFTY ticks={nifty_ticks} | option ticks={option_ticks} | "
                f"symbols active≤5s={active_symbols}/{total_symbols} | entries={daily_entries}/{Config.MAX_DAILY_ENTRIES} | "
                f"realized P&L={realized:+.2f}"
            )
            if ws_error:
                print(f"⚠️ WS error: {ws_error}")

            print("-" * 118)
            print("🔌 DATA PIPELINE")
            print("-" * 118)
            print(f"WebSocket          : {'CONNECTED' if ws_connected else 'DISCONNECTED'}")
            print(f"First WS packet    : {first_message or 'N/A'}")
            print(f"Last NIFTY tick    : {timestamp_ist() if last_nifty else 'N/A'}")
            print(f"REST option chain  : {chain_status} | updates={chain_updates}")
            print(f"Last chain update  : {timestamp_ist() if chain_last else 'N/A'}")
            print(f"Chain detail       : {chain_message or 'N/A'}")

            print("\n" + "-" * 118)
            print("⏱️ VWAP ENGINE")
            print("-" * 118)
            if warmup_start is None:
                print("⏸️ WAITING FOR FIRST NIFTY MARKET TICK | 15-minute warmup has NOT started")
            elif not warmup_complete:
                print(
                    f"🔥 15-MINUTE WARMUP | {warmup_remaining:.0f}s remaining | "
                    "no entries"
                )
            else:
                print("✅ 15-MINUTE TIME WARMUP COMPLETE")

            print("\n" + "-" * 118)
            print("📈 CURRENT ATM SIGNAL DATA — ENTRY SOURCE ONLY")
            print("-" * 118)
            ce5, ce15 = atm_vwaps.get("CE", (None, None))
            pe5, pe15 = atm_vwaps.get("PE", (None, None))
            ce_symbol = mapping.get(float(atm), {}).get("CE") if atm is not None else None
            pe_symbol = mapping.get(float(atm), {}).get("PE") if atm is not None else None
            ce_ltp = s.get_ltp(ce_symbol) if ce_symbol else None
            pe_ltp = s.get_ltp(pe_symbol) if pe_symbol else None

            print(
                f"ATM CE {ce_symbol or 'N/A'} | LTP={self.fmt(ce_ltp,2)} | "
                f"5m={self.fmt(ce5)} | 15m={self.fmt(ce15)} | "
                f"Spread={self.fmt((ce5-ce15) if ce5 is not None and ce15 is not None else None)}"
            )
            print(
                f"ATM PE {pe_symbol or 'N/A'} | LTP={self.fmt(pe_ltp,2)} | "
                f"5m={self.fmt(pe5)} | 15m={self.fmt(pe15)} | "
                f"Spread={self.fmt((pe5-pe15) if pe5 is not None and pe15 is not None else None)}"
            )

            print("\n" + "-" * 118)
            print("📊 ATM-1 / ATM / ATM+1 ROLLING VWAPs")
            print("-" * 118)
            if not tracked:
                print("Current tracked strikes are not available yet.")
            else:
                for strike in tracked:
                    label = (
                        "ATM" if atm is not None and strike == atm
                        else ("ATM-1" if atm is not None and strike < atm else "ATM+1")
                    )
                    for opt in ("CE", "PE"):
                        symbol = mapping.get(strike, {}).get(opt)
                        if not symbol:
                            continue
                        v5, v15 = s.get_symbol_vwaps(symbol)
                        ltp = s.get_ltp(symbol)
                        span = s.history_span(symbol)
                        print(
                            f"{label:5s} {strike:8.0f} {opt} | {symbol:30s} | "
                            f"LTP={self.fmt(ltp,2):>8s} | 5m={self.fmt(v5):>10s} | "
                            f"15m={self.fmt(v15):>10s} | history={span:6.0f}s"
                        )

            print("\n" + "-" * 118)
            print("📌 POSITION")
            print("-" * 118)
            if position:
                held_symbol = position["symbol"]
                held_5, held_15 = s.get_symbol_vwaps(held_symbol)
                held_ltp = s.get_ltp(held_symbol) or position["entry_premium"]
                pnl = (held_ltp - position["entry_premium"]) * Config.LOT_SIZE
                print(f"Type          : {position['entry_type']}")
                print(f"Symbol        : {held_symbol}")
                print(f"Entry strike  : {position['entry_strike']:.0f}")
                print(f"Entry premium : {position['entry_premium']:.2f}")
                print(f"Current LTP   : {held_ltp:.2f}")
                print(f"Unrealized P&L: {pnl:+.2f}")
                print(f"Held 5m VWAP  : {self.fmt(held_5)}")
                print(f"Held 15m VWAP : {self.fmt(held_15)}")
                print("Exit rule     : HELD option 5m VWAP crosses BELOW held option 15m VWAP")
            else:
                print("No active position.")

            print("\n" + "-" * 118)
            print("🧠 DECISION")
            print("-" * 118)
            print(reason or "No decision yet")

            print("\n" + "-" * 118)
            print("⚙️ RULES")
            print("-" * 118)
            print("Entry CE : CURRENT ATM CE 5m VWAP crosses ABOVE 15m VWAP")
            print("Entry PE : CURRENT ATM PE 5m VWAP crosses ABOVE 15m VWAP")
            print("Exit     : HELD OPTION 5m VWAP crosses BELOW 15m VWAP")
            print("VWAP     : rolling volume-weighted using LTP × incremental traded volume")
            print("Warmup   : 15 minutes of actual NIFTY/option data; no signal before that")
            print("Scope    : VWAPs tracked for ATM-1 / ATM / ATM+1; entry signal only from current ATM")
            print("State    : crossover memory is keyed by actual option symbol")
            print("=" * 118)

        except Exception as exc:
            log_debug(f"Dashboard error: {exc}\n{traceback.format_exc()}")


# ============================================================
# HEARTBEAT
# ============================================================
def heartbeat_monitor(session: SessionState, ws_manager: MarketWSManager):
    while session.running:
        time.sleep(max(2, Config.WS_HEARTBEAT_TIMEOUT // 2))

        now_ts = time.time()
        nifty_ts = session.get_ltp_time(Config.INDEX_SYMBOL)

        # If WS is connected but NIFTY has never arrived, do NOT blindly restart
        # repeatedly. Keep the diagnostic visible and let the connection settle.
        if nifty_ts is None:
            continue

        if now_ts - nifty_ts > Config.WS_HEARTBEAT_TIMEOUT:
            log_console(
                f"⚠️ NIFTY tick stale for >{Config.WS_HEARTBEAT_TIMEOUT}s. Restarting WS..."
            )
            ws_manager.stop()
            time.sleep(1)
            if session.running:
                ws_manager.start()
                time.sleep(1)
                ws_manager.resubscribe(list(ws_manager.subscribed))


# ============================================================
# CREDENTIALS
# ============================================================
def load_credentials(session: SessionState):
    try:
        with open(Config.CREDENTIALS_FILE, "r") as f:
            creds = json.load(f)
        session.cid = str(creds.get("client_id", ""))
        session.token = str(creds.get("access_token", ""))
        log_console(f"Loaded credentials: {session.cid}")
    except Exception as exc:
        log_console(f"Credentials file failed: {exc}; using environment variables")
        session.cid = os.getenv("FYERS_CID", "")
        session.token = os.getenv("FYERS_TOKEN", "")
        log_console(f"Using env client id: {session.cid}")


# ============================================================
# MAIN
# ============================================================
def main():
    log_console("Starting FYERS ATM 5m/15m VWAP Crossover Strategy...")

    session = SessionState()
    session.option_chain_api_count = 0
    session.api_window_start = now_ist()

    load_credentials(session)
    data_logger = DataLogger()
    dashboard = TerminalDashboard(session)

    poller_thread = None
    sampler_thread = None
    heartbeat_thread = None
    ws_manager = None
    fyers = None

    while True:
        os.system("cls" if os.name == "nt" else "clear")
        mode = "PAPER" if PAPER_MODE else "LIVE"
        print("=" * 60)
        print(f"📈 FYERS ATM VWAP CROSSOVER — {mode}")
        print("=" * 60)
        print("1. Start Trading")
        print("2. Settings")
        print("3. Exit")
        choice = input("Select option: ").strip()

        if choice == "1":
            if not (session.cid and session.token):
                print("❌ Client ID/access token missing")
                input("Press Enter...")
                continue

            session.reset_for_new_day()

            auto_trade = input("Enable Auto Trade? (y/n): ").strip().lower() == "y"
            log_console(f"Auto trade: {'ON' if auto_trade else 'OFF'}")

            # IMPORTANT: running BEFORE any thread starts.
            session.running = True

            # Construct FYERS REST client now so errors are immediate.
            fyers = fyersModel.FyersModel(
                client_id=session.cid,
                token=session.token,
                is_async=False,
                log_path="",
            )

            ws_manager = MarketWSManager(session, session.token)

            # Queue mandatory subscriptions before connecting.
            ws_manager.subscribe([Config.INDEX_SYMBOL, Config.VIX_SYMBOL])
            ws_manager.start()

            poller_thread = threading.Thread(
                target=chain_poller,
                args=(session, ws_manager, Config.INDEX_SYMBOL),
                name="ChainPoller",
                daemon=True,
            )
            sampler_thread = threading.Thread(
                target=sampler,
                args=(session, data_logger, auto_trade, fyers),
                name="Sampler",
                daemon=True,
            )
            heartbeat_thread = threading.Thread(
                target=heartbeat_monitor,
                args=(session, ws_manager),
                name="Heartbeat",
                daemon=True,
            )

            poller_thread.start()
            sampler_thread.start()
            heartbeat_thread.start()

            print("\n✅ Trading started. Press Ctrl+C to stop.\n")

            try:
                while True:
                    dashboard.display()
                    time.sleep(1)

            except KeyboardInterrupt:
                log_console("\n🛑 Stopping trading...")
                session.running = False

                if ws_manager:
                    ws_manager.stop()

                if sampler_thread:
                    sampler_thread.join(timeout=5)
                if poller_thread:
                    poller_thread.join(timeout=Config.OPTION_CHAIN_INTERVAL + 5)
                if heartbeat_thread:
                    heartbeat_thread.join(timeout=3)

                if session.active_position:
                    log_console("Attempting shutdown square-off...")
                    if PAPER_MODE:
                        paper_exit(session, "SHUTDOWN")
                    else:
                        live_exit(session, fyers, "SHUTDOWN")

                log_console("✅ Trading stopped.")

        elif choice == "2":
            print("\n⚙️ SETTINGS")
            new_cid = input(f"Client ID [{session.cid}]: ").strip()
            if new_cid:
                session.cid = new_cid

            new_token = input("Access token: ").strip()
            if new_token:
                session.token = new_token

            try:
                with open(Config.CREDENTIALS_FILE, "w") as f:
                    json.dump(
                        {
                            "client_id": session.cid,
                            "access_token": session.token,
                        },
                        f,
                        indent=2,
                    )
                print("✅ Saved")
            except Exception as exc:
                print(f"❌ Save failed: {exc}")
            input("Press Enter...")

        elif choice == "3":
            session.running = False
            if ws_manager:
                ws_manager.stop()
            break


if __name__ == "__main__":
    main()
