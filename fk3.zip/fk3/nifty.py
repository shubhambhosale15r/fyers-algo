import time
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import pytz
from fyers_apiv3 import fyersModel
import logging
import os
import json
from collections import deque
import csv

# ============================================================
# CONFIGURATION
# ============================================================
class Config:
    REFRESH_INTERVAL = 60
    API_RATE_LIMIT = 200
    API_WINDOW = 60
    LOT_SIZE = 65
    MAX_RETRIES = 3
    RETRY_DELAY = 2
    MAX_DAILY_ORDERS = 8
    ROLLING_WINDOW_SIZE = 15
    TRAIL_STOP_PCT = 0.25          # trailing stop on cumulative idwp

# ============================================================
# LOGGING
# ============================================================
logging.basicConfig(
    filename="trading_app.log",
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)

IST = pytz.timezone("Asia/Kolkata")

def now_ist():
    return datetime.now(IST)

def timestamp_ist():
    return now_ist().strftime("%Y-%m-%d %H:%M:%S")

def is_market_open():
    return True   # override for live

# ============================================================
# ERROR HANDLER
# ============================================================
def handle_errors(func):
    def wrapper(*args, **kwargs):
        retries = 0
        while retries < Config.MAX_RETRIES:
            try:
                return func(*args, **kwargs)
            except Exception as e:
                retries += 1
                print(f"[ERROR] {func.__name__} failed: {e}")
                logging.error(f"{func.__name__} failed: {e}")
                if retries < Config.MAX_RETRIES:
                    time.sleep(Config.RETRY_DELAY)
                else:
                    return None
        return None
    return wrapper

# ============================================================
# HELPER FUNCTIONS
# ============================================================
def get_next_aligned_time(interval_seconds):
    now = now_ist()
    current_seconds = (now - now.replace(hour=0, minute=0, second=0, microsecond=0)).total_seconds()
    intervals_passed = current_seconds // interval_seconds
    next_aligned_seconds = (intervals_passed + 1) * interval_seconds
    next_time = now.replace(hour=0, minute=0, second=0, microsecond=0) + timedelta(seconds=next_aligned_seconds)
    return next_time

def wait_until_next_interval(interval_seconds):
    next_time = get_next_aligned_time(interval_seconds)
    wait_seconds = (next_time - now_ist()).total_seconds()
    if wait_seconds > 0:
        print(f"⏳ Next update at {next_time.strftime('%H:%M:%S')} (waiting {wait_seconds:.1f}s)")
        time.sleep(wait_seconds)

# ============================================================
# DATA LOGGER (full cumulative columns)
# ============================================================
class DataLogger:
    def __init__(self, filename="trading_data.csv"):
        self.filename = filename
        self._ensure_header()

    def _ensure_header(self):
        try:
            with open(self.filename, 'r'):
                pass
        except FileNotFoundError:
            with open(self.filename, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'timestamp', 'underlying_ltp', 'signal', 'atm_strike',
                    'expiry_date', 'idwp', 'inof', 'cumul_idwp', 'cumul_inof', 'position'
                ])

    def log_data(self, timestamp, underlying_ltp, signal, atm_strike,
                 expiry_date, idwp, inof, cumul_idwp, cumul_inof, position):
        with open(self.filename, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                str(timestamp),
                float(underlying_ltp) if underlying_ltp is not None else 0.0,
                str(signal),
                int(atm_strike) if atm_strike is not None else 0,
                str(expiry_date),
                round(float(idwp), 2),
                round(float(inof), 2),
                round(float(cumul_idwp), 2),
                round(float(cumul_inof), 2),
                str(position)
            ])

    def read_data(self, limit=None):
        try:
            df = pd.read_csv(self.filename)
            if limit:
                return df.tail(limit)
            return df
        except:
            return pd.DataFrame()

# ============================================================
# DASHBOARD (simplified)
# ============================================================
class TerminalDashboard:
    def __init__(self, data_logger, session_state=None):
        self.data_logger = data_logger
        self.session_state = session_state

    def display_live_dashboard(self):
        try:
            os.system('cls' if os.name == 'nt' else 'clear')
            df = self.data_logger.read_data(limit=20)
            print("\n" + "=" * 100)
            print("📊 LIVE TRADING DASHBOARD")
            print("=" * 100)
            print(f"Last Update: {timestamp_ist()}")
            if self.session_state:
                print(f"📈 DAILY ORDER COUNT: {self.session_state.daily_executed_orders}/{Config.MAX_DAILY_ORDERS}")
            if df.empty:
                print("🔄 Waiting for trading data...")
                return
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            df = df.sort_values('timestamp')
            latest = df.iloc[-1]
            print(f"\n📈 CURRENT STATUS:")
            print(f"   Nifty LTP: {latest.get('underlying_ltp', 0)}")
            print(f"   Signal: {latest.get('signal', '')}")
            print(f"   ATM Strike: {latest.get('atm_strike', '')}")
            print(f"   idwp: {latest.get('idwp', '')} | inof: {latest.get('inof', '')}")
            print(f"   Cumul idwp: {latest.get('cumul_idwp', '')} | Cumul inof: {latest.get('cumul_inof', '')}")
            print(f"   Position: {latest.get('position', '')}")

            if self.session_state:
                pos = self.session_state.position
                if pos == "LONG":
                    peak = self.session_state.peak_cumul_idwp
                    thresh = peak * (1 - Config.TRAIL_STOP_PCT)
                    print(f"   📈 LONG: peak cumul={peak:.2f}, exit below {thresh:.2f}")
                elif pos == "SHORT":
                    trough = self.session_state.trough_cumul_idwp
                    thresh = trough * (1 - Config.TRAIL_STOP_PCT)
                    print(f"   📉 SHORT: trough cumul={trough:.2f}, exit above {thresh:.2f}")
                else:
                    print(f"   💤 No active position")

            print(f"\n🔄 RECENT SIGNALS (Last 5):")
            for _, row in df.tail(5).iterrows():
                color = {'BUY': '🟢', 'SELL': '🔴', 'EXIT': '🟡', 'HOLD': '⚪'}.get(row['signal'], '⚪')
                print(f"   {row['timestamp'].strftime('%H:%M:%S')} - {color} {row['signal']} - LTP: {row['underlying_ltp']}")
            print("\n" + "=" * 100)
        except Exception as e:
            print(f"[ERROR] Dashboard error: {e}")

# ============================================================
# SESSION STATE
# ============================================================
class SessionState:
    def __init__(self):
        self.option_chain_api_count = 0
        self.quote_api_count = 0
        self.api_window_start = now_ist()
        self.last_signal = None
        self.cid = ""
        self.token = ""
        self._hb_lock = False
        self.daily_executed_orders = 0
        self.last_order_sync = None

        # Rolling buffers
        self.idwp_window = deque(maxlen=Config.ROLLING_WINDOW_SIZE)
        self.inof_window = deque(maxlen=Config.ROLLING_WINDOW_SIZE)
        self.window_filled = False

        # Position and trailing stop on cumulative idwp
        self.position = "FLAT"
        self.peak_cumul_idwp = 0.0
        self.trough_cumul_idwp = 0.0

    def sync_order_count_with_fyers(self, fyers):
        today = now_ist().date()
        if self.last_order_sync != today:
            self.daily_executed_orders = 0
            self.last_order_sync = today
        try:
            resp = fyers.orderbook()
            if resp.get("s") == "ok":
                self.daily_executed_orders = len([o for o in resp.get("orderBook", []) if o.get("status") == 2])
        except:
            pass

    def can_place_order(self, fyers=None):
        if fyers:
            self.sync_order_count_with_fyers(fyers)
        return self.daily_executed_orders < Config.MAX_DAILY_ORDERS

# ============================================================
# CREDENTIALS
# ============================================================
def load_credentials(session_state):
    try:
        with open('fyers_credentials.json', 'r') as f:
            creds = json.load(f)
            session_state.cid = creds.get('client_id', '')
            session_state.token = creds.get('access_token', '')
    except:
        session_state.cid = os.getenv("FYERS_CID", session_state.cid)
        session_state.token = os.getenv("FYERS_TOKEN", session_state.token)

# ============================================================
# API FUNCTIONS (unchanged)
# ============================================================
def enforce_rate_limit(session_state):
    now = now_ist()
    window = now - session_state.api_window_start
    total_calls = session_state.option_chain_api_count + session_state.quote_api_count
    if window.total_seconds() > Config.API_WINDOW:
        session_state.api_window_start = now
        session_state.option_chain_api_count = 0
        session_state.quote_api_count = 0
    elif total_calls >= Config.API_RATE_LIMIT:
        wait = Config.API_WINDOW - int(window.total_seconds())
        if wait > 0:
            time.sleep(wait)
        session_state.api_window_start = now
        session_state.option_chain_api_count = 0
        session_state.quote_api_count = 0

@handle_errors
def get_option_chain_data(session_state, cid, token, sym, expiry_ts=""):
    enforce_rate_limit(session_state)
    session_state.option_chain_api_count += 1
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    payload = {
        "symbol": sym,
        "strikecount": 5,
        "timestamp": expiry_ts,
        "greeks": "1"
    }
    resp = fy.optionchain(data=payload)
    if not resp or resp.get("code") != 200:
        return None
    return resp["data"]["optionsChain"]

@handle_errors
def get_underlying_ltp(session_state, cid, token, sym):
    enforce_rate_limit(session_state)
    session_state.quote_api_count += 1
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    resp = fy.quotes(data={"symbols": sym})
    if not resp or resp.get("code") != 200 or not resp.get("d"):
        return None
    return resp["d"][0]["v"]["lp"]

@handle_errors
def update_all_data(session_state, cid, token, sym):
    fy = fyersModel.FyersModel(client_id=cid, token=token, is_async=False, log_path="")
    enforce_rate_limit(session_state)
    session_state.option_chain_api_count += 1
    meta = fy.optionchain(data={"symbol": sym, "timestamp": ""})
    if meta.get("code") != 200:
        return None, None, None
    exp = sorted([(e["date"], e.get("expiry")) for e in meta["data"]["expiryData"]],
                 key=lambda x: datetime.strptime(x[0], "%d-%m-%Y"))
    today = now_ist().date()
    dates = [datetime.strptime(d, "%d-%m-%Y").date() for d,_ in exp]
    idx = next((i for i,d in enumerate(dates) if d >= today), 0)
    curr_date, curr_ts = exp[idx]
    ltp = get_underlying_ltp(session_state, cid, token, sym)
    chain = get_option_chain_data(session_state, cid, token, sym, expiry_ts=curr_ts)
    return ltp, chain, curr_date

# ============================================================
# SIGNAL COMPUTATION (simple directional based on cumulative)
# ============================================================
def compute_signals(merged_df, atm_strike, ltp, session_state):
    if merged_df is None or merged_df.empty:
        return "HOLD", {}, "FLAT"

    # Compute current idwp and inof from ATM ±1 strikes
    available_strikes = sorted(merged_df["strike"].unique())
    if atm_strike not in available_strikes:
        return "HOLD", {}, "FLAT"
    atm_idx = available_strikes.index(atm_strike)
    selected = [atm_strike]
    if atm_idx > 0:
        selected.append(available_strikes[atm_idx-1])
    if atm_idx < len(available_strikes)-1:
        selected.append(available_strikes[atm_idx+1])

    idwps, inofs = [], []
    for strike in selected:
        rows = merged_df[merged_df["strike"] == strike]
        ce = rows[rows["option_type"] == "CE"]
        pe = rows[rows["option_type"] == "PE"]
        if ce.empty or pe.empty:
            continue
        ce = ce.iloc[0]
        pe = pe.iloc[0]
        ce_ltp = float(ce.get("ltp", 0))
        pe_ltp = float(pe.get("ltp", 0))
        ce_delta = float(ce.get("delta", 0))
        pe_delta = abs(float(pe.get("delta", 0)))
        ce_vol = float(ce.get("volume", 0))
        pe_vol = float(pe.get("volume", 0))
        idwps.append((ce_ltp * ce_delta) - (pe_ltp * pe_delta))
        inofs.append((ce_vol * ce_delta) - (pe_vol * pe_delta))

    if not idwps or not inofs:
        return "HOLD", {}, session_state.position

    idwp = sum(idwps) / len(idwps)
    inof = sum(inofs) / len(inofs)

    # Update rolling windows
    session_state.idwp_window.append(idwp)
    session_state.inof_window.append(inof)

    # Warm-up
    if not session_state.window_filled:
        if len(session_state.inof_window) < Config.ROLLING_WINDOW_SIZE:
            metrics = {"idwp": idwp, "inof": inof, "cumul_idwp": 0.0, "cumul_inof": 0.0}
            return "HOLD", metrics, session_state.position
        else:
            session_state.window_filled = True

    # Compute cumulative sums
    cumul_idwp = sum(session_state.idwp_window)
    cumul_inof = sum(session_state.inof_window)

    signal = "HOLD"

    # --- EXIT based on cumulative idwp ---
    if session_state.position == "LONG":
        if cumul_idwp > session_state.peak_cumul_idwp:
            session_state.peak_cumul_idwp = cumul_idwp
        exit_threshold = session_state.peak_cumul_idwp * (1 - Config.TRAIL_STOP_PCT)
        if cumul_idwp < exit_threshold:
            signal = "EXIT"
            session_state.position = "FLAT"
            session_state.peak_cumul_idwp = 0.0
    elif session_state.position == "SHORT":
        if cumul_idwp < session_state.trough_cumul_idwp:
            session_state.trough_cumul_idwp = cumul_idwp
        exit_threshold = session_state.trough_cumul_idwp * (1 - Config.TRAIL_STOP_PCT)
        if cumul_idwp > exit_threshold:
            signal = "EXIT"
            session_state.position = "FLAT"
            session_state.trough_cumul_idwp = 0.0

    # --- ENTRY (only if FLAT) ---
    if session_state.position == "FLAT" and signal != "EXIT":
        if cumul_idwp > 0 and cumul_inof > 0:
            signal = "BUY"
            session_state.position = "LONG"
            session_state.peak_cumul_idwp = cumul_idwp
        elif cumul_idwp < 0 and cumul_inof < 0:
            signal = "SELL"
            session_state.position = "SHORT"
            session_state.trough_cumul_idwp = cumul_idwp

    metrics = {
        "atm_strike": atm_strike,
        "spot": ltp,
        "idwp": idwp,
        "inof": inof,
        "cumul_idwp": cumul_idwp,
        "cumul_inof": cumul_inof
    }
    return signal, metrics, session_state.position

# ============================================================
# STRIKE SELECTION (only ATM for directional)
# ============================================================
def select_atm_option(chain, atm_strike, option_type):
    """Return the option dict for given strike and type ('CE' or 'PE')"""
    try:
        df = pd.DataFrame(chain)
        if df.empty:
            return None
        opt = df[(df["strike_price"] == atm_strike) & (df["option_type"] == option_type)]
        if opt.empty:
            return None
        return opt.iloc[0].to_dict()
    except:
        return None

# ============================================================
# ORDER MANAGEMENT (simple directional)
# ============================================================
def place_order(session_state, signal, atm_ce, atm_pe, fyers):
    if getattr(session_state, '_hb_lock', False):
        return False
    session_state._hb_lock = True
    try:
        lot = Config.LOT_SIZE
        if signal in ("EXIT", "HOLD"):
            # Exit all positions
            fyers.exit_positions(data={"segment": [11], "side": [-1], "productType": ["MARGIN"]})
            fyers.exit_positions(data={"segment": [11], "side": [1], "productType": ["MARGIN"]})
            time.sleep(2)
            session_state.last_signal = signal
            return True
        if signal in ("BUY", "SELL") and session_state.can_place_order(fyers):
            leg = atm_ce if signal == "BUY" else atm_pe
            if not leg:
                return False
            order = {
                "symbol": leg["symbol"],
                "qty": lot,
                "type": 2,
                "side": 1,
                "productType": "MARGIN",
                "validity": "DAY",
            }
            resp = fyers.place_order(data=order)
            if resp.get("s") == "ok":
                session_state.last_signal = signal
                return True
        return False
    except Exception as e:
        print(f"[ERROR] Order error: {e}")
        return False
    finally:
        session_state._hb_lock = False

# ============================================================
# MAIN
# ============================================================
def main():
    session_state = SessionState()
    load_credentials(session_state)
    data_logger = DataLogger()
    dashboard = TerminalDashboard(data_logger, session_state)
    sym = 'NSE:NIFTY50-INDEX'

    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        print("="*50)
        print("📈 FYERS ALGO TRADING")
        print("1. Start Live Trading")
        print("2. Settings")
        print("3. Exit")
        choice = input("Select option: ").strip()
        if choice == "1":
            if not (session_state.cid and session_state.token):
                print("❌ Set credentials first")
                input("Press Enter...")
                continue
            auto_trade = input("Enable Auto Trade? (y/n): ").lower() == 'y'
            if not auto_trade:
                continue
            print("Starting live trading loop...")
            try:
                while True:
                    dashboard.display_live_dashboard()
                    ltp, chain, curr_date = update_all_data(session_state, session_state.cid, session_state.token, sym)
                    if ltp is None or chain is None:
                        wait_until_next_interval(Config.REFRESH_INTERVAL)
                        continue

                    fy = fyersModel.FyersModel(client_id=session_state.cid, token=session_state.token, is_async=False, log_path="")
                    session_state.sync_order_count_with_fyers(fy)

                    records = []
                    for opt in chain:
                        if opt.get("option_type") in ("CE","PE"):
                            greeks = opt.get("greeks", {})
                            records.append({
                                "strike": opt["strike_price"],
                                "option_type": opt["option_type"],
                                "ltp": opt.get("ltp", 0),
                                "delta": greeks.get("delta", 0),
                                "volume": opt.get("volume", 0)
                            })
                    merged_df = pd.DataFrame(records)
                    if merged_df.empty:
                        wait_until_next_interval(Config.REFRESH_INTERVAL)
                        continue

                    atm_strike = min(merged_df["strike"].unique(), key=lambda x: abs(x - ltp))
                    signal, metrics, position = compute_signals(merged_df, atm_strike, ltp, session_state)

                    # Log to CSV
                    data_logger.log_data(
                        timestamp=timestamp_ist(),
                        underlying_ltp=ltp,
                        signal=signal,
                        atm_strike=atm_strike,
                        expiry_date=curr_date,
                        idwp=metrics.get("idwp", 0),
                        inof=metrics.get("inof", 0),
                        cumul_idwp=metrics.get("cumul_idwp", 0),
                        cumul_inof=metrics.get("cumul_inof", 0),
                        position=position
                    )

                    if auto_trade:
                        atm_ce = select_atm_option(chain, atm_strike, "CE")
                        atm_pe = select_atm_option(chain, atm_strike, "PE")
                        place_order(session_state, signal, atm_ce, atm_pe, fy)

                    wait_until_next_interval(Config.REFRESH_INTERVAL)
            except KeyboardInterrupt:
                print("\nStopped by user")
        elif choice == "2":
            print("\n⚙️ SETTINGS")
            new_cid = input(f"Client ID [{session_state.cid}]: ").strip()
            if new_cid:
                session_state.cid = new_cid
            new_token = input(f"Access token: ").strip()
            if new_token:
                session_state.token = new_token
            with open('fyers_credentials.json', 'w') as f:
                json.dump({"client_id": session_state.cid, "access_token": session_state.token}, f)
            print("✅ Settings saved")
            input("Press Enter...")
        elif choice == "3":
            break

if __name__ == "__main__":
    main()