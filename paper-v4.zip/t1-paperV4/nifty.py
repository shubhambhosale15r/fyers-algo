# ============================================================
# nifty.py – Multi-Period Momentum Ranking Strategy
# With Strike Filter Breakdown (see why each strike is rejected)
# ============================================================

import time
import numpy as np
from datetime import datetime
import pytz
from fyers_apiv3 import fyersModel
from fyers_apiv3.FyersWebsocket import data_ws
import logging
import os
import json
from collections import deque
import csv
import threading
import traceback

# ============================================================
# PAPER TRADE FLAG
# ============================================================
PAPER_MODE = True   # Change to False for live trading

# ============================================================
# CONFIGURATION
# ============================================================
class Config:
    SAMPLE_INTERVAL = 1
    OPTION_CHAIN_INTERVAL = 30
    SCORE_WIN_5 = 300
    SCORE_WIN_15 = 900
    WARMUP_DURATION = SCORE_WIN_15   
    ATM_RANGE = 5
    MAX_POSITIONS = 3
    LOT_SIZE = 65
    MAX_DAILY_ENTRIES = 24
    API_RATE_LIMIT = 200
    API_WINDOW = 60
    MAX_RETRIES = 3
    RETRY_DELAY = 2
    FNO_SEGMENT = 14

# ============================================================
# LOGGING
# ============================================================
logging.basicConfig(
    filename="trading_app.log",
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)

def log_debug(msg):
    logging.debug(msg)

def log_console(msg):
    print(msg, flush=True)
    logging.info(msg)

IST = pytz.timezone("Asia/Kolkata")

def now_ist():
    return datetime.now(IST)

def timestamp_ist():
    return now_ist().strftime("%Y-%m-%d %H:%M:%S")

# ============================================================
# ERROR HANDLER
# ============================================================
def handle_errors(func):
    def wrapper(*args, **kwargs):
        for retry in range(Config.MAX_RETRIES):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                log_debug(f"{func.__name__} attempt {retry+1} failed: {e}\n{traceback.format_exc()}")
                if retry < Config.MAX_RETRIES-1:
                    time.sleep(Config.RETRY_DELAY)
                else:
                    log_debug(f"{func.__name__} permanently failed")
                    return None, None, None, None, []
    return wrapper

# ============================================================
# DATA LOGGER
# ============================================================
class DataLogger:
    def __init__(self, filename="trading_data.csv"):
        self.filename = filename
        self._ensure_header()

    def _ensure_header(self):
        if not os.path.exists(self.filename):
            with open(self.filename, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'timestamp', 'underlying_ltp', 'atm_strike', 'expiry_date',
                    'top1_symbol', 'top1_score', 'top1_ltp', 'top1_vwap',
                    'top2_symbol', 'top2_score', 'top2_ltp', 'top2_vwap',
                    'top3_symbol', 'top3_score', 'top3_ltp', 'top3_vwap',
                    'held1_symbol', 'held1_entry', 'held1_current', 'held1_pnl',
                    'held2_symbol', 'held2_entry', 'held2_current', 'held2_pnl',
                    'held3_symbol', 'held3_entry', 'held3_current', 'held3_pnl',
                    'total_paper_pnl', 'vix', 'daily_entries', 'warmup_remaining'
                ])

    def log_data(self, timestamp, underlying_ltp, atm_strike, expiry_date,
                 top_candidates, active_positions, total_pnl, vix, daily_entries, warmup_remaining):
        # Unpack top 3
        top1_s = top_candidates[0]['symbol'] if len(top_candidates) > 0 else ''
        top1_sc = top_candidates[0]['score'] if len(top_candidates) > 0 else 0.0
        top1_l = top_candidates[0]['ltp'] if len(top_candidates) > 0 else 0.0
        top1_v = top_candidates[0]['vwap'] if len(top_candidates) > 0 else 0.0

        top2_s = top_candidates[1]['symbol'] if len(top_candidates) > 1 else ''
        top2_sc = top_candidates[1]['score'] if len(top_candidates) > 1 else 0.0
        top2_l = top_candidates[1]['ltp'] if len(top_candidates) > 1 else 0.0
        top2_v = top_candidates[1]['vwap'] if len(top_candidates) > 1 else 0.0

        top3_s = top_candidates[2]['symbol'] if len(top_candidates) > 2 else ''
        top3_sc = top_candidates[2]['score'] if len(top_candidates) > 2 else 0.0
        top3_l = top_candidates[2]['ltp'] if len(top_candidates) > 2 else 0.0
        top3_v = top_candidates[2]['vwap'] if len(top_candidates) > 2 else 0.0

        held1_s = active_positions[0]['symbol'] if len(active_positions) > 0 else ''
        held1_e = active_positions[0]['entry_price'] if len(active_positions) > 0 else 0.0
        held1_c = active_positions[0].get('current', held1_e) if len(active_positions) > 0 else 0.0
        held1_p = (held1_c - held1_e) * Config.LOT_SIZE if held1_e and held1_c else 0.0

        held2_s = active_positions[1]['symbol'] if len(active_positions) > 1 else ''
        held2_e = active_positions[1]['entry_price'] if len(active_positions) > 1 else 0.0
        held2_c = active_positions[1].get('current', held2_e) if len(active_positions) > 1 else 0.0
        held2_p = (held2_c - held2_e) * Config.LOT_SIZE if held2_e and held2_c else 0.0

        held3_s = active_positions[2]['symbol'] if len(active_positions) > 2 else ''
        held3_e = active_positions[2]['entry_price'] if len(active_positions) > 2 else 0.0
        held3_c = active_positions[2].get('current', held3_e) if len(active_positions) > 2 else 0.0
        held3_p = (held3_c - held3_e) * Config.LOT_SIZE if held3_e and held3_c else 0.0

        with open(self.filename, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                str(timestamp), round(underlying_ltp, 2), atm_strike, expiry_date,
                top1_s, round(top1_sc, 4), round(top1_l, 2), round(top1_v, 2),
                top2_s, round(top2_sc, 4), round(top2_l, 2), round(top2_v, 2),
                top3_s, round(top3_sc, 4), round(top3_l, 2), round(top3_v, 2),
                held1_s, round(held1_e, 2), round(held1_c, 2), round(held1_p, 2),
                held2_s, round(held2_e, 2), round(held2_c, 2), round(held2_p, 2),
                held3_s, round(held3_e, 2), round(held3_c, 2), round(held3_p, 2),
                round(total_pnl, 2), round(vix, 2), daily_entries, warmup_remaining
            ])

# ============================================================
# SESSION STATE
# ============================================================
class SessionState:
    def __init__(self):
        self.lock = threading.RLock()
        self.option_chain_api_count = 0
        self.api_window_start = now_ist()
        self.cid = ""
        self.token = ""
        self.daily_entries = 0
        self.position_state = "FLAT"
        self.eod_square_off_triggered = False

        # Warmup timer
        self.warmup_start_time = None

        self.symbol_histories = {}
        self.live_ltp = {}
        self.live_vwap = {}
        self.live_volume = {}

        self.option_chain = []
        self.fut_price = None
        self.expiry_date = None
        self.atm_strike = None
        self.option_symbols = []

        self.active_positions = []        # list of dicts with 'symbol', 'entry_price', 'current'
        self.india_vix = 15.0
        self.paper_realized_pnl = 0.0

        self.last_top_candidates = []
        self.last_all_evaluations = []    # NEW: detailed breakdown per strike
        self.last_metrics = {}

        self.running = False
        self._order_lock = False

    def start_warmup(self):
        with self.lock:
            if self.warmup_start_time is None:
                self.warmup_start_time = time.time()
                log_console(f"⏳ Warmup started. No trading for {Config.WARMUP_DURATION} seconds.")

    def is_warming_up(self):
        if self.warmup_start_time is None:
            return True
        elapsed = time.time() - self.warmup_start_time
        return elapsed < Config.WARMUP_DURATION

    def warmup_remaining(self):
        if self.warmup_start_time is None:
            return Config.WARMUP_DURATION
        remaining = Config.WARMUP_DURATION - (time.time() - self.warmup_start_time)
        return max(0, int(remaining))

    def update_ws(self, symbol, ltp, vwap, volume):
        with self.lock:
            if symbol == "NSE:INDIAVIX-INDEX":
                if ltp is not None:
                    self.india_vix = float(ltp)
                    log_debug(f"India VIX updated: {self.india_vix:.2f}")
                return

            if ltp is not None:
                self.live_ltp[symbol] = float(ltp)
            if vwap is not None:
                self.live_vwap[symbol] = float(vwap)
            if volume is not None:
                self.live_volume[symbol] = int(volume)

            if symbol.endswith(('CE','PE')):
                if symbol not in self.symbol_histories:
                    self.symbol_histories[symbol] = deque(maxlen=3000)
                if ltp is not None and vwap is not None:
                    self.symbol_histories[symbol].append((time.time(), float(ltp), float(vwap)))
                elif ltp is not None:
                    self.symbol_histories[symbol].append((time.time(), float(ltp), 0.0))

            log_debug(f"Updated {symbol}: LTP={ltp}, VWAP={vwap}")

    def get_ltp(self, symbol):
        with self.lock:
            return self.live_ltp.get(symbol)

    def get_vwap(self, symbol):
        with self.lock:
            return self.live_vwap.get(symbol)

    def update_chain(self, chain, fut_price, expiry_date, atm_strike, option_symbols):
        with self.lock:
            self.option_chain = chain
            self.fut_price = float(fut_price) if fut_price else 0.0
            self.expiry_date = expiry_date
            self.atm_strike = int(atm_strike) if atm_strike else None
            self.option_symbols = option_symbols
            log_debug(f"Chain updated: ATM={self.atm_strike}, {len(option_symbols)} symbols")

    def can_place_order(self):
        return self.daily_entries < Config.MAX_DAILY_ENTRIES and not self.eod_square_off_triggered

    def reset_for_new_day(self):
        with self.lock:
            if self.active_positions:
                log_console(f"⚠️ {len(self.active_positions)} position(s) still tracked, not resetting.")
                return
            self.daily_entries = 0
            self.eod_square_off_triggered = False
            self.position_state = "FLAT"
            self.paper_realized_pnl = 0.0
            self.warmup_start_time = None

# ============================================================
# WEBSOCKET MANAGER (unchanged)
# ============================================================
class MarketWSManager:
    def __init__(self, session_state, access_token):
        self.session = session_state
        self.access_token = access_token
        self.ws = None
        self.subscribed = set()
        self.running = False

    def on_message(self, message):
        symbol = message.get("symbol")
        if symbol:
            ltp = message.get("ltp")
            vwap = message.get("avg_trade_price")
            volume = message.get("vol_traded_today")
            self.session.update_ws(symbol, ltp, vwap, volume)

    def on_error(self, msg):
        log_console(f"WS error: {msg}")

    def on_close(self, msg):
        log_console(f"WS closed: {msg}")
        self.running = False

    def on_open(self):
        log_console("WebSocket connected")
        if self.subscribed:
            log_debug(f"Subscribing to {len(self.subscribed)} symbols")
            self.ws.subscribe(list(self.subscribed), "SymbolUpdate")
        self.ws.keep_running()

    def start(self):
        if self.running:
            return
        self.running = True
        self.ws = data_ws.FyersDataSocket(
            access_token=self.access_token,
            log_path="",
            litemode=False,
            write_to_file=False,
            reconnect=True,
            on_connect=self.on_open,
            on_close=self.on_close,
            on_error=self.on_error,
            on_message=self.on_message
        )
        self.ws.connect()
        log_debug("WebSocket started")

    def subscribe(self, symbols):
        new_symbols = set(symbols) - self.subscribed
        if new_symbols:
            log_debug(f"Subscribing to new symbols: {new_symbols}")
            if self.ws:
                self.ws.subscribe(list(new_symbols), "SymbolUpdate")
            self.subscribed.update(new_symbols)

    def stop(self):
        self.running = False
        if self.ws:
            self.ws.close_connection()

# ============================================================
# REST API (unchanged)
# ============================================================
def enforce_rate_limit(session):
    now = now_ist()
    window = (now - session.api_window_start).total_seconds()
    if window > Config.API_WINDOW:
        session.api_window_start = now
        session.option_chain_api_count = 0
    elif session.option_chain_api_count >= Config.API_RATE_LIMIT:
        wait = Config.API_WINDOW - window
        if wait > 0:
            time.sleep(wait)
        session.api_window_start = now
        session.option_chain_api_count = 0

@handle_errors
def fetch_option_chain(session, index_symbol):
    log_debug("Enter fetch_option_chain")
    enforce_rate_limit(session)
    session.option_chain_api_count += 1
    fy = fyersModel.FyersModel(client_id=session.cid, token=session.token, is_async=False, log_path="")
    meta = fy.optionchain(data={"symbol": index_symbol, "timestamp": ""})
    if meta.get("code") != 200:
        log_debug(f"Meta chain failed: {meta}")
        return None, None, None, None, []

    fut_price = None
    for item in meta["data"]["optionsChain"]:
        if item.get("option_type") == "":
            fut_price = item.get("fp")
            break
    if fut_price is None:
        fut_price = meta["data"].get("fp", 0.0)

    exp_list = sorted([(e["date"], e["expiry"]) for e in meta["data"]["expiryData"]],
                      key=lambda x: datetime.strptime(x[0], "%d-%m-%Y"))
    today = now_ist().date()
    idx = 0
    for i, (d_str, _) in enumerate(exp_list):
        if datetime.strptime(d_str, "%d-%m-%Y").date() >= today:
            idx = i
            break
    curr_date, expiry_ts = exp_list[idx]

    payload = {"symbol": index_symbol, "strikecount": Config.ATM_RANGE, "timestamp": expiry_ts, "greeks": "1"}
    session.option_chain_api_count += 1
    resp = fy.optionchain(data=payload)
    if resp.get("code") != 200:
        log_debug(f"Detailed chain failed: {resp}")
        return None, None, None, None, []

    chain = resp["data"]["optionsChain"]
    for opt in chain:
        greeks = opt.get("greeks", {})
        opt["delta"] = greeks.get("delta", 0.0) if greeks else 0.0

    option_symbols = [opt["symbol"] for opt in chain if opt.get("option_type") in ("CE","PE")]
    log_debug(f"Got {len(chain)} options, {len(option_symbols)} symbols")
    return chain, fut_price, curr_date, expiry_ts, option_symbols

# ============================================================
# CHAIN POLLER (unchanged)
# ============================================================
def chain_poller(session, ws_manager, index_symbol):
    log_debug("Chain poller thread started")
    while session.running:
        try:
            log_debug("Polling option chain...")
            chain, fut_price, expiry_date, _, opt_symbols = fetch_option_chain(session, index_symbol)
            if chain is None:
                log_debug("Chain fetch returned None")
            else:
                underlying_ltp = session.get_ltp(index_symbol)
                if underlying_ltp is None:
                    underlying_ltp = fut_price

                strikes = sorted(set(opt["strike_price"] for opt in chain if opt.get("option_type") in ("CE","PE")))
                if strikes and underlying_ltp:
                    atm = min(strikes, key=lambda x: abs(x - underlying_ltp))
                else:
                    atm = None

                session.update_chain(chain, fut_price, expiry_date, atm, opt_symbols)
                all_syms = [index_symbol, "NSE:INDIAVIX-INDEX"] + opt_symbols
                ws_manager.subscribe(all_syms)

            time.sleep(Config.OPTION_CHAIN_INTERVAL)
        except Exception as e:
            log_debug(f"Chain poller error: {e}\n{traceback.format_exc()}")
            time.sleep(Config.OPTION_CHAIN_INTERVAL)

# ============================================================
# HELPERS (unchanged)
# ============================================================
def get_symbols_in_range(session, atm_strike, range_strikes=5):
    result = []
    with session.lock:
        if not session.option_chain or atm_strike is None:
            return result
        for opt in session.option_chain:
            strike = opt.get("strike_price")
            otype = opt.get("option_type")
            if otype not in ("CE", "PE"):
                continue
            if abs(strike - atm_strike) <= range_strikes * 50:
                result.append({
                    "symbol": opt["symbol"],
                    "strike": strike,
                    "option_type": otype,
                })
    return result

def compute_return_vol(session, symbol, window_sec):
    hist = session.symbol_histories.get(symbol)
    if not hist or len(hist) < 3:
        return None, None

    now = time.time()
    cutoff = now - window_sec
    relevant = []
    for ts, ltp, vwap in hist:
        if ts >= cutoff:
            relevant.append((ts, ltp))
    if len(relevant) < 2:
        return None, None

    first_ltp = relevant[0][1]
    last_ltp = relevant[-1][1]
    if first_ltp <= 0 or last_ltp <= 0:
        return None, None

    ret = (last_ltp / first_ltp) - 1.0
    log_returns = []
    for i in range(1, len(relevant)):
        prev = relevant[i-1][1]
        curr = relevant[i][1]
        if prev > 0 and curr > 0:
            log_returns.append(np.log(curr / prev))
    if len(log_returns) < 2:
        return ret, 0.0
    vol = np.std(log_returns)
    return ret, vol

# ============================================================
# GET TOP CANDIDATES – with detailed evaluations
# ============================================================
def get_top_candidates(session):
    """
    Returns: (top_candidates, all_evaluations, metrics)
    - top_candidates: list of up to 3 dicts (only if warmup complete)
    - all_evaluations: detailed breakdown for every strike in range
    """
    log_debug(">>> get_top_candidates called")
    try:
        with session.lock:
            all_evaluations = []
            warming_up = session.is_warming_up()

            spot = session.get_ltp("NSE:NIFTY50-INDEX")
            if spot is None:
                session.last_metrics = {}
                return [], [], {"spot": 0}

            atm_strike = session.atm_strike
            if atm_strike is None:
                return [], [], {"spot": spot}

            # EOD check
            now = now_ist()
            eod_square_off = (now.hour > 15) or (now.hour == 15 and now.minute >= 15)
            if eod_square_off:
                session.eod_square_off_triggered = True

            symbols_in_range = get_symbols_in_range(session, atm_strike, Config.ATM_RANGE)
            if not symbols_in_range:
                return [], [], {"spot": spot, "atm": atm_strike}

            candidates = []

            for entry in symbols_in_range:
                symbol = entry["symbol"]
                current_ltp = session.get_ltp(symbol)
                current_vwap = session.get_vwap(symbol)

                # Build evaluation entry
                eval_entry = {
                    "symbol": symbol,
                    "strike": entry["strike"],
                    "otype": entry["option_type"],
                    "ltp": current_ltp,
                    "vwap": current_vwap,
                    "pass_vwap": False,
                    "ret5": None,
                    "vol5": None,
                    "ret15": None,
                    "vol15": None,
                    "score": None,
                    "status": "PENDING",
                    "reason": ""
                }

                # Filter 1: LTP / VWAP availability
                if current_ltp is None or current_vwap is None:
                    eval_entry["status"] = "REJECTED"
                    eval_entry["reason"] = "No LTP/VWAP"
                    all_evaluations.append(eval_entry)
                    continue

                # Filter 2: VWAP (LTP > VWAP)
                if current_ltp <= current_vwap:
                    eval_entry["status"] = "REJECTED"
                    eval_entry["reason"] = f"LTP {current_ltp:.2f} ≤ VWAP {current_vwap:.2f}"
                    all_evaluations.append(eval_entry)
                    continue

                eval_entry["pass_vwap"] = True

                # If warming up, we don't compute scores yet
                if warming_up:
                    eval_entry["status"] = "WARMING UP"
                    eval_entry["reason"] = f"Need {Config.SCORE_WIN_15}s of data"
                    all_evaluations.append(eval_entry)
                    continue

                # Filter 3 & 4: Historical data for 5m and 15m
                ret5, vol5 = compute_return_vol(session, symbol, Config.SCORE_WIN_5)
                ret15, vol15 = compute_return_vol(session, symbol, Config.SCORE_WIN_15)

                eval_entry["ret5"] = ret5
                eval_entry["vol5"] = vol5
                eval_entry["ret15"] = ret15
                eval_entry["vol15"] = vol15

                if ret5 is None or ret15 is None:
                    eval_entry["status"] = "REJECTED"
                    eval_entry["reason"] = "Insufficient tick data"
                    all_evaluations.append(eval_entry)
                    continue

                if vol5 == 0.0 or vol15 == 0.0:
                    eval_entry["status"] = "REJECTED"
                    eval_entry["reason"] = "Volatility = 0"
                    all_evaluations.append(eval_entry)
                    continue

                # All filters passed: compute score
                score5 = ret5 / vol5
                score15 = ret15 / vol15
                score = (1.0/3.0) * score5 + (2.0/3.0) * score15

                eval_entry["score"] = score
                eval_entry["status"] = "CANDIDATE"
                eval_entry["reason"] = ""

                candidates.append({
                    "symbol": symbol,
                    "strike": entry["strike"],
                    "option_type": entry["option_type"],
                    "ltp": current_ltp,
                    "vwap": current_vwap,
                    "score": score,
                    "ret5": ret5,
                    "vol5": vol5,
                    "ret15": ret15,
                    "vol15": vol15
                })

                all_evaluations.append(eval_entry)

            candidates.sort(key=lambda x: x["score"], reverse=True)
            top_candidates = candidates[:Config.MAX_POSITIONS]

            session.last_top_candidates = top_candidates
            session.last_all_evaluations = all_evaluations
            session.last_metrics = {"spot": spot, "atm": atm_strike}

            log_debug(f">>> Top candidates: {[c['symbol'] for c in top_candidates]}")
            return top_candidates, all_evaluations, {"spot": spot, "atm": atm_strike}

    except Exception as e:
        log_debug(f"CRASH in get_top_candidates: {e}\n{traceback.format_exc()}")
        return [], [], {}

# ============================================================
# SYNC POSITIONS (unchanged logic)
# ============================================================
def sync_positions(session, top_candidates, fyers):
    if getattr(session, '_order_lock', False):
        return
    session._order_lock = True
    try:
        with session.lock:
            if session.is_warming_up():
                return

            held_symbols = [p["symbol"] for p in session.active_positions]
            top_symbols = [c["symbol"] for c in top_candidates]
            cand_by_symbol = {c["symbol"]: c for c in top_candidates}

            # SELL dropped
            to_sell = [s for s in held_symbols if s not in top_symbols]
            for sym in to_sell:
                pos = next((p for p in session.active_positions if p["symbol"] == sym), None)
                if not pos:
                    continue

                if PAPER_MODE:
                    current = session.get_ltp(sym)
                    if current is None:
                        for opt in session.option_chain:
                            if opt["symbol"] == sym:
                                current = opt.get("ltp", 0)
                                break
                    if current is None or current == 0:
                        current = pos["entry_price"]
                    pnl = (current - pos["entry_price"]) * Config.LOT_SIZE
                    session.paper_realized_pnl += pnl
                    log_console(f"📊 SOLD (dropped): {sym} at {current:.2f}, P&L={pnl:+.2f}")
                    session.active_positions.remove(pos)
                else:
                    order = {
                        "symbol": sym,
                        "qty": Config.LOT_SIZE,
                        "type": 2,
                        "side": -1,
                        "productType": "MARGIN",
                        "validity": "DAY",
                    }
                    resp = fyers.place_order(data=order)
                    if resp.get("s") == "ok":
                        log_console(f"📊 SOLD (dropped): {sym} (Order ID: {resp.get('id')})")
                        session.active_positions.remove(pos)
                    else:
                        log_console(f"❌ FAILED to sell {sym}: {resp}")

            # BUY new
            held_symbols = [p["symbol"] for p in session.active_positions]
            to_buy = [s for s in top_symbols if s not in held_symbols]

            if session.eod_square_off_triggered:
                return
            if session.daily_entries >= Config.MAX_DAILY_ENTRIES:
                log_console("⛔ Daily entry limit reached. Skipping new buys.")
                return

            available_slots = Config.MAX_POSITIONS - len(session.active_positions)
            to_buy = to_buy[:available_slots]

            for sym in to_buy:
                cand = cand_by_symbol.get(sym)
                if not cand:
                    continue

                if PAPER_MODE:
                    entry_price = cand["ltp"]
                    if entry_price <= 0:
                        continue
                    session.active_positions.append({
                        "symbol": sym,
                        "entry_price": entry_price,
                    })
                    log_console(f"🟢 BOUGHT (new): {sym} at {entry_price:.2f}")
                    session.daily_entries += 1
                else:
                    order = {
                        "symbol": sym,
                        "qty": Config.LOT_SIZE,
                        "type": 2,
                        "side": 1,
                        "productType": "MARGIN",
                        "validity": "DAY",
                    }
                    resp = fyers.place_order(data=order)
                    if resp.get("s") == "ok":
                        session.active_positions.append({
                            "symbol": sym,
                            "entry_price": cand["ltp"],
                        })
                        log_console(f"🟢 BOUGHT (new): {sym} at {cand['ltp']:.2f} (Order ID: {resp.get('id')})")
                        session.daily_entries += 1
                    else:
                        log_console(f"❌ FAILED to buy {sym}: {resp}")

            session.position_state = "ACTIVE" if session.active_positions else "FLAT"

    except Exception as e:
        log_console(f"sync_positions error: {e}")
    finally:
        session._order_lock = False

# ============================================================
# SAMPLER THREAD
# ============================================================
def sampler(session, data_logger, auto_trade, fyers):
    log_debug("Sampler thread started")
    first_run = True
    while session.running:
        start = now_ist()
        try:
            if first_run:
                session.start_warmup()
                first_run = False

            top_candidates, all_evaluations, metrics = get_top_candidates(session)

            with session.lock:
                for pos in session.active_positions:
                    pos["current"] = session.get_ltp(pos["symbol"]) or pos["entry_price"]

            total_pnl = session.paper_realized_pnl
            for pos in session.active_positions:
                current = pos.get("current", pos["entry_price"])
                total_pnl += (current - pos["entry_price"]) * Config.LOT_SIZE

            warmup_remaining = session.warmup_remaining() if session.is_warming_up() else 0

            data_logger.log_data(
                timestamp=timestamp_ist(),
                underlying_ltp=metrics.get("spot", 0),
                atm_strike=metrics.get("atm", 0),
                expiry_date=session.expiry_date or "",
                top_candidates=top_candidates,
                active_positions=session.active_positions,
                total_pnl=total_pnl,
                vix=session.india_vix,
                daily_entries=session.daily_entries,
                warmup_remaining=warmup_remaining
            )

            if auto_trade:
                sync_positions(session, top_candidates, fyers)

            elapsed = (now_ist() - start).total_seconds()
            if elapsed < Config.SAMPLE_INTERVAL:
                time.sleep(Config.SAMPLE_INTERVAL - elapsed)

        except Exception as e:
            log_debug(f"Sampler error: {e}\n{traceback.format_exc()}")
            time.sleep(1)

# ============================================================
# DASHBOARD – Now includes strike filter breakdown
# ============================================================
class TerminalDashboard:
    def __init__(self, data_logger, session_state):
        self.data_logger = data_logger
        self.session_state = session_state

    def display(self):
        try:
            os.system('cls' if os.name == 'nt' else 'clear')
            mode = "PAPER" if PAPER_MODE else "LIVE"
            print("\n" + "="*120)
            print(f"📊 {mode} TRADING DASHBOARD – Momentum Strategy (Per‑Symbol Sync)")
            print("="*120)

            with self.session_state.lock:
                daily_entries = self.session_state.daily_entries
                vix = self.session_state.india_vix
                realized = self.session_state.paper_realized_pnl
                position_state = self.session_state.position_state
                top_candidates = self.session_state.last_top_candidates[:]
                active_positions = self.session_state.active_positions[:]
                eod_triggered = self.session_state.eod_square_off_triggered
                warming_up = self.session_state.is_warming_up()
                warmup_rem = self.session_state.warmup_remaining()
                all_evals = self.session_state.last_all_evaluations[:]  # NEW

            print(f"Last Update: {timestamp_ist()}")
            print(f"📈 Daily Entries (Buys): {daily_entries}/{Config.MAX_DAILY_ENTRIES}")
            print(f"📊 India VIX: {vix:.2f}")
            print(f"💰 Realized P&L: {realized:+.2f}")

            # Warmup Status
            if warming_up:
                print("\n" + "🔴"*20)
                print(f"⏳ WARMING UP... {warmup_rem} SECONDS REMAINING")
                print("   (No trading will occur until data buffer is filled)")
                print("🔴"*20 + "\n")
            else:
                print("\n✅ WARMUP COMPLETE – Trading active\n")

            if position_state == "ACTIVE":
                total_unrealized = 0
                for pos in active_positions:
                    current = pos.get("current", pos["entry_price"])
                    pnl = (current - pos["entry_price"]) * Config.LOT_SIZE
                    total_unrealized += pnl
                print(f"💰 Unrealized P&L: {total_unrealized:+.2f}")
                print(f"💰 Total P&L: {realized + total_unrealized:+.2f}")

            if eod_triggered:
                print("⛔ EOD square‑off triggered – no new buys allowed")

            # ---- TOP 3 CANDIDATES ----
            print("\n" + "-"*80)
            print("🏆 TOP 3 CANDIDATES (LTP > VWAP Filter Applied)")
            print("-"*80)
            if warming_up:
                print("   ⏳ Candidates will appear here after warmup")
            elif top_candidates:
                print(f"{'Rank':<4} | {'Symbol':<25} | {'Strike':<8} | {'Type':<4} | {'Score':<10} | {'LTP':<8} | {'VWAP':<8}")
                print("-"*80)
                for i, c in enumerate(top_candidates[:3], 1):
                    print(f"{i:<4} | {c['symbol']:<25} | {c['strike']:<8} | {c['option_type']:<4} | {c['score']:<10.4f} | {c['ltp']:<8.2f} | {c['vwap']:<8.2f}")
            else:
                print("   No candidates passing VWAP filter (or insufficient data)")

            # ---- NEW: STRIKE FILTER BREAKDOWN ----
            print("\n" + "-"*80)
            print("🔍 STRIKE FILTER BREAKDOWN (ATM +/- 5) – Status per strike")
            print("-"*80)
            if all_evals:
                # Print header
                print(f"{'Symbol':<25} | {'Strike':<8} | {'Type':<4} | {'LTP':<8} | {'VWAP':<8} | {'Pass VWAP':<9} | {'Score':<10} | {'Status/Reason'}")
                print("-"*80)
                for e in all_evals:
                    # Truncate long reasons
                    reason = e["reason"]
                    if len(reason) > 25:
                        reason = reason[:22] + "..."
                    # Color code status visually using symbols
                    if e["status"] == "CANDIDATE":
                        status_display = f"✅ {e['status']}"
                    elif e["status"] == "REJECTED":
                        status_display = f"❌ {e['status']}"
                    elif e["status"] == "WARMING UP":
                        status_display = f"⏳ {e['status']}"
                    else:
                        status_display = f"⬜ {e['status']}"

                    # If rejected, show reason; if candidate, show score
                    if e["status"] == "CANDIDATE":
                        score_display = f"{e['score']:.4f}"
                    else:
                        score_display = ""

                    pass_vwap_display = "✅" if e["pass_vwap"] else "❌"
                    ltp_display = f"{e['ltp']:.2f}" if e["ltp"] else "N/A"
                    vwap_display = f"{e['vwap']:.2f}" if e["vwap"] else "N/A"

                    print(f"{e['symbol']:<25} | {e['strike']:<8} | {e['otype']:<4} | {ltp_display:<8} | {vwap_display:<8} | {pass_vwap_display:<9} | {score_display:<10} | {status_display} ({reason})")
            else:
                print("   No strike data available (waiting for option chain)")

            # ---- ACTIVE POSITIONS ----
            print("\n" + "-"*80)
            print("📌 ACTIVE POSITIONS")
            print("-"*80)
            if active_positions:
                print(f"{'#':<3} | {'Symbol':<25} | {'Entry':<8} | {'Current':<8} | {'P&L':<10}")
                print("-"*80)
                total_pnl = 0
                for i, pos in enumerate(active_positions, 1):
                    current = pos.get("current", pos["entry_price"])
                    pnl = (current - pos["entry_price"]) * Config.LOT_SIZE
                    total_pnl += pnl
                    print(f"{i:<3} | {pos['symbol']:<25} | {pos['entry_price']:<8.2f} | {current:<8.2f} | {pnl:<+10.2f}")
                print("-"*80)
                print(f"Total Unrealized P&L: {total_pnl:+.2f}")
            else:
                print("   No active positions (FLAT)")

            print("\n" + "="*120)
        except Exception as e:
            log_debug(f"Dashboard error: {e}")

# ============================================================
# CREDENTIALS & MAIN (unchanged)
# ============================================================
def load_credentials(session):
    try:
        with open('fyers_credentials.json', 'r') as f:
            creds = json.load(f)
            session.cid = creds.get('client_id', '')
            session.token = creds.get('access_token', '')
        log_console(f"Loaded credentials: {session.cid}")
    except Exception as e:
        session.cid = os.getenv("FYERS_CID", "")
        session.token = os.getenv("FYERS_TOKEN", "")
        log_console(f"Using env vars: {session.cid}")

def main():
    log_console("Starting Momentum Ranking Algo Trading System...")
    session = SessionState()
    load_credentials(session)
    data_logger = DataLogger()
    dashboard = TerminalDashboard(data_logger, session)
    index_symbol = "NSE:NIFTY50-INDEX"
    vix_symbol = "NSE:INDIAVIX-INDEX"

    poller_thread = None
    sampler_thread = None
    ws_manager = None
    fyers = None

    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        print("="*50)
        mode = "PAPER" if PAPER_MODE else "LIVE"
        print(f"📈 FYERS ALGO TRADING ({mode} MODE) – Momentum Strategy (Per‑Symbol Sync)")
        print("1. Start Trading")
        print("2. Settings")
        print("3. Exit")
        choice = input("Select option: ").strip()
        if choice == "1":
            if not (session.cid and session.token):
                print("❌ Set credentials first")
                input("Press Enter...")
                continue

            session.reset_for_new_day()

            auto_trade = input("Enable Auto Trade? (y/n): ").lower() == 'y'
            log_console(f"Auto trade: {'ON' if auto_trade else 'OFF'}")

            ws_manager = MarketWSManager(session, session.token)
            ws_manager.start()
            ws_manager.subscribe([index_symbol, vix_symbol])
            session.running = True

            fyers = fyersModel.FyersModel(client_id=session.cid, token=session.token, is_async=False, log_path="")
            poller_thread = threading.Thread(target=chain_poller, args=(session, ws_manager, index_symbol), daemon=True)
            sampler_thread = threading.Thread(target=sampler, args=(session, data_logger, auto_trade, fyers), daemon=True)
            poller_thread.start()
            sampler_thread.start()

            print("\n✅ Trading started. Press Ctrl+C to stop.\n")
            try:
                while True:
                    dashboard.display()
                    time.sleep(2)
            except KeyboardInterrupt:
                log_console("\n🛑 Stopping trading...")
                session.running = False
                ws_manager.stop()

                if sampler_thread is not None:
                    sampler_thread.join(timeout=5)
                if poller_thread is not None:
                    poller_thread.join(timeout=Config.OPTION_CHAIN_INTERVAL + 5)

                if session.active_positions:
                    log_console(f"Attempting to close {len(session.active_positions)} open position(s)...")
                    sync_positions(session, [], fyers)

                with session.lock:
                    if session.active_positions:
                        log_console(f"⚠️ {len(session.active_positions)} position(s) could not be closed. Check broker manually.")
                    else:
                        session.eod_square_off_triggered = False
                        session.daily_entries = 0
                        session.paper_realized_pnl = 0.0
                        session.warmup_start_time = None
                        log_console("✅ Trading stopped and state reset. You can start again.")
        elif choice == "2":
            print("\n⚙️ SETTINGS")
            new_cid = input(f"Client ID [{session.cid}]: ").strip()
            if new_cid:
                session.cid = new_cid
            new_token = input("Access token: ").strip()
            if new_token:
                session.token = new_token
            with open('fyers_credentials.json', 'w') as f:
                json.dump({"client_id": session.cid, "access_token": session.token}, f)
            print("✅ Saved")
            input("Press Enter...")
        elif choice == "3":
            if session.running:
                session.running = False
                if ws_manager:
                    ws_manager.stop()
            if session.active_positions:
                log_console(f"⚠️ Exiting with {len(session.active_positions)} position(s) still tracked.")
            break

if __name__ == "__main__":
    main()