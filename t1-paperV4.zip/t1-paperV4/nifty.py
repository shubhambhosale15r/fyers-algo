# ============================================================
# nifty.py – Momentum Strategy (Hold Top 1 by Type)
# Exit only when Top 1 type changes (CE ↔ PE)
# with persistence filter (entry & exit) and underlying filter
# ============================================================

import time
import numpy as np
from datetime import datetime
import pytz
from fyers_apiv3 import fyersModel
from fyers_apiv3.FyersWebsocket import data_ws
import logging
import os
import json
from collections import deque
import csv
import threading
import traceback

# ============================================================
# PAPER TRADE FLAG
# ============================================================
PAPER_MODE = True   # Change to False for live trading

# ============================================================
# CONFIGURATION
# ============================================================
class Config:
    SAMPLE_INTERVAL = 1
    OPTION_CHAIN_INTERVAL = 30
    SCORE_WIN_SHORT =  300      
    SCORE_WIN_LONG = 900     # 15 minutes (short window)
    WARMUP_DURATION = SCORE_WIN_LONG
    ATM_RANGE = 5
    MAX_POSITIONS = 1
    LOT_SIZE = 65
    MAX_DAILY_ENTRIES = 100
    API_RATE_LIMIT = 200
    API_WINDOW = 60
    MAX_RETRIES = 3
    RETRY_DELAY = 2
    FNO_SEGMENT = 14

    # Churn Prevention (No stability timer)
    REBALANCE_THRESHOLD = 0.5        # Minimum score gap to replace Top 1
    SYMBOL_COOLDOWN = 1             # Seconds before re-buying a sold symbol

    # VWAP Filter Toggle
    ENABLE_VWAP_FILTER = False        # Set to True to enable LTP > VWAP

    # Persistence filter
    CONFIRMATION_SECONDS = 30         # Seconds Top 1 type must remain #1 before entry/exit

# ============================================================
# LOGGING
# ============================================================
logging.basicConfig(
    filename="trading_app.log",
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)

def log_debug(msg):
    logging.debug(msg)

def log_console(msg):
    print(msg, flush=True)
    logging.info(msg)

IST = pytz.timezone("Asia/Kolkata")

def now_ist():
    return datetime.now(IST)

def timestamp_ist():
    return now_ist().strftime("%Y-%m-%d %H:%M:%S")

# ============================================================
# ERROR HANDLER
# ============================================================
def handle_errors(func):
    def wrapper(*args, **kwargs):
        for retry in range(Config.MAX_RETRIES):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                log_debug(f"{func.__name__} attempt {retry+1} failed: {e}\n{traceback.format_exc()}")
                if retry < Config.MAX_RETRIES-1:
                    time.sleep(Config.RETRY_DELAY)
                else:
                    log_debug(f"{func.__name__} permanently failed")
                    return None, None, None, None, []
    return wrapper

# ============================================================
# DATA LOGGER
# ============================================================
class DataLogger:
    def __init__(self, filename="trading_data.csv"):
        self.filename = filename
        self._ensure_header()

    def _ensure_header(self):
        if not os.path.exists(self.filename):
            with open(self.filename, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'timestamp', 'underlying_ltp', 'atm_strike', 'expiry_date',
                    'top1_symbol', 'top1_score', 'top1_ltp', 'top1_vwap',
                    'top2_symbol', 'top2_score', 'top2_ltp', 'top2_vwap',
                    'top3_symbol', 'top3_score', 'top3_ltp', 'top3_vwap',
                    'held_symbol', 'held_entry', 'held_current', 'held_pnl',
                    'total_paper_pnl', 'vix', 'daily_entries', 'warmup_remaining',
                    'decision_reason',
                    'underlying_score'
                ])

    def log_data(self, timestamp, underlying_ltp, atm_strike, expiry_date,
                 top_candidates, active_positions, total_pnl, vix, daily_entries,
                 warmup_remaining, decision_reason, underlying_score):
        # Unpack top 3
        top1_s = top_candidates[0]['symbol'] if len(top_candidates) > 0 else ''
        top1_sc = top_candidates[0]['score'] if len(top_candidates) > 0 else 0.0
        top1_l = top_candidates[0]['ltp'] if len(top_candidates) > 0 else 0.0
        top1_v = top_candidates[0]['vwap'] if len(top_candidates) > 0 else 0.0

        top2_s = top_candidates[1]['symbol'] if len(top_candidates) > 1 else ''
        top2_sc = top_candidates[1]['score'] if len(top_candidates) > 1 else 0.0
        top2_l = top_candidates[1]['ltp'] if len(top_candidates) > 1 else 0.0
        top2_v = top_candidates[1]['vwap'] if len(top_candidates) > 1 else 0.0

        top3_s = top_candidates[2]['symbol'] if len(top_candidates) > 2 else ''
        top3_sc = top_candidates[2]['score'] if len(top_candidates) > 2 else 0.0
        top3_l = top_candidates[2]['ltp'] if len(top_candidates) > 2 else 0.0
        top3_v = top_candidates[2]['vwap'] if len(top_candidates) > 2 else 0.0

        held_s = active_positions[0]['symbol'] if len(active_positions) > 0 else ''
        held_e = active_positions[0]['entry_price'] if len(active_positions) > 0 else 0.0
        held_c = active_positions[0].get('current', held_e) if len(active_positions) > 0 else 0.0
        held_p = (held_c - held_e) * Config.LOT_SIZE if held_e and held_c else 0.0

        with open(self.filename, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                str(timestamp), round(underlying_ltp, 2), atm_strike, expiry_date,
                top1_s, round(top1_sc, 4), round(top1_l, 2), round(top1_v, 2),
                top2_s, round(top2_sc, 4), round(top2_l, 2), round(top2_v, 2),
                top3_s, round(top3_sc, 4), round(top3_l, 2), round(top3_v, 2),
                held_s, round(held_e, 2), round(held_c, 2), round(held_p, 2),
                round(total_pnl, 2), round(vix, 2), daily_entries, warmup_remaining,
                decision_reason,
                round(underlying_score, 4) if underlying_score is not None else ''
            ])

# ============================================================
# SESSION STATE
# ============================================================
class SessionState:
    def __init__(self):
        self.lock = threading.RLock()
        self.option_chain_api_count = 0
        self.api_window_start = now_ist()
        self.cid = ""
        self.token = ""
        self.daily_entries = 0
        self.position_state = "FLAT"
        self.eod_square_off_triggered = False

        self.warmup_start_time = None

        self.sold_time = {}          # symbol -> timestamp of last sell

        self.symbol_histories = {}   # includes index and option symbols
        self.live_ltp = {}
        self.live_vwap = {}
        self.live_volume = {}

        self.option_chain = []
        self.fut_price = None
        self.expiry_date = None
        self.atm_strike = None
        self.option_symbols = []

        self.active_positions = []
        self.india_vix = 15.0
        self.paper_realized_pnl = 0.0

        self.last_top_candidates = []
        self.last_candidates = []            # full sorted candidate list
        self.last_all_evaluations = []
        self.last_metrics = {}
        self.decision_reason = ""

        self.running = False
        self._order_lock = False

        # Persistence tracking
        self.current_leader_type = None   # 'CE' or 'PE' or None
        self.leader_since = 0.0           # timestamp when this leader type became #1

    def start_warmup(self):
        with self.lock:
            if self.warmup_start_time is None:
                self.warmup_start_time = time.time()
                log_console(f"⏳ Warmup started. No trading for {Config.WARMUP_DURATION} seconds.")

    def is_warming_up(self):
        if self.warmup_start_time is None:
            return True
        elapsed = time.time() - self.warmup_start_time
        return elapsed < Config.WARMUP_DURATION

    def warmup_remaining(self):
        if self.warmup_start_time is None:
            return Config.WARMUP_DURATION
        remaining = Config.WARMUP_DURATION - (time.time() - self.warmup_start_time)
        return max(0, int(remaining))

    def update_ws(self, symbol, ltp, vwap, volume):
        with self.lock:
            if symbol == "NSE:INDIAVIX-INDEX":
                if ltp is not None:
                    self.india_vix = float(ltp)
                    log_debug(f"India VIX updated: {self.india_vix:.2f}")
                return

            if ltp is not None:
                self.live_ltp[symbol] = float(ltp)
            if vwap is not None:
                self.live_vwap[symbol] = float(vwap)
            if volume is not None:
                self.live_volume[symbol] = int(volume)

            # Store history for both options and the underlying index
            if symbol.endswith(('CE','PE')) or symbol == "NSE:NIFTY50-INDEX":
                if symbol not in self.symbol_histories:
                    self.symbol_histories[symbol] = deque(maxlen=3000)
                if ltp is not None:
                    if vwap is not None:
                        self.symbol_histories[symbol].append((time.time(), float(ltp), float(vwap)))
                    else:
                        self.symbol_histories[symbol].append((time.time(), float(ltp), 0.0))

            log_debug(f"Updated {symbol}: LTP={ltp}, VWAP={vwap}")

    def get_ltp(self, symbol):
        with self.lock:
            return self.live_ltp.get(symbol)

    def get_vwap(self, symbol):
        with self.lock:
            return self.live_vwap.get(symbol)

    def update_chain(self, chain, fut_price, expiry_date, atm_strike, option_symbols):
        with self.lock:
            self.option_chain = chain
            self.fut_price = float(fut_price) if fut_price else 0.0
            self.expiry_date = expiry_date
            self.atm_strike = int(atm_strike) if atm_strike else None
            self.option_symbols = option_symbols
            log_debug(f"Chain updated: ATM={self.atm_strike}, {len(option_symbols)} symbols")

    def can_place_order(self):
        return self.daily_entries < Config.MAX_DAILY_ENTRIES and not self.eod_square_off_triggered

    def reset_for_new_day(self):
        with self.lock:
            if self.active_positions:
                log_console(f"⚠️ {len(self.active_positions)} position(s) still tracked, not resetting.")
                return
            self.daily_entries = 0
            self.eod_square_off_triggered = False
            self.position_state = "FLAT"
            self.paper_realized_pnl = 0.0
            self.warmup_start_time = None
            self.sold_time.clear()
            self.decision_reason = ""
            self.current_leader_type = None
            self.leader_since = 0.0

# ============================================================
# WEBSOCKET MANAGER
# ============================================================
class MarketWSManager:
    def __init__(self, session_state, access_token):
        self.session = session_state
        self.access_token = access_token
        self.ws = None
        self.subscribed = set()
        self.running = False

    def on_message(self, message):
        symbol = message.get("symbol")
        if symbol:
            ltp = message.get("ltp")
            vwap = message.get("avg_trade_price")
            volume = message.get("vol_traded_today")
            self.session.update_ws(symbol, ltp, vwap, volume)

    def on_error(self, msg):
        log_console(f"WS error: {msg}")

    def on_close(self, msg):
        log_console(f"WS closed: {msg}")
        self.running = False

    def on_open(self):
        log_console("WebSocket connected")
        if self.subscribed:
            log_debug(f"Subscribing to {len(self.subscribed)} symbols")
            self.ws.subscribe(list(self.subscribed), "SymbolUpdate")
        self.ws.keep_running()

    def start(self):
        if self.running:
            return
        self.running = True
        self.ws = data_ws.FyersDataSocket(
            access_token=self.access_token,
            log_path="",
            litemode=False,
            write_to_file=False,
            reconnect=True,
            on_connect=self.on_open,
            on_close=self.on_close,
            on_error=self.on_error,
            on_message=self.on_message
        )
        self.ws.connect()
        log_debug("WebSocket started")

    def subscribe(self, symbols):
        new_symbols = set(symbols) - self.subscribed
        if new_symbols:
            log_debug(f"Subscribing to new symbols: {new_symbols}")
            if self.ws:
                self.ws.subscribe(list(new_symbols), "SymbolUpdate")
            self.subscribed.update(new_symbols)

    def stop(self):
        self.running = False
        if self.ws:
            self.ws.close_connection()

# ============================================================
# REST API
# ============================================================
def enforce_rate_limit(session):
    now = now_ist()
    window = (now - session.api_window_start).total_seconds()
    if window > Config.API_WINDOW:
        session.api_window_start = now
        session.option_chain_api_count = 0
    elif session.option_chain_api_count >= Config.API_RATE_LIMIT:
        wait = Config.API_WINDOW - window
        if wait > 0:
            time.sleep(wait)
        session.api_window_start = now
        session.option_chain_api_count = 0

@handle_errors
def fetch_option_chain(session, index_symbol):
    log_debug("Enter fetch_option_chain")
    enforce_rate_limit(session)
    session.option_chain_api_count += 1
    fy = fyersModel.FyersModel(client_id=session.cid, token=session.token, is_async=False, log_path="")
    meta = fy.optionchain(data={"symbol": index_symbol, "timestamp": ""})
    if meta.get("code") != 200:
        log_debug(f"Meta chain failed: {meta}")
        return None, None, None, None, []

    fut_price = None
    for item in meta["data"]["optionsChain"]:
        if item.get("option_type") == "":
            fut_price = item.get("fp")
            break
    if fut_price is None:
        fut_price = meta["data"].get("fp", 0.0)

    exp_list = sorted([(e["date"], e["expiry"]) for e in meta["data"]["expiryData"]],
                      key=lambda x: datetime.strptime(x[0], "%d-%m-%Y"))
    today = now_ist().date()
    idx = 0
    for i, (d_str, _) in enumerate(exp_list):
        if datetime.strptime(d_str, "%d-%m-%Y").date() >= today:
            idx = i
            break
    curr_date, expiry_ts = exp_list[idx]

    payload = {"symbol": index_symbol, "strikecount": Config.ATM_RANGE, "timestamp": expiry_ts, "greeks": "1"}
    session.option_chain_api_count += 1
    resp = fy.optionchain(data=payload)
    if resp.get("code") != 200:
        log_debug(f"Detailed chain failed: {resp}")
        return None, None, None, None, []

    chain = resp["data"]["optionsChain"]
    for opt in chain:
        greeks = opt.get("greeks", {})
        opt["delta"] = greeks.get("delta", 0.0) if greeks else 0.0

    option_symbols = [opt["symbol"] for opt in chain if opt.get("option_type") in ("CE","PE")]
    log_debug(f"Got {len(chain)} options, {len(option_symbols)} symbols")
    return chain, fut_price, curr_date, expiry_ts, option_symbols

# ============================================================
# CHAIN POLLER
# ============================================================
def chain_poller(session, ws_manager, index_symbol):
    log_debug("Chain poller thread started")
    while session.running:
        try:
            log_debug("Polling option chain...")
            chain, fut_price, expiry_date, _, opt_symbols = fetch_option_chain(session, index_symbol)
            if chain is None:
                log_debug("Chain fetch returned None")
            else:
                underlying_ltp = session.get_ltp(index_symbol)
                if underlying_ltp is None:
                    underlying_ltp = fut_price

                strikes = sorted(set(opt["strike_price"] for opt in chain if opt.get("option_type") in ("CE","PE")))
                if strikes and underlying_ltp:
                    atm = min(strikes, key=lambda x: abs(x - underlying_ltp))
                else:
                    atm = None

                session.update_chain(chain, fut_price, expiry_date, atm, opt_symbols)
                all_syms = [index_symbol, "NSE:INDIAVIX-INDEX"] + opt_symbols
                ws_manager.subscribe(all_syms)

            time.sleep(Config.OPTION_CHAIN_INTERVAL)
        except Exception as e:
            log_debug(f"Chain poller error: {e}\n{traceback.format_exc()}")
            time.sleep(Config.OPTION_CHAIN_INTERVAL)

# ============================================================
# HELPERS
# ============================================================
def get_symbols_in_range(session, atm_strike, range_strikes=5):
    result = []
    with session.lock:
        if not session.option_chain or atm_strike is None:
            return result
        for opt in session.option_chain:
            strike = opt.get("strike_price")
            otype = opt.get("option_type")
            if otype not in ("CE", "PE"):
                continue
            if abs(strike - atm_strike) <= range_strikes * 50:
                result.append({
                    "symbol": opt["symbol"],
                    "strike": strike,
                    "option_type": otype,
                })
    return result

def compute_return_vol(session, symbol, window_sec):
    hist = session.symbol_histories.get(symbol)
    if not hist or len(hist) < 3:
        return None, None

    now = time.time()
    cutoff = now - window_sec
    relevant = []
    for ts, ltp, vwap in hist:
        if ts >= cutoff:
            relevant.append((ts, ltp))
    if len(relevant) < 2:
        return None, None

    first_ltp = relevant[0][1]
    last_ltp = relevant[-1][1]
    if first_ltp <= 0 or last_ltp <= 0:
        return None, None

    ret = (last_ltp / first_ltp) - 1.0
    log_returns = []
    for i in range(1, len(relevant)):
        prev = relevant[i-1][1]
        curr = relevant[i][1]
        if prev > 0 and curr > 0:
            log_returns.append(np.log(curr / prev))
    if len(log_returns) < 2:
        return ret, 0.0
    vol = np.std(log_returns)
    return ret, vol

# ============================================================
# GET TOP CANDIDATES (computes underlying_score too)
# ============================================================
def get_top_candidates(session):
    log_debug(">>> get_top_candidates called")
    try:
        with session.lock:
            all_evaluations = []
            warming_up = session.is_warming_up()

            spot = session.get_ltp("NSE:NIFTY50-INDEX")
            if spot is None:
                session.last_metrics = {}
                return [], [], {"spot": 0}

            atm_strike = session.atm_strike
            if atm_strike is None:
                return [], [], {"spot": spot}

            now = now_ist()
            eod_square_off = (now.hour > 15) or (now.hour == 15 and now.minute >= 15)
            if eod_square_off:
                session.eod_square_off_triggered = True

            symbols_in_range = get_symbols_in_range(session, atm_strike, Config.ATM_RANGE)
            if not symbols_in_range:
                return [], [], {"spot": spot, "atm": atm_strike}

            candidates = []

            for entry in symbols_in_range:
                symbol = entry["symbol"]
                current_ltp = session.get_ltp(symbol)
                current_vwap = session.get_vwap(symbol)

                eval_entry = {
                    "symbol": symbol,
                    "strike": entry["strike"],
                    "otype": entry["option_type"],
                    "ltp": current_ltp,
                    "vwap": current_vwap,
                    "pass_vwap": False,
                    "ret_short": None,
                    "vol_short": None,
                    "ret_long": None,
                    "vol_long": None,
                    "score": None,
                    "status": "PENDING",
                    "reason": ""
                }

                if current_ltp is None or current_vwap is None:
                    eval_entry["status"] = "REJECTED"
                    eval_entry["reason"] = "No LTP/VWAP"
                    all_evaluations.append(eval_entry)
                    continue

                if Config.ENABLE_VWAP_FILTER:
                    if current_ltp <= current_vwap:
                        eval_entry["status"] = "REJECTED"
                        eval_entry["reason"] = f"LTP {current_ltp:.2f} ≤ VWAP {current_vwap:.2f}"
                        all_evaluations.append(eval_entry)
                        continue
                    else:
                        eval_entry["pass_vwap"] = True
                else:
                    eval_entry["pass_vwap"] = True

                if warming_up:
                    eval_entry["status"] = "WARMING UP"
                    eval_entry["reason"] = f"Need {Config.SCORE_WIN_LONG}s of data"
                    all_evaluations.append(eval_entry)
                    continue

                ret_short, vol_short = compute_return_vol(session, symbol, Config.SCORE_WIN_SHORT)
                ret_long, vol_long = compute_return_vol(session, symbol, Config.SCORE_WIN_LONG)

                eval_entry["ret_short"] = ret_short
                eval_entry["vol_short"] = vol_short
                eval_entry["ret_long"] = ret_long
                eval_entry["vol_long"] = vol_long

                if ret_short is None or ret_long is None:
                    eval_entry["status"] = "REJECTED"
                    eval_entry["reason"] = "Insufficient tick data"
                    all_evaluations.append(eval_entry)
                    continue

                if vol_short == 0.0 or vol_long == 0.0:
                    eval_entry["status"] = "REJECTED"
                    eval_entry["reason"] = "Volatility = 0"
                    all_evaluations.append(eval_entry)
                    continue

                score_short = ret_short / vol_short
                score_long = ret_long / vol_long
                score = (1.0/3.0) * score_short + (2.0/3.0) * score_long

                eval_entry["score"] = score
                eval_entry["status"] = "CANDIDATE"
                eval_entry["reason"] = ""

                candidates.append({
                    "symbol": symbol,
                    "strike": entry["strike"],
                    "option_type": entry["option_type"],
                    "ltp": current_ltp,
                    "vwap": current_vwap,
                    "score": score,
                    "ret_short": ret_short,
                    "vol_short": vol_short,
                    "ret_long": ret_long,
                    "vol_long": vol_long
                })

                all_evaluations.append(eval_entry)

            candidates.sort(key=lambda x: x["score"], reverse=True)
            session.last_candidates = candidates

            top_candidates = candidates[:3]
            session.last_top_candidates = top_candidates
            session.last_all_evaluations = all_evaluations

            # --- Compute underlying_score ---
            underlying_score = None
            if not warming_up:
                ret_short_u, vol_short_u = compute_return_vol(session, "NSE:NIFTY50-INDEX", Config.SCORE_WIN_SHORT)
                ret_long_u, vol_long_u = compute_return_vol(session, "NSE:NIFTY50-INDEX", Config.SCORE_WIN_LONG)
                if ret_short_u is not None and ret_long_u is not None and vol_short_u is not None and vol_long_u is not None:
                    if vol_short_u > 0 and vol_long_u > 0:
                        score_short_u = ret_short_u / vol_short_u
                        score_long_u = ret_long_u / vol_long_u
                        underlying_score = (1.0/3.0) * score_short_u + (2.0/3.0) * score_long_u
                    else:
                        underlying_score = None
                else:
                    underlying_score = None

            session.last_metrics = {
                "spot": spot,
                "atm": atm_strike,
                "underlying_score": underlying_score
            }

            log_debug(f">>> Top candidates: {[c['symbol'] for c in top_candidates]}")
            log_debug(f">>> Underlying score: {underlying_score}")
            return top_candidates, all_evaluations, session.last_metrics

    except Exception as e:
        log_debug(f"CRASH in get_top_candidates: {e}\n{traceback.format_exc()}")
        return [], [], {}

# ============================================================
# SYNC POSITIONS – with persistence filter + underlying score
# ============================================================
def sync_positions(session, top_candidates, all_candidates, fyers):
    if getattr(session, '_order_lock', False):
        return
    session._order_lock = True
    try:
        with session.lock:
            # --- 1. Warmup & Safety ---
            if session.is_warming_up():
                session.decision_reason = "Warming up"
                return
            if session.eod_square_off_triggered:
                if session.active_positions:
                    log_console("⏰ EOD – closing held position")
                else:
                    session.decision_reason = "EOD passed"
                    return

            # --- 2. Get Current State ---
            held_positions = session.active_positions
            held_symbol = held_positions[0]["symbol"] if held_positions else None

            top_1_candidate = top_candidates[0] if len(top_candidates) >= 1 else None
            top_1_symbol = top_1_candidate["symbol"] if top_1_candidate else None

            def get_type(sym):
                if sym.endswith('CE'):
                    return 'CE'
                elif sym.endswith('PE'):
                    return 'PE'
                return None

            held_type = get_type(held_symbol) if held_symbol else None
            top_type = get_type(top_1_symbol) if top_1_symbol else None

            # ========== PERSISTENCE TRACKING ==========
            current_time = time.time()
            new_leader_type = top_type

            if new_leader_type != session.current_leader_type:
                session.current_leader_type = new_leader_type
                session.leader_since = current_time
                log_debug(f"Leader type changed to {new_leader_type}")

            leader_duration = 0
            if session.current_leader_type is not None:
                leader_duration = current_time - session.leader_since

            leader_confirmed = leader_duration >= Config.CONFIRMATION_SECONDS
            # =========================================

            # --- 3. Exit Logic (with persistence check) ---
            if held_symbol is not None:
                # Safety: if no top candidate, exit immediately (no persistence)
                if top_1_symbol is None:
                    log_console(f"📊 No Top 1 candidate – exiting {held_symbol}")
                    pos = held_positions[0]
                    if PAPER_MODE:
                        current = session.get_ltp(held_symbol)
                        if current is None:
                            for opt in session.option_chain:
                                if opt["symbol"] == held_symbol:
                                    current = opt.get("ltp", 0)
                                    break
                        if current is None or current == 0:
                            current = pos["entry_price"]
                        pnl = (current - pos["entry_price"]) * Config.LOT_SIZE
                        session.paper_realized_pnl += pnl
                        log_console(f"📊 SOLD: {held_symbol} at {current:.2f}, P&L={pnl:+.2f}")
                        session.active_positions.clear()
                        session.sold_time[held_symbol] = time.time()
                        session.decision_reason = f"Sold {held_symbol} (no top candidate)"
                    else:
                        order = {
                            "symbol": held_symbol,
                            "qty": Config.LOT_SIZE,
                            "type": 2,
                            "side": -1,
                            "productType": "MARGIN",
                            "validity": "DAY",
                        }
                        resp = fyers.place_order(data=order)
                        if resp.get("s") == "ok":
                            log_console(f"📊 SOLD: {held_symbol} (Order ID: {resp.get('id')})")
                            session.active_positions.clear()
                            session.sold_time[held_symbol] = time.time()
                            session.decision_reason = f"Sold {held_symbol} (no top candidate)"
                        else:
                            log_console(f"❌ FAILED to sell {held_symbol}: {resp}")
                            session.decision_reason = f"Failed to sell {held_symbol}"
                            return
                    session.position_state = "FLAT" if not session.active_positions else "ACTIVE"
                    return

                # --- PERSISTENCE CHECK FOR EXIT ---
                if not leader_confirmed:
                    remaining = max(0, int(Config.CONFIRMATION_SECONDS - leader_duration))
                    session.decision_reason = f"Top 1 type {session.current_leader_type} not confirmed yet ({remaining}s remaining) – holding"
                    return   # Do NOT exit, stay in position

                # Normal exit: if held type != top type
                if held_type != top_type:
                    log_console(f"📊 Type changed: held {held_type} → top {top_type}. Exiting {held_symbol}")
                    pos = held_positions[0]
                    if PAPER_MODE:
                        current = session.get_ltp(held_symbol)
                        if current is None:
                            for opt in session.option_chain:
                                if opt["symbol"] == held_symbol:
                                    current = opt.get("ltp", 0)
                                    break
                        if current is None or current == 0:
                            current = pos["entry_price"]
                        pnl = (current - pos["entry_price"]) * Config.LOT_SIZE
                        session.paper_realized_pnl += pnl
                        log_console(f"📊 SOLD: {held_symbol} at {current:.2f}, P&L={pnl:+.2f}")
                        session.active_positions.clear()
                        session.sold_time[held_symbol] = time.time()
                        session.decision_reason = f"Sold {held_symbol} (type changed to {top_type})"
                    else:
                        order = {
                            "symbol": held_symbol,
                            "qty": Config.LOT_SIZE,
                            "type": 2,
                            "side": -1,
                            "productType": "MARGIN",
                            "validity": "DAY",
                        }
                        resp = fyers.place_order(data=order)
                        if resp.get("s") == "ok":
                            log_console(f"📊 SOLD: {held_symbol} (Order ID: {resp.get('id')})")
                            session.active_positions.clear()
                            session.sold_time[held_symbol] = time.time()
                            session.decision_reason = f"Sold {held_symbol} (type changed to {top_type})"
                        else:
                            log_console(f"❌ FAILED to sell {held_symbol}: {resp}")
                            session.decision_reason = f"Failed to sell {held_symbol}"
                            return
                    session.position_state = "FLAT" if not session.active_positions else "ACTIVE"
                else:
                    session.decision_reason = f"Holding {held_symbol} (same type {held_type} as Top 1)"
                    return

            # --- 4. Entry (only if flat) ---
            if not session.active_positions:
                if not top_1_candidate:
                    session.decision_reason = "No Top 1 candidate"
                    return

                # --- PERSISTENCE CHECK FOR ENTRY ---
                if not leader_confirmed:
                    remaining = max(0, int(Config.CONFIRMATION_SECONDS - leader_duration))
                    session.decision_reason = f"Top 1 type {session.current_leader_type} not confirmed yet ({remaining}s remaining) – no entry"
                    return

                # --- Get underlying_score ---
                underlying_score = session.last_metrics.get("underlying_score")
                if underlying_score is None:
                    session.decision_reason = "Underlying score not available"
                    return

                # --- Check top & bottom types ---
                full_candidates = session.last_candidates
                if len(full_candidates) < 2:
                    session.decision_reason = "Not enough candidates (need at least 2)"
                    return

                bottom_1_candidate = full_candidates[-1]   # lowest score
                bottom_type = get_type(bottom_1_candidate["symbol"])

                # Underlying score filter
                if underlying_score > 0.5:
                    if top_type == 'CE' and bottom_type == 'PE':
                        pass
                    else:
                        session.decision_reason = f"Underlying > 0.5 but top/bottom mismatch: top={top_type}, bottom={bottom_type}"
                        return
                elif underlying_score < -0.5:
                    if top_type == 'PE' and bottom_type == 'CE':
                        pass
                    else:
                        session.decision_reason = f"Underlying < -0.5 but top/bottom mismatch: top={top_type}, bottom={bottom_type}"
                        return
                else:
                    session.decision_reason = f"Underlying score {underlying_score:.4f} within [-0.5, 0.5] – no entry"
                    return

                # --- Existing filters: daily limit, cooldown, score gap ---
                if session.daily_entries >= Config.MAX_DAILY_ENTRIES:
                    session.decision_reason = "Daily entry limit reached"
                    return

                now = time.time()
                if top_1_symbol in session.sold_time:
                    if now - session.sold_time[top_1_symbol] < Config.SYMBOL_COOLDOWN:
                        session.decision_reason = f"{top_1_symbol} on cooldown ({int(Config.SYMBOL_COOLDOWN - (now - session.sold_time[top_1_symbol]))}s remaining)"
                        return

                if len(top_candidates) >= 2:
                    gap = top_candidates[0]["score"] - top_candidates[1]["score"]
                    if gap < Config.REBALANCE_THRESHOLD:
                        session.decision_reason = f"Score gap too small ({gap:.4f} < {Config.REBALANCE_THRESHOLD})"
                        return

                # --- All checks passed – BUY ---
                sym = top_1_candidate["symbol"]
                entry_price = top_1_candidate["ltp"]

                if PAPER_MODE:
                    if entry_price <= 0:
                        session.decision_reason = f"Invalid price for {sym}"
                        return
                    session.active_positions.append({
                        "symbol": sym,
                        "entry_price": entry_price,
                    })
                    log_console(f"🟢 BOUGHT (Top 1): {sym} at {entry_price:.2f}")
                    session.daily_entries += 1
                    session.decision_reason = f"Bought {sym} (type {get_type(sym)}) at {entry_price:.2f}"
                else:
                    order = {
                        "symbol": sym,
                        "qty": Config.LOT_SIZE,
                        "type": 2,
                        "side": 1,
                        "productType": "MARGIN",
                        "validity": "DAY",
                    }
                    resp = fyers.place_order(data=order)
                    if resp.get("s") == "ok":
                        session.active_positions.append({
                            "symbol": sym,
                            "entry_price": entry_price,
                        })
                        log_console(f"🟢 BOUGHT (Top 1): {sym} at {entry_price:.2f} (Order ID: {resp.get('id')})")
                        session.daily_entries += 1
                        session.decision_reason = f"Bought {sym} (type {get_type(sym)}) at {entry_price:.2f}"
                    else:
                        log_console(f"❌ FAILED to buy {sym}: {resp}")
                        session.decision_reason = f"Failed to buy {sym}"

                session.position_state = "ACTIVE" if session.active_positions else "FLAT"

    except Exception as e:
        log_console(f"sync_positions error: {e}")
        session.decision_reason = f"Error: {str(e)}"
    finally:
        session._order_lock = False

# ============================================================
# SAMPLER THREAD
# ============================================================
def sampler(session, data_logger, auto_trade, fyers):
    log_debug("Sampler thread started")
    first_run = True
    while session.running:
        start = now_ist()
        try:
            if first_run:
                session.start_warmup()
                first_run = False

            top_candidates, all_candidates, metrics = get_top_candidates(session)

            with session.lock:
                for pos in session.active_positions:
                    pos["current"] = session.get_ltp(pos["symbol"]) or pos["entry_price"]

            total_pnl = session.paper_realized_pnl
            for pos in session.active_positions:
                current = pos.get("current", pos["entry_price"])
                total_pnl += (current - pos["entry_price"]) * Config.LOT_SIZE

            warmup_remaining = session.warmup_remaining() if session.is_warming_up() else 0
            underlying_score = metrics.get("underlying_score")

            if auto_trade:
                sync_positions(session, top_candidates, all_candidates, fyers)

            data_logger.log_data(
                timestamp=timestamp_ist(),
                underlying_ltp=metrics.get("spot", 0),
                atm_strike=metrics.get("atm", 0),
                expiry_date=session.expiry_date or "",
                top_candidates=top_candidates,
                active_positions=session.active_positions,
                total_pnl=total_pnl,
                vix=session.india_vix,
                daily_entries=session.daily_entries,
                warmup_remaining=warmup_remaining,
                decision_reason=session.decision_reason,
                underlying_score=underlying_score
            )

            elapsed = (now_ist() - start).total_seconds()
            if elapsed < Config.SAMPLE_INTERVAL:
                time.sleep(Config.SAMPLE_INTERVAL - elapsed)

        except Exception as e:
            log_debug(f"Sampler error: {e}\n{traceback.format_exc()}")
            time.sleep(1)

# ============================================================
# DASHBOARD
# ============================================================
class TerminalDashboard:
    def __init__(self, data_logger, session_state):
        self.data_logger = data_logger
        self.session_state = session_state

    def display(self):
        try:
            os.system('cls' if os.name == 'nt' else 'clear')
            mode = "PAPER" if PAPER_MODE else "LIVE"
            print("\n" + "="*130)
            print(f"📊 {mode} TRADING DASHBOARD – Momentum Strategy (Hold by Type)")
            print("="*130)

            with self.session_state.lock:
                daily_entries = self.session_state.daily_entries
                vix = self.session_state.india_vix
                realized = self.session_state.paper_realized_pnl
                position_state = self.session_state.position_state
                top_candidates = self.session_state.last_top_candidates[:]
                full_candidates = self.session_state.last_candidates[:]
                active_positions = self.session_state.active_positions[:]
                eod_triggered = self.session_state.eod_square_off_triggered
                warming_up = self.session_state.is_warming_up()
                warmup_rem = self.session_state.warmup_remaining()
                all_evals = self.session_state.last_all_evaluations[:]
                decision_reason = self.session_state.decision_reason
                underlying_score = self.session_state.last_metrics.get("underlying_score")

            # Extract bottom 3
            if len(full_candidates) >= 3:
                bottom_candidates = full_candidates[-3:][::-1]
            else:
                bottom_candidates = full_candidates[::-1]

            print(f"Last Update: {timestamp_ist()}")
            print(f"📈 Daily Entries (Buys): {daily_entries}/{Config.MAX_DAILY_ENTRIES}")
            print(f"📊 India VIX: {vix:.2f}")
            print(f"💰 Realized P&L: {realized:+.2f}")
            if underlying_score is not None:
                print(f"📉 Underlying Score: {underlying_score:.4f} {'(>0.5 → Long)' if underlying_score > 0.5 else '(< -0.5 → Short)' if underlying_score < -0.5 else '(neutral)'}")
            else:
                print("📉 Underlying Score: N/A")

            if warming_up:
                print("\n" + "🔴"*25)
                print(f"⏳ WARMING UP... {warmup_rem} SECONDS REMAINING")
                print("🔴"*25 + "\n")
            else:
                print("\n✅ WARMUP COMPLETE – Trading active\n")

            if Config.ENABLE_VWAP_FILTER:
                print("🔵 VWAP FILTER: ON (LTP > VWAP required)")
            else:
                print("⚪ VWAP FILTER: OFF (disabled)")

            print(f"🧠 Decision: {decision_reason}")

            if position_state == "ACTIVE":
                total_unrealized = 0
                for pos in active_positions:
                    current = pos.get("current", pos["entry_price"])
                    pnl = (current - pos["entry_price"]) * Config.LOT_SIZE
                    total_unrealized += pnl
                print(f"💰 Unrealized P&L: {total_unrealized:+.2f}")
                print(f"💰 Total P&L: {realized + total_unrealized:+.2f}")

            if eod_triggered:
                print("⛔ EOD square‑off triggered – no new buys allowed")

            print("\n" + "-"*80)
            print("🏆 TOP CANDIDATES")
            print("-"*80)
            if warming_up:
                print("   ⏳ Candidates will appear here after warmup")
            elif top_candidates:
                print(f"{'Rank':<4} | {'Symbol':<25} | {'Strike':<8} | {'Type':<4} | {'Score':<10} | {'LTP':<8} | {'VWAP':<8}")
                print("-"*80)
                for i, c in enumerate(top_candidates[:3], 1):
                    print(f"{i:<4} | {c['symbol']:<25} | {c['strike']:<8} | {c['option_type']:<4} | {c['score']:<10.4f} | {c['ltp']:<8.2f} | {c['vwap']:<8.2f}")
            else:
                print("   No candidates (insufficient data or all rejected)")

            print("\n" + "-"*80)
            print("🔻 BOTTOM 3 CANDIDATES (lowest scores)")
            print("-"*80)
            if warming_up:
                print("   ⏳ Candidates will appear here after warmup")
            elif bottom_candidates:
                print(f"{'Rank':<4} | {'Symbol':<25} | {'Strike':<8} | {'Type':<4} | {'Score':<10} | {'LTP':<8} | {'VWAP':<8}")
                print("-"*80)
                for i, c in enumerate(bottom_candidates, 1):
                    print(f"{i:<4} | {c['symbol']:<25} | {c['strike']:<8} | {c['option_type']:<4} | {c['score']:<10.4f} | {c['ltp']:<8.2f} | {c['vwap']:<8.2f}")
            else:
                print("   No bottom candidates (insufficient data)")

            print("\n" + "-"*130)
            print("🔍 STRIKE FILTER BREAKDOWN (ATM +/- 5)")
            print("-"*130)
            if all_evals:
                print(f"{'Symbol':<25} | {'Strike':<8} | {'Type':<4} | {'LTP':<8} | {'VWAP':<8} | {'Pass VWAP':<9} | {'Score':<10} | {'Status/Reason'}")
                print("-"*130)
                for e in all_evals:
                    reason = e["reason"]
                    if len(reason) > 25:
                        reason = reason[:22] + "..."

                    if e["status"] == "CANDIDATE":
                        status_display = f"✅ {e['status']}"
                    elif e["status"] == "REJECTED":
                        status_display = f"❌ {e['status']}"
                    elif e["status"] == "WARMING UP":
                        status_display = f"⏳ {e['status']}"
                    else:
                        status_display = f"⬜ {e['status']}"

                    if e["status"] == "CANDIDATE":
                        score_display = f"{e['score']:.4f}"
                    else:
                        score_display = ""

                    if Config.ENABLE_VWAP_FILTER:
                        pass_vwap_display = "✅" if e["pass_vwap"] else "❌"
                    else:
                        pass_vwap_display = "⚪ OFF"

                    ltp_display = f"{e['ltp']:.2f}" if e["ltp"] else "N/A"
                    vwap_display = f"{e['vwap']:.2f}" if e["vwap"] else "N/A"

                    print(f"{e['symbol']:<25} | {e['strike']:<8} | {e['otype']:<4} | {ltp_display:<8} | {vwap_display:<8} | {pass_vwap_display:<9} | {score_display:<10} | {status_display} ({reason})")
            else:
                print("   No strike data available")

            print("\n" + "-"*80)
            print("📌 ACTIVE POSITION")
            print("-"*80)
            if active_positions:
                pos = active_positions[0]
                current = pos.get("current", pos["entry_price"])
                pnl = (current - pos["entry_price"]) * Config.LOT_SIZE
                print(f"  Symbol: {pos['symbol']}")
                print(f"  Entry: {pos['entry_price']:.2f}  |  Current: {current:.2f}  |  P&L: {pnl:+.2f}")
            else:
                print("   No active position (FLAT)")

            print("\n" + "="*130)
        except Exception as e:
            log_debug(f"Dashboard error: {e}")

# ============================================================
# CREDENTIALS & MAIN
# ============================================================
def load_credentials(session):
    try:
        with open('fyers_credentials.json', 'r') as f:
            creds = json.load(f)
            session.cid = creds.get('client_id', '')
            session.token = creds.get('access_token', '')
        log_console(f"Loaded credentials: {session.cid}")
    except Exception as e:
        session.cid = os.getenv("FYERS_CID", "")
        session.token = os.getenv("FYERS_TOKEN", "")
        log_console(f"Using env vars: {session.cid}")

def main():
    log_console("Starting Momentum Ranking Algo Trading System...")
    session = SessionState()
    load_credentials(session)
    data_logger = DataLogger()
    dashboard = TerminalDashboard(data_logger, session)
    index_symbol = "NSE:NIFTY50-INDEX"
    vix_symbol = "NSE:INDIAVIX-INDEX"

    poller_thread = None
    sampler_thread = None
    ws_manager = None
    fyers = None

    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        print("="*50)
        mode = "PAPER" if PAPER_MODE else "LIVE"
        print(f"📈 FYERS ALGO TRADING ({mode} MODE) – Momentum Strategy (Hold by Type)")
        print("1. Start Trading")
        print("2. Settings")
        print("3. Exit")
        choice = input("Select option: ").strip()
        if choice == "1":
            if not (session.cid and session.token):
                print("❌ Set credentials first")
                input("Press Enter...")
                continue

            session.reset_for_new_day()

            auto_trade = input("Enable Auto Trade? (y/n): ").lower() == 'y'
            log_console(f"Auto trade: {'ON' if auto_trade else 'OFF'}")

            ws_manager = MarketWSManager(session, session.token)
            ws_manager.start()
            ws_manager.subscribe([index_symbol, vix_symbol])
            session.running = True

            fyers = fyersModel.FyersModel(client_id=session.cid, token=session.token, is_async=False, log_path="")
            poller_thread = threading.Thread(target=chain_poller, args=(session, ws_manager, index_symbol), daemon=True)
            sampler_thread = threading.Thread(target=sampler, args=(session, data_logger, auto_trade, fyers), daemon=True)
            poller_thread.start()
            sampler_thread.start()

            print("\n✅ Trading started. Press Ctrl+C to stop.\n")
            try:
                while True:
                    dashboard.display()
                    time.sleep(2)
            except KeyboardInterrupt:
                log_console("\n🛑 Stopping trading...")
                session.running = False
                ws_manager.stop()

                if sampler_thread is not None:
                    sampler_thread.join(timeout=5)
                if poller_thread is not None:
                    poller_thread.join(timeout=Config.OPTION_CHAIN_INTERVAL + 5)

                if session.active_positions:
                    log_console(f"Attempting to close {len(session.active_positions)} open position(s)...")
                    sync_positions(session, [], [], fyers)

                with session.lock:
                    if session.active_positions:
                        log_console(f"⚠️ {len(session.active_positions)} position(s) could not be closed. Check broker manually.")
                    else:
                        session.eod_square_off_triggered = False
                        session.daily_entries = 0
                        session.paper_realized_pnl = 0.0
                        session.warmup_start_time = None
                        session.sold_time.clear()
                        log_console("✅ Trading stopped and state reset. You can start again.")
        elif choice == "2":
            print("\n⚙️ SETTINGS")
            new_cid = input(f"Client ID [{session.cid}]: ").strip()
            if new_cid:
                session.cid = new_cid
            new_token = input("Access token: ").strip()
            if new_token:
                session.token = new_token
            with open('fyers_credentials.json', 'w') as f:
                json.dump({"client_id": session.cid, "access_token": session.token}, f)
            print("✅ Saved")
            input("Press Enter...")
        elif choice == "3":
            if session.running:
                session.running = False
                if ws_manager:
                    ws_manager.stop()
            if session.active_positions:
                log_console(f"⚠️ Exiting with {len(session.active_positions)} position(s) still tracked.")
            break

if __name__ == "__main__":
    main()