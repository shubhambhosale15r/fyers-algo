# ============================================================
# paper_nifty.py – Paper trading version (no real orders)
# Residual-based Strategy (Z-score → EMA smoothing)
# ============================================================

import time
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import pytz
from fyers_apiv3 import fyersModel
from fyers_apiv3.FyersWebsocket import data_ws
import logging
import os
import json
from collections import deque
import csv
import threading
import traceback

# ============================================================
# PAPER TRADE FLAG – set to True for paper simulation
# ============================================================
PAPER_MODE = True   # Change to False for live trading

# ============================================================
# CONFIGURATION
# ============================================================
class Config:
    SAMPLE_INTERVAL = 1
    OPTION_CHAIN_INTERVAL = 30
    # --- Strategy parameters (as specified) ---
    MOVE_WINDOW = 60               # seconds for spot/option move
    MIN_SPOT_CHANGE = 5.0          # ignore if spot moves less than 5 pts
    ZSCORE_WINDOW = 300            # rolling window for z-score (raw residuals)
    Z_EMA_PERIOD = 15              # EMA smoothing period for z-score (10-20)
    ZSCORE_THRESHOLD = 2.0         # entry threshold
    MIN_EXPECTED_MOVE = 1.0        # unused now (kept for reference)
    # --- Existing ---
    OPTION_TRAIL_MULTIPLIER = 1.0
    TARGET_MULTIPLIER = 2
    LOT_SIZE = 195
    MAX_DAILY_ORDERS = 6
    API_RATE_LIMIT = 200
    API_WINDOW = 60
    MAX_RETRIES = 3
    RETRY_DELAY = 2
    FNO_SEGMENT = 14               # NSE F&O segment for exits

# ============================================================
# LOGGING (unchanged)
# ============================================================
logging.basicConfig(
    filename="trading_app.log",
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)

def log_debug(msg):
    logging.debug(msg)

def log_console(msg):
    print(msg, flush=True)
    logging.info(msg)

IST = pytz.timezone("Asia/Kolkata")

def now_ist():
    return datetime.now(IST)

def timestamp_ist():
    return now_ist().strftime("%Y-%m-%d %H:%M:%S")

# ============================================================
# ERROR HANDLER (unchanged)
# ============================================================
def handle_errors(func):
    def wrapper(*args, **kwargs):
        for retry in range(Config.MAX_RETRIES):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                log_debug(f"{func.__name__} attempt {retry+1} failed: {e}\n{traceback.format_exc()}")
                if retry < Config.MAX_RETRIES-1:
                    time.sleep(Config.RETRY_DELAY)
                else:
                    log_debug(f"{func.__name__} permanently failed")
                    return None
    return wrapper

# ============================================================
# DATA LOGGER – updated columns
# ============================================================
class DataLogger:
    def __init__(self, filename="trading_data.csv"):
        self.filename = filename
        self._ensure_header()

    def _ensure_header(self):
        if not os.path.exists(self.filename):
            with open(self.filename, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'timestamp', 'underlying_ltp', 'fut_price', 'signal', 'atm_strike',
                    'expiry_date',
                    'ce_ltp', 'pe_ltp', 'ce_delta', 'pe_delta',
                    'spot_change',
                    'expected_ce', 'observed_ce', 'residual_ce',
                    'expected_pe', 'observed_pe', 'residual_pe',
                    'residual_diff',
                    'raw_z_score',
                    'smoothed_z_score',
                    'position',
                    'opt_symbol', 'opt_entry', 'opt_current', 'opt_stop', 'opt_target',
                    'trailing_stop', 'peak_opt_price',
                    'vix', 'sl_pct', 'paper_pnl'
                ])

    def log_data(self, timestamp, underlying_ltp, fut_price, signal, atm_strike,
                 expiry_date,
                 ce_ltp, pe_ltp, ce_delta, pe_delta,
                 spot_change, expected_ce, observed_ce, residual_ce,
                 expected_pe, observed_pe, residual_pe,
                 residual_diff, raw_z_score, smoothed_z_score,
                 position,
                 opt_symbol='', opt_entry=0.0, opt_current=0.0, opt_stop=0.0, opt_target=0.0,
                 trailing_stop=0.0, peak_opt_price=0.0,
                 vix=0.0, sl_pct=0.0, paper_pnl=0.0):
        with open(self.filename, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                str(timestamp), underlying_ltp, fut_price, signal, atm_strike,
                expiry_date,
                round(ce_ltp,2), round(pe_ltp,2), round(ce_delta,4), round(pe_delta,4),
                round(spot_change,2),
                round(expected_ce,2), round(observed_ce,2), round(residual_ce,2),
                round(expected_pe,2), round(observed_pe,2), round(residual_pe,2),
                round(residual_diff,2),
                round(raw_z_score,3), round(smoothed_z_score,3),
                position,
                opt_symbol, round(opt_entry,2), round(opt_current,2), round(opt_stop,2), round(opt_target,2),
                round(trailing_stop,2), round(peak_opt_price,2),
                round(vix,2), round(sl_pct*100,2), round(paper_pnl,2)
            ])

# ============================================================
# STRIKE DETAILS (now also returns deltas)
# ============================================================
def get_strike_details(session):
    details = []
    with session.lock:
        if not session.option_chain or session.atm_strike is None:
            return details
        atm = session.atm_strike
        all_strikes = sorted(set(opt["strike_price"] for opt in session.option_chain if opt.get("option_type") in ("CE","PE")))
        if not all_strikes or atm not in all_strikes:
            return details
        idx = all_strikes.index(atm)
        selected = [atm]
        if idx > 0:
            selected.append(all_strikes[idx-1])
        if idx < len(all_strikes)-1:
            selected.append(all_strikes[idx+1])
        for strike in selected:
            ce = next((o for o in session.option_chain if o["strike_price"] == strike and o["option_type"] == "CE"), None)
            pe = next((o for o in session.option_chain if o["strike_price"] == strike and o["option_type"] == "PE"), None)
            if not ce or not pe:
                continue
            ce_ltp = session.get_ltp(ce["symbol"]) or ce.get("ltp", 0)
            pe_ltp = session.get_ltp(pe["symbol"]) or pe.get("ltp", 0)
            ce_delta = ce.get("delta", 0.0)
            pe_delta = pe.get("delta", 0.0)
            details.append({
                "strike": strike,
                "ce_ltp": ce_ltp,
                "ce_delta": ce_delta,
                "pe_ltp": pe_ltp,
                "pe_delta": pe_delta,
            })
    return details

# ============================================================
# DASHBOARD – updated for new metrics
# ============================================================
class TerminalDashboard:
    def __init__(self, data_logger, session_state):
        self.data_logger = data_logger
        self.session_state = session_state

    def display(self):
        try:
            os.system('cls' if os.name == 'nt' else 'clear')
            print("\n" + "="*120)
            print("📊 PAPER TRADING DASHBOARD (Residual + Z‑score → EMA)") if PAPER_MODE else print("📊 LIVE TRADING DASHBOARD (Residual + Z‑score → EMA)")
            print("="*120)
            print(f"Last Update: {timestamp_ist()}")
            print(f"📈 DAILY ORDER COUNT: {self.session_state.daily_executed_orders}/{Config.MAX_DAILY_ORDERS}")
            print(f"📊 India VIX: {self.session_state.india_vix:.2f}")
            have = len(self.session_state.residual_history)
            if have < Config.ZSCORE_WINDOW:
                print(f"⏳ WARMING UP (z-score): {have}/{Config.ZSCORE_WINDOW} samples")
            else:
                print(f"✅ Z-SCORE WINDOW FULL: {have} samples")

            if PAPER_MODE:
                print(f"💰 PAPER P&L (Realized): {self.session_state.paper_realized_pnl:+.2f}")
                if self.session_state.position in ("LONG", "SHORT"):
                    current_opt = self.session_state.get_ltp(self.session_state.held_option_symbol)
                    if current_opt and self.session_state.option_entry_price:
                        unrealized = (current_opt - self.session_state.option_entry_price) * Config.LOT_SIZE
                        print(f"💰 Unrealized P&L: {unrealized:+.2f}")
                        total = self.session_state.paper_realized_pnl + unrealized
                        print(f"💰 Total P&L (Realized+Unrealized): {total:+.2f}")

            print("\n" + "-"*80)
            print("📈 CURRENT SIGNAL VALUES")
            print("-"*80)
            metrics = self.session_state.last_metrics
            signal = self.session_state.last_signal
            if metrics:
                print(f"   Nifty LTP: {metrics.get('spot', 0)}")
                print(f"   Signal: {signal}")
                print(f"   Position: {self.session_state.position}")
                print(f"   ATM Strike: {metrics.get('atm_strike', 0)}")
                print(f"\n   CE LTP: {metrics.get('ce_ltp', 0):.2f}   |   CE Delta: {metrics.get('ce_delta', 0):.4f}")
                print(f"   PE LTP: {metrics.get('pe_ltp', 0):.2f}   |   PE Delta: {metrics.get('pe_delta', 0):.4f}")
                print(f"\n   Spot Change (last {Config.MOVE_WINDOW}s): {metrics.get('spot_change', 0):.2f}")
                print(f"   Expected CE move: {metrics.get('expected_ce', 0):.2f}")
                print(f"   Expected PE move: {metrics.get('expected_pe', 0):.2f}")
                print(f"   Residual Diff: {metrics.get('residual_diff', 0):.2f}")
                print(f"   Raw Z-score (of residual): {metrics.get('raw_z_score', 0):.3f}")
                print(f"   Smoothed Z-score (EMA): {metrics.get('smoothed_z_score', 0):.3f}  [Period={Config.Z_EMA_PERIOD}s]")
                z = metrics.get('smoothed_z_score', 0)
                if abs(z) > Config.ZSCORE_THRESHOLD:
                    dir = "BUY (Long CE)" if z > 0 else "SELL (Long PE)"
                    print(f"   🔔 SIGNAL ACTIVE: {dir} (|z|={abs(z):.2f} > {Config.ZSCORE_THRESHOLD})")
                else:
                    print(f"   ⏳ No signal (|z|={abs(z):.2f} ≤ {Config.ZSCORE_THRESHOLD})")
            else:
                print("   Waiting for first data point...")

            strike_details = get_strike_details(self.session_state)
            if strike_details:
                print("\n" + "-"*80)
                print("🔍 PER‑STRIKE DETAILS (Live from WebSocket)")
                print("-"*80)
                print(f"{'Strike':>8} | {'CE LTP':>8} | {'CE Delta':>8} | {'PE LTP':>8} | {'PE Delta':>8}")
                print("-"*80)
                for d in strike_details:
                    print(f"{d['strike']:8} | {d['ce_ltp']:8.2f} | {d['ce_delta']:8.4f} | {d['pe_ltp']:8.2f} | {d['pe_delta']:8.4f}")

            pos = self.session_state.position
            if pos in ("LONG", "SHORT"):
                if self.session_state.held_option_symbol:
                    opt_ltp = self.session_state.get_ltp(self.session_state.held_option_symbol)
                    if opt_ltp:
                        trailing_stop = self.session_state.peak_opt_price * (1 - self.session_state.current_sl_pct)
                        print(f"\n{'📈 LONG (Call)' if pos == 'LONG' else '📉 SHORT (Put)'} POSITION ACTIVE (Fixed + Trailing SL)")
                        print(f"   Held option: {self.session_state.held_option_symbol}")
                        print(f"   Entry price: {self.session_state.option_entry_price:.2f}")
                        print(f"   Current price: {opt_ltp:.2f}")
                        print(f"   Peak price: {self.session_state.peak_opt_price:.2f}")
                        print(f"   VIX at entry: {self.session_state.entry_vix:.2f}")
                        print(f"   SL %: {self.session_state.current_sl_pct*100:.2f}%")
                        print(f"   Fixed stop: {self.session_state.option_stop_price:.2f}")
                        print(f"   Trailing stop: {trailing_stop:.2f}")
                        print(f"   Target: {self.session_state.option_target_price:.2f}")
                    else:
                        print(f"\n{'📈 LONG' if pos == 'LONG' else '📉 SHORT'} POSITION ACTIVE (waiting for price)")
                else:
                    print(f"\n{'📈 LONG' if pos == 'LONG' else '📉 SHORT'} POSITION ACTIVE (no symbol)")
            elif len(self.session_state.residual_history) >= Config.ZSCORE_WINDOW:
                print(f"\n💤 FLAT - Ready for entry")
            else:
                print(f"\n💤 FLAT - Warming up")
            print("\n" + "="*120)
        except Exception as e:
            log_debug(f"Dashboard error: {e}")

# ============================================================
# SESSION STATE – updated with timestamp snapshots and last_signal
# ============================================================
class SessionState:
    def __init__(self):
        self.lock = threading.RLock()
        self.option_chain_api_count = 0
        self.quote_api_count = 0
        self.api_window_start = now_ist()
        self.cid = ""
        self.token = ""
        self._hb_lock = False
        self.daily_executed_orders = 0
        self.last_order_sync = None
        self.position = "FLAT"

        # Raw residual history for z-score
        self.residual_history = deque(maxlen=Config.ZSCORE_WINDOW)
        self.z_score_ema = None          # EMA of raw z-score

        # Timestamped price snapshots for accurate 60s window
        self._price_snapshots = deque(maxlen=Config.MOVE_WINDOW + 10)  # store (timestamp, record)

        self.live_ltp = {}
        self.live_vwap = {}
        self.live_volume = {}
        self.option_chain = []            # each dict now includes 'delta'
        self.fut_price = None
        self.expiry_date = None
        self.atm_strike = None
        self.option_symbols = []
        self.running = False
        # Option tracking
        self.held_option_symbol = None
        self.option_entry_price = 0.0
        self.option_stop_price = 0.0
        self.option_target_price = 0.0
        self.current_sl_pct = 0.0
        self.entry_vix = 0.0
        self.peak_opt_price = 0.0
        # India VIX
        self.india_vix = 15.0
        # Paper trading
        self.paper_realized_pnl = 0.0
        # Last computed metrics and signal
        self.last_metrics = None
        self.last_signal = "HOLD"
        # Signal change tracker (moved from global)
        self.last_signal_logged = None

    def update_ws(self, symbol, ltp, vwap, volume):
        with self.lock:
            if symbol == "NSE:INDIAVIX-INDEX":
                if ltp is not None:
                    self.india_vix = float(ltp)
                    log_debug(f"India VIX updated: {self.india_vix:.2f}")
                return
            if ltp is not None:
                self.live_ltp[symbol] = float(ltp)
            if vwap is not None:
                self.live_vwap[symbol] = float(vwap)
            if volume is not None:
                self.live_volume[symbol] = int(volume)
            log_debug(f"Updated {symbol}: LTP={ltp}, VWAP={vwap}, VOL={volume}")

    def get_ltp(self, symbol):
        with self.lock:
            return self.live_ltp.get(symbol)

    def get_vwap(self, symbol):
        with self.lock:
            return self.live_vwap.get(symbol)

    def get_volume(self, symbol):
        with self.lock:
            return self.live_volume.get(symbol)

    def update_chain(self, chain, fut_price, expiry_date, atm_strike, option_symbols):
        with self.lock:
            self.option_chain = chain
            self.fut_price = float(fut_price) if fut_price else 0.0
            self.expiry_date = expiry_date
            self.atm_strike = int(atm_strike) if atm_strike else None
            self.option_symbols = option_symbols
            log_debug(f"Chain updated: ATM={self.atm_strike}, fut={self.fut_price}, {len(option_symbols)} symbols")

    def sync_order_count(self, fyers):
        if PAPER_MODE:
            return
        today = now_ist().date()
        if self.last_order_sync != today:
            self.daily_executed_orders = 0
            self.last_order_sync = today
        try:
            resp = fyers.orderbook()
            if resp.get("s") == "ok":
                self.daily_executed_orders = len([o for o in resp.get("orderBook", []) if o.get("status") == 2])
        except Exception as e:
            log_debug(f"Order sync failed: {e}")

    def can_place_order(self, fyers=None):
        if PAPER_MODE:
            return self.daily_executed_orders < Config.MAX_DAILY_ORDERS
        if fyers:
            self.sync_order_count(fyers)
        return self.daily_executed_orders < Config.MAX_DAILY_ORDERS

# ============================================================
# MARKET WEBSOCKET MANAGER (unchanged)
# ============================================================
class MarketWSManager:
    def __init__(self, session_state, access_token):
        self.session = session_state
        self.access_token = access_token
        self.ws = None
        self.subscribed = set()
        self.running = False

    def on_message(self, message):
        symbol = message.get("symbol")
        if symbol:
            ltp = message.get("ltp")
            vwap = message.get("avg_trade_price")
            volume = message.get("vol_traded_today")
            self.session.update_ws(symbol, ltp, vwap, volume)

    def on_error(self, msg):
        log_console(f"WS error: {msg}")

    def on_close(self, msg):
        log_console(f"WS closed: {msg}")
        self.running = False

    def on_open(self):
        log_console("WebSocket connected")
        if self.subscribed:
            log_debug(f"Subscribing to {len(self.subscribed)} symbols")
            self.ws.subscribe(list(self.subscribed), "SymbolUpdate")
        self.ws.keep_running()

    def start(self):
        if self.running:
            return
        self.running = True
        self.ws = data_ws.FyersDataSocket(
            access_token=self.access_token,
            log_path="",
            litemode=False,
            write_to_file=False,
            reconnect=True,
            on_connect=self.on_open,
            on_close=self.on_close,
            on_error=self.on_error,
            on_message=self.on_message
        )
        self.ws.connect()
        log_debug("WebSocket started")

    def subscribe(self, symbols):
        new_symbols = set(symbols) - self.subscribed
        if new_symbols:
            log_debug(f"Subscribing to new symbols: {new_symbols}")
            if self.ws:
                self.ws.subscribe(list(new_symbols), "SymbolUpdate")
            self.subscribed.update(new_symbols)

    def stop(self):
        self.running = False
        if self.ws:
            self.ws.close_connection()

# ============================================================
# REST API HELPERS – parses delta from greeks
# ============================================================
def enforce_rate_limit(session):
    now = now_ist()
    window = (now - session.api_window_start).total_seconds()
    total = session.option_chain_api_count + session.quote_api_count
    if window > Config.API_WINDOW:
        session.api_window_start = now
        session.option_chain_api_count = 0
        session.quote_api_count = 0
    elif total >= Config.API_RATE_LIMIT:
        wait = Config.API_WINDOW - window
        if wait > 0:
            time.sleep(wait)
        session.api_window_start = now
        session.option_chain_api_count = 0
        session.quote_api_count = 0

@handle_errors
def fetch_option_chain(session, index_symbol):
    log_debug("Enter fetch_option_chain")
    enforce_rate_limit(session)
    session.option_chain_api_count += 2
    fy = fyersModel.FyersModel(client_id=session.cid, token=session.token, is_async=False, log_path="")
    meta = fy.optionchain(data={"symbol": index_symbol, "timestamp": ""})
    if meta.get("code") != 200:
        log_debug(f"Meta chain failed: {meta}")
        return None, None, None, None, []
    fut_price = None
    for item in meta["data"]["optionsChain"]:
        if item.get("option_type") == "":
            fut_price = item.get("fp")
            break
    if fut_price is None:
        fut_price = meta["data"].get("fp", 0.0)
    exp_list = sorted([(e["date"], e["expiry"]) for e in meta["data"]["expiryData"]],
                      key=lambda x: datetime.strptime(x[0], "%d-%m-%Y"))
    today = now_ist().date()
    idx = 0
    for i, (d_str, _) in enumerate(exp_list):
        if datetime.strptime(d_str, "%d-%m-%Y").date() >= today:
            idx = i
            break
    curr_date, expiry_ts = exp_list[idx]
    payload = {"symbol": index_symbol, "strikecount": 5, "timestamp": expiry_ts, "greeks": "1"}
    resp = fy.optionchain(data=payload)
    if resp.get("code") != 200:
        log_debug(f"Detailed chain failed: {resp}")
        return None, None, None, None, []
    chain = resp["data"]["optionsChain"]
    # Parse delta from greeks
    for opt in chain:
        greeks = opt.get("greeks", {})
        opt["delta"] = greeks.get("delta", 0.0) if greeks else 0.0
    option_symbols = [opt["symbol"] for opt in chain if opt.get("option_type") in ("CE","PE")]
    log_debug(f"Got {len(chain)} options, {len(option_symbols)} symbols")
    return chain, fut_price, curr_date, expiry_ts, option_symbols

# ============================================================
# CHAIN POLLER THREAD (unchanged)
# ============================================================
def chain_poller(session, ws_manager, index_symbol):
    log_debug("Chain poller thread started")
    while session.running:
        try:
            log_debug("Polling option chain...")
            chain, fut_price, expiry_date, _, opt_symbols = fetch_option_chain(session, index_symbol)
            if chain is None:
                log_debug("Chain fetch returned None")
            else:
                underlying_ltp = session.get_ltp(index_symbol)
                if underlying_ltp is None:
                    underlying_ltp = fut_price
                strikes = sorted(set(opt["strike_price"] for opt in chain if opt.get("option_type") in ("CE","PE")))
                if strikes and underlying_ltp:
                    atm = min(strikes, key=lambda x: abs(x - underlying_ltp))
                else:
                    atm = None
                session.update_chain(chain, fut_price, expiry_date, atm, opt_symbols)
                all_syms = [index_symbol] + opt_symbols
                ws_manager.subscribe(all_syms)
            time.sleep(Config.OPTION_CHAIN_INTERVAL)
        except Exception as e:
            log_debug(f"Chain poller error: {e}\n{traceback.format_exc()}")
            time.sleep(Config.OPTION_CHAIN_INTERVAL)

# ============================================================
# SIGNAL COMPUTATION – Residual → Z-score → EMA (with timestamped window)
# ============================================================
def compute_signal(session):
    log_debug(">>> compute_signal called")
    try:
        with session.lock:
            log_debug(">>> Lock acquired")
            spot = session.get_ltp("NSE:NIFTY50-INDEX")
            if spot is None:
                log_debug(">>> No spot LTP -> HOLD")
                session.last_metrics = {}
                session.last_signal = "HOLD"
                return "HOLD", {}

            if not session.option_chain or session.atm_strike is None:
                log_debug(">>> No option chain or ATM strike -> HOLD")
                session.last_metrics = {"spot": spot, "atm_strike": None}
                session.last_signal = "HOLD"
                return "HOLD", {"spot": spot, "atm_strike": None}

            atm_ce = next((o for o in session.option_chain if o["strike_price"] == session.atm_strike and o["option_type"] == "CE"), None)
            atm_pe = next((o for o in session.option_chain if o["strike_price"] == session.atm_strike and o["option_type"] == "PE"), None)
            if not atm_ce or not atm_pe:
                log_debug(">>> ATM CE/PE not found -> HOLD")
                session.last_metrics = {"spot": spot, "atm_strike": session.atm_strike}
                session.last_signal = "HOLD"
                return "HOLD", {"spot": spot, "atm_strike": session.atm_strike}

            ce_sym = atm_ce["symbol"]
            pe_sym = atm_pe["symbol"]

            ce_ltp = session.get_ltp(ce_sym)
            pe_ltp = session.get_ltp(pe_sym)
            if ce_ltp is None or pe_ltp is None:
                log_debug(">>> Missing CE/PE LTP -> HOLD")
                metrics = {"spot": spot, "atm_strike": session.atm_strike}
                session.last_metrics = metrics
                session.last_signal = "HOLD"
                return "HOLD", metrics

            ce_delta = atm_ce.get("delta", 0.0)
            pe_delta = atm_pe.get("delta", 0.0)

            # ---------- Store timestamped snapshot ----------
            now_ts = time.time()
            record = {
                "spot": spot,
                "ce_ltp": ce_ltp,
                "pe_ltp": pe_ltp,
                "ce_delta": ce_delta,
                "pe_delta": pe_delta,
            }
            session._price_snapshots.append((now_ts, record))

            metrics = {
                "spot": spot,
                "atm_strike": session.atm_strike,
                "ce_ltp": ce_ltp,
                "pe_ltp": pe_ltp,
                "ce_delta": ce_delta,
                "pe_delta": pe_delta,
                "spot_change": 0.0,
                "expected_ce": 0.0,
                "observed_ce": 0.0,
                "residual_ce": 0.0,
                "expected_pe": 0.0,
                "observed_pe": 0.0,
                "residual_pe": 0.0,
                "residual_diff": 0.0,
                "raw_z_score": 0.0,
                "smoothed_z_score": 0.0,
            }

            # ---------- Get snapshot from exactly MOVE_WINDOW seconds ago ----------
            if len(session._price_snapshots) < 2:
                log_debug(">>> Not enough snapshots -> HOLD")
                session.last_metrics = metrics
                session.last_signal = "HOLD"
                return "HOLD", metrics

            target_time = now_ts - Config.MOVE_WINDOW
            # Find the snapshot with timestamp closest to target_time
            best = None
            best_diff = float('inf')
            for ts, rec in session._price_snapshots:
                diff = abs(ts - target_time)
                if diff < best_diff:
                    best_diff = diff
                    best = rec
            if best is None:
                log_debug(">>> No suitable snapshot found -> HOLD")
                session.last_metrics = metrics
                session.last_signal = "HOLD"
                return "HOLD", metrics

            old = best
            spot_old = old["spot"]
            ce_ltp_old = old["ce_ltp"]
            pe_ltp_old = old["pe_ltp"]
            ce_delta_old = old["ce_delta"]
            pe_delta_old = old["pe_delta"]

            spot_change = spot - spot_old
            metrics["spot_change"] = spot_change

            expected_ce = ce_delta_old * spot_change
            expected_pe = pe_delta_old * spot_change
            observed_ce = ce_ltp - ce_ltp_old
            observed_pe = pe_ltp - pe_ltp_old
            residual_ce = observed_ce - expected_ce
            residual_pe = observed_pe - expected_pe
            residual_diff = residual_ce - residual_pe

            metrics.update({
                "expected_ce": expected_ce,
                "observed_ce": observed_ce,
                "residual_ce": residual_ce,
                "expected_pe": expected_pe,
                "observed_pe": observed_pe,
                "residual_pe": residual_pe,
                "residual_diff": residual_diff,
            })

            # ---------- Append residual to history (always) ----------
            session.residual_history.append(residual_diff)

            # ---------- Compute raw z-score only if we have enough samples ----------
            raw_z = 0.0
            if len(session.residual_history) >= Config.ZSCORE_WINDOW:
                mean = np.mean(session.residual_history)
                std = np.std(session.residual_history)
                if std > 1e-9:
                    raw_z = (residual_diff - mean) / std
            metrics["raw_z_score"] = raw_z

            # ---------- EMA of z-score (no zero-drag) ----------
            z_to_smooth = raw_z   # always use raw_z, no conditional zeroing
            alpha = 2.0 / (Config.Z_EMA_PERIOD + 1)
            if session.z_score_ema is None:
                session.z_score_ema = z_to_smooth
            else:
                session.z_score_ema = alpha * z_to_smooth + (1 - alpha) * session.z_score_ema
            smoothed_z = session.z_score_ema
            metrics["smoothed_z_score"] = smoothed_z

            # ---------- Exit logic (unchanged) ----------
            signal = "HOLD"
            intended = session.position

            if session.held_option_symbol is not None:
                now = now_ist()
                if now.hour > 15 or (now.hour == 15 and now.minute >= 15):
                    log_console("⏰ EOD Square-off Triggered")
                    signal = "EXIT"
                    intended = "FLAT"
                else:
                    opt_ltp = session.get_ltp(session.held_option_symbol)
                    if opt_ltp is not None:
                        exit_reason = None
                        if opt_ltp > session.peak_opt_price:
                            session.peak_opt_price = opt_ltp
                            log_debug(f"New peak: {session.peak_opt_price:.2f}")

                        trailing_stop = session.peak_opt_price * (1 - session.current_sl_pct)
                        fixed_stop = session.option_stop_price
                        target = session.option_target_price

                        if opt_ltp <= fixed_stop:
                            exit_reason = f"Fixed SL hit: {opt_ltp:.2f} <= {fixed_stop:.2f}"
                        elif opt_ltp <= trailing_stop:
                            exit_reason = f"Trailing SL hit: {opt_ltp:.2f} <= {trailing_stop:.2f} (peak: {session.peak_opt_price:.2f})"
                        elif opt_ltp >= target:
                            exit_reason = f"Target hit: {opt_ltp:.2f} >= {target:.2f}"

                        if exit_reason:
                            log_console(exit_reason)
                            signal = "EXIT"
                            intended = "FLAT"

            # ---------- Entry logic: smoothed z-score threshold ----------
            # Entry requires spot change >= MIN_SPOT_CHANGE AND enough z-score samples
            if session.position == "FLAT" and signal != "EXIT":
                if abs(spot_change) >= Config.MIN_SPOT_CHANGE and len(session.residual_history) >= Config.ZSCORE_WINDOW:
                    if smoothed_z > Config.ZSCORE_THRESHOLD:
                        log_debug(f">>> BUY (Long CE) triggered: smoothed_z={smoothed_z:.3f} > {Config.ZSCORE_THRESHOLD}")
                        signal = "BUY"
                        intended = "LONG"
                    elif smoothed_z < -Config.ZSCORE_THRESHOLD:
                        log_debug(f">>> SELL (Long PE) triggered: smoothed_z={smoothed_z:.3f} < -{Config.ZSCORE_THRESHOLD}")
                        signal = "SELL"
                        intended = "SHORT"
                else:
                    log_debug(f">>> Spot change {spot_change:.2f} or insufficient samples -> HOLD")

            session.last_metrics = metrics
            session.last_signal = signal
            log_debug(f">>> Returning signal={signal}, smoothed_z={smoothed_z:.3f}")
            return signal, metrics

    except Exception as e:
        log_debug(f"CRASH in compute_signal: {e}\n{traceback.format_exc()}")
        session.last_metrics = {}
        session.last_signal = "HOLD"
        return "HOLD", {}

# ============================================================
# ORDER PLACEMENT – paper simulation (with fixed segment)
# ============================================================
def place_order(session, signal, atm_ce, atm_pe, fyers, entry_metrics=None):
    if getattr(session, '_hb_lock', False):
        return False
    session._hb_lock = True
    try:
        if signal == "EXIT":
            log_console("🟡 EXIT signal – closing positions")
            if PAPER_MODE:
                if session.held_option_symbol:
                    current_ltp = session.get_ltp(session.held_option_symbol)
                    if current_ltp is not None:
                        pnl = (current_ltp - session.option_entry_price) * Config.LOT_SIZE
                        session.paper_realized_pnl += pnl
                        log_console(f"📊 Paper trade closed: P&L = {pnl:+.2f} (Total realized: {session.paper_realized_pnl:+.2f})")
                    else:
                        log_console("⚠️ Could not get current LTP for P&L; using last known price")
                        for opt in session.option_chain:
                            if opt["symbol"] == session.held_option_symbol:
                                current_ltp = opt.get("ltp", 0)
                                pnl = (current_ltp - session.option_entry_price) * Config.LOT_SIZE
                                session.paper_realized_pnl += pnl
                                log_console(f"📊 Paper trade closed (estimated): P&L = {pnl:+.2f}")
                                break
                session.position = "FLAT"
                session.held_option_symbol = None
                session.option_stop_price = 0.0
                session.option_target_price = 0.0
                session.peak_opt_price = 0.0
                log_console("✓ Paper positions closed")
                return True
            else:
                # Live exit – use FNO segment
                fyers.exit_positions(data={"segment": [Config.FNO_SEGMENT], "side": [-1], "productType": ["MARGIN"]})
                fyers.exit_positions(data={"segment": [Config.FNO_SEGMENT], "side": [1], "productType": ["MARGIN"]})
                time.sleep(2)
                session.position = "FLAT"
                session.held_option_symbol = None
                session.option_stop_price = 0.0
                session.option_target_price = 0.0
                session.peak_opt_price = 0.0
                log_console("✓ Positions closed")
                return True

        if signal in ("BUY","SELL") and session.can_place_order(fyers):
            leg = atm_ce if signal == "BUY" else atm_pe
            if not leg:
                return False

            if PAPER_MODE:
                current_opt_ltp = session.get_ltp(leg["symbol"])
                if current_opt_ltp is None:
                    for opt in session.option_chain:
                        if opt["symbol"] == leg["symbol"]:
                            current_opt_ltp = opt.get("ltp", 0)
                            break
                if current_opt_ltp is None or current_opt_ltp <= 0:
                    log_console("❌ Paper entry failed: invalid option price")
                    return False

                side = "LONG" if signal == "BUY" else "SHORT"
                session.position = side
                session.held_option_symbol = leg["symbol"]
                session.option_entry_price = current_opt_ltp
                session.entry_vix = session.india_vix

                sl_pct = (session.india_vix / 100.0) * Config.OPTION_TRAIL_MULTIPLIER
                sl_pct = max(0.01, sl_pct)
                session.current_sl_pct = sl_pct
                session.option_stop_price = current_opt_ltp * (1 - sl_pct)
                session.option_target_price = current_opt_ltp * (1 + Config.TARGET_MULTIPLIER * sl_pct)
                session.peak_opt_price = current_opt_ltp

                log_console(f"🟢 {signal} signal – PAPER {side} entry: {leg['symbol']} at {current_opt_ltp:.2f}")
                log_console(f"   VIX: {session.india_vix:.2f} -> SL% = {sl_pct*100:.2f}%")
                log_console(f"   Fixed stop: {session.option_stop_price:.2f}, Target: {session.option_target_price:.2f}")
                session.daily_executed_orders += 1
                log_console(f"✓ Paper {side} order placed successfully")
                return True
            else:
                order = {
                    "symbol": leg["symbol"],
                    "qty": Config.LOT_SIZE,
                    "type": 2,
                    "side": 1,
                    "productType": "MARGIN",
                    "validity": "DAY",
                }
                side = "LONG" if signal == "BUY" else "SHORT"
                log_console(f"🟢 {signal} signal – placing {side} order (buy {leg['symbol']})")
                resp = fyers.place_order(data=order)
                if resp.get("s") == "ok":
                    if signal == "BUY":
                        session.position = "LONG"
                    else:
                        session.position = "SHORT"
                    session.held_option_symbol = leg["symbol"]
                    current_opt_ltp = session.get_ltp(leg["symbol"]) or leg.get("ltp", 0)
                    session.option_entry_price = current_opt_ltp
                    session.entry_vix = session.india_vix
                    sl_pct = (session.india_vix / 100.0) * Config.OPTION_TRAIL_MULTIPLIER
                    sl_pct = max(0.01, sl_pct)
                    session.current_sl_pct = sl_pct
                    session.option_stop_price = current_opt_ltp * (1 - sl_pct)
                    session.option_target_price = current_opt_ltp * (1 + Config.TARGET_MULTIPLIER * sl_pct)
                    session.peak_opt_price = current_opt_ltp
                    log_console(f"{side} entry: {leg['symbol']} at {current_opt_ltp:.2f}")
                    log_console(f"   VIX: {session.india_vix:.2f} -> SL% = {sl_pct*100:.2f}%")
                    log_console(f"   Fixed stop: {session.option_stop_price:.2f}, Target: {session.option_target_price:.2f}")
                    log_console(f"✓ {side} order placed successfully")
                    return True
        return False
    except Exception as e:
        log_console(f"Order error: {e}")
        return False
    finally:
        session._hb_lock = False

# ============================================================
# SAMPLER THREAD – updated logging (no global)
# ============================================================
def sampler(session, data_logger, auto_trade, fyers):
    log_debug("Sampler thread started")
    while session.running:
        start = now_ist()
        try:
            signal, metrics = compute_signal(session)
            if metrics:
                opt_symbol = session.held_option_symbol if session.held_option_symbol else ''
                opt_entry = session.option_entry_price if session.held_option_symbol else 0.0
                opt_current = session.get_ltp(opt_symbol) if opt_symbol else 0.0
                opt_stop = session.option_stop_price if session.held_option_symbol else 0.0
                opt_target = session.option_target_price if session.held_option_symbol else 0.0
                peak = session.peak_opt_price if session.held_option_symbol else 0.0
                trailing_stop = peak * (1 - session.current_sl_pct) if session.held_option_symbol else 0.0
                vix = session.india_vix
                sl_pct = session.current_sl_pct if session.held_option_symbol else 0.0

                paper_pnl = session.paper_realized_pnl
                if session.position in ("LONG", "SHORT") and opt_current:
                    unrealized = (opt_current - opt_entry) * Config.LOT_SIZE
                    paper_pnl += unrealized

                data_logger.log_data(
                    timestamp=timestamp_ist(),
                    underlying_ltp=metrics.get("spot", 0),
                    fut_price=session.fut_price or 0,
                    signal=signal,
                    atm_strike=metrics.get("atm_strike", 0),
                    expiry_date=session.expiry_date or "",
                    ce_ltp=metrics.get("ce_ltp", 0),
                    pe_ltp=metrics.get("pe_ltp", 0),
                    ce_delta=metrics.get("ce_delta", 0),
                    pe_delta=metrics.get("pe_delta", 0),
                    spot_change=metrics.get("spot_change", 0),
                    expected_ce=metrics.get("expected_ce", 0),
                    observed_ce=metrics.get("observed_ce", 0),
                    residual_ce=metrics.get("residual_ce", 0),
                    expected_pe=metrics.get("expected_pe", 0),
                    observed_pe=metrics.get("observed_pe", 0),
                    residual_pe=metrics.get("residual_pe", 0),
                    residual_diff=metrics.get("residual_diff", 0),
                    raw_z_score=metrics.get("raw_z_score", 0),
                    smoothed_z_score=metrics.get("smoothed_z_score", 0),
                    position=session.position,
                    opt_symbol=opt_symbol,
                    opt_entry=opt_entry,
                    opt_current=opt_current,
                    opt_stop=opt_stop,
                    opt_target=opt_target,
                    trailing_stop=trailing_stop,
                    peak_opt_price=peak,
                    vix=vix,
                    sl_pct=sl_pct,
                    paper_pnl=paper_pnl
                )
                if signal != session.last_signal_logged and signal != "HOLD":
                    log_console(f"📢 Signal changed to: {signal}")
                    session.last_signal_logged = signal

            if auto_trade and signal in ("BUY","SELL","EXIT"):
                atm_ce = atm_pe = None
                if session.atm_strike:
                    for opt in session.option_chain:
                        if opt["strike_price"] == session.atm_strike:
                            if opt["option_type"] == "CE":
                                atm_ce = {"symbol": opt["symbol"]}
                            elif opt["option_type"] == "PE":
                                atm_pe = {"symbol": opt["symbol"]}
                if signal == "EXIT":
                    place_order(session, signal, None, None, fyers, None)
                elif signal == "BUY" and atm_ce:
                    place_order(session, signal, atm_ce, None, fyers, metrics)
                elif signal == "SELL" and atm_pe:
                    place_order(session, signal, None, atm_pe, fyers, metrics)
            elapsed = (now_ist() - start).total_seconds()
            if elapsed < Config.SAMPLE_INTERVAL:
                time.sleep(Config.SAMPLE_INTERVAL - elapsed)
        except Exception as e:
            log_debug(f"Sampler error: {e}\n{traceback.format_exc()}")
            time.sleep(1)

# ============================================================
# CREDENTIALS (unchanged)
# ============================================================
def load_credentials(session):
    try:
        with open('fyers_credentials.json', 'r') as f:
            creds = json.load(f)
            session.cid = creds.get('client_id', '')
            session.token = creds.get('access_token', '')
        log_console(f"Loaded credentials: {session.cid}")
    except Exception as e:
        session.cid = os.getenv("FYERS_CID", "")
        session.token = os.getenv("FYERS_TOKEN", "")
        log_console(f"Using env vars: {session.cid}")

# ============================================================
# MAIN (unchanged)
# ============================================================
def main():
    log_console("Starting Algo Trading System...")
    session = SessionState()
    load_credentials(session)
    data_logger = DataLogger()
    dashboard = TerminalDashboard(data_logger, session)
    index_symbol = "NSE:NIFTY50-INDEX"
    vix_symbol = "NSE:INDIAVIX-INDEX"

    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        print("="*50)
        mode = "PAPER" if PAPER_MODE else "LIVE"
        print(f"📈 FYERS ALGO TRADING ({mode} MODE)")
        print("1. Start Trading")
        print("2. Settings")
        print("3. Exit")
        choice = input("Select option: ").strip()
        if choice == "1":
            if not (session.cid and session.token):
                print("❌ Set credentials first")
                input("Press Enter...")
                continue
            auto_trade = input("Enable Auto Trade? (y/n): ").lower() == 'y'
            log_console(f"Auto trade: {'ON' if auto_trade else 'OFF'}")
            ws_manager = MarketWSManager(session, session.token)
            ws_manager.start()
            ws_manager.subscribe([index_symbol, vix_symbol])
            session.running = True
            threading.Thread(target=chain_poller, args=(session, ws_manager, index_symbol), daemon=True).start()
            fyers = fyersModel.FyersModel(client_id=session.cid, token=session.token, is_async=False, log_path="")
            threading.Thread(target=sampler, args=(session, data_logger, auto_trade, fyers), daemon=True).start()
            print("\n✅ Trading started. Press Ctrl+C to stop.\n")
            try:
                while True:
                    dashboard.display()
                    time.sleep(2)
            except KeyboardInterrupt:
                session.running = False
                ws_manager.stop()
                log_console("\n🛑 Trading stopped by user")
        elif choice == "2":
            print("\n⚙️ SETTINGS")
            new_cid = input(f"Client ID [{session.cid}]: ").strip()
            if new_cid:
                session.cid = new_cid
            new_token = input("Access token: ").strip()
            if new_token:
                session.token = new_token
            with open('fyers_credentials.json', 'w') as f:
                json.dump({"client_id": session.cid, "access_token": session.token}, f)
            print("✅ Saved")
            input("Press Enter...")
        elif choice == "3":
            break

if __name__ == "__main__":
    main()