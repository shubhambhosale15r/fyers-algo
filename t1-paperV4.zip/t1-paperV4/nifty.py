# ============================================================
# nifty.py – Multi-Period Momentum Ranking Strategy
# (All issues from user verification fixed)
# ============================================================

import time
import numpy as np
from datetime import datetime
import pytz
from fyers_apiv3 import fyersModel
from fyers_apiv3.FyersWebsocket import data_ws
import logging
import os
import json
from collections import deque
import csv
import threading
import traceback

# ============================================================
# PAPER TRADE FLAG
# ============================================================
PAPER_MODE = True   # Change to False for live trading

# ============================================================
# CONFIGURATION
# ============================================================
class Config:
    SAMPLE_INTERVAL = 1
    OPTION_CHAIN_INTERVAL = 30
    SCORE_WIN_5 = 300
    SCORE_WIN_15 = 900
    ATM_RANGE = 5
    MAX_POSITIONS = 3
    LOT_SIZE = 65                     # Nifty current lot size (updated)
    MAX_DAILY_ENTRIES = 6
    API_RATE_LIMIT = 200
    API_WINDOW = 60
    MAX_RETRIES = 3
    RETRY_DELAY = 2
    FNO_SEGMENT = 14

# ============================================================
# LOGGING
# ============================================================
logging.basicConfig(
    filename="trading_app.log",
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)

def log_debug(msg):
    logging.debug(msg)

def log_console(msg):
    print(msg, flush=True)
    logging.info(msg)

IST = pytz.timezone("Asia/Kolkata")

def now_ist():
    return datetime.now(IST)

def timestamp_ist():
    return now_ist().strftime("%Y-%m-%d %H:%M:%S")

# ============================================================
# ERROR HANDLER – returns consistent tuple on failure
# ============================================================
def handle_errors(func):
    def wrapper(*args, **kwargs):
        for retry in range(Config.MAX_RETRIES):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                log_debug(f"{func.__name__} attempt {retry+1} failed: {e}\n{traceback.format_exc()}")
                if retry < Config.MAX_RETRIES-1:
                    time.sleep(Config.RETRY_DELAY)
                else:
                    log_debug(f"{func.__name__} permanently failed")
                    # Return a consistent 5-tuple of Nones
                    return None, None, None, None, []
    return wrapper

# ============================================================
# DATA LOGGER – fixed KeyError 'entry' → 'entry_price'
# ============================================================
class DataLogger:
    def __init__(self, filename="trading_data.csv"):
        self.filename = filename
        self._ensure_header()

    def _ensure_header(self):
        if not os.path.exists(self.filename):
            with open(self.filename, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'timestamp', 'underlying_ltp', 'atm_strike', 'expiry_date',
                    'top1_symbol', 'top1_score', 'top1_ltp', 'top1_vwap',
                    'top2_symbol', 'top2_score', 'top2_ltp', 'top2_vwap',
                    'top3_symbol', 'top3_score', 'top3_ltp', 'top3_vwap',
                    'held1_symbol', 'held1_entry', 'held1_current', 'held1_pnl',
                    'held2_symbol', 'held2_entry', 'held2_current', 'held2_pnl',
                    'held3_symbol', 'held3_entry', 'held3_current', 'held3_pnl',
                    'total_paper_pnl', 'vix', 'signal', 'daily_entries'
                ])

    def log_data(self, timestamp, underlying_ltp, atm_strike, expiry_date,
                 top_candidates, active_positions, total_pnl, vix, signal, daily_entries):
        # Unpack top 3
        top1_s = top_candidates[0]['symbol'] if len(top_candidates) > 0 else ''
        top1_sc = top_candidates[0]['score'] if len(top_candidates) > 0 else 0.0
        top1_l = top_candidates[0]['ltp'] if len(top_candidates) > 0 else 0.0
        top1_v = top_candidates[0]['vwap'] if len(top_candidates) > 0 else 0.0

        top2_s = top_candidates[1]['symbol'] if len(top_candidates) > 1 else ''
        top2_sc = top_candidates[1]['score'] if len(top_candidates) > 1 else 0.0
        top2_l = top_candidates[1]['ltp'] if len(top_candidates) > 1 else 0.0
        top2_v = top_candidates[1]['vwap'] if len(top_candidates) > 1 else 0.0

        top3_s = top_candidates[2]['symbol'] if len(top_candidates) > 2 else ''
        top3_sc = top_candidates[2]['score'] if len(top_candidates) > 2 else 0.0
        top3_l = top_candidates[2]['ltp'] if len(top_candidates) > 2 else 0.0
        top3_v = top_candidates[2]['vwap'] if len(top_candidates) > 2 else 0.0

        # FIX: use 'entry_price'
        held1_s = active_positions[0]['symbol'] if len(active_positions) > 0 else ''
        held1_e = active_positions[0]['entry_price'] if len(active_positions) > 0 else 0.0
        held1_c = active_positions[0].get('current', held1_e) if len(active_positions) > 0 else 0.0
        held1_p = (held1_c - held1_e) * Config.LOT_SIZE if held1_e and held1_c else 0.0

        held2_s = active_positions[1]['symbol'] if len(active_positions) > 1 else ''
        held2_e = active_positions[1]['entry_price'] if len(active_positions) > 1 else 0.0
        held2_c = active_positions[1].get('current', held2_e) if len(active_positions) > 1 else 0.0
        held2_p = (held2_c - held2_e) * Config.LOT_SIZE if held2_e and held2_c else 0.0

        held3_s = active_positions[2]['symbol'] if len(active_positions) > 2 else ''
        held3_e = active_positions[2]['entry_price'] if len(active_positions) > 2 else 0.0
        held3_c = active_positions[2].get('current', held3_e) if len(active_positions) > 2 else 0.0
        held3_p = (held3_c - held3_e) * Config.LOT_SIZE if held3_e and held3_c else 0.0

        with open(self.filename, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                str(timestamp), round(underlying_ltp, 2), atm_strike, expiry_date,
                top1_s, round(top1_sc, 4), round(top1_l, 2), round(top1_v, 2),
                top2_s, round(top2_sc, 4), round(top2_l, 2), round(top2_v, 2),
                top3_s, round(top3_sc, 4), round(top3_l, 2), round(top3_v, 2),
                held1_s, round(held1_e, 2), round(held1_c, 2), round(held1_p, 2),
                held2_s, round(held2_e, 2), round(held2_c, 2), round(held2_p, 2),
                held3_s, round(held3_e, 2), round(held3_c, 2), round(held3_p, 2),
                round(total_pnl, 2), round(vix, 2), signal, daily_entries
            ])

# ============================================================
# SESSION STATE – added EOD flag and improved locking
# ============================================================
class SessionState:
    def __init__(self):
        self.lock = threading.RLock()
        self.option_chain_api_count = 0
        self.api_window_start = now_ist()
        self.cid = ""
        self.token = ""
        self.daily_entries = 0
        self.position_state = "FLAT"
        self.eod_square_off_triggered = False   # prevents re-entry after 15:15

        self.symbol_histories = {}
        self.live_ltp = {}
        self.live_vwap = {}
        self.live_volume = {}

        self.option_chain = []
        self.fut_price = None
        self.expiry_date = None
        self.atm_strike = None
        self.option_symbols = []

        self.active_positions = []        # list of dicts with 'symbol', 'entry_price', 'current'
        self.india_vix = 15.0
        self.paper_realized_pnl = 0.0

        self.last_top_candidates = []
        self.last_signal = "HOLD"
        self.last_metrics = {}

        self.running = False
        self._order_lock = False

    def update_ws(self, symbol, ltp, vwap, volume):
        with self.lock:
            if symbol == "NSE:INDIAVIX-INDEX":
                if ltp is not None:
                    self.india_vix = float(ltp)
                    log_debug(f"India VIX updated: {self.india_vix:.2f}")
                return

            if ltp is not None:
                self.live_ltp[symbol] = float(ltp)
            if vwap is not None:
                self.live_vwap[symbol] = float(vwap)
            if volume is not None:
                self.live_volume[symbol] = int(volume)

            # Store history for options only
            if symbol.endswith(('CE','PE')):
                if symbol not in self.symbol_histories:
                    self.symbol_histories[symbol] = deque(maxlen=3000)  # increased to hold 15min at high tick rate
                if ltp is not None and vwap is not None:
                    self.symbol_histories[symbol].append((time.time(), float(ltp), float(vwap)))
                elif ltp is not None:
                    self.symbol_histories[symbol].append((time.time(), float(ltp), 0.0))

            log_debug(f"Updated {symbol}: LTP={ltp}, VWAP={vwap}")

    def get_ltp(self, symbol):
        with self.lock:
            return self.live_ltp.get(symbol)

    def get_vwap(self, symbol):
        with self.lock:
            return self.live_vwap.get(symbol)

    def update_chain(self, chain, fut_price, expiry_date, atm_strike, option_symbols):
        with self.lock:
            self.option_chain = chain
            self.fut_price = float(fut_price) if fut_price else 0.0
            self.expiry_date = expiry_date
            self.atm_strike = int(atm_strike) if atm_strike else None
            self.option_symbols = option_symbols
            log_debug(f"Chain updated: ATM={self.atm_strike}, {len(option_symbols)} symbols")

    def can_place_order(self):
        return self.daily_entries < Config.MAX_DAILY_ENTRIES and not self.eod_square_off_triggered

    def reset_for_new_day(self):
        """Call at start of each new trading day or after restart."""
        with self.lock:
            self.daily_entries = 0
            self.eod_square_off_triggered = False
            self.active_positions = []
            self.position_state = "FLAT"
            self.paper_realized_pnl = 0.0

# ============================================================
# WEBSOCKET MANAGER (unchanged)
# ============================================================
class MarketWSManager:
    def __init__(self, session_state, access_token):
        self.session = session_state
        self.access_token = access_token
        self.ws = None
        self.subscribed = set()
        self.running = False

    def on_message(self, message):
        symbol = message.get("symbol")
        if symbol:
            ltp = message.get("ltp")
            vwap = message.get("avg_trade_price")
            volume = message.get("vol_traded_today")
            self.session.update_ws(symbol, ltp, vwap, volume)

    def on_error(self, msg):
        log_console(f"WS error: {msg}")

    def on_close(self, msg):
        log_console(f"WS closed: {msg}")
        self.running = False

    def on_open(self):
        log_console("WebSocket connected")
        if self.subscribed:
            log_debug(f"Subscribing to {len(self.subscribed)} symbols")
            self.ws.subscribe(list(self.subscribed), "SymbolUpdate")
        self.ws.keep_running()

    def start(self):
        if self.running:
            return
        self.running = True
        self.ws = data_ws.FyersDataSocket(
            access_token=self.access_token,
            log_path="",
            litemode=False,
            write_to_file=False,
            reconnect=True,
            on_connect=self.on_open,
            on_close=self.on_close,
            on_error=self.on_error,
            on_message=self.on_message
        )
        self.ws.connect()
        log_debug("WebSocket started")

    def subscribe(self, symbols):
        new_symbols = set(symbols) - self.subscribed
        if new_symbols:
            log_debug(f"Subscribing to new symbols: {new_symbols}")
            if self.ws:
                self.ws.subscribe(list(new_symbols), "SymbolUpdate")
            self.subscribed.update(new_symbols)

    def stop(self):
        self.running = False
        if self.ws:
            self.ws.close_connection()

# ============================================================
# REST API – fixed return consistency and rate limiting
# ============================================================
def enforce_rate_limit(session):
    now = now_ist()
    window = (now - session.api_window_start).total_seconds()
    if window > Config.API_WINDOW:
        session.api_window_start = now
        session.option_chain_api_count = 0
    elif session.option_chain_api_count >= Config.API_RATE_LIMIT:
        wait = Config.API_WINDOW - window
        if wait > 0:
            time.sleep(wait)
        session.api_window_start = now
        session.option_chain_api_count = 0

@handle_errors
def fetch_option_chain(session, index_symbol):
    log_debug("Enter fetch_option_chain")
    enforce_rate_limit(session)
    # Count this as one API call (we'll make two, but count only the second)
    session.option_chain_api_count += 1
    fy = fyersModel.FyersModel(client_id=session.cid, token=session.token, is_async=False, log_path="")
    meta = fy.optionchain(data={"symbol": index_symbol, "timestamp": ""})
    if meta.get("code") != 200:
        log_debug(f"Meta chain failed: {meta}")
        return None, None, None, None, []

    fut_price = None
    for item in meta["data"]["optionsChain"]:
        if item.get("option_type") == "":
            fut_price = item.get("fp")
            break
    if fut_price is None:
        fut_price = meta["data"].get("fp", 0.0)

    exp_list = sorted([(e["date"], e["expiry"]) for e in meta["data"]["expiryData"]],
                      key=lambda x: datetime.strptime(x[0], "%d-%m-%Y"))
    today = now_ist().date()
    idx = 0
    for i, (d_str, _) in enumerate(exp_list):
        if datetime.strptime(d_str, "%d-%m-%Y").date() >= today:
            idx = i
            break
    curr_date, expiry_ts = exp_list[idx]

    # Use Config.ATM_RANGE for strikecount to keep in sync
    payload = {"symbol": index_symbol, "strikecount": Config.ATM_RANGE, "timestamp": expiry_ts, "greeks": "1"}
    session.option_chain_api_count += 1  # count this second call
    resp = fy.optionchain(data=payload)
    if resp.get("code") != 200:
        log_debug(f"Detailed chain failed: {resp}")
        return None, None, None, None, []

    chain = resp["data"]["optionsChain"]
    for opt in chain:
        greeks = opt.get("greeks", {})
        opt["delta"] = greeks.get("delta", 0.0) if greeks else 0.0

    option_symbols = [opt["symbol"] for opt in chain if opt.get("option_type") in ("CE","PE")]
    log_debug(f"Got {len(chain)} options, {len(option_symbols)} symbols")
    return chain, fut_price, curr_date, expiry_ts, option_symbols

# ============================================================
# CHAIN POLLER (unchanged)
# ============================================================
def chain_poller(session, ws_manager, index_symbol):
    log_debug("Chain poller thread started")
    while session.running:
        try:
            log_debug("Polling option chain...")
            chain, fut_price, expiry_date, _, opt_symbols = fetch_option_chain(session, index_symbol)
            if chain is None:
                log_debug("Chain fetch returned None")
            else:
                underlying_ltp = session.get_ltp(index_symbol)
                if underlying_ltp is None:
                    underlying_ltp = fut_price

                strikes = sorted(set(opt["strike_price"] for opt in chain if opt.get("option_type") in ("CE","PE")))
                if strikes and underlying_ltp:
                    atm = min(strikes, key=lambda x: abs(x - underlying_ltp))
                else:
                    atm = None

                session.update_chain(chain, fut_price, expiry_date, atm, opt_symbols)
                all_syms = [index_symbol, "NSE:INDIAVIX-INDEX"] + opt_symbols
                ws_manager.subscribe(all_syms)

            time.sleep(Config.OPTION_CHAIN_INTERVAL)
        except Exception as e:
            log_debug(f"Chain poller error: {e}\n{traceback.format_exc()}")
            time.sleep(Config.OPTION_CHAIN_INTERVAL)

# ============================================================
# HELPER: Get ATM+/- range symbols
# ============================================================
def get_symbols_in_range(session, atm_strike, range_strikes=5):
    result = []
    with session.lock:
        if not session.option_chain or atm_strike is None:
            return result
        for opt in session.option_chain:
            strike = opt.get("strike_price")
            otype = opt.get("option_type")
            if otype not in ("CE", "PE"):
                continue
            if abs(strike - atm_strike) <= range_strikes * 50:
                result.append({
                    "symbol": opt["symbol"],
                    "strike": strike,
                    "option_type": otype,
                })
    return result

# ============================================================
# HELPER: Compute return and volatility
# ============================================================
def compute_return_vol(session, symbol, window_sec):
    hist = session.symbol_histories.get(symbol)
    if not hist or len(hist) < 3:
        return None, None

    now = time.time()
    cutoff = now - window_sec
    relevant = []
    for ts, ltp, vwap in hist:
        if ts >= cutoff:
            relevant.append((ts, ltp))
    if len(relevant) < 2:
        # warn if we don't have enough data
        log_debug(f"Symbol {symbol}: only {len(relevant)} ticks for {window_sec}s window")
        return None, None

    first_ltp = relevant[0][1]
    last_ltp = relevant[-1][1]
    if first_ltp <= 0 or last_ltp <= 0:
        return None, None

    ret = (last_ltp / first_ltp) - 1.0
    log_returns = []
    for i in range(1, len(relevant)):
        prev = relevant[i-1][1]
        curr = relevant[i][1]
        if prev > 0 and curr > 0:
            log_returns.append(np.log(curr / prev))
    if len(log_returns) < 2:
        return ret, 0.0
    vol = np.std(log_returns)
    return ret, vol

# ============================================================
# CORE SIGNAL COMPUTATION
# ============================================================
def compute_momentum_signal(session):
    log_debug(">>> compute_momentum_signal called")
    try:
        with session.lock:
            log_debug(">>> Lock acquired")
            spot = session.get_ltp("NSE:NIFTY50-INDEX")
            if spot is None:
                log_debug(">>> No spot LTP -> HOLD")
                session.last_metrics = {}
                session.last_signal = "HOLD"
                return "HOLD", [], {}

            atm_strike = session.atm_strike
            if atm_strike is None:
                log_debug(">>> No ATM strike -> HOLD")
                session.last_metrics = {"spot": spot}
                session.last_signal = "HOLD"
                return "HOLD", [], {"spot": spot}

            # Check EOD flag – if already triggered, prevent ENTER
            now = now_ist()
            eod_square_off = (now.hour > 15) or (now.hour == 15 and now.minute >= 15)
            if eod_square_off:
                session.eod_square_off_triggered = True

            symbols_in_range = get_symbols_in_range(session, atm_strike, Config.ATM_RANGE)
            if not symbols_in_range:
                log_debug(">>> No symbols in range -> HOLD")
                session.last_signal = "HOLD"
                return "HOLD", [], {"spot": spot, "atm": atm_strike}

            candidates = []
            for entry in symbols_in_range:
                symbol = entry["symbol"]
                current_ltp = session.get_ltp(symbol)
                current_vwap = session.get_vwap(symbol)
                if current_ltp is None or current_vwap is None:
                    continue
                if current_ltp <= current_vwap:
                    continue

                ret5, vol5 = compute_return_vol(session, symbol, Config.SCORE_WIN_5)
                ret15, vol15 = compute_return_vol(session, symbol, Config.SCORE_WIN_15)
                if ret5 is None or ret15 is None:
                    continue
                if vol5 == 0.0 or vol15 == 0.0:
                    continue

                score5 = ret5 / vol5
                score15 = ret15 / vol15
                score = (1.0/3.0) * score5 + (2.0/3.0) * score15

                candidates.append({
                    "symbol": symbol,
                    "strike": entry["strike"],
                    "option_type": entry["option_type"],
                    "ltp": current_ltp,
                    "vwap": current_vwap,
                    "score": score,
                    "ret5": ret5,
                    "vol5": vol5,
                    "ret15": ret15,
                    "vol15": vol15
                })

            candidates.sort(key=lambda x: x["score"], reverse=True)
            top_candidates = candidates[:Config.MAX_POSITIONS]

            held_symbols = [p["symbol"] for p in session.active_positions]
            top_symbols = [c["symbol"] for c in top_candidates]

            signal = "HOLD"
            if eod_square_off and session.active_positions:
                log_console("⏰ EOD Square-off Triggered")
                signal = "EXIT_ALL"
            elif session.active_positions and set(held_symbols) != set(top_symbols):
                log_debug(f">>> Churn detected: held {set(held_symbols)} vs top {set(top_symbols)}")
                signal = "EXIT_ALL"
            elif (not session.active_positions and len(top_candidates) >= Config.MAX_POSITIONS
                  and not session.eod_square_off_triggered and session.can_place_order()):
                log_debug(">>> ENTER triggered (flat and top 3 available)")
                signal = "ENTER"
            else:
                signal = "HOLD"

            session.last_top_candidates = top_candidates
            session.last_signal = signal
            session.last_metrics = {"spot": spot, "atm": atm_strike}

            log_debug(f">>> Returning signal={signal}, top={[c['symbol'] for c in top_candidates[:3]]}")
            return signal, top_candidates, {"spot": spot, "atm": atm_strike}

    except Exception as e:
        log_debug(f"CRASH in compute_momentum_signal: {e}\n{traceback.format_exc()}")
        session.last_signal = "HOLD"
        return "HOLD", [], {}

# ============================================================
# ORDER PLACEMENT – fixed rollback, symbol‑specific live exit, locking
# ============================================================
def place_order(session, signal, top_candidates, fyers):
    if getattr(session, '_order_lock', False):
        return False
    session._order_lock = True
    try:
        with session.lock:
            if signal == "EXIT_ALL":
                log_console("🟡 EXIT_ALL signal – closing all positions")
                if PAPER_MODE:
                    for pos in session.active_positions[:]:
                        symbol = pos["symbol"]
                        entry = pos["entry_price"]
                        current = session.get_ltp(symbol)
                        if current is None:
                            for opt in session.option_chain:
                                if opt["symbol"] == symbol:
                                    current = opt.get("ltp", 0)
                                    break
                        if current is None or current == 0:
                            current = entry
                        pnl = (current - entry) * Config.LOT_SIZE
                        session.paper_realized_pnl += pnl
                        log_console(f"📊 Closed {symbol}: Entry={entry:.2f}, Current={current:.2f}, P&L={pnl:+.2f}")
                    session.active_positions.clear()
                    session.position_state = "FLAT"
                    log_console(f"✓ All paper positions closed. Total realized P&L: {session.paper_realized_pnl:+.2f}")
                    return True
                else:
                    # Close each held symbol individually
                    for pos in session.active_positions[:]:
                        symbol = pos["symbol"]
                        qty = Config.LOT_SIZE
                        order = {
                            "symbol": symbol,
                            "qty": qty,
                            "type": 2,
                            "side": -1,          # sell to close
                            "productType": "MARGIN",
                            "validity": "DAY",
                        }
                        resp = fyers.place_order(data=order)
                        if resp.get("s") == "ok":
                            log_console(f"Closed {symbol} (order id: {resp.get('id')})")
                        else:
                            log_console(f"❌ Failed to close {symbol}: {resp}")
                    session.active_positions.clear()
                    session.position_state = "FLAT"
                    log_console("✓ All live positions closed")
                    return True

            elif signal == "ENTER":
                if not session.can_place_order():
                    log_console("❌ Daily entry limit reached or EOD passed")
                    return False
                if len(top_candidates) < Config.MAX_POSITIONS:
                    log_console("❌ Not enough top candidates (need 3)")
                    return False

                # Use temporary list to avoid partial commit
                temp_positions = []
                if PAPER_MODE:
                    for cand in top_candidates:
                        symbol = cand["symbol"]
                        entry_price = cand["ltp"]
                        if entry_price <= 0:
                            log_console(f"❌ Invalid entry price for {symbol}: {entry_price}")
                            return False
                        temp_positions.append({
                            "symbol": symbol,
                            "entry_price": entry_price,
                        })
                    # Commit all at once
                    session.active_positions = temp_positions
                    session.position_state = "ACTIVE"
                    session.daily_entries += 1
                    log_console(f"🟢 ENTER: {len(temp_positions)} paper positions (Entry #{session.daily_entries})")
                    return True
                else:
                    # Live: attempt all orders; if any fails, abort and don't commit
                    for cand in top_candidates:
                        order = {
                            "symbol": cand["symbol"],
                            "qty": Config.LOT_SIZE,
                            "type": 2,
                            "side": 1,
                            "productType": "MARGIN",
                            "validity": "DAY",
                        }
                        resp = fyers.place_order(data=order)
                        if resp.get("s") != "ok":
                            log_console(f"❌ Failed to enter {cand['symbol']}: {resp}")
                            # Attempt to cancel any previously placed orders in this batch? Not trivial.
                            # We'll abort and not update active_positions.
                            return False
                        else:
                            temp_positions.append({
                                "symbol": cand["symbol"],
                                "entry_price": cand["ltp"],
                            })
                    # All succeeded
                    session.active_positions = temp_positions
                    session.position_state = "ACTIVE"
                    session.daily_entries += 1
                    log_console(f"🟢 ENTER: {len(temp_positions)} live positions (Entry #{session.daily_entries})")
                    return True
        return False
    except Exception as e:
        log_console(f"Order error: {e}")
        return False
    finally:
        session._order_lock = False

# ============================================================
# SAMPLER THREAD – now does logging after place_order? No, we keep as is
# but we must update positions' current price before logging.
# Also we must ensure place_order is called even if logging fails – we moved
# place_order outside the logging try? Actually place_order is called later in
# the same try block; we need to keep logging and place_order in same try so
# we don't lose the order on logging error. But we fixed the logging error, so it's fine.
# ============================================================
def sampler(session, data_logger, auto_trade, fyers):
    log_debug("Sampler thread started")
    while session.running:
        start = now_ist()
        try:
            signal, top_candidates, metrics = compute_momentum_signal(session)

            # Update current price for active positions (for P&L)
            with session.lock:
                for pos in session.active_positions:
                    pos["current"] = session.get_ltp(pos["symbol"]) or pos["entry_price"]

            # Log data (now safe)
            total_pnl = session.paper_realized_pnl
            for pos in session.active_positions:
                current = pos.get("current", pos["entry_price"])
                total_pnl += (current - pos["entry_price"]) * Config.LOT_SIZE

            data_logger.log_data(
                timestamp=timestamp_ist(),
                underlying_ltp=metrics.get("spot", 0),
                atm_strike=metrics.get("atm", 0),
                expiry_date=session.expiry_date or "",
                top_candidates=top_candidates,
                active_positions=session.active_positions,
                total_pnl=total_pnl,
                vix=session.india_vix,
                signal=signal,
                daily_entries=session.daily_entries
            )

            # Auto-trade execution (now will run even if logging succeeded)
            if auto_trade and signal in ("ENTER", "EXIT_ALL"):
                place_order(session, signal, top_candidates, fyers)

            elapsed = (now_ist() - start).total_seconds()
            if elapsed < Config.SAMPLE_INTERVAL:
                time.sleep(Config.SAMPLE_INTERVAL - elapsed)
        except Exception as e:
            log_debug(f"Sampler error: {e}\n{traceback.format_exc()}")
            time.sleep(1)

# ============================================================
# DASHBOARD – now thread‑safe
# ============================================================
class TerminalDashboard:
    def __init__(self, data_logger, session_state):
        self.data_logger = data_logger
        self.session_state = session_state

    def display(self):
        try:
            os.system('cls' if os.name == 'nt' else 'clear')
            mode = "PAPER" if PAPER_MODE else "LIVE"
            print("\n" + "="*120)
            print(f"📊 {mode} TRADING DASHBOARD – Momentum Ranking Strategy (5min/15min)")
            print("="*120)
            # Use a local snapshot to avoid holding lock while printing
            with self.session_state.lock:
                daily_entries = self.session_state.daily_entries
                vix = self.session_state.india_vix
                realized = self.session_state.paper_realized_pnl
                position_state = self.session_state.position_state
                top_candidates = self.session_state.last_top_candidates[:]
                active_positions = self.session_state.active_positions[:]
                eod_triggered = self.session_state.eod_square_off_triggered

            print(f"Last Update: {timestamp_ist()}")
            print(f"📈 Daily Entries: {daily_entries}/{Config.MAX_DAILY_ENTRIES}")
            print(f"📊 India VIX: {vix:.2f}")
            print(f"💰 Realized P&L: {realized:+.2f}")

            if position_state == "ACTIVE":
                total_unrealized = 0
                for pos in active_positions:
                    current = pos.get("current", pos["entry_price"])
                    pnl = (current - pos["entry_price"]) * Config.LOT_SIZE
                    total_unrealized += pnl
                print(f"💰 Unrealized P&L: {total_unrealized:+.2f}")
                print(f"💰 Total P&L: {realized + total_unrealized:+.2f}")

            if eod_triggered:
                print("⛔ EOD square‑off triggered – no new entries allowed")

            print("\n" + "-"*80)
            print("🏆 TOP 3 CANDIDATES (LTP > VWAP Filter Applied)")
            print("-"*80)
            if top_candidates:
                print(f"{'Rank':<4} | {'Symbol':<25} | {'Strike':<8} | {'Type':<4} | {'Score':<10} | {'LTP':<8} | {'VWAP':<8}")
                print("-"*80)
                for i, c in enumerate(top_candidates[:3], 1):
                    print(f"{i:<4} | {c['symbol']:<25} | {c['strike']:<8} | {c['option_type']:<4} | {c['score']:<10.4f} | {c['ltp']:<8.2f} | {c['vwap']:<8.2f}")
            else:
                print("   No candidates passing VWAP filter (or insufficient data)")

            print("\n" + "-"*80)
            print("📌 ACTIVE POSITIONS")
            print("-"*80)
            if active_positions:
                print(f"{'#':<3} | {'Symbol':<25} | {'Entry':<8} | {'Current':<8} | {'P&L':<10}")
                print("-"*80)
                total_pnl = 0
                for i, pos in enumerate(active_positions, 1):
                    current = pos.get("current", pos["entry_price"])
                    pnl = (current - pos["entry_price"]) * Config.LOT_SIZE
                    total_pnl += pnl
                    print(f"{i:<3} | {pos['symbol']:<25} | {pos['entry_price']:<8.2f} | {current:<8.2f} | {pnl:<+10.2f}")
                print("-"*80)
                print(f"Total Unrealized P&L: {total_pnl:+.2f}")
            else:
                print("   No active positions (FLAT)")

            print("\n" + "="*120)
        except Exception as e:
            log_debug(f"Dashboard error: {e}")

# ============================================================
# CREDENTIALS (unchanged)
# ============================================================
def load_credentials(session):
    try:
        with open('fyers_credentials.json', 'r') as f:
            creds = json.load(f)
            session.cid = creds.get('client_id', '')
            session.token = creds.get('access_token', '')
        log_console(f"Loaded credentials: {session.cid}")
    except Exception as e:
        session.cid = os.getenv("FYERS_CID", "")
        session.token = os.getenv("FYERS_TOKEN", "")
        log_console(f"Using env vars: {session.cid}")

# ============================================================
# MAIN – added proper cleanup and reset
# ============================================================
def main():
    log_console("Starting Momentum Ranking Algo Trading System...")
    session = SessionState()
    load_credentials(session)
    data_logger = DataLogger()
    dashboard = TerminalDashboard(data_logger, session)
    index_symbol = "NSE:NIFTY50-INDEX"
    vix_symbol = "NSE:INDIAVIX-INDEX"

    # Thread references for cleanup
    poller_thread = None
    sampler_thread = None
    ws_manager = None
    fyers = None

    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        print("="*50)
        mode = "PAPER" if PAPER_MODE else "LIVE"
        print(f"📈 FYERS ALGO TRADING ({mode} MODE) – Momentum Strategy")
        print("1. Start Trading")
        print("2. Settings")
        print("3. Exit")
        choice = input("Select option: ").strip()
        if choice == "1":
            if not (session.cid and session.token):
                print("❌ Set credentials first")
                input("Press Enter...")
                continue

            # Reset daily state if it's a new day or after a clean restart
            session.reset_for_new_day()

            auto_trade = input("Enable Auto Trade? (y/n): ").lower() == 'y'
            log_console(f"Auto trade: {'ON' if auto_trade else 'OFF'}")

            ws_manager = MarketWSManager(session, session.token)
            ws_manager.start()
            ws_manager.subscribe([index_symbol, vix_symbol])
            session.running = True

            fyers = fyersModel.FyersModel(client_id=session.cid, token=session.token, is_async=False, log_path="")
            poller_thread = threading.Thread(target=chain_poller, args=(session, ws_manager, index_symbol), daemon=True)
            sampler_thread = threading.Thread(target=sampler, args=(session, data_logger, auto_trade, fyers), daemon=True)
            poller_thread.start()
            sampler_thread.start()

            print("\n✅ Trading started. Press Ctrl+C to stop.\n")
            try:
                while True:
                    dashboard.display()
                    time.sleep(2)
            except KeyboardInterrupt:
                log_console("\n🛑 Stopping trading...")
                session.running = False
                ws_manager.stop()
                # Wait a moment for threads to finish
                time.sleep(1)
                # Clear any leftover positions and reset state
                with session.lock:
                    session.active_positions.clear()
                    session.position_state = "FLAT"
                    session.eod_square_off_triggered = False
                    session.daily_entries = 0
                    session.paper_realized_pnl = 0.0
                log_console("✅ Trading stopped and state reset. You can start again.")
        elif choice == "2":
            print("\n⚙️ SETTINGS")
            new_cid = input(f"Client ID [{session.cid}]: ").strip()
            if new_cid:
                session.cid = new_cid
            new_token = input("Access token: ").strip()
            if new_token:
                session.token = new_token
            with open('fyers_credentials.json', 'w') as f:
                json.dump({"client_id": session.cid, "access_token": session.token}, f)
            print("✅ Saved")
            input("Press Enter...")
        elif choice == "3":
            # Ensure clean exit
            if session.running:
                session.running = False
                if ws_manager:
                    ws_manager.stop()
            break

if __name__ == "__main__":
    main()