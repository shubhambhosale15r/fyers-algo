#!/usr/bin/env python3
"""
ATM CE/PE Option Efficiency Logger – FULL COLUMNS + SMOOTH INTERPOLATION
Eliminates spikes while preserving all original data fields.
"""

import os, sys, time, math, datetime, logging, pandas as pd
from typing import Dict, List, Tuple, Optional
from fyers_apiv3 import fyersModel

# ----------------------------- CONFIGURATION -----------------------------
CLIENT_ID = "J0ENYFX9ME-200"          # e.g., "ABCDEF-1234"
SECRET_KEY = "3ei40I8iN5nMWxWL"        # e.g., "XXXXXXXXXXXX" (not actually used for API, but keep)
ACCESS_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOlsiZDoxIiwiZDoyIiwieDowIiwieDoxIiwieDoyIl0sImF0X2hhc2giOiJnQUFBQUFCcWFDbkxmSUQtTXlBWjJFWmJtNjlLcWg1bVFITFFSYUdJd3F4aVBwMG1nbUZlQWFLTzZ2T2d6ZDVLaW5oWjR5UllvZk9kT0hrQ3FCYkQxaEFCckhvdjhCSFhBck15SlVYRTJwUlMtRG5Id0hPS0xJND0iLCJkaXNwbGF5X25hbWUiOiIiLCJvbXMiOiJLMSIsImhzbV9rZXkiOiI3MGYzYjMwZTE4YzNhNDlhY2MyMzQxMjU4OTEzOWE1Yzk3MDkyMTljNWQ3NzE5ZWYxNTg5ZDM3ZiIsImlzRGRwaUVuYWJsZWQiOiJOIiwiaXNNdGZFbmFibGVkIjoiTiIsImZ5X2lkIjoiRkFBMzE0OTUiLCJhcHBUeXBlIjoyMDAsImV4cCI6MTc4NTI4NTAwMCwiaWF0IjoxNzg1MjExMzM5LCJpc3MiOiJhcGkuZnllcnMuaW4iLCJuYmYiOjE3ODUyMTEzMzksInN1YiI6ImFjY2Vzc190b2tlbiJ9.dVZflCdoeWeFAqFHt87mh73zk1ydLv4EFrqbtgbG11Y"

INDEX = "NIFTY"

INDEX_CONFIG = {
    "NIFTY": {"strike_interval": 50, "symbol": "NSE:NIFTY50-INDEX"},
    "BANKNIFTY": {"strike_interval": 100, "symbol": "NSE:BANKNIFTY-INDEX"},
    "FINNIFTY": {"strike_interval": 50, "symbol": "NSE:FINNIFTY-INDEX"},
}

CSV_FILE = f"option_efficiency_{INDEX}.csv"

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# ----------------------------- FYERS CLIENT -----------------------------
fyers = fyersModel.FyersModel(
    client_id=CLIENT_ID,
    token=ACCESS_TOKEN,
    is_async=False,
    log_path="",
)

# ----------------------------- API HELPERS -----------------------------

def fetch_option_chain(expiry_timestamp: str = "", strikecount: int = 50) -> Dict:
    data = {
        "symbol": INDEX_CONFIG[INDEX]["symbol"],
        "strikecount": strikecount,
        "timestamp": expiry_timestamp,
        "greeks": "1"
    }
    response = fyers.optionchain(data=data)
    if response.get("code") != 200:
        raise RuntimeError(f"Option chain API failed: {response}")
    return response.get("data", {})

def get_expiry_list(chain_data: Dict) -> List[Dict]:
    return chain_data.get("expiryData", [])

def parse_expiry_date(date_str: str) -> datetime.date:
    return datetime.datetime.strptime(date_str, "%d-%m-%Y").date()

def get_nearest_expiry(expiry_data: List[Dict]) -> str:
    today = datetime.date.today()
    valid = []
    for item in expiry_data:
        date_str = item.get("date")
        ts = item.get("expiry")
        if date_str and ts:
            dt = parse_expiry_date(date_str)
            if dt >= today:
                valid.append((dt, ts))
    if valid:
        valid.sort(key=lambda x: x[0])
        return valid[0][1]
    if expiry_data:
        return expiry_data[0]["expiry"]
    raise RuntimeError("No expiry data available.")

def get_underlying_ltp(chain_data: Dict) -> float:
    for item in chain_data.get("optionsChain", []):
        if item.get("option_type") == "" and item.get("strike_price") == -1:
            ltp = item.get("ltp")
            if ltp is not None:
                return float(ltp)
    raise RuntimeError("Underlying LTP not found.")

def get_option_by_strike(options: List[Dict], strike: int, opt_type: str) -> Optional[Dict]:
    for o in options:
        if o.get("strike_price") == strike and o.get("option_type") == opt_type:
            return o
    return None

def compute_score_from_ltp_greeks(ltp: float, delta: float, gamma: float, theta: float) -> float:
    if None in (ltp, delta, gamma, theta) or ltp == 0 or abs(theta) == 0:
        return 0.0
    return (abs(delta) * gamma) / (ltp * abs(theta))

def interpolate_option_data(opt_low: Dict, opt_high: Dict, weight: float) -> Dict:
    """Interpolate premium and all Greeks between two option objects."""
    g_low = opt_low.get("greeks", {})
    g_high = opt_high.get("greeks", {})
    
    return {
        "symbol": opt_low.get("symbol", ""),  # symbol will change at boundary, but we keep the low one or can leave blank
        "premium": opt_low["ltp"] * (1 - weight) + opt_high["ltp"] * weight,
        "delta": g_low.get("delta", 0) * (1 - weight) + g_high.get("delta", 0) * weight,
        "gamma": g_low.get("gamma", 0) * (1 - weight) + g_high.get("gamma", 0) * weight,
        "theta": g_low.get("theta", 0) * (1 - weight) + g_high.get("theta", 0) * weight,
        "iv": g_low.get("iv", 0) * (1 - weight) + g_high.get("iv", 0) * weight,
    }

def get_interpolated_snapshot(options: List[Dict], ltp: float) -> Tuple[Dict, Dict, int, int]:
    """
    Returns interpolated CE, PE, and the two bracketing strikes.
    """
    # 1. Get all CE/PE strikes sorted
    strikes = sorted(set(
        opt['strike_price'] for opt in options 
        if opt.get('option_type') in ('CE', 'PE') and opt.get('strike_price') is not None
    ))
    
    if len(strikes) < 2:
        raise RuntimeError("Not enough strikes for interpolation.")
    
    # 2. Find bracketing strikes
    low_strike = None
    high_strike = None
    for s in strikes:
        if s <= ltp:
            low_strike = s
        if s >= ltp and high_strike is None:
            high_strike = s
    
    # Edge case: LTP exactly equals a strike
    if low_strike == high_strike:
        # If exact match, we can still interpolate with next higher strike if available,
        # but weight will be 0, so we just use low_strike data.
        idx = strikes.index(low_strike)
        if idx + 1 < len(strikes):
            high_strike = strikes[idx + 1]
        else:
            high_strike = low_strike  # fallback, but weight = 0 so it's fine
    
    if low_strike is None or high_strike is None:
        raise RuntimeError(f"Could not bracket LTP {ltp}.")
    
    # 3. Fetch CE and PE for both strikes
    ce_low = get_option_by_strike(options, low_strike, "CE")
    ce_high = get_option_by_strike(options, high_strike, "CE")
    pe_low = get_option_by_strike(options, low_strike, "PE")
    pe_high = get_option_by_strike(options, high_strike, "PE")
    
    if not all([ce_low, ce_high, pe_low, pe_high]):
        raise RuntimeError(f"Missing CE/PE for strikes {low_strike} or {high_strike}")
    
    # 4. Weight
    if high_strike == low_strike:
        weight = 0
    else:
        weight = (ltp - low_strike) / (high_strike - low_strike)
    
    # 5. Interpolate CE and PE data
    ce_interp = interpolate_option_data(ce_low, ce_high, weight)
    pe_interp = interpolate_option_data(pe_low, pe_high, weight)
    
    # 6. Compute scores from interpolated Greeks
    ce_score = compute_score_from_ltp_greeks(
        ce_interp["premium"], ce_interp["delta"], ce_interp["gamma"], ce_interp["theta"]
    )
    pe_score = compute_score_from_ltp_greeks(
        pe_interp["premium"], pe_interp["delta"], pe_interp["gamma"], pe_interp["theta"]
    )
    
    # Attach scores
    ce_interp["score"] = ce_score
    pe_interp["score"] = pe_score
    
    return ce_interp, pe_interp, low_strike, high_strike

# ----------------------------- MAIN LOOP -----------------------------

def run_logger():
    # CSV Header (EXACTLY as you requested)
    if not os.path.isfile(CSV_FILE):
        header = [
            "Timestamp", "Underlying_LTP", "ATM_Strike_Low", "ATM_Strike_High",
            "CE_Symbol", "CE_Premium", "CE_Delta", "CE_Gamma", "CE_Theta", "CE_IV", "CE_Score",
            "PE_Symbol", "PE_Premium", "PE_Delta", "PE_Gamma", "PE_Theta", "PE_IV", "PE_Score",
            "CE_PE_Ratio"
        ]
        pd.DataFrame(columns=header).to_csv(CSV_FILE, index=False)

    # Get expiry
    chain_data = fetch_option_chain()
    expiry_list = get_expiry_list(chain_data)
    if not expiry_list:
        logger.error("No expiry data found. Exiting.")
        return
    expiry_ts = get_nearest_expiry(expiry_list)
    logger.info(f"Selected expiry timestamp: {expiry_ts}")
    logger.info(f"Starting {INDEX} logger. CSV: {CSV_FILE}")

    while True:
        try:
            # Sync to 15-second wall clock
            now = time.time()
            next_time = math.ceil(now / 15.0) * 15.0
            sleep_sec = next_time - now
            if sleep_sec > 0:
                time.sleep(sleep_sec)

            snapshot_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            # Fetch option chain
            chain_data = fetch_option_chain(expiry_ts, strikecount=50)
            options = chain_data.get("optionsChain", [])
            if not options:
                raise RuntimeError("No options in chain.")

            # Get LTP
            ltp = get_underlying_ltp(chain_data)

            # Get interpolated data (SMOOTH, continuous)
            ce, pe, low_strike, high_strike = get_interpolated_snapshot(options, ltp)
            ratio = ce["score"] / pe["score"] if pe["score"] != 0 else float('inf')

            # Build row (all original columns)
            row = {
                "Timestamp": snapshot_time,
                "Underlying_LTP": ltp,
                "ATM_Strike_Low": low_strike,
                "ATM_Strike_High": high_strike,
                "CE_Symbol": ce.get("symbol", "INTERP_CE"),
                "CE_Premium": ce["premium"],
                "CE_Delta": ce["delta"],
                "CE_Gamma": ce["gamma"],
                "CE_Theta": ce["theta"],
                "CE_IV": ce["iv"],
                "CE_Score": ce["score"],
                "PE_Symbol": pe.get("symbol", "INTERP_PE"),
                "PE_Premium": pe["premium"],
                "PE_Delta": pe["delta"],
                "PE_Gamma": pe["gamma"],
                "PE_Theta": pe["theta"],
                "PE_IV": pe["iv"],
                "PE_Score": pe["score"],
                "CE_PE_Ratio": ratio,
            }

            # Append to CSV
            pd.DataFrame([row]).to_csv(CSV_FILE, mode='a', header=False, index=False)

            # Terminal output (smooth signal)
            print(f"Time {snapshot_time.split()[1]}  LTP {ltp:.2f}  Strikes [{low_strike}-{high_strike}]  "
                  f"CE Score {ce['score']:.6f}  PE Score {pe['score']:.6f}  Ratio {ratio:.3f}")

        except Exception as e:
            logger.error(f"Error: {e}", exc_info=True)
            continue

if __name__ == "__main__":
    try:
        run_logger()
    except KeyboardInterrupt:
        logger.info("Shutdown requested. Exiting gracefully.")
        sys.exit(0)