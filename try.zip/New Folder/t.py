#!/usr/bin/env python3
"""
ATM CE/PE Option Efficiency Logger – Fyers Option Chain API
Clock‑synchronised 15‑second snapshots, automatic expiry selection.
Logs underlying price and shows it in terminal.
"""

import os
import sys
import time
import math
import datetime
import logging
import pandas as pd
from typing import Dict, List
from fyers_apiv3 import fyersModel

# ----------------------------- CONFIGURATION -----------------------------
# **FILL YOUR CREDENTIALS HERE**
CLIENT_ID = "J0ENYFX9ME-200"          # e.g., "ABCDEF-1234"
SECRET_KEY = "3ei40I8iN5nMWxWL"        # e.g., "XXXXXXXXXXXX" (not actually used for API, but keep)
ACCESS_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOlsiZDoxIiwiZDoyIiwieDowIiwieDoxIiwieDoyIl0sImF0X2hhc2giOiJnQUFBQUFCcVp0b0QySmFkQXlURmpNM1hVR3A3NkFpMkZ4OXZjUnhiVG5uRlAxSFlLTklDWmNHdGc3V195WlBlREo5SkxXdDd3R2pJcU5NLUYydkZpYUpmTTV0M1V6QnlReWJIOTQ1VWtSa2F4ZXc2LWowUGxpST0iLCJkaXNwbGF5X25hbWUiOiIiLCJvbXMiOiJLMSIsImhzbV9rZXkiOiI3MGYzYjMwZTE4YzNhNDlhY2MyMzQxMjU4OTEzOWE1Yzk3MDkyMTljNWQ3NzE5ZWYxNTg5ZDM3ZiIsImlzRGRwaUVuYWJsZWQiOiJOIiwiaXNNdGZFbmFibGVkIjoiTiIsImZ5X2lkIjoiRkFBMzE0OTUiLCJhcHBUeXBlIjoyMDAsImV4cCI6MTc4NTE5ODYwMCwiaWF0IjoxNzg1MTI1Mzc5LCJpc3MiOiJhcGkuZnllcnMuaW4iLCJuYmYiOjE3ODUxMjUzNzksInN1YiI6ImFjY2Vzc190b2tlbiJ9.QEtvqyLGAY-pCo2QgBZQhXB790O_Wigc6qjPnjkWDfc"    # e.g., "eyJ0eXAiOiJKV1Qi..."


# Underlying index (NIFTY, BANKNIFTY, FINNIFTY)
INDEX = "NIFTY"

# Strike interval for ATM rounding
INDEX_CONFIG = {
    "NIFTY": {"strike_interval": 50, "symbol": "NSE:NIFTY50-INDEX"},
    "BANKNIFTY": {"strike_interval": 100, "symbol": "NSE:BANKNIFTY-INDEX"},
    "FINNIFTY": {"strike_interval": 50, "symbol": "NSE:FINNIFTY-INDEX"},
}

# CSV file name
CSV_FILE = f"option_efficiency_{INDEX}.csv"

# Logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)

# ----------------------------- FYERS CLIENT -----------------------------
fyers = fyersModel.FyersModel(
    client_id=CLIENT_ID,
    token=ACCESS_TOKEN,
    is_async=False,
    log_path="",
)

# ----------------------------- API HELPERS -----------------------------

def fetch_option_chain(expiry_timestamp: str = "", strikecount: int = 50) -> Dict:
    """Fetch option chain for the index."""
    data = {
        "symbol": INDEX_CONFIG[INDEX]["symbol"],
        "strikecount": strikecount,
        "timestamp": expiry_timestamp,
        "greeks": "1"
    }
    response = fyers.optionchain(data=data)
    if response.get("code") != 200:
        raise RuntimeError(f"Option chain API failed: {response}")
    return response.get("data", {})

def get_expiry_list(chain_data: Dict) -> List[Dict]:
    return chain_data.get("expiryData", [])

def parse_expiry_date(date_str: str) -> datetime.date:
    return datetime.datetime.strptime(date_str, "%d-%m-%Y").date()

def get_nearest_expiry(expiry_data: List[Dict]) -> str:
    today = datetime.date.today()
    valid = []
    for item in expiry_data:
        date_str = item.get("date")
        ts = item.get("expiry")
        if date_str and ts:
            dt = parse_expiry_date(date_str)
            if dt >= today:
                valid.append((dt, ts))
    if valid:
        valid.sort(key=lambda x: x[0])
        return valid[0][1]
    if expiry_data:
        return expiry_data[0]["expiry"]
    raise RuntimeError("No expiry data available.")

def get_underlying_ltp(chain_data: Dict) -> float:
    """Extract underlying LTP from the optionsChain."""
    for item in chain_data.get("optionsChain", []):
        if item.get("option_type") == "" and item.get("strike_price") == -1:
            ltp = item.get("ltp")
            if ltp is not None:
                return float(ltp)
    raise RuntimeError("Underlying LTP not found in option chain response.")

def find_atm_strike_and_options(options: List[Dict], ltp: float) -> tuple:
    """Return (atm_strike, ce_data, pe_data) for the strike closest to LTP."""
    strikes = {}
    for opt in options:
        opt_type = opt.get("option_type")
        if opt_type in ("CE", "PE"):
            strike = opt.get("strike_price")
            if strike is not None:
                strikes.setdefault(strike, {})[opt_type] = opt
    if not strikes:
        raise RuntimeError("No CE/PE options found.")
    atm_strike = min(strikes.keys(), key=lambda s: abs(s - ltp))
    ce_data = strikes[atm_strike].get("CE")
    pe_data = strikes[atm_strike].get("PE")
    if ce_data is None or pe_data is None:
        raise RuntimeError(f"CE or PE missing for ATM strike {atm_strike}")
    return atm_strike, ce_data, pe_data

def compute_score(option_data: Dict) -> float:
    """Score = (abs(Delta) * Gamma) / (Premium * abs(Theta))"""
    ltp = option_data.get("ltp")
    greeks = option_data.get("greeks", {})
    delta = greeks.get("delta")
    gamma = greeks.get("gamma")
    theta = greeks.get("theta")
    if None in (ltp, delta, gamma, theta) or ltp == 0 or abs(theta) == 0:
        return 0.0
    return (abs(delta) * gamma) / (ltp * abs(theta))

# ----------------------------- MAIN LOOP -----------------------------

def run_logger():
    # Create CSV with header if not exists
    if not os.path.isfile(CSV_FILE):
        header = [
            "Timestamp", "Underlying_LTP", "ATM_Strike",
            "CE_Symbol", "CE_Premium", "CE_Delta", "CE_Gamma", "CE_Theta", "CE_IV", "CE_Score",
            "PE_Symbol", "PE_Premium", "PE_Delta", "PE_Gamma", "PE_Theta", "PE_IV", "PE_Score",
            "CE_PE_Ratio"
        ]
        pd.DataFrame(columns=header).to_csv(CSV_FILE, index=False)

    # Get expiry list and choose nearest
    chain_data = fetch_option_chain()   # first call without expiry to get expiryData
    expiry_list = get_expiry_list(chain_data)
    if not expiry_list:
        logger.error("No expiry data found. Exiting.")
        return
    expiry_ts = get_nearest_expiry(expiry_list)
    logger.info(f"Selected expiry timestamp: {expiry_ts}")

    logger.info(f"Starting {INDEX} logger. CSV: {CSV_FILE}")

    while True:
        try:
            # Wait until next 15-second boundary
            now = time.time()
            next_time = math.ceil(now / 15.0) * 15.0
            sleep_sec = next_time - now
            if sleep_sec > 0:
                time.sleep(sleep_sec)

            snapshot_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            # Fetch option chain
            chain_data = fetch_option_chain(expiry_ts, strikecount=50)
            options = chain_data.get("optionsChain", [])
            if not options:
                raise RuntimeError("No options in chain.")

            # Get underlying LTP
            ltp = get_underlying_ltp(chain_data)

            # Find ATM strike and CE/PE data
            atm_strike, ce_data, pe_data = find_atm_strike_and_options(options, ltp)

            # Compute scores
            ce_score = compute_score(ce_data)
            pe_score = compute_score(pe_data)
            ratio = ce_score / pe_score if pe_score != 0 else float('inf')

            # Build row
            ce_greeks = ce_data.get("greeks", {})
            pe_greeks = pe_data.get("greeks", {})
            row = {
                "Timestamp": snapshot_time,
                "Underlying_LTP": ltp,
                "ATM_Strike": atm_strike,
                "CE_Symbol": ce_data.get("symbol", ""),
                "CE_Premium": ce_data.get("ltp"),
                "CE_Delta": ce_greeks.get("delta"),
                "CE_Gamma": ce_greeks.get("gamma"),
                "CE_Theta": ce_greeks.get("theta"),
                "CE_IV": ce_greeks.get("iv"),
                "CE_Score": ce_score,
                "PE_Symbol": pe_data.get("symbol", ""),
                "PE_Premium": pe_data.get("ltp"),
                "PE_Delta": pe_greeks.get("delta"),
                "PE_Gamma": pe_greeks.get("gamma"),
                "PE_Theta": pe_greeks.get("theta"),
                "PE_IV": pe_greeks.get("iv"),
                "PE_Score": pe_score,
                "CE_PE_Ratio": ratio,
            }

            # Append to CSV
            pd.DataFrame([row]).to_csv(CSV_FILE, mode='a', header=False, index=False)

            # Console output (includes underlying LTP)
            print(f"Time {snapshot_time.split()[1]}  Underlying {ltp:.2f}  ATM {atm_strike}  "
                  f"CE Score {ce_score:.6f}  PE Score {pe_score:.6f}  Ratio {ratio:.3f}")

        except Exception as e:
            logger.error(f"Error in snapshot cycle: {e}", exc_info=True)
            # continue to next cycle

if __name__ == "__main__":
    try:
        run_logger()
    except KeyboardInterrupt:
        logger.info("Shutdown requested. Exiting gracefully.")
        sys.exit(0)