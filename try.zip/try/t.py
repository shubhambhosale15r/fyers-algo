# ============================================================
# t.py – Straddle + Price Breakout Strategy
# Entry: LTP breaks 5-min range + Straddle breaks ABOVE its 5-min high within 60s
# Exit: Trailing volatility stop (2% drop from peak straddle)
# ============================================================

import time
import numpy as np
from datetime import datetime
import pytz
from fyers_apiv3 import fyersModel
from fyers_apiv3.FyersWebsocket import data_ws
import logging
import os
import json
from collections import deque
import csv
import threading
import traceback

# ============================================================
# PAPER TRADE FLAG
# ============================================================
PAPER_MODE = True   # Change to False for live trading

# ============================================================
# CONFIGURATION
# ============================================================
class Config:
    SAMPLE_INTERVAL = 1
    OPTION_CHAIN_INTERVAL = 30

    # Rolling window (5 minutes of 1-second data)
    WINDOW_BARS = 300        # 5 min history
    REQUIRED_BARS = 301      # 300 history + 1 current

    # Pending confirmation
    PENDING_WAIT_BARS = 60   # max 60 seconds to confirm

    # Exit: trailing volatility stop
    STRADDLE_TRAILING_PERCENT = 2.0   # exit when straddle drops 2% from peak

    ATM_RANGE = 2
    LOT_SIZE = 195
    MAX_DAILY_ENTRIES = 100
    API_RATE_LIMIT = 200
    API_WINDOW = 60
    MAX_RETRIES = 3
    RETRY_DELAY = 2

# ============================================================
# LOGGING
# ============================================================
logging.basicConfig(
    filename="trading_app.log",
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)

def log_debug(msg):
    logging.debug(msg)

def log_console(msg):
    print(msg, flush=True)
    logging.info(msg)

IST = pytz.timezone("Asia/Kolkata")

def now_ist():
    return datetime.now(IST)

def timestamp_ist():
    return now_ist().strftime("%Y-%m-%d %H:%M:%S")

# ============================================================
# ERROR HANDLER
# ============================================================
def handle_errors(func):
    def wrapper(*args, **kwargs):
        for retry in range(Config.MAX_RETRIES):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                log_debug(f"{func.__name__} attempt {retry+1} failed: {e}\n{traceback.format_exc()}")
                if retry < Config.MAX_RETRIES-1:
                    time.sleep(Config.RETRY_DELAY)
                else:
                    log_debug(f"{func.__name__} permanently failed")
                    return None, None, None, None, []
    return wrapper

# ============================================================
# DATA LOGGER
# ============================================================
class DataLogger:
    def __init__(self, filename="trading_data.csv"):
        self.filename = filename
        self._ensure_header()

    def _ensure_header(self):
        if not os.path.exists(self.filename):
            with open(self.filename, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'timestamp', 'ltp', 'straddle',
                    'rolling_max_ltp', 'rolling_min_ltp',
                    'rolling_max_straddle', 'rolling_min_straddle',
                    'pending_signal', 'pending_bars',
                    'frozen_ltp_high', 'frozen_ltp_low',
                    'frozen_strad_high', 'frozen_strad_low',
                    'held_symbol', 'held_entry_premium', 'held_current_premium',
                    'held_pnl', 'peak_straddle', 'exit_level',
                    'total_paper_pnl', 'daily_entries', 'bars_collected',
                    'decision_reason'
                ])

    def log_data(self, timestamp, ltp, straddle, rolling_max_ltp, rolling_min_ltp,
                 rolling_max_straddle, rolling_min_straddle, pending_signal, pending_bars,
                 frozen_ltp_high, frozen_ltp_low, frozen_strad_high, frozen_strad_low,
                 active_positions, total_pnl, daily_entries, bars_collected,
                 peak_straddle, exit_level, decision_reason):
        held_s = active_positions[0]['symbol'] if len(active_positions) > 0 else ''
        held_e = active_positions[0]['entry_premium'] if len(active_positions) > 0 else 0.0
        held_c = active_positions[0].get('current_premium', held_e) if len(active_positions) > 0 else 0.0
        if held_e is not None and held_c is not None:
            held_p = (held_c - held_e) * Config.LOT_SIZE
        else:
            held_p = 0.0

        with open(self.filename, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                str(timestamp), round(ltp, 2), round(straddle, 2),
                round(rolling_max_ltp, 2), round(rolling_min_ltp, 2),
                round(rolling_max_straddle, 2), round(rolling_min_straddle, 2),
                pending_signal, pending_bars,
                round(frozen_ltp_high, 2), round(frozen_ltp_low, 2),
                round(frozen_strad_high, 2), round(frozen_strad_low, 2),
                held_s, round(held_e, 2), round(held_c, 2), round(held_p, 2),
                round(peak_straddle, 2), round(exit_level, 2),
                round(total_pnl, 2), daily_entries, bars_collected,
                decision_reason
            ])

# ============================================================
# SESSION STATE
# ============================================================
class SessionState:
    def __init__(self):
        self.lock = threading.RLock()
        self.option_chain_api_count = 0
        self.api_window_start = now_ist()
        self.cid = ""
        self.token = ""
        self.daily_entries = 0
        self.position_state = "FLAT"
        self.eod_square_off_triggered = False
        self.warmup_start_time = None

        self.sold_time = {}
        self.symbol_histories = {}
        self.live_ltp = {}
        self.live_vwap = {}
        self.live_volume = {}

        self.option_chain = []
        self.fut_price = None
        self.expiry_date = None
        self.atm_strike = None
        self.option_symbols = []

        self.active_positions = []  # list of dicts with keys: symbol, entry_premium, entry_strike, entry_type (CE/PE)
        self.india_vix = 15.0
        self.paper_realized_pnl = 0.0

        self.decision_reason = ""
        self.running = False
        self._order_lock = False

        # ========== New strategy state ==========
        # Rolling histories (1-second bars)
        self.ltp_history = deque(maxlen=Config.REQUIRED_BARS)
        self.straddle_history = deque(maxlen=Config.REQUIRED_BARS)
        self.bars_collected = 0

        # Pending state
        self.pending_signal = 0          # 0 = none, 1 = BUY CE, -1 = BUY PE
        self.pending_bars = 0
        self.frozen_ltp_high = 0.0
        self.frozen_ltp_low = 0.0
        self.frozen_strad_high = 0.0
        self.frozen_strad_low = 0.0

        # Holding state (trailing stop)
        self.peak_straddle = 0.0
        self.exit_level = 0.0           # peak_straddle * (1 - STRADDLE_TRAILING_PERCENT/100)

        # Current snapshot values (for dashboard)
        self.current_ltp = 0.0
        self.current_straddle = 0.0
        self.rolling_max_ltp = 0.0
        self.rolling_min_ltp = 0.0
        self.rolling_max_straddle = 0.0
        self.rolling_min_straddle = 0.0

    def start_warmup(self):
        with self.lock:
            if self.warmup_start_time is None:
                self.warmup_start_time = time.time()
                log_console(f"⏳ Warmup started. Need {Config.REQUIRED_BARS} bars of data.")

    def is_warming_up(self):
        return self.bars_collected < Config.REQUIRED_BARS

    def warmup_remaining(self):
        return max(0, Config.REQUIRED_BARS - self.bars_collected)

    def update_ws(self, symbol, ltp, vwap, volume):
        with self.lock:
            if symbol == "NSE:INDIAVIX-INDEX":
                if ltp is not None:
                    self.india_vix = float(ltp)
                return

            if ltp is not None:
                self.live_ltp[symbol] = float(ltp)
            if vwap is not None:
                self.live_vwap[symbol] = float(vwap)
            if volume is not None:
                self.live_volume[symbol] = int(volume)

            # We still store histories for options and underlying (if needed later)
            if symbol.endswith(('CE','PE')) or symbol == "NSE:NIFTY50-INDEX":
                if symbol not in self.symbol_histories:
                    self.symbol_histories[symbol] = deque(maxlen=10000)
                if ltp is not None:
                    self.symbol_histories[symbol].append((time.time(), float(ltp), float(vwap) if vwap else 0.0))

    def get_ltp(self, symbol):
        with self.lock:
            return self.live_ltp.get(symbol)

    def get_vwap(self, symbol):
        with self.lock:
            return self.live_vwap.get(symbol)

    def update_chain(self, chain, fut_price, expiry_date, atm_strike, option_symbols):
        with self.lock:
            self.option_chain = chain
            self.fut_price = float(fut_price) if fut_price else 0.0
            self.expiry_date = expiry_date
            self.atm_strike = int(atm_strike) if atm_strike else None
            self.option_symbols = option_symbols

    def reset_for_new_day(self):
        with self.lock:
            if self.active_positions:
                log_console(f"⚠️ {len(self.active_positions)} position(s) still tracked, not resetting.")
                return
            self.daily_entries = 0
            self.eod_square_off_triggered = False
            self.position_state = "FLAT"
            self.paper_realized_pnl = 0.0
            self.warmup_start_time = None
            self.sold_time.clear()
            self.decision_reason = ""
            self.pending_signal = 0
            self.pending_bars = 0
            self.bars_collected = 0
            self.ltp_history.clear()
            self.straddle_history.clear()
            self.peak_straddle = 0.0
            self.exit_level = 0.0
            self.active_positions.clear()

# ============================================================
# WEBSOCKET MANAGER
# ============================================================
class MarketWSManager:
    def __init__(self, session_state, access_token):
        self.session = session_state
        self.access_token = access_token
        self.ws = None
        self.subscribed = set()
        self.running = False

    def on_message(self, message):
        symbol = message.get("symbol")
        if symbol:
            ltp = message.get("ltp")
            vwap = message.get("avg_trade_price")
            volume = message.get("vol_traded_today")
            self.session.update_ws(symbol, ltp, vwap, volume)

    def on_error(self, msg):
        log_console(f"WS error: {msg}")

    def on_close(self, msg):
        log_console(f"WS closed: {msg}")
        self.running = False

    def on_open(self):
        log_console("WebSocket connected")
        if self.subscribed:
            self.ws.subscribe(list(self.subscribed), "SymbolUpdate")
        self.ws.keep_running()

    def start(self):
        if self.running:
            return
        self.running = True
        self.ws = data_ws.FyersDataSocket(
            access_token=self.access_token,
            log_path="",
            litemode=False,
            write_to_file=False,
            reconnect=True,
            on_connect=self.on_open,
            on_close=self.on_close,
            on_error=self.on_error,
            on_message=self.on_message
        )
        self.ws.connect()

    def subscribe(self, symbols):
        new_symbols = set(symbols) - self.subscribed
        if new_symbols:
            if self.ws:
                self.ws.subscribe(list(new_symbols), "SymbolUpdate")
            self.subscribed.update(new_symbols)

    def stop(self):
        self.running = False
        if self.ws:
            self.ws.close_connection()

# ============================================================
# REST API
# ============================================================
def enforce_rate_limit(session):
    now = now_ist()
    window = (now - session.api_window_start).total_seconds()
    if window > Config.API_WINDOW:
        session.api_window_start = now
        session.option_chain_api_count = 0
    elif session.option_chain_api_count >= Config.API_RATE_LIMIT:
        wait = Config.API_WINDOW - window
        if wait > 0:
            time.sleep(wait)
        session.api_window_start = now
        session.option_chain_api_count = 0

@handle_errors
def fetch_option_chain(session, index_symbol):
    enforce_rate_limit(session)
    session.option_chain_api_count += 1
    fy = fyersModel.FyersModel(client_id=session.cid, token=session.token, is_async=False, log_path="")
    meta = fy.optionchain(data={"symbol": index_symbol, "timestamp": ""})
    if meta.get("code") != 200:
        return None, None, None, None, []

    fut_price = None
    for item in meta["data"]["optionsChain"]:
        if item.get("option_type") == "":
            fut_price = item.get("fp")
            break
    if fut_price is None:
        fut_price = meta["data"].get("fp", 0.0)

    exp_list = sorted([(e["date"], e["expiry"]) for e in meta["data"]["expiryData"]],
                      key=lambda x: datetime.strptime(x[0], "%d-%m-%Y"))
    today = now_ist().date()
    idx = 0
    for i, (d_str, _) in enumerate(exp_list):
        if datetime.strptime(d_str, "%d-%m-%Y").date() >= today:
            idx = i
            break
    curr_date, expiry_ts = exp_list[idx]

    payload = {"symbol": index_symbol, "strikecount": Config.ATM_RANGE, "timestamp": expiry_ts, "greeks": "1"}
    session.option_chain_api_count += 1
    resp = fy.optionchain(data=payload)
    if resp.get("code") != 200:
        return None, None, None, None, []

    chain = resp["data"]["optionsChain"]
    for opt in chain:
        greeks = opt.get("greeks", {})
        opt["delta"] = greeks.get("delta", 0.0) if greeks else 0.0
        opt["gamma"] = greeks.get("gamma", 0.0) if greeks else 0.0
        opt["oi"] = opt.get("oi", 0)

    option_symbols = [opt["symbol"] for opt in chain if opt.get("option_type") in ("CE","PE")]
    return chain, fut_price, curr_date, expiry_ts, option_symbols

# ============================================================
# CHAIN POLLER
# ============================================================
def chain_poller(session, ws_manager, index_symbol):
    while session.running:
        try:
            chain, fut_price, expiry_date, _, opt_symbols = fetch_option_chain(session, index_symbol)
            if chain is not None:
                underlying_ltp = session.get_ltp(index_symbol)
                if underlying_ltp is None:
                    underlying_ltp = fut_price

                strikes = sorted(set(opt["strike_price"] for opt in chain if opt.get("option_type") in ("CE","PE")))
                if strikes and underlying_ltp:
                    atm = min(strikes, key=lambda x: abs(x - underlying_ltp))
                else:
                    atm = None

                session.update_chain(chain, fut_price, expiry_date, atm, opt_symbols)
                all_syms = [index_symbol, "NSE:INDIAVIX-INDEX"] + opt_symbols
                ws_manager.subscribe(all_syms)
            time.sleep(Config.OPTION_CHAIN_INTERVAL)
        except Exception as e:
            log_debug(f"Chain poller error: {e}\n{traceback.format_exc()}")
            time.sleep(Config.OPTION_CHAIN_INTERVAL)

# ============================================================
# INTERPOLATION HELPERS
# ============================================================
def get_interpolated_straddle(session, spot):
    """
    Returns (ce_interp, pe_interp, straddle_interp)
    using linear interpolation between the two strikes bracketing `spot`.
    """
    chain = session.option_chain
    if not chain:
        return None, None, None

    ce_map = {opt["strike_price"]: opt["ltp"] for opt in chain if opt.get("option_type") == "CE" and opt.get("ltp")}
    pe_map = {opt["strike_price"]: opt["ltp"] for opt in chain if opt.get("option_type") == "PE" and opt.get("ltp")}
    if not ce_map or not pe_map:
        return None, None, None

    strikes = sorted(ce_map.keys())
    low_strike = None
    high_strike = None
    for s in strikes:
        if s <= spot:
            low_strike = s
        elif s > spot:
            high_strike = s
            break

    if low_strike is None or high_strike is None:
        return None, None, None

    w = (spot - low_strike) / (high_strike - low_strike)
    ce_interp = ce_map[low_strike] * (1 - w) + ce_map[high_strike] * w
    pe_interp = pe_map[low_strike] * (1 - w) + pe_map[high_strike] * w
    return ce_interp, pe_interp, ce_interp + pe_interp

def get_real_atm_premium(session, spot, option_type):
    """Returns the real LTP of the ATM CE or PE (closest strike)."""
    chain = session.option_chain
    if not chain:
        return None
    target = "CE" if option_type == "CE" else "PE"
    best = None
    best_dist = float('inf')
    for opt in chain:
        if opt.get("option_type") != target:
            continue
        strike = opt.get("strike_price")
        if strike is None:
            continue
        dist = abs(strike - spot)
        if dist < best_dist:
            best_dist = dist
            best = opt.get("ltp")
    return best

# ============================================================
# STATE MACHINE (Core Signal Logic)
# ============================================================
def process_snapshot(session, fyers):
    """
    Called every second. Updates history, runs pending checks, enters/exits trades.
    """
    if getattr(session, '_order_lock', False):
        return
    session._order_lock = True
    try:
        with session.lock:
            # 1. Get current underlying LTP
            spot = session.get_ltp("NSE:NIFTY50-INDEX")
            if spot is None or spot <= 0:
                session.decision_reason = "No LTP"
                session._order_lock = False
                return

            # 2. Compute interpolated straddle
            ce_interp, pe_interp, straddle = get_interpolated_straddle(session, spot)
            if straddle is None or straddle <= 0:
                session.decision_reason = "No straddle"
                session._order_lock = False
                return

            session.current_ltp = spot
            session.current_straddle = straddle

            # 3. Update rolling histories
            session.ltp_history.append(spot)
            session.straddle_history.append(straddle)
            if session.bars_collected < Config.REQUIRED_BARS:
                session.bars_collected += 1

            # Compute rolling max/min (only if we have at least 2 bars)
            if len(session.ltp_history) >= 2:
                # For breakout, we use the history excluding the current bar (i.e., previous bars)
                # But since we just appended, history[:-1] is the previous 300 bars
                prev_ltp = list(session.ltp_history)[:-1]
                prev_strad = list(session.straddle_history)[:-1]
                if prev_ltp:
                    session.rolling_max_ltp = max(prev_ltp)
                    session.rolling_min_ltp = min(prev_ltp)
                if prev_strad:
                    session.rolling_max_straddle = max(prev_strad)
                    session.rolling_min_straddle = min(prev_strad)

            # 4. Warmup check
            if session.is_warming_up():
                session.decision_reason = f"Warming up ({session.bars_collected}/{Config.REQUIRED_BARS})"
                session._order_lock = False
                return

            # EOD check
            now = now_ist()
            eod_square_off = (now.hour > 15) or (now.hour == 15 and now.minute >= 15)
            if eod_square_off:
                session.eod_square_off_triggered = True
                if session.active_positions:
                    log_console("⏰ EOD – closing held position")
                    # Force exit
                    pos = session.active_positions[0]
                    held_symbol = pos["symbol"]
                    if PAPER_MODE:
                        current_premium = session.get_ltp(held_symbol)
                        if current_premium is None:
                            for opt in session.option_chain:
                                if opt["symbol"] == held_symbol:
                                    current_premium = opt.get("ltp", 0)
                                    break
                        if current_premium is None or current_premium == 0:
                            current_premium = pos["entry_premium"]
                        pnl = (current_premium - pos["entry_premium"]) * Config.LOT_SIZE
                        session.paper_realized_pnl += pnl
                        log_console(f"📊 EOD SOLD: {held_symbol} at {current_premium:.2f}, P&L={pnl:+.2f}")
                        session.active_positions.clear()
                        session.sold_time[held_symbol] = time.time()
                        session.decision_reason = f"EOD square-off: sold {held_symbol}"
                        session.peak_straddle = 0.0
                        session.exit_level = 0.0
                        session.position_state = "FLAT"
                    else:
                        order = {
                            "symbol": held_symbol,
                            "qty": Config.LOT_SIZE,
                            "type": 2,
                            "side": -1,
                            "productType": "MARGIN",
                            "validity": "DAY",
                        }
                        resp = fyers.place_order(data=order)
                        if resp.get("s") == "ok":
                            session.active_positions.clear()
                            session.sold_time[held_symbol] = time.time()
                            session.decision_reason = f"EOD square-off: sold {held_symbol}"
                            session.peak_straddle = 0.0
                            session.exit_level = 0.0
                            session.position_state = "FLAT"
                    session._order_lock = False
                    return
                else:
                    session.decision_reason = "EOD passed"
                    session._order_lock = False
                    return

            # --- 5. State Machine ---

            # 5a. If holding a position, update trailing stop and check exit
            if session.active_positions:
                pos = session.active_positions[0]
                # Update peak straddle
                if straddle > session.peak_straddle:
                    session.peak_straddle = straddle
                    session.exit_level = session.peak_straddle * (1 - Config.STRADDLE_TRAILING_PERCENT / 100.0)
                    log_debug(f"Peak straddle updated to {session.peak_straddle:.2f}, exit level {session.exit_level:.2f}")

                # Check exit
                if straddle < session.exit_level:
                    log_console(f"📉 Straddle {straddle:.2f} < exit level {session.exit_level:.2f} – exiting {pos['symbol']}")
                    held_symbol = pos["symbol"]
                    if PAPER_MODE:
                        current_premium = session.get_ltp(held_symbol)
                        if current_premium is None:
                            for opt in session.option_chain:
                                if opt["symbol"] == held_symbol:
                                    current_premium = opt.get("ltp", 0)
                                    break
                        if current_premium is None or current_premium == 0:
                            current_premium = pos["entry_premium"]
                        pnl = (current_premium - pos["entry_premium"]) * Config.LOT_SIZE
                        session.paper_realized_pnl += pnl
                        log_console(f"📊 SOLD: {held_symbol} at {current_premium:.2f}, P&L={pnl:+.2f}")
                        session.active_positions.clear()
                        session.sold_time[held_symbol] = time.time()
                        session.decision_reason = f"Exited {held_symbol} (trailing stop)"
                        session.peak_straddle = 0.0
                        session.exit_level = 0.0
                        session.position_state = "FLAT"
                    else:
                        order = {
                            "symbol": held_symbol,
                            "qty": Config.LOT_SIZE,
                            "type": 2,
                            "side": -1,
                            "productType": "MARGIN",
                            "validity": "DAY",
                        }
                        resp = fyers.place_order(data=order)
                        if resp.get("s") == "ok":
                            session.active_positions.clear()
                            session.sold_time[held_symbol] = time.time()
                            session.decision_reason = f"Exited {held_symbol} (trailing stop)"
                            session.peak_straddle = 0.0
                            session.exit_level = 0.0
                            session.position_state = "FLAT"
                        else:
                            log_console(f"❌ FAILED to sell {held_symbol}: {resp}")
                            session.decision_reason = f"Failed to sell {held_symbol}"
                    session._order_lock = False
                    return

                # Update current premium in position (for P&L display)
                current_premium = session.get_ltp(pos["symbol"])
                if current_premium is None:
                    for opt in session.option_chain:
                        if opt["symbol"] == pos["symbol"]:
                            current_premium = opt.get("ltp", 0)
                            break
                pos["current_premium"] = current_premium if current_premium else pos["entry_premium"]

                session.decision_reason = f"Holding {pos['symbol']} (peak straddle {session.peak_straddle:.2f}, SL {session.exit_level:.2f})"
                session._order_lock = False
                return

            # 5b. If flat, handle pending state or check for new trigger
            # Reset pending if we have a pending order but price reversed or timed out
            if session.pending_signal != 0:
                session.pending_bars += 1

                # Check price reversal cancellation
                if session.pending_signal == 1:  # BUY CE (triggered on high breakout)
                    if spot < session.frozen_ltp_max:
                        log_console(f"❌ Price reversed below {session.frozen_ltp_max:.2f} – cancelling BUY")
                        session.pending_signal = 0
                        session.pending_bars = 0
                        session.decision_reason = "Cancelled BUY (price reversal)"
                        session._order_lock = False
                        return
                elif session.pending_signal == -1:  # BUY PE (triggered on low breakout)
                    if spot > session.frozen_ltp_min:
                        log_console(f"❌ Price reversed above {session.frozen_ltp_min:.2f} – cancelling SELL")
                        session.pending_signal = 0
                        session.pending_bars = 0
                        session.decision_reason = "Cancelled SELL (price reversal)"
                        session._order_lock = False
                        return

                # Check straddle confirmation – ONLY BREAKOUT (above high)
                if straddle > session.frozen_strad_max:
                    # CONFIRMED – ENTER TRADE
                    if session.pending_signal == 1:
                        entry_type = "CE"
                        log_console(f"✅ CONFIRMED: Straddle {straddle:.2f} broke ABOVE {session.frozen_strad_max:.2f} – BUY CE")
                    else:
                        entry_type = "PE"
                        log_console(f"✅ CONFIRMED: Straddle {straddle:.2f} broke ABOVE {session.frozen_strad_max:.2f} – BUY PE")

                    # Get real ATM premium for the chosen side
                    entry_premium = get_real_atm_premium(session, spot, entry_type)
                    if entry_premium is None or entry_premium <= 0:
                        log_console(f"❌ Invalid entry premium for {entry_type}")
                        session.pending_signal = 0
                        session.pending_bars = 0
                        session._order_lock = False
                        return

                    # Find the actual ATM symbol for that type
                    symbol = None
                    for opt in session.option_chain:
                        if opt.get("option_type") == entry_type:
                            strike = opt.get("strike_price")
                            if strike is not None and abs(strike - spot) == min(abs(s - spot) for s in [o["strike_price"] for o in session.option_chain if o.get("option_type") == entry_type]):
                                symbol = opt["symbol"]
                                break
                    if symbol is None:
                        log_console("❌ Could not find ATM symbol")
                        session.pending_signal = 0
                        session.pending_bars = 0
                        session._order_lock = False
                        return

                    if PAPER_MODE:
                        session.active_positions.append({
                            "symbol": symbol,
                            "entry_premium": entry_premium,
                            "entry_strike": int(round(spot / 50) * 50) if entry_type == "CE" else int(round(spot / 50) * 50),
                            "entry_type": entry_type,
                            "current_premium": entry_premium,
                        })
                        session.peak_straddle = straddle
                        session.exit_level = straddle * (1 - Config.STRADDLE_TRAILING_PERCENT / 100.0)
                        session.daily_entries += 1
                        session.position_state = "ACTIVE"
                        log_console(f"🟢 BOUGHT: {symbol} at {entry_premium:.2f} (straddle {straddle:.2f}, SL {session.exit_level:.2f})")
                    else:
                        order = {
                            "symbol": symbol,
                            "qty": Config.LOT_SIZE,
                            "type": 2,
                            "side": 1,
                            "productType": "MARGIN",
                            "validity": "DAY",
                        }
                        resp = fyers.place_order(data=order)
                        if resp.get("s") == "ok":
                            session.active_positions.append({
                                "symbol": symbol,
                                "entry_premium": entry_premium,
                                "entry_strike": int(round(spot / 50) * 50),
                                "entry_type": entry_type,
                                "current_premium": entry_premium,
                            })
                            session.peak_straddle = straddle
                            session.exit_level = straddle * (1 - Config.STRADDLE_TRAILING_PERCENT / 100.0)
                            session.daily_entries += 1
                            session.position_state = "ACTIVE"
                            log_console(f"🟢 BOUGHT: {symbol} at {entry_premium:.2f} (Order ID: {resp.get('id')})")
                        else:
                            log_console(f"❌ FAILED to buy {symbol}: {resp}")

                    session.pending_signal = 0
                    session.pending_bars = 0
                    session.decision_reason = f"Entered {symbol}"
                    session._order_lock = False
                    return

                # Check timeout
                if session.pending_bars >= Config.PENDING_WAIT_BARS:
                    log_console(f"⏰ Pending order timed out after {Config.PENDING_WAIT_BARS}s")
                    session.pending_signal = 0
                    session.pending_bars = 0
                    session.decision_reason = "Pending order timed out"
                    session._order_lock = False
                    return

                # Still pending
                dir_str = "BUY CE" if session.pending_signal == 1 else "BUY PE"
                session.decision_reason = f"⏳ PENDING {dir_str} ({session.pending_bars}/{Config.PENDING_WAIT_BARS})"
                session._order_lock = False
                return

            # 5c. IDLE – check for LTP breakout
            if spot > session.rolling_max_ltp:
                # Trigger BUY CE
                session.pending_signal = 1
                session.pending_bars = 0
                session.frozen_ltp_max = session.rolling_max_ltp
                session.frozen_ltp_min = session.rolling_min_ltp
                session.frozen_strad_max = session.rolling_max_straddle
                session.frozen_strad_min = session.rolling_min_straddle
                log_console(f"🔔 TRIGGER BUY CE: LTP {spot:.2f} > {session.rolling_max_ltp:.2f}")
                session.decision_reason = "Triggered BUY CE (waiting confirmation)"
                session._order_lock = False
                return

            elif spot < session.rolling_min_ltp:
                # Trigger BUY PE
                session.pending_signal = -1
                session.pending_bars = 0
                session.frozen_ltp_max = session.rolling_max_ltp
                session.frozen_ltp_min = session.rolling_min_ltp
                session.frozen_strad_max = session.rolling_max_straddle
                session.frozen_strad_min = session.rolling_min_straddle
                log_console(f"🔔 TRIGGER BUY PE: LTP {spot:.2f} < {session.rolling_min_ltp:.2f}")
                session.decision_reason = "Triggered BUY PE (waiting confirmation)"
                session._order_lock = False
                return

            session.decision_reason = "IDLE (no trigger)"
            session._order_lock = False
            return

    except Exception as e:
        log_console(f"process_snapshot error: {e}")
        session.decision_reason = f"Error: {str(e)}"
    finally:
        session._order_lock = False

# ============================================================
# SAMPLER THREAD
# ============================================================
def sampler(session, data_logger, auto_trade, fyers):
    log_debug("Sampler thread started")
    first_run = True
    while session.running:
        start = now_ist()
        try:
            if first_run:
                session.start_warmup()
                first_run = False

            # Process the current snapshot (runs state machine)
            if auto_trade:
                process_snapshot(session, fyers)

            # Compute total P&L for logging
            total_pnl = session.paper_realized_pnl
            for pos in session.active_positions:
                current = pos.get("current_premium", pos["entry_premium"])
                total_pnl += (current - pos["entry_premium"]) * Config.LOT_SIZE

            bars_collected = session.bars_collected
            pending_signal = session.pending_signal
            pending_bars = session.pending_bars
            frozen_ltp_high = session.frozen_ltp_max if hasattr(session, 'frozen_ltp_max') else 0.0
            frozen_ltp_low = session.frozen_ltp_min if hasattr(session, 'frozen_ltp_min') else 0.0
            frozen_strad_high = session.frozen_strad_max if hasattr(session, 'frozen_strad_max') else 0.0
            frozen_strad_low = session.frozen_strad_min if hasattr(session, 'frozen_strad_min') else 0.0
            peak_straddle = session.peak_straddle
            exit_level = session.exit_level

            # Update current premium for active positions
            with session.lock:
                for pos in session.active_positions:
                    current_premium = session.get_ltp(pos["symbol"])
                    if current_premium is None:
                        for opt in session.option_chain:
                            if opt["symbol"] == pos["symbol"]:
                                current_premium = opt.get("ltp", 0)
                                break
                    pos["current_premium"] = current_premium if current_premium else pos["entry_premium"]

            data_logger.log_data(
                timestamp=timestamp_ist(),
                ltp=session.current_ltp,
                straddle=session.current_straddle,
                rolling_max_ltp=session.rolling_max_ltp,
                rolling_min_ltp=session.rolling_min_ltp,
                rolling_max_straddle=session.rolling_max_straddle,
                rolling_min_straddle=session.rolling_min_straddle,
                pending_signal=pending_signal,
                pending_bars=pending_bars,
                frozen_ltp_high=frozen_ltp_high,
                frozen_ltp_low=frozen_ltp_low,
                frozen_strad_high=frozen_strad_high,
                frozen_strad_low=frozen_strad_low,
                active_positions=session.active_positions,
                total_pnl=total_pnl,
                daily_entries=session.daily_entries,
                bars_collected=bars_collected,
                peak_straddle=peak_straddle,
                exit_level=exit_level,
                decision_reason=session.decision_reason
            )

            elapsed = (now_ist() - start).total_seconds()
            if elapsed < Config.SAMPLE_INTERVAL:
                time.sleep(Config.SAMPLE_INTERVAL - elapsed)

        except Exception as e:
            log_debug(f"Sampler error: {e}\n{traceback.format_exc()}")
            time.sleep(1)

# ============================================================
# DASHBOARD
# ============================================================
class TerminalDashboard:
    def __init__(self, data_logger, session_state):
        self.data_logger = data_logger
        self.session_state = session_state

    def display(self):
        try:
            os.system('cls' if os.name == 'nt' else 'clear')
            mode = "PAPER" if PAPER_MODE else "LIVE"
            print("\n" + "="*130)
            print(f"📊 {mode} TRADING DASHBOARD – Straddle + Price Breakout")
            print("="*130)

            with self.session_state.lock:
                daily_entries = self.session_state.daily_entries
                vix = self.session_state.india_vix
                realized = self.session_state.paper_realized_pnl
                position_state = self.session_state.position_state
                decision_reason = self.session_state.decision_reason
                bars_collected = self.session_state.bars_collected
                warmup = self.session_state.is_warming_up()
                warmup_rem = self.session_state.warmup_remaining()

                ltp = self.session_state.current_ltp
                straddle = self.session_state.current_straddle
                rolling_max_ltp = self.session_state.rolling_max_ltp
                rolling_min_ltp = self.session_state.rolling_min_ltp
                rolling_max_straddle = self.session_state.rolling_max_straddle
                rolling_min_straddle = self.session_state.rolling_min_straddle

                pending_signal = self.session_state.pending_signal
                pending_bars = self.session_state.pending_bars
                frozen_ltp_high = self.session_state.frozen_ltp_max if hasattr(self.session_state, 'frozen_ltp_max') else 0.0
                frozen_ltp_low = self.session_state.frozen_ltp_min if hasattr(self.session_state, 'frozen_ltp_min') else 0.0
                frozen_strad_high = self.session_state.frozen_strad_max if hasattr(self.session_state, 'frozen_strad_max') else 0.0
                frozen_strad_low = self.session_state.frozen_strad_min if hasattr(self.session_state, 'frozen_strad_min') else 0.0

                active_positions = self.session_state.active_positions[:]
                peak_straddle = self.session_state.peak_straddle
                exit_level = self.session_state.exit_level

            # Build status line
            if warmup:
                status = f"🔥 WARMUP [{bars_collected}/{Config.REQUIRED_BARS}]"
            else:
                status = f"✅ ACTIVE [{bars_collected}/{Config.REQUIRED_BARS}]"

            # Pending status
            pending_str = ""
            if pending_signal == 1:
                pending_str = f"⏳ PENDING BUY CE ({pending_bars}/{Config.PENDING_WAIT_BARS})"
            elif pending_signal == -1:
                pending_str = f"⏳ PENDING BUY PE ({pending_bars}/{Config.PENDING_WAIT_BARS})"
            else:
                pending_str = "🔍 IDLE"

            # Position
            pos_str = "NEUTRAL"
            if active_positions:
                pos = active_positions[0]
                pos_str = f"{pos['entry_type']} @ {pos['entry_premium']:.2f}"

            print(f"Last Update: {timestamp_ist()}")
            print(f"📈 Daily Entries: {daily_entries}/{Config.MAX_DAILY_ENTRIES}")
            print(f"📊 India VIX: {vix:.2f}")
            print(f"💰 Realized P&L: {realized:+.2f}")

            if warmup:
                print(f"⏳ WARMING UP... {warmup_rem} bars remaining")
            else:
                print("✅ WARMUP COMPLETE – Trading active")

            print("\n" + "-"*80)
            print("📊 SNAPSHOT DATA")
            print("-"*80)
            print(f"  LTP: {ltp:.2f} | Straddle: {straddle:.2f}")
            print(f"  Rolling 5-min LTP:  Max {rolling_max_ltp:.2f}  |  Min {rolling_min_ltp:.2f}")
            print(f"  Rolling 5-min Straddle:  Max {rolling_max_straddle:.2f}  |  Min {rolling_min_straddle:.2f}")

            if pending_signal != 0:
                print("\n" + "-"*80)
                print("🔒 FROZEN LEVELS (Pending Order)")
                print("-"*80)
                print(f"  LTP:  High {frozen_ltp_high:.2f}  |  Low {frozen_ltp_low:.2f}")
                print(f"  Straddle:  High {frozen_strad_high:.2f}  |  Low {frozen_strad_low:.2f}")

            print("\n" + "-"*80)
            print("📌 POSITION & EXIT")
            print("-"*80)
            if active_positions:
                pos = active_positions[0]
                current = pos.get("current_premium", pos["entry_premium"])
                pnl = (current - pos["entry_premium"]) * Config.LOT_SIZE
                print(f"  Symbol: {pos['symbol']}")
                print(f"  Entry Premium: {pos['entry_premium']:.2f} | Current: {current:.2f} | P&L: {pnl:+.2f}")
                print(f"  Peak Straddle Since Entry: {peak_straddle:.2f}")
                print(f"  Exit Level (2% below peak): {exit_level:.2f}")
            else:
                print("  No active position (FLAT)")

            print("\n" + "-"*80)
            print("🧠 STATUS")
            print("-"*80)
            print(f"  {status}")
            print(f"  {pending_str}")
            print(f"  Position: {pos_str}")
            print(f"  Decision: {decision_reason}")

            print("\n" + "="*130)
        except Exception as e:
            log_debug(f"Dashboard error: {e}")

# ============================================================
# CREDENTIALS & MAIN
# ============================================================
def load_credentials(session):
    try:
        with open('fyers_credentials.json', 'r') as f:
            creds = json.load(f)
            session.cid = creds.get('client_id', '')
            session.token = creds.get('access_token', '')
        log_console(f"Loaded credentials: {session.cid}")
    except Exception as e:
        log_console(f"Failed to load credentials file: {e} – falling back to env vars")
        session.cid = os.getenv("FYERS_CID", "")
        session.token = os.getenv("FYERS_TOKEN", "")
        log_console(f"Using env vars: {session.cid}")

def main():
    log_console("Starting Straddle + Price Breakout Strategy...")
    session = SessionState()
    load_credentials(session)
    data_logger = DataLogger()
    dashboard = TerminalDashboard(data_logger, session)
    index_symbol = "NSE:NIFTY50-INDEX"
    vix_symbol = "NSE:INDIAVIX-INDEX"

    poller_thread = None
    sampler_thread = None
    ws_manager = None
    fyers = None

    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        print("="*50)
        mode = "PAPER" if PAPER_MODE else "LIVE"
        print(f"📈 FYERS ALGO TRADING ({mode} MODE) – Straddle + Price Breakout")
        print("1. Start Trading")
        print("2. Settings")
        print("3. Exit")
        choice = input("Select option: ").strip()
        if choice == "1":
            if not (session.cid and session.token):
                print("❌ Set credentials first")
                input("Press Enter...")
                continue

            session.reset_for_new_day()

            auto_trade = input("Enable Auto Trade? (y/n): ").lower() == 'y'
            log_console(f"Auto trade: {'ON' if auto_trade else 'OFF'}")

            ws_manager = MarketWSManager(session, session.token)
            ws_manager.start()
            ws_manager.subscribe([index_symbol, vix_symbol])
            session.running = True

            fyers = fyersModel.FyersModel(client_id=session.cid, token=session.token, is_async=False, log_path="")
            poller_thread = threading.Thread(target=chain_poller, args=(session, ws_manager, index_symbol), daemon=True)
            sampler_thread = threading.Thread(target=sampler, args=(session, data_logger, auto_trade, fyers), daemon=True)
            poller_thread.start()
            sampler_thread.start()

            print("\n✅ Trading started. Press Ctrl+C to stop.\n")
            try:
                while True:
                    dashboard.display()
                    time.sleep(1)
            except KeyboardInterrupt:
                log_console("\n🛑 Stopping trading...")
                session.running = False
                ws_manager.stop()

                if sampler_thread is not None:
                    sampler_thread.join(timeout=5)
                if poller_thread is not None:
                    poller_thread.join(timeout=Config.OPTION_CHAIN_INTERVAL + 5)

                if session.active_positions:
                    log_console(f"Attempting to close {len(session.active_positions)} open position(s)...")
                    process_snapshot(session, fyers)  # triggers EOD exit if needed

                with session.lock:
                    if session.active_positions:
                        log_console(f"⚠️ {len(session.active_positions)} position(s) could not be closed. Check broker manually.")
                    else:
                        session.eod_square_off_triggered = False
                        session.daily_entries = 0
                        session.paper_realized_pnl = 0.0
                        session.warmup_start_time = None
                        session.sold_time.clear()
                        log_console("✅ Trading stopped and state reset. You can start again.")
        elif choice == "2":
            print("\n⚙️ SETTINGS")
            new_cid = input(f"Client ID [{session.cid}]: ").strip()
            if new_cid:
                session.cid = new_cid
            new_token = input("Access token: ").strip()
            if new_token:
                session.token = new_token
            with open('fyers_credentials.json', 'w') as f:
                json.dump({"client_id": session.cid, "access_token": session.token}, f)
            print("✅ Saved")
            input("Press Enter...")
        elif choice == "3":
            if session.running:
                session.running = False
                if ws_manager:
                    ws_manager.stop()
            if session.active_positions:
                log_console(f"⚠️ Exiting with {len(session.active_positions)} position(s) still tracked.")
            break

if __name__ == "__main__":
    main()